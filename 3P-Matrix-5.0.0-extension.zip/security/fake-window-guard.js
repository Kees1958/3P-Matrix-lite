/*
 * fake-window-guard.js — blockFakeSignInWindow (3P Matrix 4.7.0, protection 28), ISOLATED-world only.
 * "Warn about a fake sign-in window drawn on a page" — Browser-in-the-Browser: a page draws a fake OS/browser
 * chrome (title bar, address bar showing "accounts.google.com") around an ordinary login form. There is no real
 * second window and no real address bar — the drawn text can say anything.
 *
 * Own file (not shared with security/password-form-guard.js, protection 15): two protections sharing one content
 * script would make core/script-builder.js merge their registrations whenever both are active, which is fine for
 * injection but defeats tools/test-perf-guards.mjs's per-file scope invariant — kept separate on purpose, at the
 * cost of a small, independent copy of the dialog, same pattern as this file's own LOG_PREFIX/MSG_* copies.
 *
 * Check (cheap, runs only at the moment a password field is focused, no MutationObserver watching the page):
 *   1. From the focused field, walk up to MAX_ANCESTOR_WALK ancestors for the nearest one the PAGE styled
 *      position:fixed/absolute (a drawn "window"; <html>/<body> never count).
 *   2. Read that one ancestor's own text (not the whole page) for a URL-shaped token (SHOWN_URL_RE) — the drawn
 *      "address bar".
 *   3. Send ONLY that token to the service worker (core/password-form.js fakeWindowDecision) — it matches it
 *      against known sign-in providers and decides there, so no provider list is duplicated in a classic script.
 *      Nothing is sent when no drawn window or no URL-shaped text is found (the overwhelmingly common case).
 * Accepted false positive: a real page with a styled box around its OWN login form that also shows another
 * provider's name/logo nearby. Accepted false negative: a shown name/brand instead of a URL-shaped address.
 *
 * "Continue" only closes the dialog — nothing was held (the shown window is fake, not a real login the user is
 * sending); "Go back" leaves the site (core/leave-site.js, no history kept), same as the password-form warning.
 * Cost: nothing until a password field is focused; then one bounded DOM walk, and only on a hit, one message
 * round-trip. Fail-silent guard: an unreachable service worker means no dialog, never a broken page.
 * World: ISOLATED, all frames, document_start. Classic script (content scripts cannot import).
 */
'use strict';
(function(){
    'use strict';
    // ── Settings (one place) ── copies of shared values (this script cannot import); kept equal to their sources
    // by tools/check-shipped-terms.mjs: LOG_PREFIX (data/constants.js), MSG_* (data/message-types.js).
    const LOG_PREFIX = '[3PMCF]';
    const MSG_CHECK_FAKE_WINDOW = 'CHECK_FAKE_WINDOW';
    const MSG_PASSWORD_FORM_LEAVE = 'PASSWORD_FORM_LEAVE';
    const TEXT = Object.freeze({
        title: 'This looks like a fake sign-in window drawn on the page',
        intro: 'The box around this password field draws its own title bar and address, not a real browser window. It shows an address for:',
        back: 'Go back',
        cont: 'I know, continue',
        brand: '3P Matrix — content firewall'
    });
    const DIALOG_CSS = [
        ':host{all:initial}',
        '.bg{position:fixed;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:2147483647}',
        '.dlg{max-width:440px;margin:16px;background:#181C26;color:#FFFFFF;border:2px solid #F87171;border-radius:8px;padding:20px;font:14px/1.45 system-ui,sans-serif}',
        '.brand{font:12px ui-monospace,monospace;color:#C0C7D4;margin-bottom:8px}',
        'h1{font-size:18px;margin:0 0 8px;color:#F87171}',
        '.host{font:14px ui-monospace,monospace;background:#0F1117;padding:6px 8px;border-radius:4px;margin:10px 0 16px;word-break:break-all}',
        '.act{display:flex;gap:10px;flex-wrap:wrap}',
        'button{flex:1;min-width:140px;height:40px;border:0;border-radius:6px;font:600 14px system-ui,sans-serif;cursor:pointer;color:#0F1117}',
        '.back{background:#4ADE80}.cont{background:#FF8A1F}',
        'button:focus-visible{outline:3px solid #FFFFFF;outline-offset:2px}'
    ].join('');

    const MAX_ANCESTOR_WALK = 8;                        // bounds the walk from the field to <html>
    const MAX_WINDOW_TEXT_CHARS = 400;                  // the drawn chrome's own text is short (title bar + address)
    const SHOWN_URL_RE = /\b(?:https?:\/\/)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}\b/i;
    const DRAWN_POSITIONS = Object.freeze(['fixed', 'absolute']);
    const checkedBoxes = new WeakSet();                 // guard: ask about the same drawn box only once per page
    let openDialog = null;                               // guard: one dialog at a time

    function drawnWindowAncestorOf(field) {
        let el = field.parentElement;
        for (let i = 0; i < MAX_ANCESTOR_WALK && el; i++, el = el.parentElement) {
            if (el === document.documentElement || el === document.body) break;
            let position = '';
            try { position = window.getComputedStyle(el).position; } catch { continue; }
            if (DRAWN_POSITIONS.includes(position)) return el;
        }
        return null;
    }

    function shownUrlTextOf(box) {
        let text = '';
        try { text = String(box.textContent || ''); } catch { return ''; }
        if (text.length > MAX_WINDOW_TEXT_CHARS) text = text.slice(0, MAX_WINDOW_TEXT_CHARS);
        const m = SHOWN_URL_RE.exec(text);
        return m ? m[0] : '';
    }

    function closeDialog() {
        if (!openDialog) return;
        openDialog.host.remove();
        document.removeEventListener('keydown', openDialog.onKey, true);
        openDialog = null;
    }

    function showDialog(shownHost) {
        closeDialog();
        const host = document.createElement('div');
        const root = host.attachShadow({ mode: 'closed' });
        const style = document.createElement('style');
        style.textContent = DIALOG_CSS;
        const bg = document.createElement('div'); bg.className = 'bg';
        const dlg = document.createElement('section'); dlg.className = 'dlg';
        dlg.setAttribute('role', 'alertdialog');
        const brand = document.createElement('div'); brand.className = 'brand'; brand.textContent = TEXT.brand;
        const h1 = document.createElement('h1'); h1.textContent = TEXT.title;
        const intro = document.createElement('p'); intro.textContent = TEXT.intro;
        const where = document.createElement('div'); where.className = 'host'; where.textContent = shownHost;
        const act = document.createElement('div'); act.className = 'act';
        const back = document.createElement('button'); back.className = 'back'; back.type = 'button'; back.textContent = TEXT.back;
        const cont = document.createElement('button'); cont.className = 'cont'; cont.type = 'button'; cont.textContent = TEXT.cont;
        act.append(back, cont);
        dlg.append(brand, h1, intro, where, act);
        bg.append(dlg);
        root.append(style, bg);
        back.addEventListener('click', (e) => {
            if (!e.isTrusted) return;
            closeDialog();
            chrome.runtime.sendMessage({ type: MSG_PASSWORD_FORM_LEAVE })
                .catch((err) => console.warn(LOG_PREFIX, 'fake-window: go back failed', err));
        });
        cont.addEventListener('click', (e) => { if (!e.isTrusted) return; closeDialog(); });   // nothing was held
        function onKey(e) { if (e.key === 'Escape' && e.isTrusted) { e.stopPropagation(); closeDialog(); } }
        document.addEventListener('keydown', onKey, true);
        (document.documentElement || document).append(host);
        openDialog = { host, onKey };
        back.focus();
    }

    async function checkFakeWindow(field) {
        const box = drawnWindowAncestorOf(field);
        if (!box || checkedBoxes.has(box)) return;
        const shownText = shownUrlTextOf(box);
        if (!shownText) return;
        checkedBoxes.add(box);
        let res = null;
        try { res = await chrome.runtime.sendMessage({ type: MSG_CHECK_FAKE_WINDOW, shownText }); }
        catch (err) { console.warn(LOG_PREFIX, 'fake-window check unavailable', err); return; }   // fail silent
        const decision = res && res.ok ? res.data : null;
        if (decision && decision.warn) showDialog(decision.shownHost);
    }

    document.addEventListener('focusin', (e) => {
        const field = e.target;
        if (field instanceof HTMLInputElement && field.type === 'password') checkFakeWindow(field).catch(() => {});
    }, true);
})();
