// ── ui/popup.js — popup page controller ────────────────────────────────────────
// Renders the toolbar popup: level tabs, per-level policy/rule bullets, the
// TLD blacklist/whitelist panels (L2/L3), and the per-site pin lock control.
// This is a page entry script, not an importable module — nothing else in
// the extension imports from it — so it has no exported "public interface"
// in the sense the core/data module headers use; its top-level functions
// below are internal to this page only.
//
// Key top-level functions:
//   render()             — full re-render of the popup from current state
//   updateTabs()          — rebuilds the level tab strip for the active level
//   renderPinnedList()    — see comment at its declaration (no visible panel)
//   pushState()           — sends the in-memory state to the SW (MSG_SET_STATE)
//   handleLockClick()     — pins/unpins the current site to a level
//   renderPage()           — paginates a TLD list (blacklist/whitelist panels)
//
// Communicates with the SW via chrome.runtime.sendMessage using MSG_*
// constants from data/message-types.js. Also opens ui/matrix-panel.html
// directly (chrome.windows.create) for the Show Matrix feature.
// ─────────────────────────────────────────────────────────────────────────────
import {
  MSG_GET_STATE, MSG_SET_STATE, MSG_ADD_SITE_RULE, MSG_REMOVE_SITE_RULE, MSG_SET_ICON,
  MSG_START_MATRIX
} from "../data/message-types.js";
import { SESSION_KEY_LEVEL, SESSION_KEY_PREV_LEVEL, SITE_RULES_CAP, freshState } from "../data/state-storage.js";
import { BASE_TLDS, rebuildTldList, rebuildBlockedTldList } from "../core/tld-engine.js";
import { getApexDomain } from "../util/tld-utils.js";

// ── Level definitions ──────────────────────────────────────────────────────────
// `rules` holds ONLY each level's block bullets now (always shown last, per
// the fixed bullet order below). The two universal green "allow" bullets and
// each level's single mode-specific colored bullet are NOT declared per-level
// here anymore — they're centralised in ALWAYS_ALLOW_TEXTS / LEVEL_MODE_BULLET
// just below, since they follow one fixed rule each (see those comments),
// rather than being duplicated/injected ad-hoc per level as before.
const LEVELS = [
  { name: "Easy mode \u2014 allow all", color: "#16A34A", showDomain: true, showTld: false,
    rules: [] }, // L1 renders its own single "allow all" line — see render()
  { name: "Easy mode with enhanced security", color: "#93C5FD", showDomain: false, showTld: false,
    rules: [
      { type: "block", text: "Third-party frames are blocked" }
    ]},
  { name: "Easy medium mode", color: "#FACC15", showDomain: false, showTld: true,
    rules: [
      { type: "block", text: "Third-party frames not in TLD whitelist are blocked" },
      { type: "block", text: "Third-party scripts not in TLD whitelist are blocked" }
    ]},
  { name: "Medium mode \u2014 trust CDN\u2019s", color: "#FB923C", showDomain: true, showTld: false,
    rules: [
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]},
  { name: "Medium mode", color: "#C0392B", showDomain: true, showTld: false,
    rules: [
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]}
];

// ── Active Policy bullet order (fixed, every level 2-5) ─────────────────────
//   1. The two universal ALLOW bullets (ALWAYS_ALLOW_TEXTS) — always green,
//      always first, always in this order, whenever a level has any rules
//      at all (i.e. every level except L1, which has nothing to whitelist).
//   2. The level's own mode-specific bullet (LEVEL_MODE_BULLET), if it has
//      one — colored with that level's OWN brand color (LEVELS[].color
//      above), reused rather than re-declared, so there is exactly one
//      place (LEVELS) that ever names a level's color.
//   3. That level's BLOCK bullets (LEVELS[].rules above), always red, always last.
// L1 is the sole exception — it renders its own single hyphen-bulleted line.
const ALWAYS_ALLOW_TEXTS = [
  "3P-scripts & frames are allowed on whitelisted domains",
  "Built-in whitelist allows payment services, video embeds, CAPTCHA\u2019s and important JS-libraries"
];

// Returns { color, text } for the level's own mode-specific bullet, or null
// if this level has none (L1 has nothing to report here; L5 is pure
// whitelist-only with no extra mechanism beyond the block bullets already
// covered by LEVELS[].rules). `color` is always LEVELS[level-1].color — the
// level's own brand color — never a separately-declared hex value.
function getLevelModeBullet(val, state) {
  if (val === 2) {
    const blockedCount = (state.blockedTldMode > 0 && state.blockedTlds) ? state.blockedTlds.length : 0;
    return { color: LEVELS[1].color, text: "Blocks 3P-scripts from " + blockedCount + " risky TLD\u2019s" };
  }
  if (val === 3) {
    const tldCount = state.tlds ? state.tlds.length : 0;
    return { color: LEVELS[2].color, text: "Allows 3P-scripts & frames from " + tldCount + " whitelisted TLD\u2019s" };
  }
  if (val === 4) {
    return { color: LEVELS[3].color, text: "3P-scripts for URL\u2019s with CDN in name are allowed" };
  }
  return null; // L1, L5 — no level-specific mode bullet
}

// LEVEL_COLORS removed — use LEVELS[n - 1].color directly (single source of truth).

// GENERIC_BLOCKED_TLDS and WORLD_BLOCKED_TLDS are used internally by
// core/tld-engine.js's rebuildBlockedTldList() — not needed directly here.
const BLOCKED_TLD_LABELS = ["NONE","USER","GENERIC","WORLD"];
const BLOCKED_TLD_HINTS  = [
  "No TLD script blocking active",
  "Block 3P scripts from your own list of risky TLDs",
  "Block 3P scripts from known low-quality / high-abuse TLDs",
  "Generic list plus high-risk country TLDs"
];

let state       = freshState();
let tldPage     = 0;
const TLD_PAGE_SIZE = 500;
let currentHost    = "";  // exact hostname of the active tab
let lockDomain     = "";  // registrable (apex) domain used for locking — covers subdomains
let sessionLevel     = 0;  // current global level this session (0 = not yet initialised)
let prevSessionLevel = 0;  // level before last slider move — restored when lock is set

// getApexDomain() now imported from util/tld-utils.js (single source of truth).

// ── SVG icons ─────────────────────────────────────────────────────────────────
const SVG_LOCKED = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
  + '<path fill-rule="evenodd" clip-rule="evenodd" d="M4 6V4C4 1.79086 5.79086 0 8 0C10.2091 0 12 1.79086 12 4V6H14V16H2V6H4ZM6 4C6 2.89543 6.89543 2 8 2C9.10457 2 10 2.89543 10 4V6H6V4ZM7 13V9H9V13H7Z" fill="rgba(0,0,0,0.6)"/>'
  + '</svg>';

const SVG_UNLOCKED = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
  + '<path fill-rule="evenodd" clip-rule="evenodd" d="M11.5 2C10.6716 2 10 2.67157 10 3.5V6H13V16H1V6H8V3.5C8 1.567 9.567 0 11.5 0C13.433 0 15 1.567 15 3.5V4H13V3.5C13 2.67157 12.3284 2 11.5 2ZM9 10H5V12H9V10Z" fill="#ffffff"/>'
  + '</svg>';

// ── Auto TLD ──────────────────────────────────────────────────────────────────
const AUTO_TLD_LABELS = ["NONE", "BROWSER", "CONTINENT", "WORLDWIDE"];
const AUTO_TLD_HINTS  = [
  "No country codes added automatically",
  "Add country codes from your browser\u2019s language settings",
  "Same continent: adds countries sharing your browser language",
  "Worldwide: adds all countries sharing your browser language"
];
// LANG_TLD_MAP, BASE_TLDS, computeAutoTlds(), rebuildTldList(), rebuildBlockedTldList()
// are loaded from core/tld-engine.js

function renderBlockedTags() {
  renderPage('blocked-tld-tags', state.blockedTlds, 0);
}

// ── Lock button ───────────────────────────────────────────────────────────────
// ── Whitelist dropdowns ───────────────────────────────────────────────────────
// Applies the current dropdown open/closed state for both TLD (L3) and domain (L4)
// panels. Called on boot and whenever the user toggles a dropdown.
function applyDropdownState() {
  const tldOpen       = state.whitelistDropdown && state.whitelistDropdown.tld    !== false;
  const blockedTldOpen = state.blockedTldDropdownOpen === true; // starts collapsed (false)

  const tldBtn     = document.getElementById('tldDropdownBtn');
  const tldContent = document.getElementById('tldDropdownContent');
  const blkBtn     = document.getElementById('blockedTldDropdownBtn');
  const blkContent = document.getElementById('blockedTldDropdownContent');

  if (tldBtn && tldContent) {
    tldBtn.classList.toggle('open', tldOpen);
    tldContent.classList.toggle('collapsed', !tldOpen);
  }
  if (blkBtn && blkContent) {
    blkBtn.classList.toggle('open', blockedTldOpen);
    blkContent.classList.toggle('collapsed', !blockedTldOpen);
  }
}

function initDropdownToggle(btnId, contentId, stateKey) {
  const btn     = document.getElementById(btnId);
  const content = document.getElementById(contentId);
  if (!btn || !content) return;
  btn.addEventListener('click', function() {
    const nowOpen = content.classList.contains('collapsed');
    content.classList.toggle('collapsed', !nowOpen);
    btn.classList.toggle('open', nowOpen);
    if (stateKey === 'blockedTld') {
      // blockedTld dropdown state stored separately from whitelistDropdown
      state.blockedTldDropdownOpen = nowOpen;
    } else {
      if (!state.whitelistDropdown) state.whitelistDropdown = { tld: true, domain: true };
      state.whitelistDropdown[stateKey] = nowOpen;
    }
    pushState();
  });
}

function renderLockBtn() {
  const btn     = document.getElementById('lockBtn');
  const tooltip = document.getElementById('lockTooltip');
  if (!btn) return;

  const isPinned = lockDomain && state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain);

  if (isPinned) {
    const pinnedLevel = state.siteRules[lockDomain];
    const color       = LEVELS[pinnedLevel - 1].color;
    btn.innerHTML   = SVG_LOCKED;
    btn.style.background    = color;
    btn.classList.add('is-locked');
    tooltip.textContent = 'Locked to L' + pinnedLevel + ' \u2014 click to unlock';
  } else {
    btn.innerHTML   = SVG_UNLOCKED;
    btn.style.background    = 'var(--surface)';
    btn.classList.remove('is-locked');
    tooltip.textContent = 'Lock L' + sessionLevel + ' for this site';
  }
}

function handleLockClick() {
  if (!lockDomain) return;
  if (state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain)) {
    // Unlock
    chrome.runtime.sendMessage({ type: MSG_REMOVE_SITE_RULE, host: lockDomain }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok) {
        delete state.siteRules[lockDomain];
        state.siteRulesOrder = (state.siteRulesOrder || []).filter(function(h) { return h !== lockDomain; });
        updateRuleCount(resp.ruleCount);
        render();
        renderLockBtn();
        renderPinnedList();
      }
    });
  } else {
    // Lock to current level — capture host, level and restore target before async call
    // so concurrent state changes (e.g. auto-TLD mode) can't corrupt the restore.
    const lockedHost     = lockDomain;
    const lockedLevel    = sessionLevel;
    const restoreToLevel = prevSessionLevel;
    chrome.runtime.sendMessage({ type: MSG_ADD_SITE_RULE, host: lockedHost, level: lockedLevel }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok) {
        if (!state.siteRules) state.siteRules = {};
        if (!state.siteRulesOrder) state.siteRulesOrder = [];
        // FIFO eviction mirror in popup state
        if (!Object.prototype.hasOwnProperty.call(state.siteRules, lockedHost)) {
          if (state.siteRulesOrder.length >= SITE_RULES_CAP) {
            const evicted = state.siteRulesOrder.shift();
            delete state.siteRules[evicted];
          }
          state.siteRulesOrder.push(lockedHost);
        }
        state.siteRules[lockedHost] = lockedLevel;
        // Restore session to the captured pre-lock level
        sessionLevel     = restoreToLevel;
        prevSessionLevel = restoreToLevel;
        state.level      = sessionLevel;
        const _s = {}; _s[SESSION_KEY_LEVEL] = sessionLevel; _s[SESSION_KEY_PREV_LEVEL] = prevSessionLevel;
        chrome.storage.session.set(_s);
        // Update icon to restored session level and sync background global level
        chrome.runtime.sendMessage({ type: MSG_SET_ICON, level: sessionLevel });
        chrome.runtime.sendMessage({ type: MSG_SET_STATE, state: state });
        updateRuleCount(resp.ruleCount);
        render();
        renderLockBtn();
        renderPinnedList();
      }
    });
  }
}

// ── Pinned sites list (no UI — hidden FIFO list) ────────────────────────────
function renderPinnedList() { /* no panel — managed silently in background */ }

// ── Tabs ──────────────────────────────────────────────────────────────────────
// Shows the single relevant whitelist panel for the current level directly,
// with no tab-switcher UI — since removing the Domain whitelist (see
// CHANGELOG) means there is never more than one panel option per level
// anymore (L2: TLD blacklist only, L3: TLD whitelist only, L1/L4/L5: none),
// a clickable tab bar to switch between "options" has nothing left to switch
// between. Kept the function name for minimal call-site churn.
function updateTabs(displayLevel) {
  const tabBar          = document.querySelector('.tab-bar');
  const tldPanel        = document.getElementById('panel-tld');
  const blockedTldPanel = document.getElementById('panel-blocked-tld');
  if (!tldPanel) return;

  if (tabBar) tabBar.style.display = 'none'; // no longer used — see comment above

  if (displayLevel === 2) {
    if (blockedTldPanel) blockedTldPanel.classList.add('active');
    tldPanel.classList.remove('active');
    return;
  }
  if (displayLevel === 3) {
    tldPanel.classList.add('active');
    if (blockedTldPanel) blockedTldPanel.classList.remove('active');
    return;
  }
  // L1, L4, L5 — nothing to show
  tldPanel.classList.remove('active');
  if (blockedTldPanel) blockedTldPanel.classList.remove('active');
}

// ── Render ────────────────────────────────────────────────────────────────────
function render() {
  // Guard: bail out if DOM not ready
  if (!document.getElementById('levelNum')) return;

  // If on a pinned site show its locked level in the slider, else show sessionLevel/state.level
  const isPinned   = lockDomain && state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain);
  const displayVal = isPinned ? state.siteRules[lockDomain] : sessionLevel;
  const val        = displayVal || 1;
  const lvl        = LEVELS[val - 1];

  document.getElementById('levelNum').textContent  = val;
  document.getElementById('levelName').textContent = lvl.name;
  document.documentElement.style.setProperty('--accent', lvl.color);

  // Track fill
  const slider    = document.getElementById('slider');
  const trackFill = document.getElementById('trackFill');
  const fillPx    = 9 + ((slider.offsetWidth - 18) * (val - 1) / 4);
  trackFill.style.width      = fillPx + 'px';
  trackFill.style.background = lvl.color;

  // Disable slider and show hint when on a pinned site
  slider.disabled = isPinned;
  const hint = document.getElementById('siteLockHint');
  if (hint) hint.classList.toggle('visible', isPinned);

  // Ticks
  for (let i = 1; i <= 5; i++) {
    const tick = document.getElementById('tick-' + i);
    if (tick) tick.classList.toggle('active', i === val);
  }

  // Policy rules — see the "Active Policy bullet order" comment above LEVELS
  // for the fixed 1-2-3 ordering this builds.
  let html = '';
  if (val === 1) {
    // L1 — sole exception: one hyphen-bulleted line, nothing to allow/block.
    html += '<div class="rule-row"><div class="rule-hyphen">\u2013</div>'
      + '<div class="rule-text">All traffic allowed \u2014 no restrictions active</div></div>';
  } else {
    // 1. The two universal ALLOW bullets — always green, always first.
    ALWAYS_ALLOW_TEXTS.forEach(function(text) {
      html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot allow"></div></div>'
        + '<div class="rule-text">' + text + '</div></div>';
    });

    // 2. This level's own mode-specific bullet, if it has one — colored
    // with that level's own brand color (see getLevelModeBullet() above).
    const modeBullet = getLevelModeBullet(val, state);
    if (modeBullet) {
      html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot" style="background:' + modeBullet.color + '"></div></div>'
        + '<div class="rule-text">' + modeBullet.text + '</div></div>';
    }

    // 3. This level's block bullets — always red, always last.
    lvl.rules.forEach(function(rule) {
      html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot block"></div></div>'
        + '<div class="rule-text">' + rule.text + '</div></div>';
    });
  }
  const ruleListEl = document.getElementById('ruleList');
  if (ruleListEl) ruleListEl.innerHTML = html;

  // Startup badge
  const badge = document.getElementById('startupBadge');
  if (badge) badge.style.borderColor = LEVELS[(state.startupLevel || 1) - 1].color;
  const sel = document.getElementById('startupSelect');
  if (sel) sel.value = String(state.startupLevel);

  // Update SHOW BLOCKS button state based on effective level
  if (typeof updateShowBlocksBtn === 'function') updateShowBlocksBtn();

  // Tab active underline color
  document.querySelectorAll('.tab-btn.active').forEach(function(btn) {
    btn.style.borderBottomColor = lvl.color;
  });

  // Add button colors
  const addBtns = document.querySelectorAll('.wl-add-btn');
  for (let b = 0; b < addBtns.length; b++) {
    addBtns[b].style.color      = (val === 5) ? '#FFFFFF' : '#000000';
    addBtns[b].style.background = lvl.color;
  }

  updateTabs(val);
  renderLockBtn();
}

// ── Push state ────────────────────────────────────────────────────────────────
function pushState() {
  if (typeof chrome === 'undefined' || !chrome.runtime) return;
  chrome.runtime.sendMessage({ type: MSG_SET_STATE, state: state }, function(resp) {
    if (chrome.runtime.lastError) return;
    if (resp && resp.ok) updateRuleCount(resp.ruleCount);
  });
}

function updateRuleCount(n) {
  // no dedicated counter element in this version, ignore
}

// ── Paginated whitelist ───────────────────────────────────────────────────────
function renderPage(containerId, items, page) {
  const container    = document.getElementById(containerId);
  const isTld        = containerId === 'tld-tags';
  const isBlockedTld = containerId === 'blocked-tld-tags';
  if (!container) return;
  container.innerHTML = '';
  if (!items || items.length === 0) {
    const e = document.createElement('div'); e.className = 'wl-empty'; e.textContent = 'None added yet';
    container.appendChild(e);
    return;
  }
  const pageSize   = TLD_PAGE_SIZE;
  const totalPages = Math.ceil(items.length / pageSize);
  page = Math.max(0, Math.min(page, totalPages - 1));
  tldPage = page;
  const start = page * pageSize, end = Math.min(start + pageSize, items.length);
  for (let i = start; i < end; i++) {
    (function(v) {
      const tag = document.createElement('div'); tag.className = 'wl-tag';
      const LOWERCASE = {'ai':true,'io':true};
      const display = (v.length === 2 && !LOWERCASE[v]) ? v.toUpperCase() : v;
      tag.innerHTML = display + '<button class="wl-tag-remove" title="Remove">&times;</button>';
      tag.querySelector('.wl-tag-remove').addEventListener('click', function() {
        if (isTld) {
          // Remove from active list and from the manual list so the boot re-sync
          // (which rebuilds state.tlds from manualTlds + autoTlds) does not restore it.
          state.tlds = state.tlds.filter(function(x) { return x !== v; });
          if (state.manualTlds) {
            state.manualTlds = state.manualTlds.filter(function(x) { return x !== v; });
          }
          // Remember the removal so auto-detection won't silently bring it back.
          // BASE_TLDS are protected and cannot be excluded.
          if (BASE_TLDS.indexOf(v) === -1) {
            if (!state.excludedTlds) state.excludedTlds = [];
            if (state.excludedTlds.indexOf(v) === -1) state.excludedTlds.push(v);
          }
          renderPage(containerId, state.tlds, tldPage);
        } else if (isBlockedTld) {
          // Remove from the manual list first, then remember the exclusion so
          // Generic/World's own base list doesn't silently restore it on the
          // next rebuild (mode change, popup reopen) — mirrors excludedTlds
          // on the whitelist side above; unlike BASE_TLDS there, nothing in
          // the blocklist's base is protected from exclusion.
          if (state.manualBlockedTlds) {
            state.manualBlockedTlds = state.manualBlockedTlds.filter(function(x) { return x !== v; });
          }
          if (!state.excludedBlockedTlds) state.excludedBlockedTlds = [];
          if (state.excludedBlockedTlds.indexOf(v) === -1) state.excludedBlockedTlds.push(v);
          state.blockedTlds = rebuildBlockedTldList(state.blockedTldMode || 0, state.manualBlockedTlds || [], state.excludedBlockedTlds || []);
          renderBlockedTags();
        }
        pushState();
      });
      container.appendChild(tag);
    })(items[i]);
  }
}

// ── MatrixController ──────────────────────────────────────────────────────────
// Manages the Show Matrix button and its panel window.
// No level-gating on Show Matrix itself (visible/usable at every level,
// (visible/usable at every level, since it only reports — it never changes
// what's blocked). Always reloads on launch — matches Show blocks' behavior.
// (An earlier revision had a reload-vs-passive confirm dialog; removed per
// the decision to simplify back to a single always-reload flow — see
// CHANGELOG.)
//
// Public interface:
//   MatrixController.init()  — call once from DOMContentLoaded
//
// Dependencies (module scope):
//   currentHost — popup.js global
//   MSG_START_MATRIX — data/message-types.js
// ─────────────────────────────────────────────────────────────────────────────
const MatrixController = (function() {
  // ── Guarded module state — initialised false, set true only while a
  // launch is in progress, always released before _launch() can accept
  // another call. Closes the race where chrome.tabs.query() (async) hasn't
  // resolved yet for a first click when a second rapid click starts a
  // second _launch(), which would otherwise let two windows slip past the
  // single-instance check below at the same time. ─────────────────────────
  let _launchInFlight = false;

  // Finds any currently-open tab whose URL is this extension's
  // matrix-panel.html — a Matrix window is always a single-tab popup
  // window, so its one tab's URL (including the tabId query param) is
  // enough to identify both "is one open at all" and "is it open for
  // this exact tab". Queried live via chrome.tabs rather than kept in an
  // in-memory variable, since an in-memory variable resets every time the
  // popup itself closes and reopens — this needs to work even then.
  function _findOpenMatrixTabs(cb) {
    const prefix = chrome.runtime.getURL('ui/matrix-panel.html');
    chrome.tabs.query({}, function(allTabs) {
      const matches = (allTabs || []).filter(function(t) {
        return t.url && t.url.indexOf(prefix) === 0;
      });
      cb(matches);
    });
  }

  function _launch(tabId) {
    // Guard — a launch is already in progress; ignore this call rather
    // than risk a second window slipping past the check below before the
    // first one has finished opening/focusing.
    if (_launchInFlight) return;
    _launchInFlight = true;

    _findOpenMatrixTabs(function(matches) {
      const sameTab = matches.find(function(t) {
        try {
          return new URL(t.url).searchParams.get('tabId') === String(tabId);
        } catch(e) {
          return false;
        }
      });

      if (sameTab) {
        // Already open for this exact tab — focus it rather than duplicating.
        chrome.windows.update(sameTab.windowId, { focused: true }, function() {
          if (chrome.runtime.lastError) { /* stale — window closed elsewhere; fall through below is not needed since matches was already live */ }
          _launchInFlight = false; // guard: release — this launch is done
        });
        return;
      }

      // Any Matrix window open for a DIFFERENT tab — close it first, so at
      // most one Matrix window ever exists at a time, always for whichever
      // tab was most recently asked about.
      if (!matches.length) { _createMatrixWindow(tabId); return; }
      let remaining = matches.length;
      matches.forEach(function(t) {
        chrome.windows.remove(t.windowId, function() {
          if (chrome.runtime.lastError) { /* already gone — fine */ }
          remaining--;
          if (remaining === 0) _createMatrixWindow(tabId);
        });
      });
    });
  }

  function _createMatrixWindow(tabId) {
    chrome.runtime.sendMessage(
      { type: MSG_START_MATRIX, tabId: tabId, host: currentHost },
      function(result) {
        if (!result || !result.ok) { _launchInFlight = false; return; } // guard: release on failure
        const params = new URLSearchParams({ tabId: String(tabId), host: currentHost || "", level: String(getEffectiveLevel()) });
        const panelUrl = chrome.runtime.getURL('ui/matrix-panel.html') + '?' + params.toString();
        chrome.windows.create({ url: panelUrl, type: 'popup', width: 960, height: 720 }, function() {
          _launchInFlight = false; // guard: release — window has been created
        });
      }
    );
  }

  // Public: wire the Show Matrix button — call once from DOMContentLoaded
  function init() {
    const btn = document.getElementById('showMatrixBtn');
    if (!btn) return;
    btn.addEventListener('click', function() {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (!tabs || !tabs[0]) return;
        _launch(tabs[0].id);
      });
    });
  }

  return { init: init };
})();

// ── Effective level + policy-action button state ─────────────────────────────
// Defined at module scope so render() can call updatePolicyButtons() at any time,
// including before DOMContentLoaded fires.
function getEffectiveLevel() {
  const isPinned = lockDomain && state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain);
  return isPinned ? state.siteRules[lockDomain] : (sessionLevel || state.level || 1);
}

// Sets --level-color on both remaining policy-action buttons (Show Matrix,
// Import allow) to the current protection level's color — single place this
// is computed, so they can never drift out of sync with each other or with
// the level indicator elsewhere in the popup. (Show blocks was a third
// button here before its removal — see CHANGELOG.)
function updatePolicyActionColors() {
  const color = LEVELS[getEffectiveLevel() - 1].color;
  ['showMatrixBtn', 'importAllowBtn'].forEach(function(id) {
    const el = document.getElementById(id);
    if (el) el.style.setProperty('--level-color', color);
  });
}

// Import allow is only ever relevant at L1 (locking in an allow-all list
// before raising the level) — kept the function name updateShowBlocksBtn for
// minimal call-site churn even though Show blocks itself is gone; this now
// only manages Import allow's visibility plus the shared color sync.
function updateShowBlocksBtn() {
  const importBtn = document.getElementById('importAllowBtn');
  if (importBtn) importBtn.style.display = (getEffectiveLevel() < 2) ? 'inline-block' : 'none';
  updatePolicyActionColors();
}

document.addEventListener('DOMContentLoaded', function() {

  // Ticks
  const tickRow = document.getElementById('tickRow');
  for (let i = 1; i <= 5; i++) {
    const t = document.createElement('div');
    t.className = 'tick'; t.textContent = i; t.id = 'tick-' + i;
    tickRow.appendChild(t);
  }

  // Slider: pinned sites keep their lock, slider only changes global session level
  document.getElementById('slider').addEventListener('input', function() {
    const newLevel     = parseInt(this.value, 10);
    prevSessionLevel = sessionLevel;
    sessionLevel     = newLevel;
    state.level      = newLevel;
    const _s = {}; _s[SESSION_KEY_LEVEL] = sessionLevel; _s[SESSION_KEY_PREV_LEVEL] = prevSessionLevel;
    chrome.storage.session.set(_s);

    // Auto-collapse both whitelist dropdowns when the user moves the slider —
    // so next time they arrive at L3 or L4 they see the compact version, not
    // the expanded one they may have already read.
    if (!state.whitelistDropdown) state.whitelistDropdown = { tld: true, domain: true };
    state.whitelistDropdown.tld    = false;
    state.whitelistDropdown.domain = false;

    render();
    applyDropdownState();
    chrome.runtime.sendMessage({ type: MSG_SET_STATE, state: state }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok) chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs && tabs[0]) chrome.tabs.reload(tabs[0].id);
      });
    });
  });

  // Startup select
  document.getElementById('startupSelect').addEventListener('change', function() {
    state.startupLevel = parseInt(this.value, 10);
    render(); pushState();
  });

  // Whitelist dropdown toggles — L2 TLD blacklist and L3 TLD whitelist panels
  // (the tab-bar/click-switcher was removed along with Domain whitelist —
  // there is never more than one panel option per level anymore, so a
  // clickable switcher had nothing left to switch between; see CHANGELOG)
  initDropdownToggle('tldDropdownBtn',        'tldDropdownContent',        'tld');
  initDropdownToggle('blockedTldDropdownBtn', 'blockedTldDropdownContent', 'blockedTld');

  // ── TLD Blacklist slider (Level 2) ──────────────────────────────────────────
  const blockedTldSliderEl = document.getElementById('blockedTldSlider');
  const blockedTldValueEl  = document.getElementById('blockedTldValue');
  const blockedTldHintEl   = document.getElementById('blockedTldHint');

  function updateBlockedTldSliderUI(mode) {
    if (blockedTldValueEl) blockedTldValueEl.textContent = BLOCKED_TLD_LABELS[mode];
    if (blockedTldHintEl)  blockedTldHintEl.textContent  = BLOCKED_TLD_HINTS[mode];
    if (blockedTldSliderEl) blockedTldSliderEl.value = mode;
  }

  function applyBlockedTldMode(mode) {
    state.blockedTldMode = mode;
    state.blockedTlds    = rebuildBlockedTldList(mode, state.manualBlockedTlds || [], state.excludedBlockedTlds || []);
    renderBlockedTags();
    render(); // update Active Policy blocked TLD count
    pushState();
  }

  if (blockedTldSliderEl) {
    blockedTldSliderEl.addEventListener('input', function() {
      const mode = parseInt(this.value, 10);
      updateBlockedTldSliderUI(mode);
      applyBlockedTldMode(mode);
    });
  }

  // Blocked TLD manual add
  const blockedTldInput  = document.getElementById('blocked-tld-input');
  const blockedTldAddBtn = document.getElementById('blocked-tld-add');
  function addBlockedTld() {
    if (!blockedTldInput) return;
    const raw = blockedTldInput.value.trim().replace(/^\.+/, '').toLowerCase();
    if (!raw) return;
    if (!state.manualBlockedTlds) state.manualBlockedTlds = [];
    if (state.manualBlockedTlds.indexOf(raw) === -1) state.manualBlockedTlds.push(raw);
    // Re-adding a previously-excluded TLD clears the exclusion — explicit re-add wins.
    if (state.excludedBlockedTlds) {
      state.excludedBlockedTlds = state.excludedBlockedTlds.filter(function(x) { return x !== raw; });
    }
    if (state.blockedTlds.indexOf(raw) === -1) {
      state.blockedTlds.push(raw);
      renderBlockedTags();
      pushState();
    }
    blockedTldInput.value = ''; blockedTldInput.focus();
  }
  if (blockedTldAddBtn) blockedTldAddBtn.addEventListener('click', addBlockedTld);
  if (blockedTldInput)  blockedTldInput.addEventListener('keydown', function(e) { if (e.key === 'Enter') addBlockedTld(); });

  updateBlockedTldSliderUI(state.blockedTldMode || 0);
  renderBlockedTags();

  // Auto TLD slider
  const autoSlider  = document.getElementById('autoTldSlider');
  const autoValue   = document.getElementById('autoTldValue');
  const autoHint    = document.getElementById('autoTldHint');
  let browserLangs = [];
  if (typeof chrome !== 'undefined' && chrome.i18n) {
    chrome.i18n.getAcceptLanguages(function(langs) { browserLangs = langs || []; });
  }
  function updateAutoSliderUI(mode) {
    autoValue.textContent = AUTO_TLD_LABELS[mode];
    autoHint.textContent  = AUTO_TLD_HINTS[mode];
    autoSlider.value      = mode;
  }
  function applyAutoTlds(mode) {
    chrome.i18n.getAcceptLanguages(function(langs) {
      browserLangs = langs || [];
      rebuildTldList(mode, browserLangs, state.manualTlds || [], state.excludedTlds || [], function(merged) {
        state.tlds = merged; state.autoTldMode = mode;
        renderPage('tld-tags', state.tlds, 0);
        render(); // update Active Policy TLD count
        pushState();
      });
    });
  }
  autoSlider.addEventListener('input', function() {
    const mode = parseInt(this.value, 10);
    updateAutoSliderUI(mode); applyAutoTlds(mode);
  });

  // Manual TLD add
  const tldInput  = document.getElementById('tld-input');
  const tldAddBtn = document.getElementById('tld-add');
  function addManualTld() {
    const raw = tldInput.value.trim().replace(/^\.+/, '').toLowerCase();
    if (!raw) return;
    if (!state.manualTlds) state.manualTlds = [];
    if (state.manualTlds.indexOf(raw) === -1) state.manualTlds.push(raw);
    // Re-adding a previously-excluded TLD clears the exclusion — explicit re-add wins.
    if (state.excludedTlds) {
      state.excludedTlds = state.excludedTlds.filter(function(x) { return x !== raw; });
    }
    if (state.tlds.indexOf(raw) === -1) {
      state.tlds.push(raw);
      renderPage('tld-tags', state.tlds, Math.floor((state.tlds.length - 1) / TLD_PAGE_SIZE));
      pushState();
    }
    tldInput.value = ''; tldInput.focus();
  }
  tldAddBtn.addEventListener('click', addManualTld);
  tldInput.addEventListener('keydown', function(e) { if (e.key === 'Enter') addManualTld(); });

  // Lock button
  document.getElementById('lockBtn').addEventListener('click', handleLockClick);

  // ── SHOW MATRIX button ───────────────────────────────────────────────────────
  MatrixController.init();

  // ── IMPORT ALLOW button & overlay ────────────────────────────────────────────
  // At L1: replaces Show blocks. Opens a textarea pre-populated with every
  // domain currently locked AT LEVEL 1 — this list is the full, authoritative
  // editor for LEVEL-1 locks specifically. A domain locked at another level
  // (e.g. 4 or 5 — commonly used for privacy-sensitive categories someone
  // deliberately locked stricter) must never appear here, and Save must never
  // touch it: surfacing it in a plain-text list, or silently normalizing it
  // down to level 1, defeats the point of having locked it stricter in the
  // first place. Confirmed with the user directly — not a filtering call to
  // make unilaterally from the code alone.
  (function() {
    const overlay   = document.getElementById('importAllowOverlay');
    const textarea  = document.getElementById('importAllowTextarea');
    const saveBtn   = document.getElementById('importAllowSave');
    const cancelBtn = document.getElementById('importAllowCancel');
    const openBtn   = document.getElementById('importAllowBtn');
    if (!overlay || !openBtn) return;

    openBtn.addEventListener('click', function() {
      // Pre-populate with pinned domains locked AT LEVEL 1 ONLY —
      // deduplicated via a Set (defensive — siteRulesOrder shouldn't itself
      // contain duplicates, but this guards against it regardless) and
      // ordered by siteRulesOrder's existing FIFO insertion order, for
      // consistency with how eviction already works.
      const order = state.siteRulesOrder || [];
      const seen  = new Set();
      const allPinnedDomains = [];
      order.forEach(function(d) {
        if (seen.has(d)) return;
        seen.add(d);
        if (state.siteRules && state.siteRules[d] === 1) {
          allPinnedDomains.push(d);
        }
      });
      textarea.value = allPinnedDomains.join('\n');
      overlay.classList.add('visible');
      textarea.focus();
    });

    cancelBtn.addEventListener('click', function() {
      overlay.classList.remove('visible');
    });

    saveBtn.addEventListener('click', function() {
      const lines = textarea.value.split(/\r?\n/);
      const seenInPaste = new Set(); // dedup within this save — a repeated line is only processed once
      const keepDomains = new Set(); // every LEVEL-1 domain that should remain locked after this save
      let added = 0;
      lines.forEach(function(line) {
        // Strip protocol and path, lowercase
        const domain = line.trim()
          .replace(/^https?:\/\//i, '')
          .replace(/\/.*$/, '')
          .toLowerCase();
        if (!domain || seenInPaste.has(domain)) return;
        seenInPaste.add(domain);
        keepDomains.add(domain);
        if (!state.siteRules) state.siteRules = {};
        if (!state.siteRulesOrder) state.siteRulesOrder = [];
        // FIFO eviction — mirror handleLockClick logic
        if (!Object.prototype.hasOwnProperty.call(state.siteRules, domain)) {
          if (state.siteRulesOrder.length >= SITE_RULES_CAP) {
            const evicted = state.siteRulesOrder.shift();
            delete state.siteRules[evicted];
          }
          state.siteRulesOrder.push(domain);
        }
        state.siteRules[domain] = 1;  // lock at level 1 — always overwrites any prior level
        added++;
      });

      // The textarea is the authoritative list for LEVEL-1 locks only — it
      // was pre-populated with level-1 domains only (see openBtn's handler
      // above), so reconciliation must only remove domains that WERE locked
      // at level 1 and are no longer present here. A domain locked at
      // another level was never shown, was never editable through this
      // dialog, and must be left completely alone.
      let removed = 0;
      if (state.siteRulesOrder && state.siteRulesOrder.length) {
        const toRemove = state.siteRulesOrder.filter(function(d) {
          return state.siteRules[d] === 1 && !keepDomains.has(d);
        });
        toRemove.forEach(function(d) {
          delete state.siteRules[d];
          const idx = state.siteRulesOrder.indexOf(d);
          if (idx !== -1) state.siteRulesOrder.splice(idx, 1);
          removed++;
        });
      }

      if (added > 0 || removed > 0) {
        chrome.runtime.sendMessage({ type: MSG_SET_STATE, state: state }, function(resp) {
          if (chrome.runtime.lastError) return;
          if (resp && resp.ok) updateRuleCount(resp.ruleCount);
        });
        renderPinnedList();
      }
      overlay.classList.remove('visible');
    });
  })();

  // Get current tab hostname directly — tabs permission is now declared
  if (typeof chrome !== 'undefined' && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0]) {
        try { currentHost = new URL(tabs[0].url).hostname; } catch(e) { /* unparseable tab URL (e.g. chrome:// pages) — currentHost stays unset */ }
        lockDomain = getApexDomain(currentHost);
      }
      const hostnameEl = document.getElementById('siteHostname');
      if (hostnameEl) hostnameEl.textContent = currentHost || '—';
      renderLockBtn();
    });
  }

  // Sync with background — read session storage first, then persistent state
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    const _sessDefaults = {}; _sessDefaults[SESSION_KEY_LEVEL] = 0; _sessDefaults[SESSION_KEY_PREV_LEVEL] = 0;
    chrome.storage.session.get(_sessDefaults, function(sess) {
      chrome.runtime.sendMessage({ type: MSG_GET_STATE }, function(resp) {
        if (chrome.runtime.lastError) return;
        if (resp && resp.ok && resp.state) {
          state = freshState(resp.state);
          if (!state.startupLevel) state.startupLevel = 1;
          if (!state.autoTldMode && state.autoTldMode !== 0) state.autoTldMode = 1;
          if (!state.manualTlds)    state.manualTlds    = [];
          if (!state.excludedTlds)  state.excludedTlds  = [];
          if (!state.siteRules)     state.siteRules     = {};
          if (!state.siteRulesOrder) state.siteRulesOrder = Object.keys(state.siteRules);
          if (!state.whitelistDropdown) state.whitelistDropdown = { tld: true, domain: true };
          if (!state.blockedTlds)       state.blockedTlds       = [];
          if (!state.manualBlockedTlds) state.manualBlockedTlds = [];
          if (!state.excludedBlockedTlds) state.excludedBlockedTlds = [];
          if (typeof state.blockedTldMode !== 'number') state.blockedTldMode = 0;
          BASE_TLDS.forEach(function(t) { if (state.tlds.indexOf(t) === -1) state.tlds.push(t); });

          // Initialise session levels:
          // - If already set this session, restore them
          // - If first open this session (both 0), initialise from startupLevel
          if (sess[SESSION_KEY_LEVEL]) {
            sessionLevel     = sess[SESSION_KEY_LEVEL];
            prevSessionLevel = sess[SESSION_KEY_PREV_LEVEL] || sess[SESSION_KEY_LEVEL];
          } else {
            sessionLevel     = state.startupLevel;
            prevSessionLevel = state.startupLevel;
            const _si = {}; _si[SESSION_KEY_LEVEL] = sessionLevel; _si[SESSION_KEY_PREV_LEVEL] = prevSessionLevel;
            chrome.storage.session.set(_si);
          }

          // Update icon to reflect actual session level (without changing stored state)
          chrome.runtime.sendMessage({ type: MSG_SET_ICON, level: sessionLevel });

          // Set slider: pinned site shows its locked level, otherwise show sessionLevel
          const _pinned = lockDomain && state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain);
          document.getElementById('slider').value        = _pinned ? state.siteRules[lockDomain] : sessionLevel;
          document.getElementById('startupSelect').value = String(state.startupLevel);
          updateAutoSliderUI(state.autoTldMode);

          // Re-sync the auto-added TLD list from the browser's CURRENT language settings
          // using the latest mapping logic, rather than trusting whatever was saved to
          // storage by a previous version of this logic. Manual TLD entries are preserved.
          if (state.autoTldMode !== 0 && typeof chrome !== 'undefined' && chrome.i18n) {
            chrome.i18n.getAcceptLanguages(function(currentLangs) {
              rebuildTldList(state.autoTldMode, currentLangs || [], state.manualTlds || [], state.excludedTlds || [], function(merged) {
                state.tlds = merged;
                renderPage('tld-tags', state.tlds, 0);
                pushState();
              });
            });
          }

          render();
          renderPage('tld-tags',    state.tlds,    0);
          renderLockBtn();
          applyDropdownState();
          updateBlockedTldSliderUI(state.blockedTldMode || 0);
          renderBlockedTags();
        }
      });
    });
  }
});
