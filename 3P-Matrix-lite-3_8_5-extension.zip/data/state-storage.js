// ── data/state-storage.js ─────────────────────────────────────────────────────
// State schema, defaults and chrome.storage.local read/write.
// The only file allowed to call chrome.storage directly.
//
// Public interface:
//   loadState(cb)    — reads state from storage, merges defaults, calls cb(state)
//   saveState(s, cb) — writes state to storage, calls cb() when done
//
// State is persisted under a single storage key (STORAGE_KEY).
// On SW restart, loadState() reconstructs the full state object from storage.
// ─────────────────────────────────────────────────────────────────────────────

import {
  BUILTIN_DOMAINS, DEFAULT_RISKY_SITES_LEVEL4, DEFAULT_RISKY_SITES_LEVEL5,
  DEFAULT_MATRIX_ALLOW_OVERRIDES
} from "./constants.js";

export const STORAGE_KEY    = "3pmatrix_state";   // single chrome.storage.local key for all state
export const SITE_RULES_CAP = 200;                // max number of per-site pinned rules (FIFO eviction)

// ── Named constants for storage keys used outside this module ─────────────────
// These keys are written directly by popup.js and monitor-panel.js (not via
// loadState/saveState) because they are UI-session state, not extension state.
// Declaring them here keeps all storage key names in one place.
export const SESSION_KEY_LEVEL      = "sessionLevel";      // chrome.storage.session — active slider level
export const SESSION_KEY_PREV_LEVEL = "prevSessionLevel";  // chrome.storage.session — pre-lock level

// Builds the shipped-default per-site locks from data/constants.js's
// DEFAULT_RISKY_SITES_LEVEL4/5 lists — single source of truth for which
// hostnames and levels these are, so DEFAULT_STATE below never hardcodes
// them a second time. See DEFAULT_STATE.siteRules for the "fresh-install
// only, user's own lock always wins after that" contract.
function _buildDefaultSiteRules() {
  const rules = {};
  DEFAULT_RISKY_SITES_LEVEL4.forEach(function(host) { rules[host] = 4; });
  DEFAULT_RISKY_SITES_LEVEL5.forEach(function(host) { rules[host] = 5; });
  return rules;
}

export const DEFAULT_STATE = {

  startupLevel: 1,
  level:        1,
  tlds:         ["com", "ai", "edu", "gov", "io", "net", "org", "cloud", "dev", "app", "page"],
  builtinDomains: null,    // seeded with BUILTIN_DOMAINS on first install, editable by user
  autoTldMode:  1,
  manualTlds:   [],
  excludedTlds: [],        // TLDs the user explicitly removed — kept out on re-sync
  siteRules:    _buildDefaultSiteRules(),
                            // { "hostname": level } — starts pre-populated with the
                            // risky-site defaults (data/constants.js's
                            // DEFAULT_RISKY_SITES_LEVEL4/5) ONLY because this object
                            // is DEFAULT_STATE: loadState() only ever falls back to
                            // it for keys genuinely absent from stored state, so this
                            // seeding only takes effect on a fresh install (see
                            // background.js's onInstalled "install" branch). Any
                            // existing stored siteRules — including a user re-locking
                            // one of these same hostnames at a different level —
                            // replaces this default outright; there is no merge.
  siteRulesOrder: DEFAULT_RISKY_SITES_LEVEL4.concat(DEFAULT_RISKY_SITES_LEVEL5),
                            // insertion-order array for FIFO eviction — must stay in
                            // sync with siteRules above; built from the same two
                            // source lists so the two can never drift apart.
  // Whitelist dropdown state: true = expanded, false = collapsed.
  // Resets to expanded on fresh install or major.minor version update.
  whitelistDropdown: { tld: true, domain: true },
  lastShownVersion: "",    // "major.minor" e.g. "1.3" — used to detect version updates
  showBlockedCount: true,        // toolbar badge showing per-tab blocked request count (reserved for future UI toggle)
  blockedTldDropdownOpen: false, // TLD blacklist dropdown starts collapsed
  // TLD blacklist for level 2 script blocking.
  // blockedTldMode: 0=None, 1=User, 2=Generic, 3=World
  blockedTldMode:    0,
  blockedTlds:       [],   // active computed list (rebuilt from mode + manualBlockedTlds - excludedBlockedTlds)
  // Interactive Show Matrix per-domain, per-type overrides.
  // { [domain]: { frame?: "allow"|"block", script?: "allow"|"block" } }
  // Independent from `domains` above (which is a domain-wide, type-agnostic
  // whitelist used by the Domain whitelist tab) — matrixRules is scoped to a
  // single resource type per entry, and can express BOTH allow and block
  // (domains has no block concept at all). A key present here always wins
  // over the level's default disposition for that domain+type — see
  // rule-builder.js's buildMatrixOverrideRules() for the priority mechanics.
  // Only "frame" and "script" keys are ever set — those are the only two
  // resource types this extension's DNR rules are built to block at all.
  matrixRules:       Object.assign({}, DEFAULT_MATRIX_ALLOW_OVERRIDES),
                            // starts pre-populated with the shipped-default allow
                            // overrides (data/constants.js's
                            // DEFAULT_MATRIX_ALLOW_OVERRIDES) — same fresh-install-only
                            // contract as siteRules above: a user's own Show Matrix
                            // click on the same domain overwrites this entry via the
                            // normal setMatrixRule() path, no separate flag needed.
  manualBlockedTlds: [],   // TLDs the user explicitly added (persisted across mode changes)
  excludedBlockedTlds: []  // TLDs the user explicitly removed from Generic/World's base list —
                            // kept out on re-sync, mirrors excludedTlds above
};

// ── Guard: safe mutable copies of DEFAULT_STATE ────────────────────────────────
// DEFAULT_STATE is a single module-level object, and three of its fields
// (siteRules, siteRulesOrder, matrixRules) are themselves objects/arrays, not
// primitives. A bare `Object.assign({}, DEFAULT_STATE, override)` only
// shallow-copies: for any of those three fields NOT present in `override`,
// the copy's field is still the EXACT SAME object DEFAULT_STATE holds — so
// the first in-place mutation anywhere downstream (addSiteRule(),
// setMatrixRule(), etc., all of which mutate state.siteRules/matrixRules
// directly) would corrupt the shared DEFAULT_STATE singleton for the rest of
// this module's lifetime, silently changing what "the defaults" are for
// every future install/session in that same context.
// Always use freshState() instead of a bare Object.assign(...) with
// DEFAULT_STATE wherever the result will be mutated (which is everywhere a
// working `state` object is built from it).
export function freshState(override) {
  const o = override || {};
  const s = Object.assign({}, DEFAULT_STATE, o);
  // Preserve normal Object.assign "override wins outright, no merge" semantics
  // for these three fields too — only fall back to a DEEP copy of
  // DEFAULT_STATE's own value when the caller didn't supply one at all.
  s.siteRules      = o.siteRules      ? Object.assign({}, o.siteRules)   : Object.assign({}, DEFAULT_STATE.siteRules);
  s.siteRulesOrder = o.siteRulesOrder ? o.siteRulesOrder.slice()         : DEFAULT_STATE.siteRulesOrder.slice();
  s.matrixRules     = o.matrixRules    ? Object.assign({}, o.matrixRules) : Object.assign({}, DEFAULT_STATE.matrixRules);
  return s;
}

// Reads state from chrome.storage.local, merges with DEFAULT_STATE to ensure
// all keys are present (handles new keys added in later versions gracefully),
// and normalises any invalid values before calling cb(state).
export function loadState(cb) {
  chrome.storage.local.get(STORAGE_KEY, function(stored) {
    const s = Object.assign({}, DEFAULT_STATE, stored[STORAGE_KEY] || {});
    if (s.level === 0)        s.level        = 1;
    if (s.startupLevel === 0) s.startupLevel = 1;
    if (!s.siteRules)         s.siteRules     = {};
    if (!s.siteRulesOrder)    s.siteRulesOrder = Object.keys(s.siteRules);
    if (s.builtinDomains === null || s.builtinDomains === undefined) {
      s.builtinDomains = Object.assign({}, BUILTIN_DOMAINS);
    }
    if (!s.blockedTlds)        s.blockedTlds        = [];
    if (!s.manualBlockedTlds)  s.manualBlockedTlds  = [];
    if (!s.excludedBlockedTlds) s.excludedBlockedTlds = [];
    if (typeof s.blockedTldMode !== "number") s.blockedTldMode = 0;
    cb(s);
  });
}

// Writes state to chrome.storage.local as a single atomic operation.
// All related state fields are always written together — never update
// individual fields separately to avoid inconsistent intermediate state.
export function saveState(s, cb) {
  const o = {};
  o[STORAGE_KEY] = s;
  chrome.storage.local.set(o, cb || function() {});
}
