// ── data/message-types.js ─────────────────────────────────────────────────────
// Named constants for all chrome.runtime.sendMessage message types.
// Defining them here (rather than as raw strings) means a typo in either
// background.js or popup.js produces a ReferenceError instead of a silent
// no-op where the message is never handled.
//
// Load via: import { MSG_GET_STATE, ... } from "./data/message-types.js"
// (used by background.js, ui/popup.js, ui/matrix-panel.js)
//
// Dependencies: none
// ─────────────────────────────────────────────────────────────────────────────

export const MSG_GET_STATE        = "GET_STATE";         // popup → SW: fetch current state + rule count
export const MSG_SET_STATE        = "SET_STATE";         // popup → SW: save new state and apply rules
export const MSG_ADD_SITE_RULE    = "ADD_SITE_RULE";     // popup → SW: pin a per-site level override
export const MSG_REMOVE_SITE_RULE = "REMOVE_SITE_RULE";  // popup → SW: unpin a per-site level override
export const MSG_SET_ICON         = "SET_ICON";          // popup → SW: update the toolbar icon
// MSG_GET_ACTIVE_TAB_INFO and MSG_RELOAD_ACTIVE_TAB removed in v1.7.3 —
// popup now calls chrome.tabs directly since the tabs permission is declared.

// ── Show Matrix messages ──────────────────────────────────────────────────────
// Show Matrix has no pause/resume — it observes continuously for as long as
// its panel stays open, tied to tab lifecycle. (Show blocks/block-monitor.js,
// which this originally mirrored, was retired once the Matrix's own Domain
// column made it redundant — see CHANGELOG.)
export const MSG_START_MATRIX  = "START_MATRIX";   // popup → SW: begin observing the active tab (idempotent if already running)
export const MSG_STOP_MATRIX   = "STOP_MATRIX";    // popup → SW: stop observing the active tab, release its listener/state
export const MSG_GET_MATRIX_DATA = "GET_MATRIX_DATA"; // popup → SW: fetch current traffic snapshot for a tab
export const MSG_MATRIX_CLOSED = "MATRIX_CLOSED";  // SW → panel: notify panel to close (tab closed / navigated away)

// popup → SW: set or clear a per-domain, per-type Matrix override.
// action: "allow" | "block" | null (null clears/unselects, reverting to the
// level's default disposition). See core/matrix-rules.js.
export const MSG_SET_MATRIX_RULE = "SET_MATRIX_RULE";
