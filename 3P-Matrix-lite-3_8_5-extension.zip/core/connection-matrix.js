// ── core/connection-matrix.js ──────────────────────────────────────────────────
// Show Matrix — passive, always-on per-tab observer of ALL third-party
// connections (script/frame/image/media/stylesheet/font/object/fetch-xhr/
// websocket/ping/other), regardless of whether our own ruleset would block
// them.
//
// NOT filtered by core/rule-classifier.js the way the retired
// core/block-monitor.js module used to filter its own bounded,
// reload-triggered review sessions: this module's purpose is
// full-visibility traffic observation, blocked or not, so it does NOT call
// core/rule-classifier.js at all.
//
// Public interface:
//   startMatrix(tabId, host, cb)        — begin observing a tab (idempotent — calling
//                                         again for the same tab just resets its entries/timer)
//   stopMatrix(tabId)                   — release a single tab's tracked state
//   getMatrixData(tabId)                — returns current entries + remaining time for a tab
//   clearMatrixOnNavigation(tabId)      — call from webNavigation.onCommitted (main frame)
//   clearMatrixOnTabClosed(tabId)       — call from tabs.onRemoved
//   startMatrixWatchdog()               — call once on SW boot; kills orphan buckets
//                                         (belt-and-suspenders fallback, same
//                                         rationale as the retired
//                                         core/block-monitor.js's startWatchdog())
//
// State owned by this module (all in-memory, lost on SW restart — safe,
// because the webRequest listener is also lost on SW restart, so there is no
// orphaned-listener case to guard against beyond the ones handled below):
//   _tabs           {Map<tabId, TabBucket>} — one bucket per actively-tracked tab
//   _listenerActive {boolean}               — whether the shared webRequest
//                                              listener is currently registered
//   _watchdogTimer  {IntervalID}             — orphan-bucket watchdog, SW lifetime
//
// TabBucket shape:
//   { host, entries: Map<domain, EntryRecord>, startTime, timeoutHandle, requestCount }
//   host          — 1P hostname the tab was on when tracking started (for same-site skip)
//   entries       — Map keyed by third-party domain; see ENTRY shape below
//   startTime     — Date.now() when startMatrix() was called; MATRIX_DURATION counts down from here
//   timeoutHandle — primary auto-close setTimeout handle for this tab
//   requestCount  — running count of resource requests observed via
//                   _matrixListener (onBeforeRequest)
//
// ENTRY shape:
//   { domain, types: Set<string> }
//   types — labels derived from MATRIX_RESOURCE_TYPES: "image" | "media" |
//           "stylesheet" | "script" | "frame" | "fetch/xhr" | "other"
//           ("other" also covers font/object/ping/csp_report/webbundle/
//           websocket — see _typeLabel).
// ─────────────────────────────────────────────────────────────────────────────

import { MATRIX_RESOURCE_TYPES, MATRIX_CAP, MATRIX_DURATION, BUILTIN_DOMAINS, SIGNAL_DOMAINS } from "../data/constants.js";
import { MSG_MATRIX_CLOSED } from "../data/message-types.js";
import { etldPlusOne } from "./rule-classifier.js";

// ── Guarded module state — initialised empty, cleared/released explicitly ────
const _tabs = new Map();     // tabId -> TabBucket
let _listenerActive = false; // guards against double-registering the listener
let _watchdogTimer   = null; // orphan-bucket watchdog interval handle

// Maps a raw webRequest resourceType to the label shown in the Show Matrix
// table. Returns null for anything totally unrecognized (shouldn't happen
// given the listener's own types filter, but the fallback here is
// defense-in-depth rather than an assumption that the filter alone is
// sufficient). font/object/ping/csp_report/webbundle/websocket all collapse
// into "other" — stylesheet gets its own column (re-added after observing
// elevated third-party stylesheet traffic tends to correlate with heavier
// embedded ad-tech/widget infrastructure — a real, visible signal even
// though webRequest can't see stylesheet *content*, only that a request
// happened).
function _typeLabel(resourceType) {
  if (resourceType === "sub_frame")      return "frame";
  if (resourceType === "script")         return "script";
  if (resourceType === "image")          return "image";
  if (resourceType === "media")          return "media";
  if (resourceType === "stylesheet")     return "stylesheet";
  if (resourceType === "xmlhttprequest") return "fetch/xhr";
  if (resourceType === "font" || resourceType === "object" ||
      resourceType === "ping" || resourceType === "csp_report" ||
      resourceType === "webbundle" || resourceType === "websocket" ||
      resourceType === "other") return "other";
  return null;
}

// Resolves the table-row grouping key for a request, or null if the bucket
// is unknown, the URL doesn't parse, or it's actually same-site (not
// third-party at all).
//
// Normally this is just the eTLD+1 (e.g. "taboola.com"), grouping every
// subdomain of a third party into one row. EXCEPT, in two cases, a
// subdomain gets its own separate row instead:
//   1. It contains "cdn" and differs from its own eTLD+1 (e.g.
//      "cdn.taboola.com") — Level 4's CDN-allow rule genuinely can treat
//      that specific subdomain differently (allowed) than the bare
//      eTLD+1 (blocked, no "cdn" in the domain itself).
//   2. It has its OWN explicit entry in BUILTIN_DOMAINS or SIGNAL_DOMAINS,
//      distinct from its eTLD+1's entry (e.g. "js.hcaptcha.com" is its own
//      script-only entry, separate from "hcaptcha.com"'s frame-only one) —
//      per explicit user request, so a parent/child whitelist collision is
//      visible directly in the live table, not just in a static report.
// In both cases, merging them into one row was actively misleading:
// Mode's color reflected whichever specific request happened to be
// sampled first, which didn't necessarily represent the whole row.
//
// This split isn't level-gated (connection-matrix.js stays decoupled from
// state/level by design — see this file's header comment) — it's harmless
// at other levels too, since it's still fully accurate either way, just
// occasionally more granular than one row per eTLD+1. Case 2 references
// the STATIC BUILTIN_DOMAINS/SIGNAL_DOMAINS constants directly (plain
// data, not classification logic) rather than core/rule-classifier.js's
// functions — keeps this module decoupled from live per-user state edits,
// which don't need runtime precision for a display-only grouping decision.
function _groupingKeyFor(bucket, url) {
  let hostname;
  try {
    hostname = new URL(url).hostname.toLowerCase();
  } catch(e) {
    return null;
  }

  const thirdPartyHost = etldPlusOne(url);
  if (!thirdPartyHost) return null;
  const firstPartyApex = etldPlusOne("https://" + bucket.host);
  if (thirdPartyHost === firstPartyApex) return null;

  if (hostname !== thirdPartyHost) {
    if (hostname.indexOf("cdn") !== -1) return hostname;
    if (Object.prototype.hasOwnProperty.call(BUILTIN_DOMAINS, hostname)) return hostname;
    if (Object.prototype.hasOwnProperty.call(SIGNAL_DOMAINS, hostname)) return hostname;
  }
  return thirdPartyHost;
}

// Finds (or creates, respecting the FIFO cap) a domain's entry in a bucket.
// Shared by _matrixListener.
function _getOrCreateEntry(bucket, groupingKey) {
  let entry = bucket.entries.get(groupingKey);
  if (!entry) {
    // Enforce the FIFO cap by domain count, not raw event count — dropping the
    // oldest-seen domain keeps the table showing the most recently-active set.
    if (bucket.entries.size >= MATRIX_CAP) {
      const oldestKey = bucket.entries.keys().next().value;
      bucket.entries.delete(oldestKey);
    }
    entry = { domain: groupingKey, types: new Set(), sampleUrl: null };
    bucket.entries.set(groupingKey, entry);
  }
  return entry;
}

// The shared webRequest listener. Fires for every tracked tab at once —
// dispatches into whichever tab bucket (if any) matches details.tabId.
function _matrixListener(details) {
  const bucket = _tabs.get(details.tabId);
  if (!bucket) return;

  const groupingKey = _groupingKeyFor(bucket, details.url);
  if (!groupingKey) return;

  const typeLabel = _typeLabel(details.type);
  if (!typeLabel) return; // unrecognized type — shouldn't reach here given the listener's own types filter, but drop it defensively rather than pollute an entry's types Set

  const entry = _getOrCreateEntry(bucket, groupingKey);
  entry.types.add(typeLabel);
  if (!entry.sampleUrl) entry.sampleUrl = details.url; // first-seen wins — good enough for the CDN-substring heuristic
  bucket.requestCount++;
}

// Registers the shared listener if not already active. Safe to call repeatedly.
function _ensureListener() {
  if (_listenerActive) return;
  chrome.webRequest.onBeforeRequest.addListener(
    _matrixListener,
    { urls: ["<all_urls>"], types: MATRIX_RESOURCE_TYPES }
  );
  _listenerActive = true;
}

// Releases the shared listener once no tabs remain tracked. Safe to call repeatedly.
function _releaseListenerIfIdle() {
  if (!_listenerActive || _tabs.size > 0) return;
  try {
    chrome.webRequest.onBeforeRequest.removeListener(_matrixListener);
  } catch(e) {
    // Intentional: listener may already be gone (e.g. SW restart mid-teardown).
  }
  _listenerActive = false;
}

// Sends MSG_MATRIX_CLOSED to the Show Matrix panel (fire-and-forget). Ported
// from the retired core/block-monitor.js's _notifyPanel — same shape, same
// suppression of chrome.runtime.lastError when the panel is already closed
// (C21: reuse a proven pattern rather than inventing a new one).
function _notifyPanel(tabId, reason) {
  try {
    chrome.runtime.sendMessage({ type: MSG_MATRIX_CLOSED, tabId: tabId, reason: reason }, function() {
      if (chrome.runtime.lastError) { /* intentional no-op — panel may already be closed */ }
    });
  } catch(e) {
    // Intentional: SW context may be terminating; panel closure is best-effort.
  }
}

// ── Public interface ──────────────────────────────────────────────────────────

// Starts (or restarts) tracking for a single tab. Idempotent: calling again
// for a tab already being tracked simply clears its entries and re-arms the
// timer from a fresh MATRIX_DURATION window, rather than erroring or creating
// a duplicate bucket.
export function startMatrix(tabId, host, cb) {
  _clearTimeoutHandle(tabId); // guard: release any stale handle before replacing the bucket
  const bucket = {
    host: host, entries: new Map(),
    startTime: Date.now(), timeoutHandle: null,
    requestCount: 0
  };
  _tabs.set(tabId, bucket);
  bucket.timeoutHandle = setTimeout(function() {
    _timeoutMatrix(tabId);
  }, MATRIX_DURATION);
  _ensureListener();
  if (cb) cb({ ok: true });
}

// Clears a tab's timeout handle without touching anything else — used both
// as a guard before replacing a bucket and as part of full teardown.
function _clearTimeoutHandle(tabId) {
  const bucket = _tabs.get(tabId);
  if (bucket && bucket.timeoutHandle) { clearTimeout(bucket.timeoutHandle); bucket.timeoutHandle = null; }
}

// Auto-close path — the primary timer (or the watchdog fallback) firing.
// Notifies the panel with reason "timeout" before releasing the bucket, same
// shape as clearMatrixOnTabClosed's "tab_closed" notification below.
function _timeoutMatrix(tabId) {
  if (!_tabs.has(tabId)) return;
  stopMatrix(tabId);
  _notifyPanel(tabId, "timeout");
}

// Stops tracking a single tab and releases its memory. Releases the shared
// listener too, if this was the last tracked tab.
export function stopMatrix(tabId) {
  _clearTimeoutHandle(tabId);
  _tabs.delete(tabId);
  _releaseListenerIfIdle();
}

// Returns a defensive-copy snapshot of a tab's current entries plus the
// remaining/elapsed time for the panel's countdown display.
// Includes `host` and each entry's `sampleUrl` — not for direct panel
// display, but consumed by background.js's MSG_GET_MATRIX_DATA handler to
// compute per-domain frame/script disposition via core/rule-classifier.js's
// wouldBlock(), which needs both. This module stays decoupled from
// rule-classifier.js itself — see this file's header comment on why Show
// Matrix doesn't call the classifier directly.
export function getMatrixData(tabId) {
  const bucket = _tabs.get(tabId);
  if (!bucket) return { entries: [], elapsed: 0, remaining: 0, domainCount: 0, requestCount: 0, host: null };
  const entries = [];
  bucket.entries.forEach(function(entry) {
    entries.push({
      domain:    entry.domain,
      types:     Array.from(entry.types),
      sampleUrl: entry.sampleUrl
    });
  });
  const elapsed = Date.now() - bucket.startTime;
  return {
    entries:      entries,
    elapsed:      elapsed,
    remaining:    Math.max(0, MATRIX_DURATION - elapsed),
    domainCount:  bucket.entries.size,
    requestCount: bucket.requestCount,
    host:         bucket.host
  };
}

// Call from webNavigation.onCommitted (main_frame only) — a fresh navigation
// means a fresh page, so the entry list and request count both reset rather
// than carrying over from a page the user has since left.
export function clearMatrixOnNavigation(tabId) {
  const bucket = _tabs.get(tabId);
  if (!bucket) return;
  bucket.entries.clear();
  bucket.requestCount = 0;
}

// Call from tabs.onRemoved — releases the bucket entirely so closed tabs
// never leak memory in _tabs, and notifies any open panel to close itself.
export function clearMatrixOnTabClosed(tabId) {
  const wasTracked = _tabs.has(tabId);
  stopMatrix(tabId);
  if (wasTracked) _notifyPanel(tabId, "tab_closed");
}

// Watchdog: call once on SW boot. Kills any orphan bucket whose timer somehow
// didn't fire (e.g. a SW restart lost the setTimeout handle for an in-memory
// bucket) — belt-and-suspenders fallback, same rationale and shape as the
// retired core/block-monitor.js's startWatchdog(). In this module's current
// in-memory-only design a SW restart also wipes `_tabs` itself, so this
// shouldn't actually be reachable today; kept as a second line of defense
// against a future change to that assumption.
export function startMatrixWatchdog() {
  if (_watchdogTimer) clearInterval(_watchdogTimer);
  _watchdogTimer = setInterval(function() {
    _tabs.forEach(function(bucket, tabId) {
      const elapsed = Date.now() - bucket.startTime;
      if (elapsed > MATRIX_DURATION) _timeoutMatrix(tabId);
    });
  }, MATRIX_DURATION);
}
