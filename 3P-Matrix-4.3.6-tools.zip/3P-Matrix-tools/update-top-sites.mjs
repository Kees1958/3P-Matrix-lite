#!/usr/bin/env node
// ── tools/update-top-sites.mjs ───────────────────────────────────────────────────
// Rebuilds lib/downloadsentinel/util/TopSitesFilter.default.js — the Bloom filter of the web's most
// popular registered domains used by the look-alike check (LookalikeDomainCheck test 1 + test 3) —
// from the latest Chrome UX Report (CrUX) top-1M origins list, and records the update in data-sources.json.
//
// When: once per MINOR release (4.2 → 4.3), not for patches (4.3.1 → 4.3.2) — check-list-freshness.mjs
// fails the suite on a minor bump until this has run (data-sources.json "updateOn": "minor").
//
// Method (4.3.0 — DownloadSentinel 3.2.0's build-top-sites-filter.mjs, project doc
// DS_ALIGNMENT_lookalike_and_lists.md §3; reproduces DS 3.2.0's shipped filter bit for bit — verified on
// the 202609 list: 80,140 entries):
//   origins with CrUX rank ≤ RANK_CUTOFF → hostname → registered domain with the EXTENSION'S OWN UrlUtils
//   (same PSL as at runtime) → distinct set ∪ every brand website (the extension's own Brands.default.js,
//   as listed) ∪ the shared government suffixes (gov-suffixes.json, build input from DS data/GovSuffixes.json)
//   → BloomFilter.sizeFor(n, FALSE_POSITIVE_RATE) → the extension's own BloomFilter.js.
//   Reusing the runtime modules guarantees the bits are queried with the identical hashes (C21).
//   4.2: the whole top 1M (≈ 760,000 domains, 1.2 MB); 4.3.0: top 100,000 + brands + gov (≈ 125 KB).
//
// Usage:  node update-top-sites.mjs [--extension ../3P-Matrix] [--input file.csv.gz|file.csv]
//         Without --input the list is downloaded from data-sources.json "source".
// Exit:   0 = written · 1 = refused (sanity guard) · 2 = did not run (download/parse/folder)
// ─────────────────────────────────────────────────────────────────────────────

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { gunzipSync } from "node:zlib";
import { join, resolve, dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

// ── Settings (one place) ─────────────────────────────────────────────────────
const HERE = dirname(fileURLToPath(import.meta.url));
const EXIT = Object.freeze({ OK: 0, REFUSED: 1, DID_NOT_RUN: 2 });
const LIST_ID = "top-sites";
const REGISTER_FILE = join(HERE, "data-sources.json");
const DEFAULT_EXTENSION = join(HERE, "..", "3P-Matrix");
const LIB_UTIL = join("lib", "downloadsentinel", "util");
const FALSE_POSITIVE_RATE = 0.01;               // as the shipped filter (and DownloadSentinel) uses
const RANK_CUTOFF = 100000;                     // CrUX rank bucket kept (DS 3.2.0 / DS_ALIGNMENT §3)
const MIN_ENTRIES = 75000;                      // guard: refuse a truncated or wrong download (202609: 80,140)
const GOV_SUFFIXES_FILE = join(HERE, "gov-suffixes.json");   // shared government suffixes (build input only)
const MUST_CONTAIN = Object.freeze(["google.com", "wikipedia.org", "github.com", "amazon.com"]);
const CSV_HEADER = "origin,rank";
const GZIP_MAGIC = Object.freeze([0x1f, 0x8b]);
const GZIP_FLAG_OFFSET = 3, GZIP_FNAME_BIT = 0x08, GZIP_FNAME_OFFSET = 10;   // RFC 1952 header
const RELEASE_RE = /(\d{6})\.csv/;              // CrUX monthly release name, e.g. 202609.csv
const VERSION_MINOR_RE = /^(\d+\.\d+)/;
const JSON_INDENT = 2;

function didNotRun(msg) { console.error(`update-top-sites: DID NOT RUN — ${msg}`); process.exit(EXIT.DID_NOT_RUN); }
function refuse(msg) { console.error(`update-top-sites: REFUSED — ${msg}`); process.exit(EXIT.REFUSED); }
function arg(name) { const i = process.argv.indexOf(`--${name}`); return i === -1 ? null : process.argv[i + 1]; }

function isGzip(buf) { return buf[0] === GZIP_MAGIC[0] && buf[1] === GZIP_MAGIC[1]; }

// The CrUX mirror stores the release month as the gzip's original file name ("202609.csv").
function gzipReleaseName(buf) {
  if (!isGzip(buf) || !(buf[GZIP_FLAG_OFFSET] & GZIP_FNAME_BIT)) return "";
  const end = buf.indexOf(0, GZIP_FNAME_OFFSET);
  const m = RELEASE_RE.exec(buf.subarray(GZIP_FNAME_OFFSET, end).toString("latin1"));
  return m ? m[1] : "";
}

async function readSource(register) {
  const input = arg("input");
  if (input) {
    if (!existsSync(input)) didNotRun(`input not found: ${input}`);
    return readFileSync(input);
  }
  try {
    const res = await fetch(register.source);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return Buffer.from(await res.arrayBuffer());
  } catch (e) {
    didNotRun(`download failed (${e.message}) — download ${register.source} yourself and pass --input <file>`);
  }
  return null;                                   // unreachable (didNotRun exits)
}

function render(data, meta) {
  return `"use strict";

/**
 * TopSitesFilter.default.js — GENERATED FILE. Do not hand-edit; rebuild with
 * 3P-Matrix-tools/update-top-sites.mjs (once per minor release — data-sources.json).
 *
 * Source:  Chrome UX Report (CrUX) origins ranked ≤ ${RANK_CUTOFF}, release ${meta.release || "unknown"},
 *          + every brand website (Brands.default.js) + the shared government suffixes
 *          ${meta.source}
 * Licence: CrUX datasets by Google are licensed under a Creative Commons Attribution 4.0
 *          International License (https://developer.chrome.com/docs/crux/methodology).
 * Content: ${data.entryCount} distinct registered domains, Bloom filter at a ${data.falsePositiveRate} false-positive rate.
 * Generated: ${meta.generatedAt}
 */
export const TopSitesFilterDefault = ${JSON.stringify(data, null, 4)};
`;
}

async function main() {
  const ext = resolve(arg("extension") || DEFAULT_EXTENSION);
  if (!existsSync(join(ext, "manifest.json"))) didNotRun(`not an extension folder: ${ext}`);
  let registerFile;
  try { registerFile = JSON.parse(readFileSync(REGISTER_FILE, "utf8")); } catch (e) { didNotRun(`cannot read ${REGISTER_FILE}: ${e.message}`); }
  const register = registerFile.lists && registerFile.lists[LIST_ID];
  if (!register) didNotRun(`no "${LIST_ID}" entry in data-sources.json`);

  let BloomFilter, UrlUtils, BrandsDefault, govSuffixes;
  try {
    ({ BloomFilter } = await import(pathToFileURL(join(ext, LIB_UTIL, "BloomFilter.js")).href));
    ({ UrlUtils } = await import(pathToFileURL(join(ext, LIB_UTIL, "UrlUtils.js")).href));
    ({ BrandsDefault } = await import(pathToFileURL(join(ext, LIB_UTIL, "Brands.default.js")).href));
  } catch (e) { didNotRun(`cannot import the extension's BloomFilter/UrlUtils/Brands: ${e.message}`); }
  try { govSuffixes = JSON.parse(readFileSync(GOV_SUFFIXES_FILE, "utf8")); } catch (e) { didNotRun(`cannot read ${GOV_SUFFIXES_FILE}: ${e.message}`); }

  const raw = await readSource(register);
  const release = gzipReleaseName(raw);
  const text = (isGzip(raw) ? gunzipSync(raw) : raw).toString("utf8");
  const lines = text.split(/\r?\n/);
  if (lines[0].trim() !== CSV_HEADER) didNotRun(`unexpected CSV header "${lines[0].trim()}" (expected "${CSV_HEADER}")`);

  const domains = new Set();
  for (const line of lines.slice(1)) {
    const [origin, rank] = line.split(",");
    if (!origin || !(Number(rank) <= RANK_CUTOFF)) continue;
    let host;
    try { host = new URL(origin).hostname.toLowerCase(); } catch { continue; }   // malformed row: skip
    const rd = UrlUtils.getRegisteredDomain(host);
    if (rd) domains.add(rd);
  }
  for (const brand of BrandsDefault) for (const website of brand.domains) domains.add(website);   // as listed (DS 3.2.0)
  for (const suffix of govSuffixes) domains.add(suffix);
  if (domains.size < MIN_ENTRIES) refuse(`only ${domains.size} domains (expected ≥ ${MIN_ENTRIES}) — truncated download?`);

  const { size, numHashes } = BloomFilter.sizeFor(domains.size, FALSE_POSITIVE_RATE);
  const filter = BloomFilter.create(size, numHashes);
  for (const d of domains) filter.add(d);
  const missing = MUST_CONTAIN.filter((d) => !filter.has(d));
  if (missing.length) refuse(`sanity check failed — not in the new filter: ${missing.join(", ")}`);

  const data = { size, numHashes, entryCount: domains.size, falsePositiveRate: FALSE_POSITIVE_RATE, bitsBase64: filter.toBase64() };
  const generatedAt = new Date().toISOString();
  const target = join(ext, register.file);
  writeFileSync(target, render(data, { release, source: register.source, generatedAt }));

  const manifest = JSON.parse(readFileSync(join(ext, "manifest.json"), "utf8"));
  const versionMinor = (VERSION_MINOR_RE.exec(manifest.version) || [])[1] || manifest.version;
  const previous = { release: register.sourceRelease, entries: register.entries };
  Object.assign(register, { sourceRelease: release || "unknown", entries: domains.size, updatedForVersion: versionMinor, updatedAt: generatedAt.slice(0, 10) });
  writeFileSync(REGISTER_FILE, JSON.stringify(registerFile, null, JSON_INDENT) + "\n");

  console.log(`update-top-sites: wrote ${register.file} — CrUX ${release || "?"} (was ${previous.release}), ` +
              `${domains.size} domains (was ${previous.entries}), recorded for ${versionMinor}`);
  process.exit(EXIT.OK);
}

await main();
