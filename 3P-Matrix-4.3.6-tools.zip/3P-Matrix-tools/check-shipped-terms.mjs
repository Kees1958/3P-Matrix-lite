#!/usr/bin/env node
// ── tools/check-shipped-terms.mjs ────────────────────────────────────────────────
// Two guards on the shipped extension (audit 2026-10-19, finding 4):
//
// 1. LOG PREFIX IN SYNC — the MAIN-world security scripts (security/*.js) run inside the web page
//    and cannot import data/constants.js, so each one that logs declares its own copy:
//        const LOG_PREFIX = '[3PMCF]';
//    This check imports the real LOG_PREFIX from data/constants.js (single source of truth) and
//    fails when a script that writes to the console has no declaration or a different value.
//
// 2. NO uBD-ONLY TERMS — 3P Matrix took code from uBlock Stripped Dynamic (uBD). Exemption syntax
//    and identity strings that exist only in uBD must never be shown to a 3P Matrix user: they
//    point to features that do nothing here. Provenance comments ("ported from uBlock Stripped
//    Dynamic 10.2.1") are wanted for troubleshooting and are NOT flagged.
//    Deliberately kept (not matched by any pattern): window.eval.__uBolNoEvalInstalled in
//    sec-noeval.js — an internal install guard shared with uBD, so eval is wrapped once when both
//    extensions run; never shown to the user.
//
// Usage:  node check-shipped-terms.mjs --extension ../3P-Matrix
// Exit:   0 = pass · 1 = problem found · 2 = check could not run (C38)
// ─────────────────────────────────────────────────────────────────────────────

import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import { join, relative, resolve } from "node:path";
import { pathToFileURL } from "node:url";

// ── Settings (one place) ─────────────────────────────────────────────────────
const EXIT = Object.freeze({ OK: 0, FOUND: 1, DID_NOT_RUN: 2 });
const SECURITY_DIR = "security";
const SCAN_EXTENSIONS = Object.freeze([".js", ".html", ".css", ".json", ".md"]);
const PREFIX_DECL_RE = /const\s+LOG_PREFIX\s*=\s*(['"])(.*?)\1\s*;/;
const LOGS_TO_CONSOLE_RE = /\bconsole\.(?:log|info|warn|error|debug)\b/;
// uBD-only terms: [pattern, what it is, what 3P Matrix has instead]
const FORBIDDEN = Object.freeze([
  { re: /\$worryfree\b/g,               what: "uBD $worryfree exemption",         instead: "3P Matrix allow list" },
  { re: /\$saferregions\b/g,            what: "uBD $saferregions exemption",      instead: "safer regions panel (level 3)" },
  { re: /\[uBol\]/g,                    what: "uBol log prefix",                  instead: "LOG_PREFIX" },
  { re: /\[uBlock-Dynamic\]/g,          what: "uBD log prefix",                   instead: "LOG_PREFIX" },
  { re: /per-toggle allowlist/gi,       what: "uBD per-toggle allowlist",         instead: "allow list / untick the protection" },
  { re: /dashboard checkbox/gi,         what: "uBD dashboard wording",            instead: "popup Protections list" }
]);

function didNotRun(msg) {
  console.error(`check-shipped-terms: DID NOT RUN — ${msg}`);
  process.exit(EXIT.DID_NOT_RUN);
}

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i === -1 ? null : process.argv[i + 1];
}

function listFiles(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) out.push(...listFiles(p));
    else if (SCAN_EXTENSIONS.some((ext) => name.endsWith(ext))) out.push(p);
  }
  return out.sort();
}

function lineOf(text, index) { return text.slice(0, index).split("\n").length; }

async function main() {
  const root = arg("extension");
  if (!root || !existsSync(join(root, "manifest.json"))) didNotRun("missing or invalid --extension <folder>");
  if (!existsSync(join(root, SECURITY_DIR))) didNotRun(`no ${SECURITY_DIR}/ folder`);
  let expected;
  try {
    ({ LOG_PREFIX: expected } = await import(pathToFileURL(resolve(root, "data/constants.js")).href));
  } catch (e) { didNotRun(`cannot import data/constants.js: ${e.message}`); }
  if (typeof expected !== "string" || !expected) didNotRun("data/constants.js exports no LOG_PREFIX");

  const problems = [];

  // 1. Log prefix copies
  for (const path of listFiles(join(root, SECURITY_DIR)).filter((p) => p.endsWith(".js"))) {
    const rel = relative(root, path);
    const text = readFileSync(path, "utf8");
    const decl = text.match(PREFIX_DECL_RE);
    if (!decl) {
      if (LOGS_TO_CONSOLE_RE.test(text)) problems.push(`${rel}: writes to the console but declares no LOG_PREFIX`);
      continue;
    }
    if (decl[2] !== expected) problems.push(`${rel}:${lineOf(text, decl.index)}: LOG_PREFIX '${decl[2]}' ≠ constants.js '${expected}'`);
  }

  // 2. uBD-only terms anywhere in the shipped extension
  for (const path of listFiles(root)) {
    const rel = relative(root, path);
    const text = readFileSync(path, "utf8");
    for (const f of FORBIDDEN) {
      for (const m of text.matchAll(f.re)) problems.push(`${rel}:${lineOf(text, m.index)}: ${f.what} "${m[0]}" — use ${f.instead}`);
    }
  }

  if (problems.length) {
    console.error(`check-shipped-terms: FAIL — ${problems.length} problem(s):`);
    for (const p of problems) console.error("  " + p);
    process.exit(EXIT.FOUND);
  }
  console.log(`check-shipped-terms: PASS — LOG_PREFIX '${expected}' in sync, no uBD-only terms`);
  process.exit(EXIT.OK);
}

await main();
