# 3P Matrix — content firewall — changelog

(Started with 4.5.4: earlier docs packages carried no CHANGELOG.md. Technical detail for 4.5.4 is in
PERF_4.5.3_chrome_engine_and_proposals.md section 6 and the principles doc, v13.)

## 5.0.1
- Wording fix: the VirusTotal status line ("VirusTotal API key saved — …") now says it checks "the links (URL's) of executable downloads" instead of the vaguer "download addresses."

## 5.0.0
- **Removed: "Block inline scripts (strict content policy)"** (was protection 32, level 4–5 only, outside safer regions). Its strict script-src CSP had no way to tell a site's own legitimate inline `<script>` tags apart from an injected one — both got blocked, so it broke most sites it ran on instead of protecting them. If you had it on, nothing further is blocked by it; everything else at levels 4–5 (WebSocket/WebTransport/WebAssembly blocking, protections 29–31) is unchanged. Major version bump because this removes an enforced protection, not just a UI change.

## 4.7.6
- Accessibility pass on the dark theme: raised `--dim` (used for de-emphasized hint text throughout Options) from a contrast ratio that only barely cleared the WCAG AA minimum to one with real headroom; fixed one leftover spot (an "empty" checkmark in the Show Matrix panel) that used a divider color as text and was nearly invisible.
- Added `docs/STYLE_GUIDE.md`: every text/background color pairing in the UI, computed against the WCAG contrast formula rather than eyeballed, plus a regression checklist for any new color choice.

## 4.7.1 – 4.7.5
- Protections Panel layout and density pass: the Download Protection Options tab now fits a normal laptop screen without scrolling; related controls (DNS-check note, VirusTotal key row, false-positive slider and its explanation, trusted-domains block) were each tightened onto fewer lines; the redundant "Check at VirusTotal" checkbox was removed (saving/clearing the key already controls this); button ordering made consistent (secondary action left, Save right) throughout.

## 4.7.0
- **New: Block pasting a sign-in address into a website** (protection 15, every site from level 2) and **Warn when a site sends you to enter a sign-in code** (protection 16) — both target device-code and consent-phishing flows.
- **New: Fake sign-in window check (Browser-in-the-Browser)** (protection 28, every site from level 2) — catches a fake "Sign in with Google/Microsoft" popup window drawn to look like a real browser chrome.
- ClickFix protection (8) gains a visible warning, macOS/Linux patterns, and two levels instead of one.
- **New "Level 4–5 only" group, outside safer regions**: Block third-party WebSocket connections (29), Block third-party WebTransport connections (30), Block third-party WebAssembly (31), and (removed in 5.0.0) Block inline scripts (32). These, plus every existing "outside safer regions" protection, now also apply on a known high-risk site regardless of your level slider.
- Protections renumbered (15–25 → 17–27) to make room for the above; your ticks carry over.

## 4.6.0
- **New: Block exfiltrating (phishing) data to messaging bots** (protection 11, every site from level 2). Phishing pages send the passwords and card details you type to a Telegram bot, a Discord webhook or a Slack webhook. That transfer is now blocked, and the page gets the red warning "This page tried to send your data away", naming the channel.
- **New: Block exfiltrating (phishing) data to web services** (protection 24, outside safer regions from level 3). The same for form-to-email services and Power Automate workflows, which ordinary sites also use, hence only outside safer regions.
- In both warnings, **Go back** leaves the site completely: it skips the phishing site's own earlier pages (a fake login is often two pages of one site) and opens a new tab when nothing else is left. Nothing about the sites you visited is kept.
- **New: Warn when a password form sends to another site** (protection 14, every site from level 2). A login form that would send your password to a different website is held, and you choose Go back or Continue. Sign-in services (Google, Microsoft, DigiD …), payment services and sites you trust are exempt. Forms without a password field are never touched.
- **New: Block notification prompts that appear without a click** (protection 18, outside safer regions from level 3). Fake "click Allow to continue" pages ask the moment they load; that request is now answered without showing Chrome's prompt. A site that asks after you press its button works as before.
- **Protection 3 is now "Block browser-locker scams (popups, keyboard lock)"**. Besides the endless popups, fake "your PC is infected" pages can no longer: lock the keyboard (Esc always works); go fullscreen again after you have left it (a video player's own fullscreen button still works); show "Leave site?" unless you typed something on the page; keep you on the page with fake history entries (one press on Back gets you out).
- The protections are renumbered: 11 → 12, 12 → 13, 13–15 → 15–17, 16 → 19, 17–20 → 20–23, 21 → 25. Your ticks carry over.
- Data lists refreshed for 4.6: Public Suffix List, popular sites (CrUX September 2026), HaGeZi abused TLDs (5 November 2026) and the free-hosting / dynamic-DNS list.
- Removed as scheduled: the one-time 4.4.5 conversion of site locks on shared hosting suffixes.

## 4.5.9
- GitHub release downloads are now recognised as "currently used to deliver malware" even when GitHub redirects them to an address without a file extension: the link you clicked is checked as well as the final address (as DownloadSentinel already did).
- The "Download ZIP" false-alarm note and the signal count at the top no longer count lines that are shown only as "normal for this kind of download".

## 4.5.8
- The two DNS checks now default to Control D (first) and DNS4EU Protective (second): together they block more malware than Quad9 + Cloudflare. The same pair applies in every region, France included.
- If you never changed your DNS checks, the update moves you to the new pair once. A pair you picked yourself is kept. (Someone who deliberately picked exactly the old default looks the same as someone who never changed it, and is moved too — pick it again in Options to keep it.)
- A file without an extension from a file-sharing site is now rated "Probably Suspicious" from 32 MB (was 50 MB).
- From 650 MB, such a file gets a stronger warning: "large downloads are often used by malware to evade AV detection". It replaces the separate "exceeds VirusTotal maximum" line for that file, so the same fact is not counted twice. Other large downloads keep the VirusTotal line as before.
- A file from a GitHub/GitLab host that is "currently used to deliver malware" no longer also shows the file-sharing platform line (both said the same thing about the host), and the verdict at the top now matches the score instead of sometimes saying "probably safe".
- That warning now weighs −30 instead of −40: on its own it is "Probably Inconclusive" for a download (the warning still opens); it is a minimum, so the verdict only gets worse when other signals already score lower on their own. For sites: orange badge; the dialog opens from level 2 (Medium) up.

## 4.5.7
- Built-in whitelist: 35 entries added from uBlock Stripped Dynamic's list — meeting apps (Zoom, Google Meet, Jitsi, GoTo …), sign-in (Google, DigiD, eHerkenning, BankID, MitID, itsme, Duo, PingOne) and payment (iDEAL, Mercado Pago, Brazilian banks and acquirers).
- 46 suggested entries rejected, each with its reason (chat and file-upload platforms, closed services, whole game-publisher sites, government portals, messaging apps).

## 4.5.6
- Built-in whitelist reviewed entry by entry: Discord (a chat platform whose file hosts deliver malware), itch.io, Steam Community, OpenAI, FingerprintJS, an insurer and an analytics service removed; several entries moved to the right category.
- Downloads from Discord are checked again.
- Visiting a site that is merely misused for malware delivery (Discord, Telegram, bit.ly, Google Drive …) no longer shows the suspicious-site warning; sites someone created on such platforms still do, and downloads from them stay checked.
- A large file (50 MB or more) without an extension from a file-sharing site is now rated "Probably Suspicious": such files are often padded or packed malware.
- The popup's "Trusted:" line now follows the whitelist's own categories.
- The whitelist is available as JSON (docs: builtin-whitelist.json) for DownloadSentinel and uBlock Stripped Dynamic.

## 4.5.5
- Blocked downloads are now paused instead of deleted: "Download anyway" continues the same download (this also works for SharePoint/OneDrive folder downloads), "OK, cancel" or closing the notice deletes it.
- The blocked-download notice keeps working however long it stays open.
- At levels 1–3 a trusted download domain now also covers files the trusted site serves from another server (for example SharePoint zips); at levels 4–5 only the file's own server counts.
- Options explains at which levels the trusted domains lift the download block.

## 4.5.4
- Faster and lighter: the extension wakes up less often, starts faster, and no longer rewrites its rules when a setting that does not affect them is saved.
- Pages are checked against fewer content-script patterns; the suspicious-site warning appears sooner.
- The badge count, risk colour and "Continue once" are kept while the browser stays open.
- Public Suffix List refreshed; every bundled list can now be rebuilt with this project's own tools.
- Backup files from 0.1.x/0.2.0 and Show Matrix overrides saved by 4.2.2 or older are no longer converted.
