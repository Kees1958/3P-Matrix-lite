// ── ui/warning.js — warning dialog controller ─────────────────────────────────
// Shows the suspicious site (from ?u=), asks the service worker for the full
// stage 1 + stage 2 evaluation, and sends the user's choice back.
// 4.6.0: ?x=<channel id> (data/exfil-channels.js) — the page tried to send data to a phishing channel and 3P Matrix
// blocked it: red look, the reason as the first signal, and "Go back" leaves the site (the service worker decides
// that from this page's own URL, C28).
// All site text goes into the DOM via textContent.
// ─────────────────────────────────────────────────────────────────────────────

import * as M from "../data/message-types.js";
import { SEVERITY, ICON_DIR, LOG_PREFIX, WARNING_TARGET_PARAM, WARNING_REASON_PARAM, LEVEL, LEVEL_INFO, ICON_UI_SIZE } from "../data/constants.js";
import { EXFIL_CHANNEL_BY_ID } from "../data/exfil-channels.js";
import { fillDerivedText } from "./derived-text.js";
import { showError, releaseStatus } from "./status-line.js";

// ── Severity presentation (single table) ─────────────────────────────────────
// Look per severity = the level look it mirrors (data/constants.js LEVEL_INFO: orange brick wall
// for "suspicious", red for "phishing") — no colour or icon name typed here (finding 14).
const SUSPECT_LOOK  = LEVEL_INFO[LEVEL.HIGH - 1];
const PHISHING_LOOK = LEVEL_INFO[LEVEL.STRICT - 1];
const PHISHING_COLOR = "var(--block)";        // ui/common.css token (readable red on the dark dialog)
const SEVERITY_VIEW = Object.freeze({
  [SEVERITY.SUSPECT]: {
    color: SUSPECT_LOOK.color, icon: SUSPECT_LOOK.icon,
    title: "This site needs your attention",
    intro: "The address shows signs that are common on malware and phishing sites. Don’t provide sensitive information or install something without double checking."
  },
  [SEVERITY.PHISHING]: {
    color: PHISHING_COLOR, icon: PHISHING_LOOK.icon,
    title: "This site may be trying to trick you",
    intro: "The address shows strong signs that it is a scam, trying to trick you into providing sensitive information or installing something. It looks like malware or phishing!"
  }
});

// 4.6.0: the exfiltration view — text per channel built from the channel's own label (no typed copy per channel).
function exfilView(channel) {
  return {
    title: "This page tried to send your data away",
    intro: `Phishing pages send passwords and card details they collect to ${channel.label}. 3P Matrix blocked it. Don’t enter anything on this page.`,
    signal: `This page tried to send data to ${channel.label} — typical of a phishing page`
  };
}

function $(id) { return document.getElementById(id); }
const params = new URLSearchParams(location.search);
const target = params.get(WARNING_TARGET_PARAM) || "";
const exfilChannel = EXFIL_CHANNEL_BY_ID[params.get(WARNING_REASON_PARAM)] || null;   // unknown id → ordinary warning
let busy = false;                                         // guard: one action at a time

function setButtons(disabled) {
  ["btnBack", "btnTrust", "btnContinue"].forEach((id) => { $(id).disabled = disabled; });
}

function showSeverity(sev) {
  const base = SEVERITY_VIEW[exfilChannel ? SEVERITY.PHISHING : sev] || SEVERITY_VIEW[SEVERITY.SUSPECT];
  const v = exfilChannel ? { ...base, ...exfilView(exfilChannel) } : base;
  document.documentElement.style.setProperty("--sev", v.color);
  $("warnIcon").src = `../${ICON_DIR}/${v.icon}_${ICON_UI_SIZE}.png`;
  $("warnTitle").textContent = v.title;
  $("warnIntro").textContent = v.intro;
  document.title = `3P Matrix — ${v.title}`;
}

function showSignals(list) {
  const all = exfilChannel ? [exfilView(exfilChannel).signal, ...list] : list;
  $("warnSignals").replaceChildren(...all.map((s) => { const li = document.createElement("li"); li.textContent = s; return li; }));
}

async function action(kind) {
  if (busy) return;
  busy = true;
  setButtons(true);
  try {
    const res = await chrome.runtime.sendMessage({ type: M.MSG_WARNING_ACTION, action: kind, url: target });
    if (!res || !res.ok) throw new Error(res && res.error);
  } catch (e) {
    showError($("warnStatus"), e, "That did not work");
    busy = false;                                         // release so the user can try again
    setButtons(false);
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  fillDerivedText(document);
  let host = "";
  try { host = new URL(target).host; } catch { /* malformed — leave empty */ }
  $("warnHost").textContent = host || target;
  showSeverity(SEVERITY.SUSPECT);
  showSignals([]);                                       // 4.6.0: the exfiltration reason shows before the score arrives

  $("btnBack").addEventListener("click", () => action(M.WARNING_ACTION.GO_BACK));
  $("btnTrust").addEventListener("click", () => action(M.WARNING_ACTION.TRUST));
  $("btnContinue").addEventListener("click", () => action(M.WARNING_ACTION.CONTINUE_ONCE));
  $("optionsLink").addEventListener("click", (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
  $("btnBack").focus();

  try {
    const res = await chrome.runtime.sendMessage({ type: M.MSG_EVALUATE_SITE, url: target });
    if (!res || !res.ok || !res.data) throw new Error(res && res.error || "not scorable");
    const r = res.data;
    showSeverity(r.severity === SEVERITY.NONE ? SEVERITY.SUSPECT : r.severity);
    $("warnScore").textContent = `risk score ${r.score}`;
    showSignals(r.signals);
  } catch (e) {
    $("warnScore").textContent = "score unavailable";
    console.warn(LOG_PREFIX, "warning: evaluate", e);     // visible: "score unavailable" above
  } finally {
    $("warnChecking").hidden = true;
  }
});

window.addEventListener("pagehide", releaseStatus);          // release status timers with the page
