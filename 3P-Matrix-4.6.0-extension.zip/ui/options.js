// ── ui/options.js — options page controller ───────────────────────────────────
// DNS check choice, allow list (= sites locked at level 1), download protection (protection 13 —
// DownloadSentinel's options: VirusTotal key, silent when probably safe, false-positive reduction,
// trusted download domains, warning page look; 4.3.0), settings backup.
// The VirusTotal key is write-only here: the model only says whether one is set (vtKeySet).
// 4.3.4 (DownloadSentinel 3.3.0 item 5): nothing is locked behind a VirusTotal key any more — every option
// works without one. (DS's "Trust AI downloads" category is not offered — removed in 4.3.6, user decision.)
// Every change round-trips through the service worker; every outcome — success or failure — is
// shown in that section's status line (ui/status-line.js), never left in the console only.
// ─────────────────────────────────────────────────────────────────────────────

import * as M from "../data/message-types.js";
import { DNS_NONE, VT_JOIN_URL, VT_API_KEY_RE, FP_LEVEL_ORDER, FP_LEVEL_HINT, AUTO_ALLOW_THRESHOLD_MIN,
         AUTO_ALLOW_THRESHOLD_MAX, TRUSTED_DOWNLOAD_DOMAINS_MAX, DOWNLOAD_DEFAULTS, DOWNLOAD_WARNING_TITLE_DEFAULT,
         DOWNLOAD_WARNING_TITLE_MAX, RGB_CHANNEL_MAX, DECIMAL_RADIX } from "../data/constants.js";
import { fillDerivedText, formatScore } from "./derived-text.js";
import { WarnPolicy } from "../lib/downloadsentinel/protection/WarnPolicy.js";   // 4.4.1: window threshold per FP level
import { showStatus, showError, releaseStatus } from "./status-line.js";

// ── Settings (one place) ─────────────────────────────────────────────────────
const EXPORT_FILE_NAME = "3p-matrix-settings.json";
const EXPORT_MIME = "application/json";
const EXPORT_JSON_INDENT = 2;
const RESET_CONFIRM_TEXT = "Reset every 3P Matrix setting to its default (the VirusTotal key included)?";
const VT_KEY_SET_PLACEHOLDER = "•••••••••••••••• (a key is saved — paste a new one to replace it)";
const VT_KEY_EMPTY_PLACEHOLDER = "Paste your VT API key (64 hex characters)…";
const TRUSTED_PLACEHOLDER = "e.g. example.com";
// 4.4.1 — status texts for the VirusTotal key (one place; the key has its own Save button, and the
// Downloads card's Save saves a typed key too — see saveTypedVtKey()).
const VT_KEY_STATUS = Object.freeze({
  SAVED:    "API key saved.",
  CLEARED:  "API key cleared.",
  EMPTY:    "please enter your API key",
  INVALID:  "invalid key — expected 64 hex characters",
  WITH_SETTINGS: "Download settings and API key saved."
});
const RGB_INPUTS = Object.freeze({ r: "colorR", g: "colorG", b: "colorB" });
const DOMAIN_RE = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$/i;   // DownloadSentinel's input check

// ── Page state (guarded: null until the first model arrives) ─────────────────
let model = null;                      // last options model

function $(id) { return document.getElementById(id); }

function send(type, extra = {}) {
  return chrome.runtime.sendMessage({ type, ...extra })
    .then((res) => { if (!res || !res.ok) throw new Error(res && res.error || "no response"); return res.data; });
}

function fillSelect(sel, value) {
  sel.replaceChildren(...model.providers.map((p) => {
    const o = document.createElement("option");
    o.value = p.id;
    o.textContent = p.host ? `${p.label} — ${p.host}` : p.label;
    o.selected = p.id === value;
    return o;
  }));
}

function render() {
  if (!model) return;
  fillSelect($("dnsFirst"), model.dns.first);
  fillSelect($("dnsSecond"), model.dns.second);
  $("allowList").value = model.allowList;
  renderDownloads();
}

// ── Download protection ──────────────────────────────────────────────────────
function trustedInput(i) { return $(`trusted_${i}`); }

function buildDownloadControls() {
  $("autoAllowThreshold").min = String(AUTO_ALLOW_THRESHOLD_MIN);
  $("autoAllowThreshold").max = String(AUTO_ALLOW_THRESHOLD_MAX);
  $("fpSlider").min = "0";
  $("fpSlider").max = String(FP_LEVEL_ORDER.length - 1);
  $("fpSlider").step = "1";
  $("fpLabels").replaceChildren(...FP_LEVEL_ORDER.map((lvl) => { const s = document.createElement("span"); s.textContent = lvl; return s; }));
  for (const id of Object.values(RGB_INPUTS)) { $(id).min = "0"; $(id).max = String(RGB_CHANNEL_MAX); }
  $("warningTitle").maxLength = DOWNLOAD_WARNING_TITLE_MAX;
  $("warningTitle").placeholder = DOWNLOAD_WARNING_TITLE_DEFAULT;
  const grid = $("trustedInputs");
  for (let i = 0; i < TRUSTED_DOWNLOAD_DOMAINS_MAX; i++) {
    const inp = document.createElement("input");
    inp.type = "text"; inp.id = `trusted_${i}`; inp.className = "text-input mono";
    inp.placeholder = TRUSTED_PLACEHOLDER; inp.spellcheck = false; inp.autocomplete = "off";
    inp.setAttribute("aria-label", `Trusted download domain ${i + 1}`);
    inp.addEventListener("input", () => inp.classList.toggle("invalid", !!inp.value.trim() && !DOMAIN_RE.test(inp.value.trim())));
    grid.append(inp);
  }
}


function showFpLevel(index) {
  const lvl = FP_LEVEL_ORDER[index] || DOWNLOAD_DEFAULTS.fpReductionLevel;
  [...$("fpLabels").children].forEach((s, i) => s.classList.toggle("active", i === index));
  $("fpHint").textContent = `${FP_LEVEL_HINT[lvl] || ""} ${WarnPolicy.windowHint(lvl, formatScore)}`.trim();
}

function showColorPreview() {
  const v = readColor();
  $("colorPreview").style.backgroundColor = `rgb(${v.r}, ${v.g}, ${v.b})`;
}

function isCustomLook(d) {
  const def = DOWNLOAD_DEFAULTS.warningColor;
  return d.warningTitle !== "" || Object.keys(RGB_INPUTS).some((ch) => d.warningColor[ch] !== def[ch]);
}

function fillLook(color, title) {
  for (const [ch, id] of Object.entries(RGB_INPUTS)) $(id).value = String(color[ch]);
  $("warningTitle").value = title;
  showColorPreview();
}

function renderDownloads() {
  const d = model.downloads;
  $("vtApiKeyInput").value = "";
  $("vtApiKeyInput").placeholder = d.vtKeySet ? VT_KEY_SET_PLACEHOLDER : VT_KEY_EMPTY_PLACEHOLDER;
  $("vtEnabled").checked = d.vtKeySet && d.vtEnabled;
  $("vtEnabled").disabled = !d.vtKeySet;
  $("silentWhenInconclusive").checked = d.silentWhenInconclusive;
  $("autoAllow").checked = d.autoAllow;
  $("autoAllowThreshold").value = String(d.autoAllowThreshold);
  $("autoAllowRow").hidden = !d.autoAllow;
  const fpIndex = Math.max(0, FP_LEVEL_ORDER.indexOf(d.fpReductionLevel));
  $("fpSlider").value = String(fpIndex);
  showFpLevel(fpIndex);
  for (let i = 0; i < TRUSTED_DOWNLOAD_DOMAINS_MAX; i++) { trustedInput(i).value = d.trustedDomains[i] || ""; trustedInput(i).classList.remove("invalid"); }
  const custom = isCustomLook(d);
  $("personalize").checked = custom;
  $("personalizeBox").hidden = !custom;
  fillLook(d.warningColor, d.warningTitle);
}

function readColor() {
  const out = {};
  for (const [ch, id] of Object.entries(RGB_INPUTS)) {
    const n = Number.parseInt($(id).value, DECIMAL_RADIX);
    out[ch] = Number.isInteger(n) ? Math.min(RGB_CHANNEL_MAX, Math.max(0, n)) : DOWNLOAD_DEFAULTS.warningColor[ch];
  }
  return out;
}

// The form as a settings patch, or an error text when an input is invalid (nothing is sent then).
function readDownloadForm() {
  const trusted = [];
  const bad = [];
  for (let i = 0; i < TRUSTED_DOWNLOAD_DOMAINS_MAX; i++) {
    const v = trustedInput(i).value.trim().toLowerCase();
    if (!v) continue;
    if (DOMAIN_RE.test(v)) trusted.push(v); else { bad.push(v); trustedInput(i).classList.add("invalid"); }
  }
  if (bad.length) return { error: `fix invalid domains first (format: domain.tld): ${bad.join(", ")}` };
  const personalize = $("personalize").checked;
  const threshold = Number.parseInt($("autoAllowThreshold").value, DECIMAL_RADIX);
  return {
    settings: {
      vtEnabled: $("vtEnabled").checked,
      silentWhenInconclusive: $("silentWhenInconclusive").checked,
      autoAllow: $("autoAllow").checked,
      autoAllowThreshold: Number.isInteger(threshold)
        ? Math.min(AUTO_ALLOW_THRESHOLD_MAX, Math.max(AUTO_ALLOW_THRESHOLD_MIN, threshold))
        : DOWNLOAD_DEFAULTS.autoAllowThreshold,
      fpReductionLevel: FP_LEVEL_ORDER[Number.parseInt($("fpSlider").value, DECIMAL_RADIX)] || DOWNLOAD_DEFAULTS.fpReductionLevel,
      trustedDomains: trusted,
      // Personalize unticked = back to the defaults (DownloadSentinel: stale hidden values are never saved).
      warningColor: personalize ? readColor() : { ...DOWNLOAD_DEFAULTS.warningColor },
      warningTitle: personalize ? $("warningTitle").value.trim() : DOWNLOAD_DEFAULTS.warningTitle
    }
  };
}

async function saveDownloads() {
  const form = readDownloadForm();
  if (form.error) { showError($("dlStatus"), new Error(form.error)); return; }
  try {
    const typedKey = await saveTypedVtKey();                  // 4.4.1: a typed key is never silently dropped
    if (typedKey === VT_TYPED.INVALID) return;                // keep the field as typed so it can be corrected
    model = await send(M.MSG_SET_DOWNLOAD_SETTINGS, { settings: form.settings });
    render();
    showStatus($("dlStatus"), typedKey === VT_TYPED.SAVED ? VT_KEY_STATUS.WITH_SETTINGS : "Download settings saved.");
  } catch (e) { showError($("dlStatus"), e); }
}

async function saveVtKey(clear) {
  const key = clear ? "" : $("vtApiKeyInput").value.trim();
  if (!clear && !key) { showError($("vtKeyStatus"), new Error(VT_KEY_STATUS.EMPTY)); return; }
  if (!clear && !VT_API_KEY_RE.test(key)) { showError($("vtKeyStatus"), new Error(VT_KEY_STATUS.INVALID)); return; }
  try {
    model = await send(M.MSG_SET_VT_KEY, { key });
    render();
    showStatus($("vtKeyStatus"), clear ? VT_KEY_STATUS.CLEARED : VT_KEY_STATUS.SAVED);
  } catch (e) { showError($("vtKeyStatus"), e); }
}

// 4.4.1 — the key field sits in the Downloads card but has its own message (MSG_SET_VT_KEY: a key can never be
// set through the settings form). Before, pressing the card's own Save left a typed key UNSAVED and render()
// then cleared the field — the key was silently lost. The card's Save now saves it as well.
// Returns "saved" | "none" (nothing typed) | "invalid" (rejected: the caller stops and keeps the typed text).
const VT_TYPED = Object.freeze({ SAVED: "saved", NONE: "none", INVALID: "invalid" });
async function saveTypedVtKey() {
  const key = $("vtApiKeyInput").value.trim();
  if (!key) return VT_TYPED.NONE;
  if (!VT_API_KEY_RE.test(key)) { showError($("vtKeyStatus"), new Error(VT_KEY_STATUS.INVALID)); return VT_TYPED.INVALID; }
  model = await send(M.MSG_SET_VT_KEY, { key });
  return VT_TYPED.SAVED;
}

async function saveVtEnabled() {
  try {
    model = await send(M.MSG_SET_DOWNLOAD_SETTINGS, { settings: { vtEnabled: $("vtEnabled").checked } });
    render();
    showStatus($("vtKeyStatus"), model.downloads.vtEnabled ? "VirusTotal check on." : "VirusTotal check off.");
  } catch (e) { showError($("vtKeyStatus"), e); }
}

function bindDownloadControls() {
  $("vtKeySave").addEventListener("click", () => saveVtKey(false));
  $("vtKeyClear").addEventListener("click", () => saveVtKey(true));
  $("vtApiKeyInput").addEventListener("keydown", (e) => { if (e.key === "Enter") saveVtKey(false); });
  $("vtEnabled").addEventListener("change", saveVtEnabled);
  $("vtJoinLink").addEventListener("click", (e) => { e.preventDefault(); chrome.tabs.create({ url: VT_JOIN_URL }); });
  $("autoAllow").addEventListener("change", () => { $("autoAllowRow").hidden = !$("autoAllow").checked; });
  $("fpSlider").addEventListener("input", () => showFpLevel(Number.parseInt($("fpSlider").value, DECIMAL_RADIX)));
  for (const id of Object.values(RGB_INPUTS)) $(id).addEventListener("input", showColorPreview);
  $("personalize").addEventListener("change", () => {
    const on = $("personalize").checked;
    $("personalizeBox").hidden = !on;
    if (!on) fillLook(DOWNLOAD_DEFAULTS.warningColor, DOWNLOAD_DEFAULTS.warningTitle);   // visibly back to defaults
  });
  $("dlSave").addEventListener("click", saveDownloads);
  $("dlRevert").addEventListener("click", () => { if (model) renderDownloads(); });
}

async function saveDns() {
  const wantedSecond = $("dnsSecond").value;
  try {
    model = await send(M.MSG_SET_DNS, { first: $("dnsFirst").value, second: wantedSecond });
    render();
    const cleared = model.dns.second === DNS_NONE && wantedSecond !== DNS_NONE;
    showStatus($("dnsStatus"), cleared ? "Second check cleared — it was the same as the first." : "Saved.");
  } catch (e) { showError($("dnsStatus"), e); }
}

async function saveAllowList() {
  try {
    model = await send(M.MSG_SET_ALLOW_LIST, { text: $("allowList").value });
    render();
    showStatus($("allowStatus"), "Allow list saved.");
  } catch (e) { showError($("allowStatus"), e); }
}

async function exportSettings() {
  let url = null;
  try {
    const data = await send(M.MSG_EXPORT_SETTINGS);
    url = URL.createObjectURL(new Blob([JSON.stringify(data.file, null, EXPORT_JSON_INDENT)], { type: EXPORT_MIME }));
    const a = document.createElement("a");
    a.href = url; a.download = EXPORT_FILE_NAME; a.click();
    showStatus($("ioStatus"), `Saved: ${data.summary}`);
  } catch (e) {
    showError($("ioStatus"), e, "Not saved");
  } finally {
    if (url) setTimeout(() => URL.revokeObjectURL(url), 0);    // release the blob on every path
  }
}

async function importSettings(e) {
  const file = e.target.files && e.target.files[0];
  e.target.value = "";                                      // allow choosing the same file again
  if (!file) return;
  try {
    model = await send(M.MSG_IMPORT_SETTINGS, { settings: JSON.parse(await file.text()) });
    render();
    showStatus($("ioStatus"), `Restored: ${model.summary}`);
  } catch (err) { showError($("ioStatus"), err, "Not restored"); }
}

async function resetSettings() {
  if (!confirm(RESET_CONFIRM_TEXT)) return;
  try {
    model = await send(M.MSG_RESET_SETTINGS);
    render();
    showStatus($("ioStatus"), "All settings reset.");
  } catch (e) { showError($("ioStatus"), e, "Not reset"); }
}

document.addEventListener("DOMContentLoaded", async () => {
  fillDerivedText(document);
  buildDownloadControls();
  bindDownloadControls();
  $("dnsFirst").addEventListener("change", saveDns);
  $("dnsSecond").addEventListener("change", saveDns);
  $("allowSave").addEventListener("click", saveAllowList);
  $("allowRevert").addEventListener("click", () => { if (model) $("allowList").value = model.allowList; });
  $("exportAll").addEventListener("click", exportSettings);
  $("importAll").addEventListener("click", () => $("importFile").click());
  $("importFile").addEventListener("change", importSettings);
  $("resetAll").addEventListener("click", resetSettings);
  try {
    model = await send(M.MSG_GET_OPTIONS);
    render();
  } catch (e) { showError($("dnsStatus"), e, "Could not load the settings"); }
});

window.addEventListener("pagehide", releaseStatus);          // release status timers with the page
