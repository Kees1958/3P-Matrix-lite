// ── background.js — 3P-Matrix-lite service worker (workflow orchestrator) ─────
//
// This file is a thin router and lifecycle manager only.
// All business logic lives in the modules imported below (each module also
// imports its own transitive dependencies — see the module files themselves).
//
// ── State overview ────────────────────────────────────────────────────────────
//   Persisted (chrome.storage.local, key = STORAGE_KEY):
//     Full state object — see DEFAULT_STATE in data/state-storage.js
//
// ── Message types handled ─────────────────────────────────────────────────────
//   GET_STATE        — returns current state + rule count
//   SET_STATE        — validates + saves new state, applies rules
//   ADD_SITE_RULE    — pins a per-site level override
//   REMOVE_SITE_RULE — removes a per-site level override
//   SET_ICON         — updates the toolbar icon
//   START_MATRIX       — begin Show Matrix observation for a tab
//   STOP_MATRIX        — release Show Matrix state for a tab
//   GET_MATRIX_DATA    — fetch current Show Matrix entries for a tab
//   SET_MATRIX_RULE    — set/clear a per-domain, per-type Matrix override
//   SET_MATRIX_DOMAIN_RULE — set/clear a per-domain override covering both frame+script
// ─────────────────────────────────────────────────────────────────────────────

// ── Load modules ──────────────────────────────────────────────────────────────
import { BUILTIN_DOMAINS, CDN_HOST_REGEX } from "./data/constants.js";
import {
  MSG_GET_STATE, MSG_SET_STATE, MSG_ADD_SITE_RULE, MSG_REMOVE_SITE_RULE, MSG_SET_ICON,
  MSG_START_MATRIX, MSG_STOP_MATRIX, MSG_GET_MATRIX_DATA, MSG_SET_MATRIX_RULE, MSG_SET_MATRIX_DOMAIN_RULE
} from "./data/message-types.js";
import { DEFAULT_STATE, loadState, saveState } from "./data/state-storage.js";
import { browserCountryTlds, majorMinor } from "./util/tld-utils.js";
import { buildRules } from "./core/rule-builder.js";
import { addSiteRule, removeSiteRule } from "./core/site-rules.js";
import { setMatrixRule, setMatrixDomainRule } from "./core/matrix-rules.js";
import { wouldBlock, getModeState, isBuiltinWhitelisted, isSignalDomain, getBuiltinCategory, getEffectiveLevel } from "./core/rule-classifier.js";
import {
  startMatrix, stopMatrix, getMatrixData, clearMatrixOnNavigation, clearMatrixOnTabClosed,
  startMatrixWatchdog
} from "./core/connection-matrix.js";

// ── Chrome API wrappers ───────────────────────────────────────────────────────
// These belong conceptually in a data/chrome-services.js but are small enough
// to live here until the extension grows to need that split.

// Updates the toolbar icon to reflect the current level (0-indexed icon filename).
function setIcon(level) {
  const idx = level - 1;
  try {
    chrome.action.setIcon({ path: {
      "16":  "icon_" + idx + "_16.png",
      "32":  "icon_" + idx + "_32.png",
      "48":  "icon_" + idx + "_48.png",
      "128": "icon_" + idx + "_128.png"
    }});
  } catch(e) {
    // Intentional: setIcon may throw if the SW is being torn down or the
    // extension is being reloaded; icon update is best-effort.
  }
}

// Enables Chrome's built-in per-tab blocked request badge count.
// Always enabled — the badge always shows regardless of any toggle.
function enableBadgeCount() {
  if (!chrome.declarativeNetRequest ||
      typeof chrome.declarativeNetRequest.setExtensionActionOptions !== "function") return;
  const result = chrome.declarativeNetRequest.setExtensionActionOptions({
    displayActionCountAsBadgeText: true
  });
  if (result && typeof result.catch === "function") {
    result.catch(function(e) {
      console.warn("[3PM] setExtensionActionOptions:", e && e.message);
    });
  }
}

// ── Migration: Domain whitelist → Matrix rules (one-time) ────────────────────
// The Domain whitelist tab/tab-panel/state.domains mechanism was retired once
// the interactive Show Matrix's Domain column made it redundant (a Matrix
// allow override achieves the same "always allow this domain" outcome, for
// both frame and script). Existing whitelisted domains are ported into
// state.matrixRules — as an "allow" override for both types — exactly once,
// guarded by state.domainsMigratedToMatrix so re-running this on every boot
// doesn't re-add anything a user has since deliberately changed to "block".
// Mutates and returns the same state object (matches this file's other
// state-shaping helpers, e.g. the Object.assign(...) boot patterns below).
function migrateDomainsToMatrixRules(s) {
  if (s.domainsMigratedToMatrix) return s;
  if (s.domains && s.domains.length) {
    if (!s.matrixRules) s.matrixRules = {};
    s.domains.forEach(function(d) {
      if (!s.matrixRules[d]) s.matrixRules[d] = {};
      // Only fill in what isn't already set — never clobber an override a
      // user may have already created through the Matrix itself before this
      // migration ran (shouldn't normally happen given the guard above, but
      // costs nothing to be defensive here).
      if (!s.matrixRules[d].frame)  s.matrixRules[d].frame  = "allow";
      if (!s.matrixRules[d].script) s.matrixRules[d].script = "allow";
    });
  }
  s.domainsMigratedToMatrix = true;
  return s;
}

// ── CDN regex support check (cached, checked once) ────────────────────────────
// DNR's regexFilter can reject a regex outright ("too complex" for its RE2-
// based matcher), and critically, updateDynamicRules() applies its whole
// batch atomically — if ONE rule fails validation, ALL rules fail, breaking
// every level's blocking, not just the CDN one. So this is checked and
// cached ONCE via chrome.declarativeNetRequest.isRegexSupported() before
// buildRules() is ever allowed to use CDN_HOST_REGEX; if unsupported for any
// reason, rule-builder.js falls back to the old, always-valid, looser
// urlFilter: "*cdn*" behavior instead — degraded precision, but never a
// broken ruleset.
let _cdnRegexSupported = null; // null = not yet checked

function checkCdnRegexSupport(cb) {
  if (_cdnRegexSupported !== null) { cb(_cdnRegexSupported); return; }
  if (!chrome.declarativeNetRequest || typeof chrome.declarativeNetRequest.isRegexSupported !== "function") {
    _cdnRegexSupported = false;
    cb(false);
    return;
  }
  chrome.declarativeNetRequest.isRegexSupported(
    { regex: CDN_HOST_REGEX, isCaseSensitive: false },
    function(result) {
      _cdnRegexSupported = !!(result && result.isSupported);
      if (!_cdnRegexSupported) {
        console.warn("[3PM] CDN host-scoped regex not supported by this Chrome version, falling back to the looser full-URL match:", result && result.reason);
      }
      cb(_cdnRegexSupported);
    }
  );
}

// ── applyState ────────────────────────────────────────────────────────────────
// Reads existing dynamic rules, replaces them all atomically with the new rule
// set built from state, then updates the icon.
// This is the single point where state changes are applied to Chrome DNR.
function applyState(s, cb) {
  checkCdnRegexSupport(function(cdnRegexSupported) {
    chrome.declarativeNetRequest.getDynamicRules(function(existing) {
      const removeIds = existing.map(function(r) { return r.id; });
      const addRules  = buildRules(s, cdnRegexSupported);
      chrome.declarativeNetRequest.updateDynamicRules(
        { removeRuleIds: removeIds, addRules: addRules },
        function() {
          if (chrome.runtime.lastError) {
            console.warn("[3PM] updateDynamicRules:", chrome.runtime.lastError.message);
            if (cb) cb(0);
            return;
          }
          setIcon(s.level);
          if (cb) cb(addRules.length);
        }
      );
    });
  });
}

// ── Boot helper ───────────────────────────────────────────────────────────────
// Shared boot sequence used by both onInstalled (update) and onStartup.
function bootFromStorage() {
  loadState(function(s) {
    migrateDomainsToMatrixRules(s);
    const boot = Object.assign({}, s, { level: s.startupLevel || 1 });
    chrome.action.setBadgeBackgroundColor({ color: "#666666" });
    enableBadgeCount();
    saveState(boot, function() { applyState(boot); });
  });
}

// ── Show Matrix — navigation hook ─────────────────────────────────────────────
// Fires when a tab commits to a new page. Clears the tab's Matrix entries —
// a fresh page load means a fresh connection list, not accumulation across
// navigations.
if (chrome.webNavigation && chrome.webNavigation.onCommitted) {
  chrome.webNavigation.onCommitted.addListener(function(details) {
    if (details.frameId !== 0) return; // top-level frame only
    clearMatrixOnNavigation(details.tabId);
  });
}

// ── Show Matrix — tab-closed guard ───────────────────────────────────────────
// Releases a tab's matrix bucket (and the shared listener, if it was the last
// tracked tab) the moment the tab is closed, so nothing lingers in memory.
if (chrome.tabs && chrome.tabs.onRemoved) {
  chrome.tabs.onRemoved.addListener(function(tabId) {
    clearMatrixOnTabClosed(tabId);
  });
}

// ── Lifecycle ─────────────────────────────────────────────────────────────────
// ── Boot watchdog ─────────────────────────────────────────────────────────────
startMatrixWatchdog();

chrome.runtime.onInstalled.addListener(function(details) {
  const currentVersion    = chrome.runtime.getManifest().version;
  const currentMajorMinor = majorMinor(currentVersion);

  if (details.reason === "install") {
    // Fresh install — detect browser country TLDs and seed built-in domains
    browserCountryTlds(function(countryTlds) {
      const merged = DEFAULT_STATE.tlds.slice();
      countryTlds.forEach(function(tld) {
        if (merged.indexOf(tld) === -1) merged.push(tld);
      });
      const initState = Object.assign({}, DEFAULT_STATE, {
        tlds:              merged,
        builtinDomains:    Object.assign({}, BUILTIN_DOMAINS),
        whitelistDropdown: { tld: true, domain: true },
        lastShownVersion:  currentMajorMinor,
        domainsMigratedToMatrix: true // nothing to migrate on a fresh install
      });
      chrome.action.setBadgeBackgroundColor({ color: "#666666" });
      enableBadgeCount();
      saveState(initState, function() { applyState(initState); });
    });
  } else {
    // Update / reload — reset to startupLevel, re-expand dropdowns on new major.minor,
    // and run the one-time Domain-whitelist migration.
    chrome.storage.session.clear(function() {
      loadState(function(s) {
        migrateDomainsToMatrixRules(s);
        const storedMajorMinor = majorMinor(s.lastShownVersion || "");
        const isNewMajorMinor  = storedMajorMinor !== currentMajorMinor;
        const boot = Object.assign({}, s, { level: s.startupLevel || 1 });
        if (isNewMajorMinor) {
          boot.whitelistDropdown = { tld: true, domain: true };
          boot.lastShownVersion  = currentMajorMinor;
        }
        chrome.action.setBadgeBackgroundColor({ color: "#666666" });
        enableBadgeCount();
        saveState(boot, function() { applyState(boot); });
      });
    });
  }
});

chrome.runtime.onStartup.addListener(bootFromStorage);

// ── Message router ────────────────────────────────────────────────────────────
// Thin router only — no business logic here. Each branch delegates immediately
// to a core or data function.
chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {

  if (msg.type === MSG_GET_STATE) {
    loadState(function(s) {
      chrome.declarativeNetRequest.getDynamicRules(function(rules) {
        sendResponse({ ok: true, state: s, ruleCount: rules.length });
      });
    });
    return true;
  }

  if (msg.type === MSG_SET_STATE) {
    const ns = Object.assign({}, DEFAULT_STATE, msg.state);
    if (ns.level < 1 || ns.level > 5)               ns.level        = 1;
    if (ns.startupLevel < 1 || ns.startupLevel > 5) ns.startupLevel = 1;
    if (!ns.siteRules)    ns.siteRules    = {};
    if (!ns.siteRulesOrder) ns.siteRulesOrder = Object.keys(ns.siteRules);
    saveState(ns, function() {
      applyState(ns, function(count) {
        sendResponse({ ok: true, ruleCount: count });
      });
    });
    return true;
  }

  if (msg.type === MSG_ADD_SITE_RULE) {
    loadState(function(s) {
      addSiteRule(s, msg.host, msg.level);
      saveState(s, function() {
        applyState(s, function(count) {
          sendResponse({ ok: true, ruleCount: count });
        });
      });
    });
    return true;
  }

  if (msg.type === MSG_REMOVE_SITE_RULE) {
    loadState(function(s) {
      removeSiteRule(s, msg.host);
      saveState(s, function() {
        applyState(s, function(count) {
          sendResponse({ ok: true, ruleCount: count });
        });
      });
    });
    return true;
  }

  if (msg.type === MSG_SET_ICON) {
    setIcon(msg.level);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === MSG_START_MATRIX) {
    startMatrix(msg.tabId, msg.host, function(result) {
      if (result && result.ok) {
        // Always reloads. The listener is already registered (startMatrix ran
        // above), so it survives this reload and sees requests from the very
        // start of the fresh page load. lastError is checked explicitly rather
        // than ignored — reload can silently fail on restricted pages
        // (chrome://, the Web Store, etc.) or an already-closed tab, and that
        // failure would otherwise be invisible.
        chrome.tabs.reload(msg.tabId, {}, function() {
          if (chrome.runtime.lastError) {
            console.warn("[3PM] Show Matrix reload failed:", chrome.runtime.lastError.message);
          }
        });
      }
      sendResponse(result);
    });
    return true;
  }

  if (msg.type === MSG_STOP_MATRIX) {
    stopMatrix(msg.tabId);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === MSG_GET_MATRIX_DATA) {
    const data = getMatrixData(msg.tabId);
    if (!data.entries.length) {
      sendResponse({ ok: true, data: data });
      return true;
    }
    // Enrich each entry with its current frame/script disposition — computed
    // here (not inside connection-matrix.js) to keep that module decoupled
    // from rule-classifier.js/state, per its own design (full-visibility
    // observation, not filtered). sampleUrl was only ever needed for this
    // computation, so it's stripped before responding — the panel doesn't
    // need it, and there's no reason to leak an internal implementation
    // detail into the UI-facing payload.
    loadState(function(s) {
      const effLevel = getEffectiveLevel(s, data.host);
      data.entries.forEach(function(entry) {
        if (entry.types.indexOf("frame") !== -1) {
          const blocked = wouldBlock(entry.domain, "frame", entry.sampleUrl, s, data.host);
          const overridden = !!(s.matrixRules && s.matrixRules[entry.domain] && s.matrixRules[entry.domain].frame);
          entry.frameDisposition = { effective: blocked ? "block" : "allow", overridden: overridden };
        }
        if (entry.types.indexOf("script") !== -1) {
          const blocked = wouldBlock(entry.domain, "script", entry.sampleUrl, s, data.host);
          const overridden = !!(s.matrixRules && s.matrixRules[entry.domain] && s.matrixRules[entry.domain].script);
          entry.scriptDisposition = { effective: blocked ? "block" : "allow", overridden: overridden };
        }

        // Internal whitelist — new dedicated column, separate from Mode now.
        // Level-aware: at Level 2, the signal list functions as a REAL
        // whitelist (see rule-classifier.js's wouldBlock() step 3b), so a
        // signal domain there gets the same green/grey treatment as a
        // built-in one. At other levels the signal list stays purely
        // informational (yellow) — never auto-allowed, the user enables it
        // by hand. Four states: green (auto-allowed, no override), grey
        // (auto-allowed but a per-type override exists — the auto-allow
        // status is no longer the sole/deciding factor for at least one
        // type, so still-fully-green would be misleading), yellow (on the
        // signal list at a level where it's informational only), empty
        // (neither).
        const builtin = isBuiltinWhitelisted(entry.domain, s);
        const signal  = !builtin && isSignalDomain(entry.domain);
        const signalActsAsWhitelist = signal && effLevel === 2;
        const rule = s.matrixRules && s.matrixRules[entry.domain];
        const hasAnyOverride = !!(rule && (rule.frame || rule.script));
        entry.internalWhitelist = (builtin || signalActsAsWhitelist)
          ? (hasAnyOverride ? "grey" : "green")
          : (signal ? "yellow" : "empty");
        // Category text ("Payment — core / international", etc.) for the
        // column's explanatory tooltip — null if neither built-in nor signal.
        entry.internalWhitelistCategory = (builtin || signal) ? getBuiltinCategory(entry.domain, s) : null;

        // Mode — a single combined signal per domain now, not split into
        // Allow/Block columns, and no longer level-color-coded (fixed
        // green/red/grey, same visual language as SCRIPT/FRAME). See
        // core/rule-classifier.js's getModeState().
        const ms = getModeState(entry.domain, entry.sampleUrl, s, data.host);
        entry.mode = !ms.applicable ? "empty" : (ms.overridden ? "grey" : ms.winnerSide);
        delete entry.sampleUrl;
      });
      sendResponse({ ok: true, data: data });
    });
    return true;
  }

  if (msg.type === MSG_SET_MATRIX_RULE) {
    loadState(function(s) {
      setMatrixRule(msg.domain, msg.resourceType, msg.action, s, applyState, function(result) {
        sendResponse(result);
      });
    });
    return true;
  }

  if (msg.type === MSG_SET_MATRIX_DOMAIN_RULE) {
    loadState(function(s) {
      setMatrixDomainRule(msg.domain, msg.action, s, applyState, function(result) {
        sendResponse(result);
      });
    });
    return true;
  }

  sendResponse({ ok: false, error: "Unknown message type: " + msg.type });
});
