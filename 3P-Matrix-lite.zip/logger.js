// ── Constants ─────────────────────────────────────────────────────────────────
var LOG_DURATION_MS = 5 * 60 * 1000;   // 5 minutes
var POLL_INTERVAL   = 2000;             // poll every 2 seconds

// ── DOM refs ──────────────────────────────────────────────────────────────────
var timerBadge   = document.getElementById('timerBadge');
var stopBtn      = document.getElementById('stopBtn');
var logBody      = document.getElementById('logBody');
var sessionEnded = document.getElementById('sessionEnded');
var tableWrap    = document.getElementById('tableWrap');
var footerBar    = document.getElementById('footerBar');

var statTotal   = document.getElementById('statTotal');
var statScripts = document.getElementById('statScripts');
var statFrames  = document.getElementById('statFrames');
var statIp      = document.getElementById('statIp');
var statHttp    = document.getElementById('statHttp');
var statPort    = document.getElementById('statPort');

// ── State ─────────────────────────────────────────────────────────────────────
var pollTimer    = null;
var countdownInt = null;
var ended        = false;
var lastLogCount = -1;

// ── Helpers ───────────────────────────────────────────────────────────────────
function pad(n) { return n < 10 ? '0' + n : String(n); }

function formatTime(ms) {
  var s = Math.max(0, Math.ceil(ms / 1000));
  return Math.floor(s / 60) + ':' + pad(s % 60);
}

function formatTimestamp(ts) {
  var d = new Date(ts);
  return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function reasonClass(reason) {
  if (reason === '3P-script')          return 'script';
  if (reason === '3P-frame')           return 'frame';
  if (reason === '3P-XHR')            return 'xhr';
  if (reason === '3P-media')          return 'media';
  if (reason === '3P-image')          return 'image';
  if (reason === '3P-stylesheet')     return 'other';
  if (reason === '3P-font')           return 'other';
  if (reason === '3P-ping')           return 'other';
  if (reason === '3P-websocket')      return 'xhr';
  if (reason === '3P-other')          return 'other';
  if (reason === 'numeric IP address') return 'ip';
  if (reason === 'insecure HTTP link') return 'http';
  if (reason.indexOf('port') !== -1)   return 'port';
  return 'other';
}

// ── Table rendering ───────────────────────────────────────────────────────────
function renderLogs(logs) {
  if (!logs || logs.length === 0) {
    logBody.innerHTML = '<tr class="empty-row"><td colspan="4">Waiting for blocked requests…</td></tr>';
    statTotal.textContent   = '0';
    statScripts.textContent = '0';
    statFrames.textContent  = '0';
    statIp.textContent      = '0';
    statHttp.textContent    = '0';
    statPort.textContent    = '0';
    return;
  }

  // Stats
  var counts = { script: 0, frame: 0, xhr: 0, media: 0, image: 0, ip: 0, http: 0, port: 0, other: 0 };
  logs.forEach(function(e) {
    var rc = reasonClass(e.reason);
    if (counts[rc] !== undefined) counts[rc]++;
    else counts.other++;
  });
  statTotal.textContent   = logs.length;
  statScripts.textContent = counts.script;
  statFrames.textContent  = counts.frame;
  document.getElementById('statXhr').textContent   = counts.xhr;
  document.getElementById('statMedia').textContent = counts.media;
  statIp.textContent      = counts.ip;
  statHttp.textContent    = counts.http;
  statPort.textContent    = counts.port;

  // Only re-render if count changed (avoids scroll reset on every poll)
  if (logs.length === lastLogCount) return;
  lastLogCount = logs.length;

  // Render newest first
  var rows = '';
  for (var i = logs.length - 1; i >= 0; i--) {
    var e  = logs[i];
    var rc = reasonClass(e.reason);
    rows += '<tr>'
      + '<td class="domain">' + (e.domain || '—') + '</td>'
      + '<td class="reason"><span class="reason-badge ' + rc + '">' + e.reason + '</span></td>'
      + '<td class="url">'    + e.url    + '</td>'
      + '<td class="time">'   + formatTimestamp(e.time) + '</td>'
      + '</tr>';
  }
  logBody.innerHTML = rows;
}

// ── Countdown ─────────────────────────────────────────────────────────────────
function startCountdown(startTime) {
  if (countdownInt) clearInterval(countdownInt);

  countdownInt = setInterval(function() {
    var elapsed    = Date.now() - startTime;
    var remaining  = LOG_DURATION_MS - elapsed;

    if (remaining <= 0) {
      clearInterval(countdownInt);
      timerBadge.textContent = '0:00';
      timerBadge.className   = 'timer-badge done';
      endSession();
      return;
    }

    timerBadge.textContent = formatTime(remaining);
    timerBadge.className   = remaining < 60000 ? 'timer-badge ending' : 'timer-badge';
  }, 500);
}

// ── Poll for new logs ─────────────────────────────────────────────────────────
function startPolling() {
  if (pollTimer) clearInterval(pollTimer);

  pollTimer = setInterval(function() {
    chrome.storage.local.get({ logging: false, logs: [], logStartTime: null }, function(s) {
      // If background stopped logging (timer fired), end here too
      if (!s.logging && !ended) { endSession(); return; }
      renderLogs(s.logs);
    });
  }, POLL_INTERVAL);
}

// ── End session ───────────────────────────────────────────────────────────────
function endSession() {
  if (ended) return;
  ended = true;

  if (pollTimer)    { clearInterval(pollTimer);    pollTimer    = null; }
  if (countdownInt) { clearInterval(countdownInt); countdownInt = null; }

  // Tell background to stop (in case timer in background hasn't fired yet)
  try { chrome.runtime.sendMessage({ type: "STOP_LOGGING" }); } catch(e) {}

  // Show session ended UI
  tableWrap.style.display    = 'none';
  sessionEnded.classList.add('visible');
  footerBar.textContent      = 'Session ended — window closing in 3 seconds';
  timerBadge.className       = 'timer-badge done';

  // Close this tab after 3 seconds
  setTimeout(function() { window.close(); }, 3000);
}

// ── Stop button ───────────────────────────────────────────────────────────────
stopBtn.addEventListener('click', function() { endSession(); });

// ── Boot ──────────────────────────────────────────────────────────────────────
chrome.storage.local.get({ logging: false, logs: [], logStartTime: null }, function(s) {
  if (!s.logging) {
    // Logging already stopped before we opened — just close
    endSession();
    return;
  }

  // Start countdown from the stored start time
  var startTime = s.logStartTime || Date.now();
  startCountdown(startTime);

  // Render existing logs immediately
  renderLogs(s.logs);

  // Start polling
  startPolling();
});

// Also listen for background stopping logging
chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === "LOGGING_STOPPED") endSession();
});
