// ── Level definitions ─────────────────────────────────────────────────────────
// index 0 = Level 1: Easy mode — allow all           green   showDomain
// index 1 = Level 2: Easy mode with enhanced sec.    blue    showDomain
// index 2 = Level 3: Easy medium mode                yellow  showTld    (uses TLD whitelist)
// index 3 = Level 4: Medium mode — trust CDN's       orange  showDomain (uses domain whitelist + CDN)
// index 4 = Level 5: Medium mode                     darkred showDomain
var LEVELS = [
  {
    name: "Easy mode \u2014 allow all", color: "#4ADE80",
    showDomain: true, showTld: false,
    rules: [{ type: "allow", text: "All traffic allowed \u2014 no restrictions active" }]
  },
  {
    name: "Easy mode with enhanced security", color: "#67C8FF",
    showDomain: true, showTld: false,
    rules: [
      { type: "allow", text: "Whitelisted domains are allowed" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" }
    ]
  },
  {
    name: "Easy medium mode", color: "#FACC15",
    showDomain: false, showTld: true,   // FIX: shows TLD whitelist
    rules: [
      { type: "allow", text: "Whitelisted TLD\u2019s are allowed" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]
  },
  {
    name: "Medium mode \u2014 trust CDN\u2019s", color: "#FB923C",
    showDomain: true, showTld: false,   // FIX: shows Domain whitelist
    rules: [
      { type: "allow", text: "Whitelisted domains are allowed" },
      { type: "allow", text: "Domains or URLs with CDN in name are allowed" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]
  },
  {
    name: "Medium mode", color: "#C0392B",
    showDomain: true, showTld: false,
    rules: [
      { type: "allow", text: "Whitelisted domains are allowed" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]
  }
];

var DEFAULT_STATE = {
  level: 1, startupLevel: 1,
  tlds: ["com","ai","edu","gov","io","net","org","cloud"],
  domains: []
};

var state = Object.assign({}, DEFAULT_STATE);
var domainPage = 0, tldPage = 0, PAGE_SIZE = 10;

// ── Tab visibility ────────────────────────────────────────────────────────────
function updateTabs() {
  var lvl         = LEVELS[state.level - 1];
  var domainTab   = document.querySelector('[data-tab="domain"]');
  var tldTab      = document.querySelector('[data-tab="tld"]');
  var domainPanel = document.getElementById('panel-domain');
  var tldPanel    = document.getElementById('panel-tld');

  if (lvl.showDomain) {
    domainTab.style.display = ''; tldTab.style.display = 'none';
    domainTab.classList.add('active'); tldTab.classList.remove('active');
    domainPanel.classList.add('active'); tldPanel.classList.remove('active');
    domainTab.style.borderBottomColor = lvl.color;
  } else {
    tldTab.style.display = ''; domainTab.style.display = 'none';
    tldTab.classList.add('active'); domainTab.classList.remove('active');
    tldPanel.classList.add('active'); domainPanel.classList.remove('active');
    tldTab.style.borderBottomColor = lvl.color;
  }
}

// ── Render ────────────────────────────────────────────────────────────────────
function render() {
  var val = state.level;
  var lvl = LEVELS[val - 1];

  document.getElementById('levelNum').textContent  = val;
  document.getElementById('levelName').textContent = lvl.name;

  document.documentElement.style.setProperty('--accent', lvl.color);
  var logoIcon = document.getElementById('logoIcon');
  if (logoIcon) logoIcon.style.background = lvl.color;

  // Track fill
  var slider    = document.getElementById('slider');
  var trackFill = document.getElementById('trackFill');
  var fillPx    = 9 + ((slider.offsetWidth - 18) * (val - 1) / 4);
  trackFill.style.width = fillPx + 'px';
  trackFill.style.background = lvl.color;

  // Ticks
  for (var i = 1; i <= 5; i++) {
    var tick = document.getElementById('tick-' + i);
    if (tick) tick.classList.toggle('active', i === val);
  }

  // Policy rules
  var html = '';
  for (var r = 0; r < lvl.rules.length; r++) {
    var rule = lvl.rules[r];
    var dot  = (val === 1)
      ? '<div class="rule-hyphen">\u2013</div>'
      : '<div class="rule-dot ' + rule.type + '"></div>';
    html += '<div class="rule-row">' + dot + '<div class="rule-text">' + rule.text + '</div></div>';
  }
  document.getElementById('ruleList').innerHTML = html;

  // Startup badge
  var badge = document.getElementById('startupBadge');
  if (badge) badge.style.borderColor = LEVELS[state.startupLevel - 1].color;

  // Startup dropdown sync
  var sel = document.getElementById('startupSelect');
  if (sel) sel.value = String(state.startupLevel);

  // Tab visibility
  updateTabs();

  // Add button text: white on dark red
  var addBtns = document.querySelectorAll('.wl-add-btn');
  for (var b = 0; b < addBtns.length; b++) {
    addBtns[b].style.color      = (val === 4) ? '#FFFFFF' : '#000000';
    addBtns[b].style.background = lvl.color;
  }
}

// ── Push to background & update DNR count ─────────────────────────────────────
function pushState() {
  if (typeof chrome === 'undefined' || !chrome.runtime) return;
  chrome.runtime.sendMessage({ type: "SET_STATE", state: state }, function(resp) {
    if (chrome.runtime.lastError) return;
    if (resp && resp.ok) updateRuleCount(resp.ruleCount);
  });
}

function updateRuleCount(n) {
  var rc = document.getElementById('ruleCount');
  if (rc) rc.textContent = (typeof n === 'number') ? n : '?';
}

// ── Paginated whitelist ───────────────────────────────────────────────────────
function renderPage(containerId, items, page) {
  var container = document.getElementById(containerId);
  var isTld     = containerId === 'tld-tags';

  container.innerHTML = '';

  if (!items || items.length === 0) {
    var e = document.createElement('div');
    e.className = 'wl-empty'; e.textContent = 'None added yet';
    container.appendChild(e);
    var pag = document.getElementById(isTld ? 'tld-pagination' : 'domain-pagination');
    if (pag) pag.style.display = 'none';
    return;
  }

  var totalPages = Math.ceil(items.length / PAGE_SIZE);
  page = Math.max(0, Math.min(page, totalPages - 1));
  if (isTld) tldPage = page; else domainPage = page;

  var start = page * PAGE_SIZE;
  var end   = Math.min(start + PAGE_SIZE, items.length);

  for (var i = start; i < end; i++) {
    (function(v) {
      var tag = document.createElement('div');
      tag.className = 'wl-tag';
      tag.innerHTML = v + '<button class="wl-tag-remove" title="Remove">&times;</button>';
      tag.querySelector('.wl-tag-remove').addEventListener('click', function() {
        var key = isTld ? 'tlds' : 'domains';
        state[key] = state[key].filter(function(x) { return x !== v; });
        var pg = isTld ? tldPage : domainPage;
        var newTotal = Math.ceil(state[key].length / PAGE_SIZE);
        if (pg >= newTotal) pg = Math.max(0, newTotal - 1);
        renderPage(containerId, state[key], pg);
        pushState();
      });
      container.appendChild(tag);
    })(items[i]);
  }

  var pag = document.getElementById(isTld ? 'tld-pagination' : 'domain-pagination');
  if (pag) {
    if (totalPages <= 1) {
      pag.style.display = 'none';
    } else {
      pag.style.display = 'flex';
      var info = pag.querySelector('.page-info');
      if (info) info.textContent = 'Page ' + (page + 1) + ' out of ' + totalPages;
      pag.querySelector('.page-prev').onclick = function() {
        var cur   = isTld ? tldPage : domainPage;
        var tot   = Math.ceil((isTld ? state.tlds : state.domains).length / PAGE_SIZE);
        renderPage(containerId, isTld ? state.tlds : state.domains, (cur - 1 + tot) % tot);
      };
      pag.querySelector('.page-next').onclick = function() {
        var cur   = isTld ? tldPage : domainPage;
        var tot   = Math.ceil((isTld ? state.tlds : state.domains).length / PAGE_SIZE);
        renderPage(containerId, isTld ? state.tlds : state.domains, (cur + 1) % tot);
      };
    }
  }
}

function initWhitelist(inputId, btnId, tagsId, stateKey) {
  var input    = document.getElementById(inputId);
  var btn      = document.getElementById(btnId);
  var isTld    = stateKey === 'tlds';
  var sanitize = isTld
    ? function(v) { return v.replace(/^\.+/, '').toLowerCase(); }
    : function(v) { return v.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').toLowerCase(); };

  function addEntry() {
    var raw = sanitize(input.value.trim());
    if (!raw || state[stateKey].length >= 100 || state[stateKey].indexOf(raw) !== -1) {
      input.value = ''; return;
    }
    state[stateKey].push(raw);
    renderPage(tagsId, state[stateKey], Math.floor((state[stateKey].length - 1) / PAGE_SIZE));
    input.value = ''; input.focus();
    pushState();
  }

  btn.addEventListener('click', addEntry);
  input.addEventListener('keydown', function(e) { if (e.key === 'Enter') addEntry(); });
  renderPage(tagsId, state[stateKey], 0);
}

// ── Boot ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {

  // Ticks
  var tickRow = document.getElementById('tickRow');
  for (var i = 1; i <= 5; i++) {
    var t = document.createElement('div');
    t.className = 'tick'; t.textContent = i; t.id = 'tick-' + i;
    tickRow.appendChild(t);
  }

  // Slider
  document.getElementById('slider').addEventListener('input', function() {
    state.level = parseInt(this.value, 10);
    render(); pushState();
  });

  // Startup dropdown
  document.getElementById('startupSelect').addEventListener('change', function() {
    state.startupLevel = parseInt(this.value, 10);
    render(); pushState();
  });

  // Tabs
  document.querySelectorAll('.tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.tab-btn').forEach(function(b) {
        b.classList.remove('active'); b.style.borderBottomColor = '';
      });
      document.querySelectorAll('.tab-panel').forEach(function(p) { p.classList.remove('active'); });
      this.classList.add('active');
      this.style.borderBottomColor = LEVELS[state.level - 1].color;
      document.getElementById('panel-' + this.dataset.tab).classList.add('active');
    }.bind(btn));
  });

  initWhitelist('domain-input', 'domain-add', 'domain-tags', 'domains');
  initWhitelist('tld-input',    'tld-add',    'tld-tags',    'tlds');

  render();

  // ── Logging button ──────────────────────────────────────────────────────────
  var logBtn   = document.getElementById('logBtn');
  var clearBtn = document.getElementById('clearBtn');

  function updateLogBtn(logging) {
    if (logging) {
      logBtn.textContent = 'LOGGING\u2026';
      logBtn.classList.add('active');
      clearBtn.style.display = '';
    } else {
      logBtn.textContent = 'SHOW LOGS';
      logBtn.classList.remove('active');
      clearBtn.style.display = 'none';
    }
  }

  // Check current logging state on open
  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.get({ logging: false }, function(s) {
      updateLogBtn(s.logging);
    });
  }

  logBtn.addEventListener('click', function() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;
    chrome.storage.local.get({ logging: false }, function(s) {
      if (s.logging) {
        // Already logging — just open the logger page
        chrome.tabs.create({ url: chrome.runtime.getURL('logger.html') });
      } else {
        // Start logging
        chrome.storage.local.set({ logging: true, logStartTime: Date.now(), logs: [] }, function() {
          updateLogBtn(true);
          // Reload active tab so DNR debug events fire from fresh requests
          chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs && tabs[0]) chrome.tabs.reload(tabs[0].id);
          });
          // Open logger page
          chrome.tabs.create({ url: chrome.runtime.getURL('logger.html') });
          // Notify background to start the 5-min fallback timer
          chrome.runtime.sendMessage({ type: "START_LOGGING" });
        });
      }
    });
  });

  clearBtn.addEventListener('click', function() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;
    chrome.storage.local.set({ logs: [] });
  });

  // Listen for logging stopped (background timer fired or logger page closed)
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.onMessage.addListener(function(msg) {
      if (msg.type === "LOGGING_STOPPED") updateLogBtn(false);
    });
  }

  // Sync with SW — fetch live rule count too
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: "GET_STATE" }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok && resp.state) {
        state = Object.assign({}, DEFAULT_STATE, resp.state);
        if (typeof state.startupLevel === 'undefined' || state.startupLevel === 0) state.startupLevel = 1;
        updateRuleCount(resp.ruleCount);
        document.getElementById('slider').value        = state.level;
        document.getElementById('startupSelect').value = String(state.startupLevel);
        render();
        renderPage('domain-tags', state.domains, 0);
        renderPage('tld-tags',    state.tlds,    0);
      }
    });
  }
});
