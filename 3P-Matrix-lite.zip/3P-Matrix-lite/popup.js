// ── Level definitions ─────────────────────────────────────────────────────────
// index 0 = Level 1: Easy mode — allow all           green   showDomain
// index 1 = Level 2: Easy mode with enhanced sec.    blue    showDomain
// index 2 = Level 3: Easy medium mode                yellow  showTld    (uses TLD whitelist)
// index 3 = Level 4: Medium mode — trust CDN's       orange  showDomain (uses domain whitelist + CDN)
// index 4 = Level 5: Medium mode                     darkred showDomain
var LEVELS = [
  {
    name: "Easy mode \u2014 allow all", color: "#4ADE80",
    showDomain: true, showTld: false,
    rules: [{ type: "allow", text: "All traffic allowed \u2014 no restrictions active" }]
  },
  {
    name: "Easy mode with enhanced security", color: "#67C8FF",
    showDomain: true, showTld: false,
    rules: [
      { type: "allow", text: "Whitelisted domains are allowed" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" }
    ]
  },
  {
    name: "Easy medium mode", color: "#FACC15",
    showDomain: false, showTld: true,   // FIX: shows TLD whitelist
    rules: [
      { type: "allow", text: "Whitelisted TLD\u2019s are allowed" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]
  },
  {
    name: "Medium mode \u2014 trust CDN\u2019s", color: "#FB923C",
    showDomain: true, showTld: false,   // FIX: shows Domain whitelist
    rules: [
      { type: "allow", text: "Whitelisted domains are allowed" },
      { type: "allow", text: "Domains or URLs with CDN in name are allowed" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]
  },
  {
    name: "Medium mode", color: "#C0392B",
    showDomain: true, showTld: false,
    rules: [
      { type: "allow", text: "Whitelisted domains are allowed" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]
  }
];

var DEFAULT_STATE = {
  level: 1, startupLevel: 1,
  tlds: ["com","ai","edu","gov","io","net","org","cloud"],
  domains: [],
  autoTldMode: 1   // 0=NONE, 1=BROWSER, 2=CONTINENT, 3=WORLDWIDE
};

var state = Object.assign({}, DEFAULT_STATE);
var domainPage = 0, tldPage = 0;
var DOMAIN_PAGE_SIZE = 500; // all domains shown, scrollable
var TLD_PAGE_SIZE    = 500; // show all TLDs, scrollable

// ── Auto TLD language map ─────────────────────────────────────────────────────
var AUTO_TLD_LABELS = ["NONE", "BROWSER", "CONTINENT", "WORLDWIDE"];
var AUTO_TLD_HINTS  = [
  "No country codes added automatically",
  "Add country codes from your browser\u2019s language settings",
  "Same continent: adds countries sharing your browser language (e.g. German \u2192 AT, CH, LI, EU)",
  "Worldwide: adds all countries sharing your browser language (e.g. Portuguese \u2192 BR, AO, CV)"
];

// Language → related country TLDs
// continent = EU extended zone (EU + NO, IS, CH, LI, MC, AD, SM, VA) + 5 eyes (CA, GB, AU, NZ)
// worldwide = all countries speaking that language globally
var LANG_TLD_MAP = {
  "nl": { continent: ["be"],                worldwide: ["be","sr","aw","cw", "eu"] },
  "fr": { continent: ["be","ch","lu","mc"], worldwide: ["be","ch","lu","mc","ca","sn","ci","cm","mg","cd","tn","ma","dz", "eu"] },
  "de": { continent: ["at","ch","li","lu"], worldwide: ["at","ch","li","lu", "eu"] },
  "es": { continent: [],                    worldwide: ["mx","ar","co","pe","ve","cl","ec","gt","cu","bo","do","hn","py","sv","ni","cr","pa","uy", "eu"] },
  "pt": { continent: [],                    worldwide: ["br","ao","mz","cv","gw","st", "eu"] },
  "it": { continent: ["ch","sm","va"],      worldwide: ["ch","sm","va", "eu"] },
  "en": { continent: ["gb","ie","mt","au","nz","ca"], worldwide: ["gb","ie","mt","au","nz","ca","za","ng","gh","ke","ug","tz","sg","in","ph","jm"] },
  "sv": { continent: ["fi"],                worldwide: ["fi", "eu"] },
  "da": { continent: [],                    worldwide: ["eu"] },
  "no": { continent: [],                    worldwide: ["eu"] },
  "fi": { continent: [],                    worldwide: ["eu"] },
  "pl": { continent: [],                    worldwide: ["eu"] },
  "ro": { continent: ["md"],                worldwide: ["md", "eu"] },
  "el": { continent: ["cy"],                worldwide: ["cy", "eu"] },
  "hu": { continent: [],                    worldwide: ["eu"] },
  "cs": { continent: ["sk"],                worldwide: ["sk", "eu"] },
  "sk": { continent: ["cz"],                worldwide: ["cz", "eu"] },
  "hr": { continent: ["rs","ba","me","si"], worldwide: ["rs","ba","me","si", "eu"] },
  "sr": { continent: ["hr","ba","me","si"], worldwide: ["hr","ba","me","si", "eu"] },
  "bg": { continent: [],                    worldwide: ["eu"] }
};

// Base default TLDs that are always included regardless of auto mode
var BASE_TLDS = ["com","ai","edu","gov","io","net","org","cloud"];

// ── Compute auto TLDs from browser languages ──────────────────────────────────
function computeAutoTlds(mode, browserLangs, cb) {
  if (mode === 0) { cb([]); return; }

  // Mode 1: country codes from browser accept-languages + silent eu if EU language
  var browserCountries = [];
  var hasEuLang = false;
  browserLangs.forEach(function(lang) {
    var parts    = lang.toLowerCase().split('-');
    var langCode = parts[0];
    var region   = parts.length > 1 ? parts[parts.length - 1] : null;
    var EU_LANGS = {
      "bg":true,"hr":true,"cs":true,"da":true,"nl":true,"et":true,"fi":true,
      "fr":true,"de":true,"el":true,"hu":true,"ga":true,"it":true,"lv":true,
      "lt":true,"mt":true,"pl":true,"pt":true,"ro":true,"sk":true,"sl":true,
      "es":true,"sv":true
    };
    if (EU_LANGS[langCode]) hasEuLang = true;
    if (region && /^[a-z]{2,3}$/.test(region)) {
      if (browserCountries.indexOf(region) === -1) browserCountries.push(region);
    }
  });
  if (hasEuLang && browserCountries.indexOf('eu') === -1) browserCountries.push('eu');

  if (mode === 1) { cb(browserCountries); return; }

  // Modes 2 & 3: look up language families
  var extra = browserCountries.slice();
  browserLangs.forEach(function(lang) {
    var langCode = lang.toLowerCase().split('-')[0];
    var map = LANG_TLD_MAP[langCode];
    if (!map) return;
    var additions = (mode === 2) ? map.continent : map.worldwide;
    additions.forEach(function(tld) {
      if (extra.indexOf(tld) === -1) extra.push(tld);
    });
  });
  cb(extra);
}

// Rebuild TLD list = BASE_TLDS + auto TLDs + any manually added ones
function rebuildTldList(mode, browserLangs, manualTlds, cb) {
  computeAutoTlds(mode, browserLangs, function(autoTlds) {
    // Always start from BASE_TLDS
    var merged = BASE_TLDS.slice();
    // Add auto TLDs
    autoTlds.forEach(function(t) {
      if (merged.indexOf(t) === -1) merged.push(t);
    });
    // Add manual TLDs
    (manualTlds || []).forEach(function(t) {
      if (merged.indexOf(t) === -1) merged.push(t);
    });
    cb(merged);
  });
}
function updateTabs() {
  var lvl         = LEVELS[state.level - 1];
  var domainTab   = document.querySelector('[data-tab="domain"]');
  var tldTab      = document.querySelector('[data-tab="tld"]');
  var domainPanel = document.getElementById('panel-domain');
  var tldPanel    = document.getElementById('panel-tld');

  if (lvl.showDomain) {
    domainTab.style.display = ''; tldTab.style.display = 'none';
    domainTab.classList.add('active'); tldTab.classList.remove('active');
    domainPanel.classList.add('active'); tldPanel.classList.remove('active');
    domainTab.style.borderBottomColor = lvl.color;
  } else {
    tldTab.style.display = ''; domainTab.style.display = 'none';
    tldTab.classList.add('active'); domainTab.classList.remove('active');
    tldPanel.classList.add('active'); domainPanel.classList.remove('active');
    tldTab.style.borderBottomColor = lvl.color;
  }
}

// ── Render ────────────────────────────────────────────────────────────────────
function render() {
  var val = state.level;
  var lvl = LEVELS[val - 1];

  document.getElementById('levelNum').textContent  = val;
  document.getElementById('levelName').textContent = lvl.name;

  document.documentElement.style.setProperty('--accent', lvl.color);
  var logoIcon = document.getElementById('logoIcon');
  if (logoIcon) logoIcon.style.background = lvl.color;

  // Track fill
  var slider    = document.getElementById('slider');
  var trackFill = document.getElementById('trackFill');
  var fillPx    = 9 + ((slider.offsetWidth - 18) * (val - 1) / 4);
  trackFill.style.width = fillPx + 'px';
  trackFill.style.background = lvl.color;

  // Ticks
  for (var i = 1; i <= 5; i++) {
    var tick = document.getElementById('tick-' + i);
    if (tick) tick.classList.toggle('active', i === val);
  }

  // Policy rules
  var html = '';
  for (var r = 0; r < lvl.rules.length; r++) {
    var rule = lvl.rules[r];
    var dot  = (val === 1)
      ? '<div class="rule-hyphen">\u2013</div>'
      : '<div class="rule-dot ' + rule.type + '"></div>';
    html += '<div class="rule-row">' + dot + '<div class="rule-text">' + rule.text + '</div></div>';
  }
  document.getElementById('ruleList').innerHTML = html;

  // Startup badge
  var badge = document.getElementById('startupBadge');
  if (badge) badge.style.borderColor = LEVELS[state.startupLevel - 1].color;

  // Startup dropdown sync
  var sel = document.getElementById('startupSelect');
  if (sel) sel.value = String(state.startupLevel);

  // Tab visibility
  updateTabs();

  // Add button text: white on dark red
  var addBtns = document.querySelectorAll('.wl-add-btn');
  for (var b = 0; b < addBtns.length; b++) {
    addBtns[b].style.color      = (val === 4) ? '#FFFFFF' : '#000000';
    addBtns[b].style.background = lvl.color;
  }
}

// ── Push to background & update DNR count ─────────────────────────────────────
function pushState() {
  if (typeof chrome === 'undefined' || !chrome.runtime) return;
  chrome.runtime.sendMessage({ type: "SET_STATE", state: state }, function(resp) {
    if (chrome.runtime.lastError) return;
    if (resp && resp.ok) updateRuleCount(resp.ruleCount);
  });
}

function updateRuleCount(n) {
  var rc = document.getElementById('ruleCount');
  if (rc) rc.textContent = (typeof n === 'number') ? n : '?';
}

// ── Paginated whitelist ───────────────────────────────────────────────────────
function renderPage(containerId, items, page) {
  var container = document.getElementById(containerId);
  var isTld     = containerId === 'tld-tags';

  container.innerHTML = '';

  if (!items || items.length === 0) {
    var e = document.createElement('div');
    e.className = 'wl-empty'; e.textContent = 'None added yet';
    container.appendChild(e);
    var pag = document.getElementById(isTld ? 'tld-pagination' : 'domain-pagination');
    if (pag) pag.style.display = 'none';
    return;
  }

  var pageSize   = isTld ? TLD_PAGE_SIZE : DOMAIN_PAGE_SIZE;
  var totalPages = Math.ceil(items.length / pageSize);
  page = Math.max(0, Math.min(page, totalPages - 1));
  if (isTld) tldPage = page; else domainPage = page;

  var start = page * pageSize;
  var end   = Math.min(start + pageSize, items.length);

  for (var i = start; i < end; i++) {
    (function(v) {
      var tag = document.createElement('div');
      tag.className = 'wl-tag';
      var display = (v.length === 2) ? v.toUpperCase() : v;
      tag.innerHTML = display + '<button class="wl-tag-remove" title="Remove">&times;</button>';
      tag.querySelector('.wl-tag-remove').addEventListener('click', function() {
        var key = isTld ? 'tlds' : 'domains';
        state[key] = state[key].filter(function(x) { return x !== v; });
        var pg = isTld ? tldPage : domainPage;
        var newTotal = Math.ceil(state[key].length / (isTld ? TLD_PAGE_SIZE : DOMAIN_PAGE_SIZE));
        if (pg >= newTotal) pg = Math.max(0, newTotal - 1);
        renderPage(containerId, state[key], pg);
        pushState();
      });
      container.appendChild(tag);
    })(items[i]);
  }

  var pag = document.getElementById(isTld ? 'tld-pagination' : 'domain-pagination');
  if (pag) {
    if (totalPages <= 1) {
      pag.style.display = 'none';
    } else {
      pag.style.display = 'flex';
      var info = pag.querySelector('.page-info');
      if (info) info.textContent = 'Page ' + (page + 1) + ' out of ' + totalPages;
      pag.querySelector('.page-prev').onclick = function() {
        var cur   = isTld ? tldPage : domainPage;
        var tot   = Math.ceil((isTld ? state.tlds : state.domains).length / (isTld ? TLD_PAGE_SIZE : DOMAIN_PAGE_SIZE));
        renderPage(containerId, isTld ? state.tlds : state.domains, (cur - 1 + tot) % tot);
      };
      pag.querySelector('.page-next').onclick = function() {
        var cur   = isTld ? tldPage : domainPage;
        var tot   = Math.ceil((isTld ? state.tlds : state.domains).length / (isTld ? TLD_PAGE_SIZE : DOMAIN_PAGE_SIZE));
        renderPage(containerId, isTld ? state.tlds : state.domains, (cur + 1) % tot);
      };
    }
  }
}

function initWhitelist(inputId, btnId, tagsId, stateKey) {
  var input    = document.getElementById(inputId);
  var btn      = document.getElementById(btnId);
  var isTld    = stateKey === 'tlds';
  var sanitize = isTld
    ? function(v) { return v.replace(/^\.+/, '').toLowerCase(); }
    : function(v) { return v.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').toLowerCase(); };

  function addEntry() {
    var raw = sanitize(input.value.trim());
    if (!raw || state[stateKey].length >= 100 || state[stateKey].indexOf(raw) !== -1) {
      input.value = ''; return;
    }
    state[stateKey].push(raw);
    renderPage(tagsId, state[stateKey], Math.floor((state[stateKey].length - 1) / (stateKey === "tlds" ? TLD_PAGE_SIZE : DOMAIN_PAGE_SIZE)));
    input.value = ''; input.focus();
    pushState();
  }

  btn.addEventListener('click', addEntry);
  input.addEventListener('keydown', function(e) { if (e.key === 'Enter') addEntry(); });
  renderPage(tagsId, state[stateKey], 0);
}

// ── Boot ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {

  // Ticks
  var tickRow = document.getElementById('tickRow');
  for (var i = 1; i <= 5; i++) {
    var t = document.createElement('div');
    t.className = 'tick'; t.textContent = i; t.id = 'tick-' + i;
    tickRow.appendChild(t);
  }

  // Slider
  document.getElementById('slider').addEventListener('input', function() {
    state.level = parseInt(this.value, 10);
    render(); pushState();
  });

  // Startup dropdown
  document.getElementById('startupSelect').addEventListener('change', function() {
    state.startupLevel = parseInt(this.value, 10);
    render(); pushState();
  });

  // Tabs
  document.querySelectorAll('.tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.tab-btn').forEach(function(b) {
        b.classList.remove('active'); b.style.borderBottomColor = '';
      });
      document.querySelectorAll('.tab-panel').forEach(function(p) { p.classList.remove('active'); });
      this.classList.add('active');
      this.style.borderBottomColor = LEVELS[state.level - 1].color;
      document.getElementById('panel-' + this.dataset.tab).classList.add('active');
    }.bind(btn));
  });

  initWhitelist('domain-input', 'domain-add', 'domain-tags', 'domains');
  initWhitelist('tld-input',    'tld-add',    'tld-tags',    'tlds');

  // Domain rows dropdown
  var domainTags      = document.getElementById('domain-tags');
  var domainRowsSelect = document.getElementById('domainRowsSelect');
  domainRowsSelect.addEventListener('change', function() {
    domainTags.style.height = this.value + 'px';
  });

  // ── Auto TLD slider ───────────────────────────────────────────────────────
  var autoSlider  = document.getElementById('autoTldSlider');
  var autoValue   = document.getElementById('autoTldValue');
  var autoHint    = document.getElementById('autoTldHint');
  var browserLangs = [];

  // Fetch browser languages once
  if (typeof chrome !== 'undefined' && chrome.i18n) {
    chrome.i18n.getAcceptLanguages(function(langs) {
      browserLangs = langs || [];
    });
  }

  function updateAutoSliderUI(mode) {
    autoValue.textContent = AUTO_TLD_LABELS[mode];
    autoHint.textContent  = AUTO_TLD_HINTS[mode];
    autoSlider.value      = mode;
  }

  function applyAutoTlds(mode) {
    // manualTlds = TLDs the user added that are NOT in BASE_TLDS and NOT auto-generated
    // We store them separately so we can recompute when mode changes
    var manualTlds = (state.manualTlds || []);
    rebuildTldList(mode, browserLangs, manualTlds, function(merged) {
      state.tlds        = merged;
      state.autoTldMode = mode;
      renderPage('tld-tags', state.tlds, 0);
      pushState();
    });
  }

  autoSlider.addEventListener('input', function() {
    var mode = parseInt(this.value, 10);
    updateAutoSliderUI(mode);
    applyAutoTlds(mode);
  });

  // Override initWhitelist add logic to also track manual additions
  var tldInput  = document.getElementById('tld-input');
  var tldAddBtn = document.getElementById('tld-add');

  function addManualTld() {
    var raw = tldInput.value.trim().replace(/^\.+/, '').toLowerCase();
    if (!raw) return;
    if (!state.manualTlds) state.manualTlds = [];
    if (state.manualTlds.indexOf(raw) === -1) state.manualTlds.push(raw);
    if (state.tlds.indexOf(raw) === -1) {
      state.tlds.push(raw);
      renderPage('tld-tags', state.tlds, Math.floor((state.tlds.length - 1) / TLD_PAGE_SIZE));
      pushState();
    }
    tldInput.value = '';
    tldInput.focus();
  }
  tldAddBtn.addEventListener('click', addManualTld);
  tldInput.addEventListener('keydown', function(e) { if (e.key === 'Enter') addManualTld(); });

  render();

  // ── Logging button ──────────────────────────────────────────────────────────
  var logBtn   = document.getElementById('logBtn');
  var clearBtn = document.getElementById('clearBtn');

  function updateLogBtn(logging) {
    if (logging) {
      logBtn.textContent = 'LOGGING\u2026';
      logBtn.classList.add('active');
      clearBtn.style.display = '';
    } else {
      logBtn.textContent = 'SHOW LOGS';
      logBtn.classList.remove('active');
      clearBtn.style.display = 'none';
    }
  }

  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.get({ logging: false }, function(s) {
      updateLogBtn(s.logging);
    });
  }

  logBtn.addEventListener('click', function() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;
    chrome.storage.local.get({ logging: false }, function(s) {
      if (s.logging) {
        chrome.tabs.create({ url: chrome.runtime.getURL('logger.html') });
      } else {
        chrome.storage.local.set({ logging: true, logStartTime: Date.now(), logs: [] }, function() {
          updateLogBtn(true);
          chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs && tabs[0]) chrome.tabs.reload(tabs[0].id);
          });
          chrome.tabs.create({ url: chrome.runtime.getURL('logger.html') });
          chrome.runtime.sendMessage({ type: "START_LOGGING" });
        });
      }
    });
  });

  clearBtn.addEventListener('click', function() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;
    chrome.storage.local.set({ logs: [] });
  });

  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.onMessage.addListener(function(msg) {
      if (msg.type === "LOGGING_STOPPED") updateLogBtn(false);
    });
  }

  // Sync with SW
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: "GET_STATE" }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok && resp.state) {
        state = Object.assign({}, DEFAULT_STATE, resp.state);
        if (typeof state.startupLevel === 'undefined' || state.startupLevel === 0) state.startupLevel = 1;
        if (typeof state.autoTldMode  === 'undefined') state.autoTldMode = 1;
        if (!state.manualTlds) state.manualTlds = [];
        // Ensure BASE_TLDS are always present even if stored state is missing them
        BASE_TLDS.forEach(function(t) {
          if (state.tlds.indexOf(t) === -1) state.tlds.push(t);
        });
        updateRuleCount(resp.ruleCount);
        document.getElementById('slider').value        = state.level;
        document.getElementById('startupSelect').value = String(state.startupLevel);
        updateAutoSliderUI(state.autoTldMode);
        render();
        renderPage('domain-tags', state.domains, 0);
        renderPage('tld-tags',    state.tlds,    0);
      }
    });
  }
});
