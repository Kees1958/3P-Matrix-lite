/**
 * background.js — 3P-Matrix-lite service worker
 *
 * Levels 1–5 (stored and used as 1–5 everywhere, no offset):
 *   1  Easy mode — allow all           → no rules
 *   2  Easy mode with enhanced sec.    → base safety + domain whitelist + block 3P frames
 *   3  Easy medium mode                → base safety + TLD whitelist + block 3P frames+scripts
 *   4  Medium mode — trust CDN's       → base safety + domain whitelist + CDN allow + block 3P frames+scripts
 *   5  Medium mode                     → base safety + domain whitelist + block 3P frames+scripts + catch-all
 */

var STORAGE_KEY = "3pmatrix_state";

var DEFAULT_STATE = {
  startupLevel: 1,
  level:        1,
  tlds:         ["com","ai","edu","gov","io","net","org","cloud"],
  domains:      []
};

var RP_3P = [
  "sub_frame","stylesheet","script","image",
  "font","object","xmlhttprequest","ping","media","websocket","other"
];

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// ── Base safety rules (levels 2–5) ───────────────────────────────────────────
function baseRules() {
  return [
    { id: 1001, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^http://", domainType: "thirdParty",
        isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } },
    { id: 1002, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^ws://", domainType: "thirdParty",
        isUrlFilterCaseSensitive: false, resourceTypes: ["websocket"] } },
    { id: 1003, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^https?://[^/?#:]+:([1-9][0-9]?|[1-3][0-9]{2}|4[0-3][0-9]|44[0-2])([/?#]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } },
    { id: 1004, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^https?://[^/?#:]+:(44[4-9]|4[5-9][0-9]|[5-9][0-9]{2}|[1-9][0-9]{3,})([/?#]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } },
    { id: 1005, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^https?://[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+([/?#:]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } }
  ];
}

// ── Whitelist allow rule builders ─────────────────────────────────────────────
function tldAllowRules(tlds) {
  var r = [];
  tlds.slice(0, 100).forEach(function(tld, i) {
    r.push({ id: 2100 + i, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*." + tld + "/*", resourceTypes: RP_3P } });
    r.push({ id: 2500 + i, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*." + tld + "/",  resourceTypes: RP_3P } });
  });
  return r;
}

function domainAllowRules(domains) {
  var r = [];
  domains.slice(0, 100).forEach(function(d, i) {
    r.push({ id: 2000 + i, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*" + d + "/*", resourceTypes: RP_3P } });
    r.push({ id: 2400 + i, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*" + d + "/",  resourceTypes: RP_3P } });
  });
  return r;
}

// ── Rule builder ──────────────────────────────────────────────────────────────
function buildRules(state) {
  var level   = state.level;
  var tlds    = state.tlds    || [];
  var domains = state.domains || [];
  var rules   = [];

  // Level 1: no rules at all
  if (level === 1) return [];

  // All levels 2–5: base safety rules
  rules = rules.concat(baseRules());

  // Level 2: domain whitelist + block 3P frames
  if (level === 2) {
    rules = rules.concat(domainAllowRules(domains));
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { domainType: "thirdParty", resourceTypes: ["sub_frame"] } });
    return rules;
  }

  // Level 3: TLD whitelist + block 3P frames + scripts
  if (level === 3) {
    rules = rules.concat(tldAllowRules(tlds));
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { domainType: "thirdParty", resourceTypes: ["sub_frame"] } });
    rules.push({ id: 3002, priority: 20, action: { type: "block" },
      condition: { domainType: "thirdParty", resourceTypes: ["script","webbundle"] } });
    return rules;
  }

  // Level 4: domain whitelist + CDN allow + block 3P frames + scripts
  if (level === 4) {
    rules = rules.concat(domainAllowRules(domains));
    rules.push({ id: 2200, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*cdn*", resourceTypes: RP_3P } });
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { domainType: "thirdParty", resourceTypes: ["sub_frame"] } });
    rules.push({ id: 3002, priority: 20, action: { type: "block" },
      condition: { domainType: "thirdParty", resourceTypes: ["script","webbundle"] } });
    return rules;
  }

  // Level 5: domain whitelist + block 3P frames + scripts + catch-all
  if (level === 5) {
    rules = rules.concat(domainAllowRules(domains));
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { domainType: "thirdParty", resourceTypes: ["sub_frame"] } });
    rules.push({ id: 3002, priority: 20, action: { type: "block" },
      condition: { domainType: "thirdParty", resourceTypes: ["script","webbundle"] } });
    rules.push({ id: 4000, priority: 10, action: { type: "block" },
      condition: { domainType: "thirdParty", resourceTypes: RP_3P } });
    return rules;
  }

  return rules;
}

// ── Icon ──────────────────────────────────────────────────────────────────────
function setIcon(level) {
  // Icon files are named icon_0_ through icon_4_ (0-based index)
  var idx = level - 1;
  try {
    chrome.action.setIcon({ path: {
      "16":  "icon_" + idx + "_16.png",
      "32":  "icon_" + idx + "_32.png",
      "48":  "icon_" + idx + "_48.png",
      "128": "icon_" + idx + "_128.png"
    }});
  } catch(e) {}
}

// ── State helpers ─────────────────────────────────────────────────────────────
function loadState(cb) {
  chrome.storage.local.get(STORAGE_KEY, function(stored) {
    var s = Object.assign({}, DEFAULT_STATE, stored[STORAGE_KEY] || {});
    // Migrate old 0-based levels to 1-based
    if (s.level === 0) s.level = 1;
    if (s.startupLevel === 0) s.startupLevel = 1;
    cb(s);
  });
}

function saveState(s, cb) {
  var o = {}; o[STORAGE_KEY] = s;
  chrome.storage.local.set(o, cb || function(){});
}

function applyState(s, cb) {
  chrome.declarativeNetRequest.getDynamicRules(function(existing) {
    var removeIds = existing.map(function(r) { return r.id; });
    var addRules  = buildRules(s);
    chrome.declarativeNetRequest.updateDynamicRules(
      { removeRuleIds: removeIds, addRules: addRules },
      function() {
        if (chrome.runtime.lastError) {
          console.warn("[3PM] updateDynamicRules:", chrome.runtime.lastError.message);
          if (cb) cb(0);
          return;
        }
        setIcon(s.level);
        rebuildBlockRuleIndex();
        if (cb) cb(addRules.length);
      }
    );
  });
}

// ── Country TLD detection ─────────────────────────────────────────────────────
var SKIP_TLDS = { "us": true };

function browserCountryTlds(cb) {
  chrome.i18n.getAcceptLanguages(function(langs) {
    var seen = {}, tlds = [];
    (langs || []).forEach(function(lang) {
      var parts  = lang.toLowerCase().split('-');
      var region = parts.length > 1 ? parts[parts.length - 1] : parts[0];
      if (/^[a-z]{2,3}$/.test(region) && !SKIP_TLDS[region] && !seen[region]) {
        seen[region] = true;
        tlds.push(region);
      }
    });
    cb(tlds);
  });
}

// ── Lifecycle ─────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === "install") {
    browserCountryTlds(function(countryTlds) {
      var merged = DEFAULT_STATE.tlds.slice();
      countryTlds.forEach(function(tld) {
        if (merged.indexOf(tld) === -1) merged.push(tld);
      });
      var initState = Object.assign({}, DEFAULT_STATE, { tlds: merged });
      saveState(initState, function() { applyState(initState); });
    });
  } else {
    loadState(function(s) { applyState(s); });
  }
});

chrome.runtime.onStartup.addListener(function() {
  loadState(function(s) {
    var boot = Object.assign({}, s, { level: s.startupLevel || 1 });
    saveState(boot, function() { applyState(boot); });
  });
});

// ── Messages ──────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {
  if (msg.type === "GET_STATE") {
    loadState(function(s) {
      chrome.declarativeNetRequest.getDynamicRules(function(rules) {
        sendResponse({ ok: true, state: s, ruleCount: rules.length });
      });
    });
    return true;
  }
  if (msg.type === "SET_STATE") {
    var ns = Object.assign({}, DEFAULT_STATE, msg.state);
    if (ns.level < 1 || ns.level > 5) ns.level = 1;
    if (ns.startupLevel < 1 || ns.startupLevel > 5) ns.startupLevel = 1;
    saveState(ns, function() {
      applyState(ns, function(count) {
        sendResponse({ ok: true, ruleCount: count });
      });
    });
    return true;
  }
  if (msg.type === "START_LOGGING") {
    startLoggingTimer();
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === "STOP_LOGGING") {
    stopLogging();
    sendResponse({ ok: true });
    return true;
  }
  sendResponse({ ok: false, error: "Unknown: " + msg.type });
});

// ── Logging ───────────────────────────────────────────────────────────────────
var LOG_TIMEOUT_MS = 5 * 60 * 1000;
var MAX_LOGS       = 500;
var loggingTimer   = null;
var BLOCK_RULE_IDS = {};

function rebuildBlockRuleIndex() {
  chrome.declarativeNetRequest.getDynamicRules(function(rules) {
    BLOCK_RULE_IDS = {};
    rules.forEach(function(r) {
      if (r.action && r.action.type === 'block') BLOCK_RULE_IDS[r.id] = true;
    });
  });
}

function stopLogging() {
  if (loggingTimer) { clearTimeout(loggingTimer); loggingTimer = null; }
  chrome.storage.local.set({ logging: false, logStartTime: null });
  setTimeout(function() { chrome.storage.local.set({ logs: [] }); }, 3000);
  chrome.runtime.sendMessage({ type: "LOGGING_STOPPED" }, function() {
    if (chrome.runtime.lastError) {}
  });
}

function startLoggingTimer() {
  if (loggingTimer) clearTimeout(loggingTimer);
  loggingTimer = setTimeout(function() {
    loggingTimer = null;
    stopLogging();
  }, LOG_TIMEOUT_MS);
}

chrome.runtime.onStartup.addListener(function() {
  chrome.storage.local.get({ logging: false, logStartTime: null }, function(s) {
    if (!s.logging) return;
    var elapsed   = s.logStartTime ? (Date.now() - s.logStartTime) : LOG_TIMEOUT_MS;
    var remaining = LOG_TIMEOUT_MS - elapsed;
    if (remaining <= 0) { stopLogging(); return; }
    loggingTimer = setTimeout(function() { loggingTimer = null; stopLogging(); }, remaining);
  });
});

var RULE_NAMES = {
  1001: 'HTTP', 1002: 'WS', 1003: 'port', 1004: 'port',
  1005: 'IP', 3001: 'frame', 3002: 'script', 4000: 'catch-all'
};

function isIp(host) {
  return /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/.test(host) || host.indexOf(':') !== -1;
}

function sanitizeUrl(url) {
  url.search = ''; url.hash = '';
  return url.toString();
}

function classify(url, type, ruleId) {
  var ruleName = ruleId ? (RULE_NAMES[ruleId] || 'r' + ruleId) : '';
  if (ruleId === 1001) return 'HTTP block';
  if (ruleId === 1002) return 'WS block';
  if (ruleId === 1003 || ruleId === 1004) return 'port:' + (url.port || '?');
  if (ruleId === 1005) return 'IP block';
  var typeLabel = {
    'script': '3P-script', 'sub_frame': '3P-frame', 'image': '3P-image',
    'xmlhttprequest': '3P-XHR', 'media': '3P-media', 'websocket': '3P-ws',
    'stylesheet': '3P-css', 'font': '3P-font', 'ping': '3P-ping',
    'main_frame': 'main-frame', 'object': '3P-object', 'other': '3P-other'
  }[type] || ('3P-' + type);
  return typeLabel + ' [' + ruleName + ']';
}

chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(function(info) {
  chrome.storage.local.get({ logging: false, logs: [] }, function(s) {
    if (!s.logging) return;
    if (!info.rule || !BLOCK_RULE_IDS[info.rule.ruleId]) return;
    var type = info.request.type;
    // Log all resource types — no filter so we catch downloads and any unexpected types
    var rawUrl = info.request.url;
    if (typeof rawUrl !== 'string' || !rawUrl) return;
    var url;
    try { url = new URL(rawUrl); } catch(e) { return; }
    var reason = classify(url, type, info.rule.ruleId);
    if (!reason) return;
    var callingDomain = 'unknown';
    try {
      var initiator = info.request.initiator || info.request.documentUrl || '';
      if (initiator) callingDomain = new URL(initiator).hostname || 'unknown';
    } catch(e) {}
    var logs = s.logs || [];
    logs.push({ domain: callingDomain, reason: reason, ruleId: info.rule.ruleId,
      url: sanitizeUrl(url), time: Date.now() });
    if (logs.length > MAX_LOGS) logs.splice(0, logs.length - MAX_LOGS);
    chrome.storage.local.set({ logs: logs });
  });
});
