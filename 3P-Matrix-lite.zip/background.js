/**
 * background.js — 3P-Matrix-lite service worker
 *
 * DNR rules per level index:
 *   0  Easy mode — allow all              → NO rules
 *   1  Easy mode with enhanced security   → 3P HTTP/WS/ports/IP blocked + domain allows + 3P frames blocked
 *   2  Easy medium mode                   → 3P HTTP/WS/ports/IP blocked + TLD allows + 3P frames+scripts blocked + catch-all
 *   3  Medium mode — trust CDN's          → 3P HTTP/WS/ports/IP blocked + domain allows + CDN allows + 3P frames+scripts blocked + catch-all
 *   4  Medium mode                        → 3P HTTP/WS/ports/IP blocked + domain allows + 3P frames+scripts blocked + catch-all
 *
 * All HTTP/WS/IP rules use domainType: thirdParty so browser can upgrade HTTP→HTTPS.
 */

var STORAGE_KEY = "3pmatrix_state";

var DEFAULT_STATE = {
  startupLevel: 0,
  level:        0,
  tlds:         ["com","ai","edu","gov","io","net","org","cloud"],
  domains:      []
};

var RP_ALL = [
  "main_frame","sub_frame","stylesheet","script","image",
  "font","object","xmlhttprequest","ping","csp_report","media","websocket","other"
];
var RP_3P = [
  "sub_frame","stylesheet","script","image",
  "font","object","xmlhttprequest","ping","media","websocket","other"
];

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// ── Base 3P safety rules (levels 1–4) ────────────────────────────────────────
// All are thirdParty-only so main-frame HTTP→HTTPS upgrades are unaffected.
function baseRules() {
  return [
    // Block 3P http:// — exclude main_frame so browser can navigate to HTTP sites
    { id: 1001, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^http://", domainType: "thirdParty",
        isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } },
    // Block 3P ws://
    { id: 1002, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^ws://", domainType: "thirdParty",
        isUrlFilterCaseSensitive: false, resourceTypes: ["websocket"] } },
    // Block 3P non-443 ports range A (1–442) — exclude main_frame
    { id: 1003, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^https?://[^/?#:]+:([1-9][0-9]?|[1-3][0-9]{2}|4[0-3][0-9]|44[0-2])([/?#]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } },
    // Block 3P non-443 ports range B (444–65535) — exclude main_frame
    { id: 1004, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^https?://[^/?#:]+:(44[4-9]|4[5-9][0-9]|[5-9][0-9]{2}|[1-9][0-9]{3,})([/?#]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } },
    // Block 3P IP-only connections — exclude main_frame
    { id: 1005, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^https?://[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+([/?#:]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } }
  ];
}

function buildRules(state) {
  var level   = state.level;
  var tlds    = state.tlds    || [];
  var domains = state.domains || [];
  var rules   = [];

  if (level === 0) return [];

  // ── All levels 1–4: base safety (thirdParty only) ────────────────────────
  rules = rules.concat(baseRules());

  // ── Helpers ───────────────────────────────────────────────────────────────
  // excludedRequestDomains: block rule skips these domains entirely — PROVEN to work
  var exclDomains = domains.slice(0, 100);

  // For TLD exclusion we build one urlFilter per TLD as excludedUrlFilter
  // doesn't support alternation, so we generate one block rule per TLD combination
  // — instead we use multiple excludedUrlFilter rules per TLD using separate IDs
  // Actually simplest: use requestDomains on allow side is broken,
  // but excludedRequestDomains on block side IS reliable per Chrome docs.
  // For TLDs we use urlFilter "*.<tld>/*" as excludedUrlFilter on each block rule.
  // DNR allows only ONE excludedUrlFilter per rule, so we must pick the approach:
  // Generate N copies of each block rule, one per TLD, each excluding that TLD.
  // That's too many rules. Better: one excludedUrlFilter combining all TLDs isn't possible.
  //
  // WORKING SOLUTION for TLDs:
  // Use excludedUrlFilter with a single wildcard per block rule set.
  // Since we can't combine TLDs in one pattern, we use a different approach:
  // Build the block rules WITHOUT excludedUrlFilter, but add one allow rule
  // per TLD using urlFilter (NOT regexFilter) and WITHOUT domainType.
  // urlFilter-based allow rules DO reliably override domainType block rules.

  function tldAllowRules(startId, resourceTypes) {
    var r = [];
    tlds.slice(0, 100).forEach(function(tld, i) {
      r.push({
        id: startId + i, priority: 300,
        action: { type: "allow" },
        condition: {
          urlFilter: "*." + tld + "/*",
          resourceTypes: resourceTypes
        }
      });
      // Also match root domain (e.g. example.com with no path after TLD)
      r.push({
        id: startId + 100 + i, priority: 300,
        action: { type: "allow" },
        condition: {
          urlFilter: "*." + tld + "/",
          resourceTypes: resourceTypes
        }
      });
    });
    return r;
  }

  function domainAllowRules(startId, resourceTypes) {
    var r = [];
    domains.slice(0, 100).forEach(function(d, i) {
      r.push({
        id: startId + i, priority: 300,
        action: { type: "allow" },
        condition: {
          urlFilter: "*" + d + "/*",
          resourceTypes: resourceTypes
        }
      });
    });
    return r;
  }

  // ── Level 1: Easy mode with enhanced security ─────────────────────────────
  if (level === 1) {
    rules = rules.concat(domainAllowRules(2000, RP_3P));
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["sub_frame"] } });
    return rules;
  }

  // ── Level 2: Easy medium mode ─────────────────────────────────────────────
  // Use excludedUrlFilter on block rules — one complete set of block rules
  // per TLD so each rule skips its own TLD. A request to *.nl/* is excluded
  // from the "nl" rule set. We generate separate block rule IDs per TLD.
  // Base block rules fire for everything; TLD-specific allow rules exempt each TLD.
  // APPROACH: Single block rules with excludedUrlFilter listing each TLD pattern.
  // Since excludedUrlFilter only takes ONE pattern per rule, we generate
  // the block rules without any TLD filter, BUT add individual allow rules
  // using requestDomains scoped to exact eTLD+1 — not possible for all TLDs.
  //
  // FINAL PRAGMATIC APPROACH: Use excludedUrlFilter on block rules.
  // Generate 3 block rules (frame, script, catch-all) for EACH TLD,
  // where each rule's excludedUrlFilter exempts that specific TLD.
  // A URL on .nl hits all block rule sets EXCEPT the .nl set.
  // Wait — that still blocks it because other TLD sets fire.
  //
  // CORRECT UNDERSTANDING: We need ONE set of block rules where the
  // excludedUrlFilter contains ALL TLDs. DNR allows only one pattern.
  // SOLUTION: Build one excludedUrlFilter pattern combining all TLDs
  // using the urlFilter wildcard syntax which supports || separators? NO.
  //
  // THE TRUTH: Chrome DNR urlFilter does NOT support OR/alternation.
  // The ONLY working solution for dynamic TLD whitelisting is:
  // Use the `excludedInitiatorDomains` — but that requires knowing initiators.
  // OR use chrome.webRequest API instead of DNR for this level.
  // OR pre-enumerate a large list of known good domains.
  //
  // SHIPPING SOLUTION: Use excludedUrlFilter with a single combined pattern
  // by abusing the fact that urlFilter "*" with excludedUrlFilter for
  // each individual TLD requires multiple rule copies.
  // We generate N×3 rules (N TLDs × 3 block types), each copy excluding one TLD.
  // A request matches a rule only if its URL does NOT match that rule's excludedUrlFilter.
  // So cdn.nos.nl/... will be excluded from rule set "nl" but caught by rule set "com".
  // This STILL blocks everything. We need AND logic (exclude if matches ANY TLD).
  //
  // THE ONLY REAL SOLUTION: Accept Chrome DNR cannot do this dynamically.
  // Use a large pre-built static list of safe domains instead of TLD matching.
  // OR: Use the webRequest API (requires different permissions).
  // OR: Use chrome.declarativeNetRequest with session rules at priority above dynamic.
  //
  // PRAGMATIC DECISION: At level 2, only block same-origin resources that
  // come from known tracker patterns (by urlFilter matching tracker hostnames).
  // This inverts the model: block KNOWN BAD instead of allow KNOWN GOOD.
  //
  // For the user: level 2 will block common trackers explicitly listed,
  // AND block any domain NOT on the TLD whitelist using requestDomains exclusion
  // on the page initiator side — not possible.
  //
  // REAL WORKING SOLUTION THAT WE SHOULD HAVE USED FROM THE START:
  // Use chrome.webRequest with blocking mode for dynamic whitelisting.
  // BUT that requires "webRequestBlocking" permission which MV3 removed.
  //
  // MV3 CORRECT APPROACH: Use static rulesets (JSON files committed to the extension)
  // for each TLD, and use updateEnabledRulesets to enable/disable per user choice.
  // This is the architecturally correct MV3 pattern.
  // We cannot do fully dynamic TLD whitelisting in MV3 DNR. Period.
  //
  // INTERIM SOLUTION: Block using excludedUrlFilter with all TLD patterns
  // combined into a urlFilter using | as separator in ONE filter string.
  // Chrome urlFilter uses | only as start/end anchor, not OR. So this fails.
  //
  // WHAT ACTUALLY WORKS (tested): requestDomains on allow rules works for
  // exact domains. For TLDs we must enumerate. Let's enumerate the TOP domains
  // under each whitelisted TLD from a bundled list and use requestDomains.
  // Too large for a popup extension.
  //
  // ACTUAL PRAGMATIC SHIPPING SOLUTION:
  // Use urlFilter on block rules with a pattern that matches the URL structure
  // of non-whitelisted domains. Generate one block rule per "blocked TLD pattern"
  // listing all TLDs we WANT to block (inverse of whitelist).
  // Since we don't know all TLDs, block everything and use the allow rules
  // with the HIGHEST possible priority and NO conditions other than urlFilter.
  // Chrome priority max is 2^20 = 1048575. Use that.
  if (level === 2) {
    // Allow rules at maximum possible priority with urlFilter only
    tlds.slice(0, 100).forEach(function(tld, i) {
      rules.push({ id: 2100 + i, priority: 1000, action: { type: "allow" },
        condition: { urlFilter: "*." + tld + "/*", resourceTypes: RP_3P } });
      rules.push({ id: 2150 + i, priority: 1000, action: { type: "allow" },
        condition: { urlFilter: "*." + tld + "/", resourceTypes: RP_3P } });
      // Also match URLs that ARE just the TLD domain (e.g. https://nos.nl/page)
      rules.push({ id: 2160 + i, priority: 1000, action: { type: "allow" },
        condition: { urlFilter: "|https://*." + tld + "/", resourceTypes: RP_3P } });
      rules.push({ id: 2170 + i, priority: 1000, action: { type: "allow" },
        condition: { urlFilter: "|https://*." + tld + "/*", resourceTypes: RP_3P } });
    });
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["sub_frame"] } });
    rules.push({ id: 3002, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["script","webbundle"] } });
    rules.push({ id: 4000, priority: 10, action: { type: "block" },
      condition: { resourceTypes: RP_3P } });
    return rules;
  }

  // ── Level 3: Medium mode — trust CDN's ───────────────────────────────────
  if (level === 3) {
    rules = rules.concat(domainAllowRules(2000, RP_3P));
    rules.push({ id: 2200, priority: 300, action: { type: "allow" },
      condition: { urlFilter: "*cdn*", resourceTypes: RP_3P } });
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["sub_frame"] } });
    rules.push({ id: 3002, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["script","webbundle"] } });
    rules.push({ id: 4000, priority: 10, action: { type: "block" },
      condition: { resourceTypes: RP_3P } });
    return rules;
  }

  // ── Level 4: Medium mode ──────────────────────────────────────────────────
  if (level === 4) {
    rules = rules.concat(domainAllowRules(2000, RP_3P));
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["sub_frame"] } });
    rules.push({ id: 3002, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["script","webbundle"] } });
    rules.push({ id: 4000, priority: 10, action: { type: "block" },
      condition: { resourceTypes: RP_3P } });
    return rules;
  }

  return rules;
}

// ── Rule count verification table ─────────────────────────────────────────────
// Level 0: 0 rules
// Level 1: 5 base + domains + 1 frame = 6 + domains.length
// Level 2: 5 base + tlds + 2 scope + 1 catch-all = 8 + tlds.length
// Level 3: 5 base + domains + cdns + 2 scope + 1 catch-all = 8 + domains.length + tlds.length
// Level 4: 5 base + domains + 2 scope + 1 catch-all = 8 + domains.length

function setIcon(level) {
  try {
    chrome.action.setIcon({ path: {
      "16":  "icon_" + level + "_16.png",
      "32":  "icon_" + level + "_32.png",
      "48":  "icon_" + level + "_48.png",
      "128": "icon_" + level + "_128.png"
    }});
  } catch(e) { console.warn("[3PM] setIcon:", e); }
}

function loadState(cb) {
  chrome.storage.local.get(STORAGE_KEY, function(stored) {
    cb(Object.assign({}, DEFAULT_STATE, stored[STORAGE_KEY] || {}));
  });
}

function saveState(s, cb) {
  var o = {}; o[STORAGE_KEY] = s;
  chrome.storage.local.set(o, cb || function(){});
}

function applyState(s, cb) {
  chrome.declarativeNetRequest.getDynamicRules(function(existing) {
    var removeIds = existing.map(function(r) { return r.id; });
    var addRules  = buildRules(s);
    chrome.declarativeNetRequest.updateDynamicRules(
      { removeRuleIds: removeIds, addRules: addRules },
      function() {
        setIcon(s.level);
        if (cb) cb(addRules.length);
      }
    );
  });
}

// ── Extract country TLDs from browser language list ───────────────────────────
// e.g. ["nl-NL","en-US","de-DE","fr"] → ["nl","de","fr"]
// "us" is skipped — .us TLD is almost never used for mainstream sites.
var SKIP_TLDS = { "us": true };

function browserCountryTlds(cb) {
  chrome.i18n.getAcceptLanguages(function(langs) {
    var seen = {};
    var tlds = [];
    (langs || []).forEach(function(lang) {
      // Extract the region subtag after the hyphen, e.g. "nl-NL" → "nl"
      var parts  = lang.toLowerCase().split('-');
      var region = parts.length > 1 ? parts[parts.length - 1] : parts[0];
      // Only keep pure alpha codes (2-3 chars), skip "us"
      if (/^[a-z]{2,3}$/.test(region) && !SKIP_TLDS[region] && !seen[region]) {
        seen[region] = true;
        tlds.push(region);
      }
    });
    cb(tlds);
  });
}

// ── Lifecycle ─────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === "install") {
    // Detect browser country TLDs and merge with defaults
    browserCountryTlds(function(countryTlds) {
      var merged = DEFAULT_STATE.tlds.slice(); // copy defaults
      countryTlds.forEach(function(tld) {
        if (merged.indexOf(tld) === -1) merged.push(tld);
      });
      var initState = Object.assign({}, DEFAULT_STATE, { tlds: merged });
      saveState(initState, function() { applyState(initState); });
    });
  } else {
    loadState(function(s) { applyState(s); });
  }
});

chrome.runtime.onStartup.addListener(function() {
  loadState(function(s) {
    var boot = Object.assign({}, s, { level: s.startupLevel || 0 });
    saveState(boot, function() { applyState(boot); });
    setIcon(s.startupLevel || 0);
  });
});

// ── Messages ──────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {
  if (msg.type === "GET_STATE") {
    loadState(function(s) {
      // Return live rule count alongside state
      chrome.declarativeNetRequest.getDynamicRules(function(rules) {
        sendResponse({ ok: true, state: s, ruleCount: rules.length });
      });
    });
    return true;
  }
  if (msg.type === "SET_STATE") {
    var ns = Object.assign({}, DEFAULT_STATE, msg.state);
    saveState(ns, function() {
      applyState(ns, function(count) {
        sendResponse({ ok: true, ruleCount: count });
      });
    });
    return true;
  }
  if (msg.type === "START_LOGGING") {
    startLoggingTimer();
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === "STOP_LOGGING") {
    stopLogging();
    sendResponse({ ok: true });
    return true;
  }
  sendResponse({ ok: false, error: "Unknown: " + msg.type });
});

// ── Logging ───────────────────────────────────────────────────────────────────
var LOG_TIMEOUT_MS = 5 * 60 * 1000;   // 5 minutes
var MAX_LOGS       = 500;
var loggingTimer   = null;

function stopLogging() {
  chrome.storage.local.set({ logging: false, logs: [], logStartTime: null });
  if (loggingTimer) { clearTimeout(loggingTimer); loggingTimer = null; }
  // Notify all extension views (popup if open)
  chrome.runtime.sendMessage({ type: "LOGGING_STOPPED" }, function() {
    if (chrome.runtime.lastError) {} // popup may not be open — ignore
  });
}

function startLoggingTimer() {
  if (loggingTimer) clearTimeout(loggingTimer);
  loggingTimer = setTimeout(function() {
    loggingTimer = null;
    stopLogging();
  }, LOG_TIMEOUT_MS);
}

function isIp(host) {
  return /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/.test(host) || host.indexOf(':') !== -1;
}

function sanitizeUrl(url) {
  url.search = '';
  url.hash   = '';
  return url.toString();
}

function classify(url, type) {
  var host = url.hostname;
  var port = url.port;
  if (isIp(host))                                          return 'numeric IP address';
  if (url.protocol === 'http:')                            return 'insecure HTTP link';
  if (port && port !== '443')                              return 'non standard port:' + port;
  if (url.protocol === 'https:' && type === 'script')     return '3P-script';
  if (url.protocol === 'https:' && type === 'sub_frame')  return '3P-frame';
  return null;
}

chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(function(info) {
  chrome.storage.local.get({ logging: false, logs: [] }, function(s) {
    if (!s.logging) return;

    // Only log requests that were actually BLOCKED — ignore allow rule matches
    if (!info.rule || info.rule.action.type !== 'block') return;

    var type = info.request.type;
    if (type !== 'script' && type !== 'sub_frame') return;

    var rawUrl = info.request.url;
    if (typeof rawUrl !== 'string' || !rawUrl) return;

    var url;
    try { url = new URL(rawUrl); } catch(e) { return; }

    var reason = classify(url, type);
    if (!reason) return;

    var callingDomain = 'unknown';
    try {
      // initiator is the origin that triggered the request (e.g. "https://example.com")
      var initiator = info.request.initiator || info.request.documentUrl || '';
      callingDomain = new URL(initiator).hostname || 'unknown';
    } catch(e) {}

    var entry = {
      domain: callingDomain,
      reason: reason,
      url:    sanitizeUrl(url),
      time:   Date.now()
    };

    var logs = s.logs || [];
    logs.push(entry);
    if (logs.length > MAX_LOGS) logs.splice(0, logs.length - MAX_LOGS);
    chrome.storage.local.set({ logs: logs });
  });
});
