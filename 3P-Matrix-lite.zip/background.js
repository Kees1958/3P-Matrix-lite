/**
 * background.js — 3P-Matrix-lite service worker
 *
 * Level index → protection:
 *   0  Easy mode — allow all           → no rules
 *   1  Easy mode with enhanced sec.    → base safety + domain whitelist + block 3P frames
 *   2  Easy medium mode                → base safety + TLD whitelist + block 3P frames+scripts + catch-all
 *   3  Medium mode — trust CDN's       → base safety + domain whitelist + CDN allow + block 3P frames+scripts + catch-all
 *   4  Medium mode                     → base safety + domain whitelist + block 3P frames+scripts + catch-all
 */

var STORAGE_KEY = "3pmatrix_state";

var DEFAULT_STATE = {
  startupLevel: 0,
  level:        0,
  tlds:         ["com","ai","edu","gov","io","net","org","cloud"],
  domains:      []
};

// Resource type lists
var RP_3P = [
  "sub_frame","stylesheet","script","image",
  "font","object","xmlhttprequest","ping","media","websocket","other"
];

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// ── Base safety rules (all levels 1–4) ───────────────────────────────────────
// All use domainType:thirdParty so main-frame HTTP→HTTPS upgrades are unaffected.
function baseRules() {
  return [
    { id: 1001, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^http://", domainType: "thirdParty",
        isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } },
    { id: 1002, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^ws://", domainType: "thirdParty",
        isUrlFilterCaseSensitive: false, resourceTypes: ["websocket"] } },
    { id: 1003, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^https?://[^/?#:]+:([1-9][0-9]?|[1-3][0-9]{2}|4[0-3][0-9]|44[0-2])([/?#]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } },
    { id: 1004, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^https?://[^/?#:]+:(44[4-9]|4[5-9][0-9]|[5-9][0-9]{2}|[1-9][0-9]{3,})([/?#]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } },
    { id: 1005, priority: 50, action: { type: "block" },
      condition: { regexFilter: "^https?://[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+([/?#:]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P } }
  ];
}

// ── Whitelist allow rule builders ─────────────────────────────────────────────
// Uses "||domain/" anchor syntax which matches exact domain authority only,
// preventing substring matches (e.g. "evil.com" won't match "nonevil.com").

function tldAllowRules(tlds) {
  // Rule IDs: 2100–2199 (*.tld/*) and 2500–2599 (*.tld/)
  var r = [];
  tlds.slice(0, 100).forEach(function(tld, i) {
    r.push({ id: 2100 + i, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*." + tld + "/*", resourceTypes: RP_3P } });
    r.push({ id: 2500 + i, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*." + tld + "/", resourceTypes: RP_3P } });
  });
  return r;
}

function domainAllowRules(domains) {
  // Rule IDs: 2000–2099 (*domain/*) and 2400–2499 (*domain/)
  var r = [];
  domains.slice(0, 100).forEach(function(d, i) {
    r.push({ id: 2000 + i, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*" + d + "/*", resourceTypes: RP_3P } });
    r.push({ id: 2400 + i, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*" + d + "/", resourceTypes: RP_3P } });
  });
  return r;
}

// ── Rule builder ──────────────────────────────────────────────────────────────
function buildRules(state) {
  var level   = state.level;
  var tlds    = state.tlds    || [];
  var domains = state.domains || [];
  var rules   = [];

  if (level === 0) return [];

  rules = rules.concat(baseRules());

  // Level 1: domain whitelist + block 3P frames
  if (level === 1) {
    rules = rules.concat(domainAllowRules(domains));
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["sub_frame"] } });
    return rules;
  }

  // Level 2: TLD whitelist + block 3P frames+scripts + catch-all
  if (level === 2) {
    rules = rules.concat(tldAllowRules(tlds));
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["sub_frame"] } });
    rules.push({ id: 3002, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["script","webbundle"] } });
    rules.push({ id: 4000, priority: 10, action: { type: "block" },
      condition: { resourceTypes: RP_3P } });
    return rules;
  }

  // Level 3: domain whitelist + CDN allow + block 3P frames+scripts + catch-all
  // CDN rule ID 2200 — safely above domain (2000–2099) and TLD (2100–2199) ranges
  if (level === 3) {
    rules = rules.concat(domainAllowRules(domains));
    rules.push({ id: 2200, priority: 1000, action: { type: "allow" },
      condition: { urlFilter: "*cdn*", resourceTypes: RP_3P } });
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["sub_frame"] } });
    rules.push({ id: 3002, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["script","webbundle"] } });
    rules.push({ id: 4000, priority: 10, action: { type: "block" },
      condition: { resourceTypes: RP_3P } });
    return rules;
  }

  // Level 4: domain whitelist + block 3P scripts+frames only
  // Intentionally does NOT block images/fonts/stylesheets — too disruptive
  if (level === 4) {
    rules = rules.concat(domainAllowRules(domains));
    rules.push({ id: 3001, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["sub_frame"] } });
    rules.push({ id: 3002, priority: 20, action: { type: "block" },
      condition: { resourceTypes: ["script","webbundle"] } });
    return rules;
  }

  return rules;
}

// ── Icon ──────────────────────────────────────────────────────────────────────
function setIcon(level) {
  try {
    chrome.action.setIcon({ path: {
      "16":  "icon_" + level + "_16.png",
      "32":  "icon_" + level + "_32.png",
      "48":  "icon_" + level + "_48.png",
      "128": "icon_" + level + "_128.png"
    }});
  } catch(e) { /* setIcon fails in some contexts — safe to ignore */ }
}

// ── State helpers ─────────────────────────────────────────────────────────────
function loadState(cb) {
  chrome.storage.local.get(STORAGE_KEY, function(stored) {
    cb(Object.assign({}, DEFAULT_STATE, stored[STORAGE_KEY] || {}));
  });
}

function saveState(s, cb) {
  var o = {}; o[STORAGE_KEY] = s;
  chrome.storage.local.set(o, cb || function(){});
}

function applyState(s, cb) {
  chrome.declarativeNetRequest.getDynamicRules(function(existing) {
    var removeIds = existing.map(function(r) { return r.id; });
    var addRules  = buildRules(s);
    chrome.declarativeNetRequest.updateDynamicRules(
      { removeRuleIds: removeIds, addRules: addRules },
      function() {
        if (chrome.runtime.lastError) {
          // Log error but still call cb so message channel doesn't time out
          console.warn("[3PM] updateDynamicRules:", chrome.runtime.lastError.message);
          if (cb) cb(0);
          return;
        }
        setIcon(s.level);
        rebuildBlockRuleIndex();
        if (cb) cb(addRules.length);
      }
    );
  });
}

// ── Country TLD detection ─────────────────────────────────────────────────────
var SKIP_TLDS = { "us": true };

function browserCountryTlds(cb) {
  chrome.i18n.getAcceptLanguages(function(langs) {
    var seen = {}, tlds = [];
    (langs || []).forEach(function(lang) {
      var parts  = lang.toLowerCase().split('-');
      var region = parts.length > 1 ? parts[parts.length - 1] : parts[0];
      if (/^[a-z]{2,3}$/.test(region) && !SKIP_TLDS[region] && !seen[region]) {
        seen[region] = true;
        tlds.push(region);
      }
    });
    cb(tlds);
  });
}

// ── Lifecycle ─────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === "install") {
    browserCountryTlds(function(countryTlds) {
      var merged = DEFAULT_STATE.tlds.slice();
      countryTlds.forEach(function(tld) {
        if (merged.indexOf(tld) === -1) merged.push(tld);
      });
      var initState = Object.assign({}, DEFAULT_STATE, { tlds: merged });
      saveState(initState, function() { applyState(initState); });
    });
  } else {
    // Update: re-apply existing state to pick up any rule changes
    loadState(function(s) { applyState(s); });
  }
});

chrome.runtime.onStartup.addListener(function() {
  loadState(function(s) {
    // Fix race condition: build startup state first, then apply in one step
    var startupLevel = (typeof s.startupLevel === 'number') ? s.startupLevel : 0;
    var boot = Object.assign({}, s, { level: startupLevel });
    saveState(boot, function() {
      // applyState calls setIcon internally — no separate setIcon call needed
      applyState(boot);
    });
  });
});

// ── Message handler ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {
  if (msg.type === "GET_STATE") {
    loadState(function(s) {
      chrome.declarativeNetRequest.getDynamicRules(function(rules) {
        sendResponse({ ok: true, state: s, ruleCount: rules.length });
      });
    });
    return true;
  }

  if (msg.type === "SET_STATE") {
    var ns = Object.assign({}, DEFAULT_STATE, msg.state);
    // Validate level bounds
    if (typeof ns.level !== 'number' || ns.level < 0 || ns.level > 4) ns.level = 0;
    if (typeof ns.startupLevel !== 'number' || ns.startupLevel < 0 || ns.startupLevel > 4) ns.startupLevel = 0;
    saveState(ns, function() {
      applyState(ns, function(count) {
        sendResponse({ ok: true, ruleCount: count });
      });
    });
    return true;
  }

  if (msg.type === "START_LOGGING") {
    startLoggingTimer();
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === "STOP_LOGGING") {
    stopLogging();
    sendResponse({ ok: true });
    return true;
  }

  sendResponse({ ok: false, error: "Unknown message: " + msg.type });
});

// ── Logging ───────────────────────────────────────────────────────────────────
var LOG_TIMEOUT_MS = 5 * 60 * 1000;
var MAX_LOGS       = 500;
var loggingTimer   = null;

// Cache of ruleId → action type, rebuilt whenever rules are updated.
// Block rule IDs: 1001–1005 (base), 3001 (frames), 3002 (scripts), 4000 (catch-all)
// Allow rule IDs: 2000–2299
// We use this to filter onRuleMatchedDebug to only log block-rule matches.
var BLOCK_RULE_IDS = {};

function rebuildBlockRuleIndex() {
  chrome.declarativeNetRequest.getDynamicRules(function(rules) {
    BLOCK_RULE_IDS = {};
    rules.forEach(function(r) {
      if (r.action && r.action.type === 'block') {
        BLOCK_RULE_IDS[r.id] = true;
      }
    });
  });
}

function stopLogging() {
  if (loggingTimer) { clearTimeout(loggingTimer); loggingTimer = null; }
  // Clear logging flag but preserve logs until logger page has finished reading them.
  // Logger page polls every 2s — give it 3s to do a final read before clearing logs.
  chrome.storage.local.set({ logging: false, logStartTime: null });
  setTimeout(function() {
    chrome.storage.local.set({ logs: [] });
  }, 3000);
  // Notify popup if open
  chrome.runtime.sendMessage({ type: "LOGGING_STOPPED" }, function() {
    if (chrome.runtime.lastError) { /* popup not open — ignore */ }
  });
}

function startLoggingTimer() {
  if (loggingTimer) clearTimeout(loggingTimer);
  loggingTimer = setTimeout(function() {
    loggingTimer = null;
    stopLogging();
  }, LOG_TIMEOUT_MS);
}

// Recover from SW restart mid-session: if storage shows logging=true on startup,
// re-arm the timer based on elapsed time, or stop immediately if already expired.
chrome.runtime.onStartup.addListener(function() {
  chrome.storage.local.get({ logging: false, logStartTime: null }, function(s) {
    if (!s.logging) return;
    var elapsed = s.logStartTime ? (Date.now() - s.logStartTime) : LOG_TIMEOUT_MS;
    var remaining = LOG_TIMEOUT_MS - elapsed;
    if (remaining <= 0) {
      stopLogging();
    } else {
      loggingTimer = setTimeout(function() {
        loggingTimer = null;
        stopLogging();
      }, remaining);
    }
  });
});

function isIp(host) {
  return /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/.test(host) || host.indexOf(':') !== -1;
}

function sanitizeUrl(url) {
  url.search = '';
  url.hash   = '';
  return url.toString();
}

function classify(url, type) {
  var host = url.hostname;
  var port = url.port;
  if (isIp(host))                                              return 'numeric IP address';
  if (url.protocol === 'http:')                                return 'insecure HTTP link';
  if (port && port !== '443')                                  return 'non standard port:' + port;
  if (type === 'script')                                       return '3P-script';
  if (type === 'sub_frame')                                    return '3P-frame';
  if (type === 'image')                                        return '3P-image';
  if (type === 'xmlhttprequest')                               return '3P-XHR';
  if (type === 'media')                                        return '3P-media';
  if (type === 'websocket')                                    return '3P-websocket';
  if (type === 'stylesheet')                                   return '3P-stylesheet';
  if (type === 'font')                                         return '3P-font';
  if (type === 'ping')                                         return '3P-ping';
  return '3P-other';
}

chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(function(info) {
  chrome.storage.local.get({ logging: false, logs: [] }, function(s) {
    if (!s.logging) return;

    // Only log genuine blocks — check against our cached block rule ID map
    if (!info.rule || !BLOCK_RULE_IDS[info.rule.ruleId]) return;

    var type = info.request.type;
    // Capture all resource types that our block rules can match
    var loggable = {
      'script': true, 'sub_frame': true, 'image': true,
      'xmlhttprequest': true, 'media': true, 'websocket': true,
      'stylesheet': true, 'font': true, 'ping': true, 'other': true
    };
    if (!loggable[type]) return;

    var rawUrl = info.request.url;
    if (typeof rawUrl !== 'string' || !rawUrl) return;

    var url;
    try { url = new URL(rawUrl); } catch(e) { return; }

    var reason = classify(url, type);
    if (!reason) return;

    var callingDomain = 'unknown';
    try {
      var initiator = info.request.initiator || info.request.documentUrl || '';
      if (initiator) callingDomain = new URL(initiator).hostname || 'unknown';
    } catch(e) {}

    var entry = {
      domain: callingDomain,
      reason: reason,
      url:    sanitizeUrl(url),
      time:   Date.now()
    };

    var logs = s.logs || [];
    logs.push(entry);
    if (logs.length > MAX_LOGS) logs.splice(0, logs.length - MAX_LOGS);
    chrome.storage.local.set({ logs: logs });
  });
});
