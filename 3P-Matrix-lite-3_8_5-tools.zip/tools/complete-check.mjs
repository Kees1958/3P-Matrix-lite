#!/usr/bin/env node
// ── tools/complete-check.mjs ────────────────────────────────────────────────
// Automated pre-release check suite (Part D of the programming-principles
// audit standard). Run via `npm run check` before every version bump that
// is about to be zipped — not just before a store submission.
//
// What this suite covers (see README section below for what it does NOT):
//   1. Syntax        — `node --check` on every extension .js file
//   2. ESLint         — the project's own .eslintrc.json rule set
//   3. JSON validity  — manifest.json and package.json parse cleanly
//   4. File cross-reference (C20) — every path declared in manifest.json
//      (background, popup, icons, web_accessible_resources, content_scripts),
//      every `import`/`<script src>` in the extension, resolves to a real
//      file on disk; every .js/.html file on disk is reachable from
//      manifest.json (directly or transitively via imports)
//   5. Message-routing cross-reference (C20a) — every MSG_* constant in
//      data/message-types.js has both a router `case` in background.js AND
//      at least one sender elsewhere (either the imported identifier, or its
//      literal string value — the latter covers a plain, non-ES-module
//      content script that cannot `import` the constant), UNLESS it is in
//      the maintained BROADCAST_ONLY set below (which instead must have an
//      .onmessage reader) — this is the exact check that would have caught
//      MSG_SET_MATRIX_DOMAIN_RULE having no sender (see CHANGELOG).
//   6. Version sync   — manifest.json and package.json report the same
//      version string.
//   7. DOM element cross-reference (JSDOM) — parses ui/*.html with a real
//      HTML parser (jsdom) and confirms every `document.getElementById(...)`
//      / `querySelector('#...')` call in that page's own entry script
//      resolves to a real id in the markup. This is a static check (no
//      chrome.* mocking, no live module execution) — see the scope note
//      below for why.
//   8. Functional smoke test — data/state-storage.js (the one module in
//      this codebase holding non-trivial persisted state) exercised
//      end-to-end against a mocked chrome.storage.local: fresh-install
//      defaults, value normalisation (level 0 -> 1), a save/load round
//      trip, and that freshState() never hands back a shared mutable
//      reference into DEFAULT_STATE (the exact bug its own header comment
//      warns about).
//   9. DNR rule-ID range collision check — statically extracts every
//      `idOffset + N` rule-ID base and its loop cap from
//      core/rule-builder.js and checks all resulting ranges pairwise for
//      overlap. This corrects a stale claim this file used to make (see
//      CHANGELOG) — the extension DOES have DNR rule-ID ranges to check.
//   10. Dependency hygiene — (a) every import in extension source code
//      (everything except tools/) is a relative path, since this extension
//      ships with no bundler and a bare specifier would fail at load time;
//      (b) every package.json devDependency is actually referenced by a
//      script or tool file (no orphaned installs).
//   11. Circular dependency check — builds the same import graph as step 4
//      and reports any cycle; a cycle between ES modules risks
//      temporal-dead-zone bugs that only surface at runtime.
//
// What this suite deliberately does NOT cover, and why:
//   - Step 7 is a STATIC id cross-reference, not the full standard's live
//     DOM+JS execution (import the page script as a real ES module against
//     a real DOM, catch anything that throws at load time). Live execution
//     would need a fairly complete chrome.* mock (tabs, windows, storage
//     .session, runtime.sendMessage with per-message-type response shapes,
//     i18n) to avoid throwing on this extension's own real startup path —
//     building and maintaining that mock accurately is a substantially
//     larger, separate effort, and a wrong mock produces false confidence,
//     which is worse than no check. The static id cross-reference below
//     still catches the single most common failure mode (a renamed/removed
//     element id JS still references) without that risk.
//   - No CSS class cross-reference (step 11 in the full standard's
//     numbering) — this extension has no standalone .css files; both pages'
//     styling is a single inline <style> block, audited manually.
//   - Step 8's functional smoke test covers data/state-storage.js only, not
//     core/rule-builder.js or core/tld-engine.js — those are pure functions
//     with no persisted state, already exercised indirectly by step 9 and
//     by manual testing; a state-vector smoke test adds no value to a
//     stateless module.
// These gaps are intentional simplifications for this extension's size, not
// oversights — flagged explicitly per C13a/C13b (no silent partial coverage).
//
// Exit code is non-zero if any hard check fails. Warnings (e.g. the
// BROADCAST_ONLY set needing a manual update) print but do not fail the run.
// ─────────────────────────────────────────────────────────────────────────────

import { execFileSync } from "node:child_process";
import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// ── Config — single source of truth for this script's own tunables ─────────
// Directories scanned for .js files (relative to ROOT).
const JS_SCAN_DIRS = ["", "core", "data", "ui", "util"];
// Message types sent only via chrome.runtime.sendMessage broadcast / a
// dedicated .onmessage reader, by design — expected to have NO router case
// in background.js. Maintain this by hand whenever a broadcast-only type is
// added (see C20a in the standard).
const BROADCAST_ONLY = new Set(["MSG_MATRIX_CLOSED"]);
// HTML pages -> their own entry script, for step 7's id cross-reference.
// Maintain this by hand whenever a new page is added.
const PAGE_ENTRY_SCRIPTS = {
  "ui/popup.html":        "ui/popup.js",
  "ui/matrix-panel.html": "ui/matrix-panel.js",
};
// Module holding persisted state, for step 8's functional smoke test.
const STATE_STORAGE_MODULE = "data/state-storage.js";
// File whose DNR rule-ID ranges get pairwise-collision-checked in step 9.
const RULE_BUILDER_MODULE = "core/rule-builder.js";
// devDependencies invoked as a CLI binary rather than statically imported —
// step 10b would otherwise flag these as unused. Add to this list at the
// same time a new CLI-only devDependency is added (mirrors the standard's
// own maintenance-checklist convention for this exact false-positive class).
const CLI_ONLY_DEPS = new Set(["eslint"]);

let failed = false;
const warn = (msg) => console.warn(`⚠ WARN  ${msg}`);
const fail = (msg) => { failed = true; console.error(`✗ FAIL  ${msg}`); };
const ok   = (msg) => console.log(`✓ OK    ${msg}`);

function listJsFiles() {
  const out = [];
  for (const dir of JS_SCAN_DIRS) {
    const abs = path.join(ROOT, dir);
    if (!existsSync(abs)) continue;
    for (const entry of readdirSync(abs)) {
      const full = path.join(abs, entry);
      if (statSync(full).isFile() && entry.endsWith(".js")) out.push(full);
    }
  }
  return out;
}

// ── 1. Syntax check ─────────────────────────────────────────────────────────
function checkSyntax() {
  console.log("\n── 1. Syntax (node --check) ──");
  for (const file of listJsFiles()) {
    try {
      execFileSync(process.execPath, ["--check", file], { stdio: "pipe" });
    } catch (e) {
      fail(`${path.relative(ROOT, file)}: ${e.stderr?.toString().trim() || e.message}`);
      continue;
    }
  }
  if (!failed) ok(`${listJsFiles().length} files parsed cleanly`);
}

// ── 2. ESLint ────────────────────────────────────────────────────────────────
function checkLint() {
  console.log("\n── 2. ESLint ──");
  if (!existsSync(path.join(ROOT, ".eslintrc.json"))) {
    warn("no .eslintrc.json found — skipping lint step");
    return;
  }
  // Prefer the locally-installed devDependency (matches package.json's
  // pinned version and its legacy .eslintrc.json format) over `npx`, which
  // silently fetches the latest major version and breaks on flat-config-only
  // ESLint releases.
  const localBin = path.join(ROOT, "node_modules", ".bin", process.platform === "win32" ? "eslint.cmd" : "eslint");
  if (!existsSync(localBin)) {
    warn("eslint not installed locally — run `npm install` first; skipping lint step");
    return;
  }
  try {
    execFileSync(localBin, [".", "--ext", ".js"], { cwd: ROOT, stdio: "pipe" });
    ok("eslint clean");
  } catch (e) {
    fail(`eslint reported issues:\n${e.stdout?.toString() || e.message}`);
  }
}

// ── 3. JSON validity ─────────────────────────────────────────────────────────
function loadJson(relPath) {
  const full = path.join(ROOT, relPath);
  if (!existsSync(full)) { fail(`${relPath}: file not found`); return null; }
  try {
    return JSON.parse(readFileSync(full, "utf8"));
  } catch (e) {
    fail(`${relPath}: invalid JSON — ${e.message}`);
    return null;
  }
}

function checkJson() {
  console.log("\n── 3. JSON validity ──");
  const manifest = loadJson("manifest.json");
  const pkg      = loadJson("package.json");
  if (manifest && pkg) ok("manifest.json and package.json parse cleanly");
  return { manifest, pkg };
}

// ── 4. File cross-reference (C20) ───────────────────────────────────────────
// Strips /* block */ and // line comments before static analysis, so
// example code quoted inside a header comment (e.g. "Load via: import ...")
// is never mistaken for a real import statement.
function stripComments(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/(^|[^:])\/\/.*$/gm, "$1");
}

function extractImportPaths(file) {
  const src = stripComments(readFileSync(file, "utf8"));
  const paths = [];
  const importRe = /\bimport\s+(?:[\s\S]*?\bfrom\s+)?["']([^"']+)["']/g;
  let m;
  while ((m = importRe.exec(src)) !== null) {
    if (m[1].startsWith(".") || m[1].startsWith("/")) paths.push(m[1]);
  }
  return paths;
}

function extractHtmlScriptSrcs(file) {
  const src = readFileSync(file, "utf8").replace(/<!--[\s\S]*?-->/g, "");
  const paths = [];
  const re = /<script[^>]+src=["']([^"']+)["']/g;
  let m;
  while ((m = re.exec(src)) !== null) paths.push(m[1]);
  return paths;
}

function checkFileReferences(manifest) {
  console.log("\n── 4. File cross-reference (C20) ──");
  if (!manifest) { warn("skipped — manifest.json failed to parse"); return; }

  const declared = new Set();

  // manifest.json declared paths
  if (manifest.background?.service_worker) declared.add(manifest.background.service_worker);
  if (manifest.action?.default_popup) declared.add(manifest.action.default_popup);
  for (const iconPath of Object.values(manifest.icons || {})) declared.add(iconPath);
  for (const iconPath of Object.values(manifest.action?.default_icon || {})) declared.add(iconPath);
  for (const war of manifest.web_accessible_resources || []) {
    for (const r of war.resources || []) declared.add(r);
  }
  for (const cs of manifest.content_scripts || []) {
    for (const js of cs.js || []) declared.add(js);
    for (const css of cs.css || []) declared.add(css);
  }

  // Every declared path must exist on disk.
  for (const p of declared) {
    if (!existsSync(path.join(ROOT, p))) fail(`manifest.json references missing file: ${p}`);
  }

  // Every HTML file's <script src> and every JS file's static imports must
  // resolve — walked transitively from the manifest's own entry points.
  const visited = new Set();
  const toVisit = [...declared].filter((p) => p.endsWith(".js") || p.endsWith(".html"));

  while (toVisit.length) {
    const rel = toVisit.pop();
    if (visited.has(rel)) continue;
    visited.add(rel);
    const abs = path.join(ROOT, rel);
    if (!existsSync(abs)) continue; // already flagged above if it was manifest-declared

    const dir = path.dirname(rel);
    if (rel.endsWith(".html")) {
      for (const src of extractHtmlScriptSrcs(abs)) {
        const resolved = path.normalize(path.join(dir, src));
        if (!existsSync(path.join(ROOT, resolved))) {
          fail(`${rel}: <script src="${src}"> does not resolve to a file on disk`);
        } else {
          toVisit.push(resolved);
        }
      }
    } else if (rel.endsWith(".js")) {
      for (const imp of extractImportPaths(abs)) {
        const resolved = path.normalize(path.join(dir, imp));
        if (!existsSync(path.join(ROOT, resolved))) {
          fail(`${rel}: import "${imp}" does not resolve to a file on disk`);
        } else {
          toVisit.push(resolved);
        }
      }
    }
  }

  // Every .js file on disk should be reachable from the manifest, or be a
  // build-time-only tool explicitly excluded here.
  const buildOnly = new Set(["tools/complete-check.mjs"]);
  for (const file of listJsFiles()) {
    const rel = path.relative(ROOT, file).split(path.sep).join("/");
    if (buildOnly.has(rel)) continue;
    if (!visited.has(rel)) warn(`${rel} is not reachable from manifest.json — orphaned file, or an untracked entry point`);
  }

  if (!failed) ok("all declared/imported/script-src paths resolve to real files");
}

// ── 5. Message-routing cross-reference (C20a) ───────────────────────────────
function checkMessageRouting() {
  console.log("\n── 5. Message-routing cross-reference (C20a) ──");
  const typesFile = path.join(ROOT, "data/message-types.js");
  if (!existsSync(typesFile)) { warn("data/message-types.js not found — skipped"); return; }

  const typesSrc = readFileSync(typesFile, "utf8");
  const constDecls = [...typesSrc.matchAll(/export const (MSG_\w+)\s*=\s*"([^"]+)"/g)];
  const constNames = constDecls.map((m) => m[1]);
  const valueOf     = Object.fromEntries(constDecls.map((m) => [m[1], m[2]]));

  const bgFile = path.join(ROOT, "background.js");
  const bgSrc  = existsSync(bgFile) ? readFileSync(bgFile, "utf8") : "";

  // Every JS file's sendMessage/send() call sites, to find senders.
  const allSrc = listJsFiles().map((f) => readFileSync(f, "utf8")).join("\n");

  for (const name of constNames) {
    const hasRouterCase = new RegExp(`case\\s+${name}\\s*:`).test(bgSrc);
    // A real sender constructs a message payload with this type — the
    // codebase's own consistent shape is `{ type: MSG_X, ... }`. Matching
    // that specific shape (rather than any occurrence of the name) avoids
    // false negatives from the constant's own declaration, its import list,
    // or its router `case` all counting as "used".
    //
    // A sender is also valid if it uses the constant's raw STRING VALUE
    // directly (`{ type: "THE_VALUE", ... }`) instead of the imported
    // identifier — this is deliberate, not a gap: a plain (non-ES-module)
    // content script (see content/fail-break.js) cannot `import` from
    // data/message-types.js at all, so MSG_FAIL_BREAK's one sender uses its
    // literal string value instead, exactly as that file's own header
    // comment documents. Recognizing this pattern generally (not as a
    // one-off special case) means any FUTURE content script that needs the
    // same workaround is covered automatically, with no changes needed here.
    const hasAnySender = new RegExp(`type:\\s*${name}\\b`).test(allSrc)
      || (valueOf[name] && new RegExp(`type:\\s*["']${valueOf[name]}["']`).test(allSrc));

    if (BROADCAST_ONLY.has(name)) {
      const hasReader = new RegExp(`${name}[\\s\\S]{0,80}onmessage|onmessage[\\s\\S]{0,200}${name}`, "m").test(allSrc)
        || (allSrc.match(new RegExp(`msg\\.type\\s*===\\s*${name}`)) !== null);
      if (!hasReader) fail(`${name} is in BROADCAST_ONLY but no .onmessage reader found for it`);
      if (hasRouterCase) warn(`${name} is in BROADCAST_ONLY but ALSO has a background.js router case — is it still broadcast-only?`);
    } else {
      if (!hasRouterCase) fail(`${name}: no router case in background.js (and not in BROADCAST_ONLY)`);
      if (!hasAnySender) warn(`${name}: has a router case but no sendMessage call site found anywhere — dead message type? (see MSG_SET_MATRIX_DOMAIN_RULE precedent in CHANGELOG)`);
    }
  }
  if (!failed) ok(`${constNames.length} message types checked (${BROADCAST_ONLY.size} broadcast-only)`);
}

// ── 6. Version sync ──────────────────────────────────────────────────────────
function checkVersionSync(manifest, pkg) {
  console.log("\n── 6. Version sync ──");
  if (!manifest || !pkg) { warn("skipped — manifest.json or package.json failed to parse"); return; }
  if (manifest.version !== pkg.version) {
    fail(`version mismatch: manifest.json=${manifest.version} package.json=${pkg.version}`);
  } else {
    ok(`manifest.json and package.json both at ${manifest.version}`);
  }
}

// ── 7. DOM element cross-reference (JSDOM) ──────────────────────────────────
// Static check: every getElementById/querySelector('#id') call in a page's
// own entry script must resolve to a real id in that page's HTML. See the
// scope note in the header comment for why this stops short of live
// module execution.
async function checkDomReferences() {
  console.log("\n── 7. DOM element cross-reference (JSDOM) ──");
  const jsdomPath = path.join(ROOT, "node_modules", "jsdom");
  if (!existsSync(jsdomPath)) {
    warn("jsdom not installed locally — run `npm install` first; skipping DOM check");
    return;
  }
  const { JSDOM } = await import("jsdom");

  let checkedPages = 0, checkedRefs = 0;
  for (const [htmlRel, jsRel] of Object.entries(PAGE_ENTRY_SCRIPTS)) {
    const htmlAbs = path.join(ROOT, htmlRel);
    const jsAbs   = path.join(ROOT, jsRel);
    if (!existsSync(htmlAbs)) { fail(`${htmlRel}: declared in PAGE_ENTRY_SCRIPTS but missing on disk`); continue; }
    if (!existsSync(jsAbs))   { fail(`${jsRel}: declared in PAGE_ENTRY_SCRIPTS but missing on disk`);   continue; }

    const dom = new JSDOM(readFileSync(htmlAbs, "utf8"));
    const ids = new Set(
      [...dom.window.document.querySelectorAll("[id]")].map((el) => el.id)
    );

    const src = stripComments(readFileSync(jsAbs, "utf8"));
    const refs = new Set();
    const getByIdRe = /getElementById\(\s*['"]([^'"]+)['"]\s*\)/g;
    const querySelRe = /querySelector(?:All)?\(\s*['"]#([A-Za-z0-9_-]+)['"]\s*\)/g;
    let m;
    while ((m = getByIdRe.exec(src)) !== null)  refs.add(m[1]);
    while ((m = querySelRe.exec(src)) !== null) refs.add(m[1]);

    for (const id of refs) {
      checkedRefs++;
      if (!ids.has(id)) fail(`${jsRel}: references #${id}, not found in ${htmlRel}`);
    }
    checkedPages++;
  }
  if (!failed) ok(`${checkedRefs} element-id references checked across ${checkedPages} pages`);
}

// ── 8. Functional smoke test — data/state-storage.js ────────────────────────
// Exercises the real exported functions against a mocked chrome.storage.local
// — not just that the module parses, that it behaves correctly across a
// realistic init -> normalise -> save -> reload -> clear sequence.
async function checkStateStorageSmoke() {
  console.log("\n── 8. Functional smoke test (state-storage.js) ──");
  const modAbs = path.join(ROOT, STATE_STORAGE_MODULE);
  if (!existsSync(modAbs)) { warn(`${STATE_STORAGE_MODULE} not found — skipped`); return; }

  // In-memory mock of chrome.storage.local — no test may leak into another.
  let backingStore = {};
  globalThis.chrome = {
    storage: {
      local: {
        get(key, cb) { cb({ [key]: backingStore[key] }); },
        set(obj, cb) { Object.assign(backingStore, obj); if (cb) cb(); },
      },
    },
  };

  const mod = await import(pathToFileURL(modAbs).href + `?t=${Date.now()}`);
  const { loadState, saveState, freshState, DEFAULT_STATE, STORAGE_KEY } = mod;

  const loadAsync = () => new Promise((resolve) => loadState(resolve));
  const saveAsync = (s) => new Promise((resolve) => saveState(s, resolve));

  try {
    // Guard: initialise — fresh install (empty storage) falls back to defaults.
    backingStore = {};
    let s = await loadAsync();
    if (s.level !== DEFAULT_STATE.level) fail(`fresh load: expected level ${DEFAULT_STATE.level}, got ${s.level}`);
    else ok("fresh install loads DEFAULT_STATE");

    // Value normalisation — stored level/startupLevel of 0 is invalid, must become 1.
    backingStore = { [STORAGE_KEY]: { level: 0, startupLevel: 0 } };
    s = await loadAsync();
    if (s.level !== 1 || s.startupLevel !== 1) fail(`normalisation: level 0 did not normalise to 1 (got level=${s.level}, startupLevel=${s.startupLevel})`);
    else ok("level/startupLevel 0 normalises to 1");

    // Save/load round trip.
    const written = freshState({ level: 4, siteRules: { "example.com": 5 } });
    await saveAsync(written);
    s = await loadAsync();
    if (s.level !== 4 || s.siteRules["example.com"] !== 5) fail("save/load round trip did not preserve written state");
    else ok("save/load round trip preserves state");

    // Guard: release/clear — a fresh freshState() write must fully reset, not merge leftovers.
    await saveAsync(freshState());
    s = await loadAsync();
    if (s.level !== DEFAULT_STATE.level || Object.keys(s.siteRules).length !== Object.keys(DEFAULT_STATE.siteRules).length) {
      fail("reset write did not clear the previous save's site rules");
    } else {
      ok("reset write clears previous state cleanly");
    }

    // The exact bug freshState()'s own header comment warns about: two
    // independent freshState() calls must never share the same siteRules
    // object, or mutating one would corrupt the other (and DEFAULT_STATE).
    const a = freshState();
    const b = freshState();
    a.siteRules["mutated.example"] = 1;
    if (b.siteRules["mutated.example"] || DEFAULT_STATE.siteRules["mutated.example"]) {
      fail("freshState() returned a shared siteRules reference — mutation leaked across instances");
    } else {
      ok("freshState() gives independent, non-shared siteRules objects");
    }
  } finally {
    delete globalThis.chrome; // guard: release the mock so it can't leak into a later step
  }
}

// ── 9. DNR rule-ID range collision check ────────────────────────────────────
// Statically extracts every `idOffset + N` rule-ID base used inside
// core/rule-builder.js, pairs each with its function's own `.slice(0, CAP)`
// loop bound (or treats it as a single-id range with no such bound), and
// checks the resulting ranges pairwise for overlap.
function extractIdRanges(src) {
  const ranges = [];
  // Split into top-level function bodies via brace counting — good enough
  // for this file's flat, single-nesting-level function shape.
  const funcRe = /function\s+(\w+)\s*\([^)]*\)\s*\{/g;
  let m;
  while ((m = funcRe.exec(src)) !== null) {
    const name = m[1];
    let depth = 1;
    let i = m.index + m[0].length;
    const start = i;
    while (depth > 0 && i < src.length) {
      if (src[i] === "{") depth++;
      else if (src[i] === "}") depth--;
      i++;
    }
    const body = src.slice(start, i - 1);

    const capMatch = body.match(/\.slice\(0,\s*(\d+)\)/);
    const cap = capMatch ? parseInt(capMatch[1], 10) : null;

    const baseRe = /idOffset\s*\+\s*(\d+)/g;
    const basesInBody = new Set();
    let bm;
    while ((bm = baseRe.exec(body)) !== null) basesInBody.add(parseInt(bm[1], 10));

    // A function's `.slice(0, CAP)` bounds every id-generating loop inside
    // it (this file's functions never mix a loop-driven base with an
    // unrelated one under a different, unrelated cap) — so every base found
    // in the body gets that same cap when one exists; with no slice at all
    // each base is a single, non-looped id push (size 1).
    for (const base of basesInBody) {
      ranges.push({ name, base, size: cap !== null ? cap : 1 });
    }
  }
  return ranges;
}

function checkDnrRanges() {
  console.log("\n── 9. DNR rule-ID range collision check ──");
  const modAbs = path.join(ROOT, RULE_BUILDER_MODULE);
  if (!existsSync(modAbs)) { warn(`${RULE_BUILDER_MODULE} not found — skipped`); return; }

  const src = stripComments(readFileSync(modAbs, "utf8"));
  const ranges = extractIdRanges(src);

  let collisions = 0;
  for (let i = 0; i < ranges.length; i++) {
    for (let j = i + 1; j < ranges.length; j++) {
      const a = ranges[i], b = ranges[j];
      const aEnd = a.base + a.size - 1;
      const bEnd = b.base + b.size - 1;
      const overlaps = a.base <= bEnd && b.base <= aEnd;
      if (overlaps) {
        collisions++;
        fail(`ID range collision: ${a.name} [${a.base}-${aEnd}] overlaps ${b.name} [${b.base}-${bEnd}]`);
      }
    }
  }
  if (!collisions) ok(`${ranges.length} rule-ID ranges checked, no overlaps`);
}

// ── 10. Dependency hygiene ───────────────────────────────────────────────────
function checkDependencyHygiene(pkg) {
  console.log("\n── 10. Dependency hygiene ──");
  if (!pkg) { warn("skipped — package.json failed to parse"); return; }

  // (a) Every import in extension source (everything except tools/) is a
  // relative path — a bare specifier would fail at load time, since this
  // extension ships with no bundler.
  let bareImports = 0;
  for (const file of listJsFiles()) {
    const rel = path.relative(ROOT, file).split(path.sep).join("/");
    if (rel.startsWith("tools/")) continue;
    const src = stripComments(readFileSync(file, "utf8"));
    const importRe = /\bimport\s+(?:[\s\S]*?\bfrom\s+)?["']([^"']+)["']/g;
    let m;
    while ((m = importRe.exec(src)) !== null) {
      const spec = m[1];
      if (!spec.startsWith(".") && !spec.startsWith("/")) {
        bareImports++;
        fail(`${rel}: bare import specifier "${spec}" — extension ships with no bundler, this will fail to load`);
      }
    }
  }
  if (!bareImports) ok("no bare import specifiers in extension source");

  // (b) Every devDependency is referenced by some script or tool file.
  // listJsFiles() only scans JS_SCAN_DIRS (extension source), not tools/,
  // so tools/*.mjs is read directly here instead.
  const toolsDir = path.join(ROOT, "tools");
  const toolFiles = existsSync(toolsDir)
    ? readdirSync(toolsDir).filter((f) => f.endsWith(".mjs") || f.endsWith(".js")).map((f) => path.join(toolsDir, f))
    : [];
  const allToolAndConfigSrc = toolFiles.map((f) => readFileSync(f, "utf8")).join("\n")
    + JSON.stringify(pkg.scripts || {});

  let orphaned = 0;
  for (const dep of Object.keys(pkg.devDependencies || {})) {
    const used = CLI_ONLY_DEPS.has(dep) || allToolAndConfigSrc.includes(dep);
    if (!used) { orphaned++; fail(`devDependency "${dep}" is not referenced by any script or tool file — orphaned install?`); }
  }
  if (!orphaned) ok("all devDependencies are referenced");
}

// ── 11. Circular dependency check ────────────────────────────────────────────
// Reuses step 4's own import-path extraction to build a directed module
// graph, then DFS's it for cycles.
function checkCircularDependencies() {
  console.log("\n── 11. Circular dependency check ──");
  const graph = new Map(); // rel path -> [rel path, ...]
  for (const file of listJsFiles()) {
    const rel = path.relative(ROOT, file).split(path.sep).join("/");
    const dir = path.dirname(rel);
    const deps = extractImportPaths(file).map((imp) => path.normalize(path.join(dir, imp)).split(path.sep).join("/"));
    graph.set(rel, deps);
  }

  const WHITE = 0, GRAY = 1, BLACK = 2;
  const state = new Map([...graph.keys()].map((k) => [k, WHITE]));
  let cyclesFound = 0;

  function dfs(node, stack) {
    state.set(node, GRAY);
    stack.push(node);
    for (const dep of graph.get(node) || []) {
      if (!graph.has(dep)) continue; // resolves outside the scanned set (e.g. a directory index) — step 4 already checks existence
      if (state.get(dep) === GRAY) {
        cyclesFound++;
        const cycleStart = stack.indexOf(dep);
        fail(`circular dependency: ${stack.slice(cycleStart).concat(dep).join(" -> ")}`);
      } else if (state.get(dep) === WHITE) {
        dfs(dep, stack);
      }
    }
    stack.pop();
    state.set(node, BLACK);
  }

  for (const node of graph.keys()) {
    if (state.get(node) === WHITE) dfs(node, []);
  }
  if (!cyclesFound) ok(`${graph.size} modules checked, no import cycles`);
}

// ── Run ──────────────────────────────────────────────────────────────────────
async function main() {
  checkSyntax();
  checkLint();
  const { manifest, pkg } = checkJson();
  checkFileReferences(manifest);
  checkMessageRouting();
  checkVersionSync(manifest, pkg);
  await checkDomReferences();
  await checkStateStorageSmoke();
  checkDnrRanges();
  checkDependencyHygiene(pkg);
  checkCircularDependencies();

  console.log("\n" + (failed ? "✗ complete-check FAILED — see above" : "✓ complete-check passed"));
  process.exit(failed ? 1 : 0);
}

main();
