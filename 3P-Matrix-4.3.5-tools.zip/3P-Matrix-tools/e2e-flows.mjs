#!/usr/bin/env node
// ── tools/e2e-flows.mjs ──────────────────────────────────────────────────────────
// End-to-end test in a real Chromium with the unpacked extension loaded: every user flow that goes
// through the service-worker router — level, lock/unlock, safer-regions edit, allow list (parse,
// replace, other locks untouched), "Trust this site", Show Matrix panel (open, override set/undo
// with the DNR rule checked, panel closed with its tab), settings export — and protection 12 (4.3.0):
// VirusTotal key and download settings (validation, the key never leaves the service worker, not in
// a backup, kept on restore), a real executable download opening the warning window with its record,
// "Proceed anyway" releasing it, and no window for an allow-list site or with protection 12 unticked.
// Every message name, level, action and id band comes from the extension's own modules (C39a) —
// nothing is typed here except the throwaway test hosts.
//
// Usage:  node e2e-flows.mjs --extension ../3P-Matrix [--chromium /opt/pw-browsers/chromium]
// Needs:  the `playwright` package (npm i playwright) and a Chromium binary.
// Exit:   0 = all pass · 1 = a flow failed · 2 = did not run (C38)
// ─────────────────────────────────────────────────────────────────────────────

import { createServer } from "node:http";
import { existsSync } from "node:fs";
import { resolve, join } from "node:path";
import { pathToFileURL } from "node:url";

// ── Settings (one place) ─────────────────────────────────────────────────────
const EXIT = Object.freeze({ OK: 0, FAILED: 1, DID_NOT_RUN: 2 });
const TEST_HOST = "127.0.0.1";                       // valid lockable host (isValidHost needs a dot)
const TEST_PAGE = "<!doctype html><title>e2e</title><p>e2e";
const ALLOW_LIST_INPUT = "https://www.example.com/x\n# comment\nfoo.org\nbad host!";
const ALLOW_LIST_PARSED = ["example.com", "foo.org"];
const ALLOW_LIST_KEEP = "foo.org";
const TRUST_URL = "https://trusted.example.net/";
const TRUST_SITE = "example.net";
const MATRIX_TEST_DOMAIN = "qmusic.be";
const UPGRADE_SITE_KEY = "news.example";            // a pre-4.2.3 per-site matrix key
const SCHEMA_BEFORE = 1;                             // what 4.2.2 stored
const LEGACY_SCOPE = "code";                         // pre-4.2 entry shape
const SAFER_TLD_INPUT = ".FR";
const SAFER_TLD = "fr";
const SW_SETTLE_MS = 1500;                           // let onInstalled apply the first rule set
const UI_SETTLE_MS = 800;                            // window open/close round trip
const TEST_VT_KEY = "ab".repeat(32);                 // 64 hex characters — format-valid, never sent anywhere here
const BAD_VT_KEY = "not-a-key";
const BAD_DOMAIN = "bad domain!";
const TRUSTED_DOWNLOAD_DOMAIN = "files.example.org";
const DOWNLOAD_PATH = "/setup-e2e.exe";              // a monitored (executable) file type
const DOWNLOAD_BODY = "MZ e2e";
const DOWNLOAD_WAIT_MS = 30000;                      // VT budget + host checks (DNS/RDAP time out offline)
const NO_WINDOW_WAIT_MS = 8000;                      // long enough for the budget: no window may appear
const SCHEMA_431 = 2;                                // what 4.3.1 stored (before the default-off migration)
const BLOB_FILE = "made-by-page.exe";               // a file a page generates itself (blob: URL)
const HIDDEN_EXT_TEXT = "was hidden";               // DownloadSentinel's obfuscation signal wording
// Playwright saves downloads under a random name without extension, so a blob: file is recognised by its
// executable MIME type here (DownloadSentinel DangerousMimes) — in a real browser the name counts too.
const BLOB_MIME = "application/x-msdownload";
const VT_SKIPPED_TEXT = "Reputation lookup at VirusTotal skipped";   // 4.3.4: the VT box without a key (DS item 3)
const DATA_FILE = "inline-e2e.exe";                  // a data: download (no host of its own → referrer counts)

function arg(name) { const i = process.argv.indexOf(`--${name}`); return i === -1 ? null : process.argv[i + 1]; }
function didNotRun(msg) { console.error(`e2e-flows: DID NOT RUN — ${msg}`); process.exit(EXIT.DID_NOT_RUN); }
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

const ext = arg("extension");
if (!ext || !existsSync(join(ext, "manifest.json"))) didNotRun("missing or invalid --extension <folder>");
const EXT = resolve(ext);
let chromium, C, M;
try { ({ chromium } = await import("playwright")); } catch { didNotRun("the playwright package is not installed (npm i playwright)"); }
try {
  C = await import(pathToFileURL(join(EXT, "data/constants.js")).href);
  M = await import(pathToFileURL(join(EXT, "data/message-types.js")).href);
} catch (e) { didNotRun(`cannot import extension modules: ${e.message}`); }

// Local test site (released in finally)
const server = createServer((req, res) => {
  if (req.url.startsWith(DOWNLOAD_PATH)) {
    res.writeHead(200, { "content-type": "application/octet-stream", "content-disposition": `attachment; filename="${DOWNLOAD_PATH.slice(1)}"` });
    res.end(DOWNLOAD_BODY);
    return;
  }
  res.writeHead(200, { "content-type": "text/html" }); res.end(TEST_PAGE);
});
await new Promise((r) => server.listen(0, TEST_HOST, r));
const PAGE_URL = `http://${TEST_HOST}:${server.address().port}/`;

let ctx = null, failed = 0;
function ok(name, cond, info) {
  if (!cond) failed++;
  console.log(`${cond ? "PASS" : "FAIL"} ${name}${cond ? "" : "  " + JSON.stringify(info)}`);
}

try {
  ctx = await chromium.launchPersistentContext("", {
    headless: false, executablePath: arg("chromium") || undefined,
    args: ["--headless=new", `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`]
  });
  let [sw] = ctx.serviceWorkers();
  if (!sw) sw = await ctx.waitForEvent("serviceworker");
  const extId = new URL(sw.url()).host;
  const optionsUrl = `chrome-extension://${extId}/ui/options.html`;
  await sleep(SW_SETTLE_MS);

  const site = await ctx.newPage(); await site.goto(PAGE_URL);
  const page = await ctx.newPage(); await page.goto(optionsUrl);
  const tabId = await page.evaluate(async (u) => (await chrome.tabs.query({ url: u + "*" }))[0].id, PAGE_URL);
  const send = (msg) => page.evaluate((m) => chrome.runtime.sendMessage(m), msg);
  const popup = (type, extra = {}) => send({ type, tabId, url: PAGE_URL, ...extra });
  const matrixRuleCount = () => sw.evaluate(async (base) =>
    (await chrome.declarativeNetRequest.getDynamicRules()).filter((r) => r.id >= base).length, C.MATRIX_RULE_ID_BASE);

  // Upgrade path: state exactly as 4.2.2 stored it (schema 1, per-site key, { code } entry) must
  // come out global with Script + Frame, and Chrome must get global rules for it.
  await sw.evaluate(async ({ key, site, domain, schema, scope, action }) => {
    const st = (await chrome.storage.local.get(key))[key];
    st.schema = schema;
    st.matrixRules = { [site]: { [domain]: { [scope]: action } } };
    await chrome.storage.local.set({ [key]: st });
  }, { key: C.STORAGE_KEY_STATE, site: UPGRADE_SITE_KEY, domain: MATRIX_TEST_DOMAIN, schema: SCHEMA_BEFORE, scope: LEGACY_SCOPE, action: C.MATRIX_ACTION.BLOCK });
  let r = await send({ type: M.MSG_SET_DNS, first: C.DEFAULT_DNS_FIRST, second: C.DEFAULT_DNS_SECOND });   // any save = load → migrate → apply
  const upgraded = await sw.evaluate(async (key) => (await chrome.storage.local.get(key))[key], C.STORAGE_KEY_STATE);
  ok("upgrade: schema-1 per-site { code } rule → global Script + Frame",
     upgraded.schema === C.STATE_SCHEMA_VERSION &&
     Object.keys(upgraded.matrixRules).join() === C.MATRIX_SITE_ALL &&                     // key order from storage is not stable —
     Object.values(C.MATRIX_SCOPE).every((sc) =>                                           // compare values, not JSON text
       upgraded.matrixRules[C.MATRIX_SITE_ALL][MATRIX_TEST_DOMAIN][sc] === C.MATRIX_ACTION.BLOCK),
     upgraded.matrixRules);
  ok("upgrade: Chrome holds one global rule per scope", (await matrixRuleCount()) === Object.keys(C.MATRIX_SCOPE).length, await matrixRuleCount());
  await send({ type: M.MSG_RESET_SETTINGS });

  // Levels and lock
  r = await popup(M.MSG_SET_LEVEL, { level: C.LEVEL.HIGH });
  ok("set level", r.ok && r.data.level === C.LEVEL.HIGH, r);
  await popup(M.MSG_SET_LEVEL, { level: C.LEVEL.MEDIUM });
  r = await popup(M.MSG_TOGGLE_LOCK);
  ok("lock pins the current level, session level restored", r.data.lockedLevel === C.LEVEL.MEDIUM && r.data.sessionLevel === C.LEVEL.HIGH, r.data);
  r = await popup(M.MSG_TOGGLE_LOCK);
  ok("unlock", r.data.lockedLevel === null, r.data);

  // Safer regions
  r = await popup(M.MSG_SET_SAFE_ZONE, { addTld: SAFER_TLD_INPUT });
  ok("safer regions: add (normalized)", r.data.safeZone.tlds.includes(SAFER_TLD), r.data.safeZone);
  r = await popup(M.MSG_SET_SAFE_ZONE, { removeTld: SAFER_TLD });
  ok("safer regions: remove", !r.data.safeZone.tlds.includes(SAFER_TLD), r.data.safeZone);
  r = await popup(M.MSG_SET_SAFE_ZONE, { restoreDefault: true });
  ok("safer regions: default", r.ok, r);

  // Allow list never touches a lock at another level
  await popup(M.MSG_SET_LEVEL, { level: C.LEVEL.STRICT });
  await popup(M.MSG_TOGGLE_LOCK);
  r = await send({ type: M.MSG_SET_ALLOW_LIST, text: ALLOW_LIST_INPUT });
  ok("allow list: parse", r.data.allowList === ALLOW_LIST_PARSED.join("\n"), r.data.allowList);
  r = await send({ type: M.MSG_SET_ALLOW_LIST, text: ALLOW_LIST_KEEP });
  ok("allow list: replace", r.data.allowList === ALLOW_LIST_KEEP, r.data.allowList);
  r = await popup(M.MSG_GET_POPUP_STATE);
  ok("allow list: other-level lock untouched", r.data.lockedLevel === C.LEVEL.STRICT, r.data);
  await popup(M.MSG_TOGGLE_LOCK);

  // "Trust this site" — sent from a throwaway extension page (the action navigates the sender's tab)
  const tp = await ctx.newPage(); await tp.goto(optionsUrl);
  await tp.evaluate((m) => chrome.runtime.sendMessage(m), { type: M.MSG_WARNING_ACTION, action: M.WARNING_ACTION.TRUST, url: TRUST_URL }).catch(() => {});
  await tp.close().catch(() => {});
  r = await send({ type: M.MSG_GET_OPTIONS });
  ok("trust adds the site to the allow list", r.data.allowList.split("\n").includes(TRUST_SITE), r.data.allowList);

  // Show Matrix
  const windows = () => page.evaluate(async () => (await chrome.windows.getAll()).length);
  const before = await windows();
  r = await popup(M.MSG_OPEN_MATRIX); await sleep(UI_SETTLE_MS);
  ok("Show Matrix: panel window opened", r.ok && (await windows()) === before + 1, r);
  r = await send({ type: M.MSG_SET_MATRIX_RULE, tabId, domain: MATRIX_TEST_DOMAIN, scope: C.MATRIX_SCOPE.SCRIPT, action: C.MATRIX_ACTION.BLOCK });
  ok("Show Matrix: override set", r.ok && r.data.entries.some((e) => e.domain === MATRIX_TEST_DOMAIN && e.script && e.script.overridden), r);
  const rulesSet = await matrixRuleCount();
  await send({ type: M.MSG_SET_MATRIX_RULE, tabId, domain: MATRIX_TEST_DOMAIN, scope: C.MATRIX_SCOPE.SCRIPT, action: null });
  const rulesUndone = await matrixRuleCount();
  ok("Show Matrix: undo removes the DNR rule", rulesSet === 1 && rulesUndone === 0, { rulesSet, rulesUndone });
  await site.close(); await sleep(UI_SETTLE_MS);
  ok("Show Matrix: panel closes with its tab", (await windows()) === before, { before });

  // Export
  r = await send({ type: M.MSG_EXPORT_SETTINGS });
  ok("settings export", r.ok && r.data.file.settings.allowList.includes(ALLOW_LIST_KEEP), r);

  // ── Protection 12: settings ──
  const storedDownloads = async () => (await sw.evaluate(async (key) => (await chrome.storage.local.get(key))[key], C.STORAGE_KEY_STATE)).downloads;
  r = await send({ type: M.MSG_SET_VT_KEY, key: BAD_VT_KEY });
  ok("VT key: invalid key refused", !r.ok, r);
  r = await send({ type: M.MSG_SET_VT_KEY, key: TEST_VT_KEY });
  ok("VT key: saved, the model only says it is set", r.ok && r.data.downloads.vtKeySet === true && !JSON.stringify(r.data).includes(TEST_VT_KEY), r.data && r.data.downloads);
  ok("VT key: stored in state.downloads", (await storedDownloads()).vtApiKey === TEST_VT_KEY);
  r = await send({ type: M.MSG_SET_DOWNLOAD_SETTINGS, settings: { vtApiKey: BAD_VT_KEY } });
  ok("download settings: the key is not editable through the settings form", !r.ok, r);
  r = await send({ type: M.MSG_SET_DOWNLOAD_SETTINGS, settings: { trustedDomains: [BAD_DOMAIN] } });
  ok("download settings: invalid trusted domain refused", !r.ok, r);
  r = await send({ type: M.MSG_SET_DOWNLOAD_SETTINGS, settings: { trustedDomains: [TRUSTED_DOWNLOAD_DOMAIN], autoAllowThreshold: C.AUTO_ALLOW_THRESHOLD_MAX + 1 } });
  ok("download settings: saved, threshold clamped", r.ok && r.data.downloads.trustedDomains.join() === TRUSTED_DOWNLOAD_DOMAIN &&
     r.data.downloads.autoAllowThreshold === C.AUTO_ALLOW_THRESHOLD_MAX, r.data && r.data.downloads);
  r = await send({ type: M.MSG_EXPORT_SETTINGS });
  const backup = r.data.file;
  ok("backup: download settings in, VT key out", backup.settings.downloads.trustedDomains.includes(TRUSTED_DOWNLOAD_DOMAIN) &&
     !JSON.stringify(backup).includes(TEST_VT_KEY), backup.settings.downloads);
  r = await send({ type: M.MSG_IMPORT_SETTINGS, settings: backup });
  ok("restore: keeps the VT key already in this browser", r.ok && (await storedDownloads()).vtApiKey === TEST_VT_KEY, r);
  r = await send({ type: M.MSG_SET_VT_KEY, key: "" });
  ok("VT key: cleared (VirusTotal off)", r.ok && r.data.downloads.vtKeySet === false && (await storedDownloads()).vtEnabled === false, r.data && r.data.downloads);
  r = await send({ type: M.MSG_SET_DOWNLOAD_SETTINGS, settings: { trustAiDownloads: true } });
  ok("download settings: Trust AI downloads saved", r.ok && r.data.downloads.trustAiDownloads === true &&
     (await storedDownloads()).trustAiDownloads === true, r.data && r.data.downloads);
  await send({ type: M.MSG_SET_DOWNLOAD_SETTINGS, settings: { trustAiDownloads: false } });
  r = await send({ type: M.MSG_GET_DOWNLOAD_CHECK });
  ok("download check: refused from any page but the download warning page (C28)", !r.ok, r);

  // ── Protection 12: a real download ──
  const DOWNLOAD_URL = `${PAGE_URL.replace(/\/$/, "")}${DOWNLOAD_PATH}`;
  const warningPrefix = `chrome-extension://${extId}/${C.DOWNLOAD_WARNING_PAGE}`;
  const startDownload = async () => {
    const p = await ctx.newPage(); await p.goto(PAGE_URL);
    await p.evaluate((u) => { const a = document.createElement("a"); a.href = u; a.download = ""; document.body.append(a); a.click(); }, DOWNLOAD_URL);
    return p;
  };
  const waitWarning = (ms) => ctx.waitForEvent("page", { predicate: (pg) => pg.url().startsWith(warningPrefix), timeout: ms }).catch(() => null);
  let warningPage = waitWarning(DOWNLOAD_WAIT_MS);
  let dlTab = await startDownload();
  const wp = await warningPage;
  ok("download: an executable opens the warning window", !!wp, null);
  if (wp) {
    await wp.waitForLoadState("domcontentloaded");
    await wp.waitForFunction(() => ((document.getElementById("reasonText") || {}).textContent || "").startsWith("."), null, { timeout: DOWNLOAD_WAIT_MS }).catch(() => {});
    const shown = await wp.evaluate(() => ({ type: document.getElementById("reasonText").textContent, from: document.getElementById("srcUrl").textContent,
                                            title: document.getElementById("warningTitle").textContent }));
    ok("download: the page shows the file type, address and default title",
       shown.type === ".exe" && shown.from.endsWith(DOWNLOAD_PATH) && shown.title === C.DOWNLOAD_WARNING_TITLE_DEFAULT, shown);
    const vt = await wp.evaluate(() => ({ box: !document.getElementById("vtBox").hidden, noKey: !document.getElementById("vtNoKey").hidden,
                                         text: document.getElementById("vtNoKey").textContent }));
    ok("download: without a VT key the VirusTotal box says the lookup was skipped", vt.box && vt.noKey && vt.text.includes(VT_SKIPPED_TEXT), vt);
    const closed = wp.waitForEvent("close", { timeout: DOWNLOAD_WAIT_MS }).then(() => true).catch(() => false);
    await wp.click("#btnOk");
    ok("download: Proceed anyway closes the window", await closed, null);
  }
  await dlTab.close();

  // Files a page makes itself (blob:, as claude.ai does) — 4.3.3 fixes.
  const blobDownload = async () => {
    const t = await ctx.newPage(); await t.goto(PAGE_URL);
    await t.evaluate(({ name, type }) => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["MZ"], { type })); a.download = name; document.body.append(a); a.click(); }, { name: BLOB_FILE, type: BLOB_MIME });
    return t;
  };
  warningPage = waitWarning(DOWNLOAD_WAIT_MS);
  dlTab = await blobDownload();
  const bw = await warningPage;
  ok("download: a blob: executable opens the warning window", !!bw, null);
  if (bw) {
    await bw.waitForLoadState("domcontentloaded");
    await bw.waitForFunction(() => ((document.getElementById("reasonText") || {}).textContent || "").startsWith("."), null, { timeout: DOWNLOAD_WAIT_MS }).catch(() => {});
    const rows = await bw.evaluate(() => document.getElementById("hostDetailsList").textContent);
    ok("download: a blob: file gets no 'hidden extension' signal", !rows.includes(HIDDEN_EXT_TEXT), rows);
    await bw.click("#btnOk").catch(() => {});
  }
  await dlTab.close();
  await send({ type: M.MSG_SET_DOWNLOAD_SETTINGS, settings: { trustedDomains: [TEST_HOST] } });
  warningPage = waitWarning(NO_WINDOW_WAIT_MS);
  dlTab = await blobDownload();
  ok("download: a blob: file from a trusted download domain is not checked", (await warningPage) === null, null);
  await dlTab.close();
  warningPage = waitWarning(NO_WINDOW_WAIT_MS);                     // data: has no host → the referring page counts
  dlTab = await ctx.newPage(); await dlTab.goto(PAGE_URL);
  await dlTab.evaluate(({ name, type }) => { const a = document.createElement("a"); a.href = `data:${type};base64,TVo=`; a.download = name; document.body.append(a); a.click(); }, { name: DATA_FILE, type: BLOB_MIME });
  ok("download: a data: file from a trusted page is not checked (referrer fallback)", (await warningPage) === null, null);
  await dlTab.close();
  await send({ type: M.MSG_SET_DOWNLOAD_SETTINGS, settings: { trustedDomains: [] } });

  // Allow list (the page the download came from is locked at level 1) → no window.
  await popup(M.MSG_SET_LEVEL, { level: C.LEVEL.ALLOW_ALL });
  await popup(M.MSG_TOGGLE_LOCK);
  await popup(M.MSG_SET_LEVEL, { level: C.DEFAULT_STARTUP_LEVEL });
  warningPage = waitWarning(NO_WINDOW_WAIT_MS);
  dlTab = await startDownload();
  ok("download: no warning for a page on the allow list", (await warningPage) === null, null);
  await dlTab.close();
  await popup(M.MSG_TOGGLE_LOCK);

  // Protection 12 unticked → no window.
  const P = await import(pathToFileURL(join(EXT, "data/protections.js")).href);
  await popup(M.MSG_SET_PROTECTION, { key: P.PROTECTION_KEY.WARN_RISKY_DOWNLOADS, enabled: false });
  warningPage = waitWarning(NO_WINDOW_WAIT_MS);
  dlTab = await startDownload();
  ok("download: no warning with protection 12 unticked", (await warningPage) === null, null);
  await dlTab.close();
  await popup(M.MSG_SET_PROTECTION, { key: P.PROTECTION_KEY.WARN_RISKY_DOWNLOADS, enabled: true });

  // ── Protection 18 (4.3.2): off by default; blocks risky downloads; "Download anyway" → protection 12 ──
  const storedState = async () => sw.evaluate(async (key) => (await chrome.storage.local.get(key))[key], C.STORAGE_KEY_STATE);
  ok("protection 18: off by default", (await storedState()).disabledProtections[P.PROTECTION_KEY.BLOCK_RISKY_DOWNLOADS] === true);
  await sw.evaluate(async ({ key, k, schema }) => {                // a state as 4.3.1 stored it: schema 2, no entry
    const st = (await chrome.storage.local.get(key))[key]; st.schema = schema; delete st.disabledProtections[k];
    await chrome.storage.local.set({ [key]: st });
  }, { key: C.STORAGE_KEY_STATE, k: P.PROTECTION_KEY.BLOCK_RISKY_DOWNLOADS, schema: SCHEMA_431 });
  await send({ type: M.MSG_SET_DNS, first: C.DEFAULT_DNS_FIRST, second: C.DEFAULT_DNS_SECOND });   // load → migrate → save
  const migrated = await storedState();
  ok("protection 18: a 4.3.1 state gets it unticked (schema 3)", migrated.schema === C.STATE_SCHEMA_VERSION &&
     migrated.disabledProtections[P.PROTECTION_KEY.BLOCK_RISKY_DOWNLOADS] === true, migrated.disabledProtections);

  await popup(M.MSG_SET_PROTECTION, { key: P.PROTECTION_KEY.BLOCK_RISKY_DOWNLOADS, enabled: true });
  await popup(M.MSG_SET_LEVEL, { level: C.LEVEL.HIGH });
  const blockedPrefix = `chrome-extension://${extId}/${C.DOWNLOAD_BLOCKED_PAGE}`;
  const waitBlocked = (ms) => ctx.waitForEvent("page", { predicate: (pg) => pg.url().startsWith(blockedPrefix), timeout: ms }).catch(() => null);
  const blockedP = waitBlocked(DOWNLOAD_WAIT_MS);
  const noCheckP = waitWarning(NO_WINDOW_WAIT_MS);
  dlTab = await startDownload();
  const bp = await blockedP;
  ok("protection 18: a risky download at level 4 is blocked with a notice", !!bp, null);
  ok("protection 18: no download check for the blocked file", (await noCheckP) === null, null);
  if (bp) {
    await bp.waitForLoadState("domcontentloaded");
    await bp.waitForFunction(() => ((document.getElementById("dbReason") || {}).textContent || "").length > 0, null, { timeout: DOWNLOAD_WAIT_MS }).catch(() => {});
    const file = await bp.evaluate(() => document.getElementById("dbFile").textContent);
    ok("protection 18: the notice names the file", file === DOWNLOAD_PATH.slice(DOWNLOAD_PATH.lastIndexOf("/") + 1), file);
    const checkP = waitWarning(DOWNLOAD_WAIT_MS);
    await bp.click("#btnAnyway");
    ok("protection 18: Download anyway → the download check runs", !!(await checkP), null);
  }
  await dlTab.close();

  // Level 3 respects the trusted download domains (and the built-in whitelist); level 4 does not.
  await send({ type: M.MSG_SET_DOWNLOAD_SETTINGS, settings: { trustedDomains: [TEST_HOST] } });
  await popup(M.MSG_SET_LEVEL, { level: C.LEVEL.MEDIUM });
  let notice = waitBlocked(NO_WINDOW_WAIT_MS);
  dlTab = await startDownload();
  ok("protection 18: level 3 does not block a trusted download host", (await notice) === null, null);
  await dlTab.close();
  await popup(M.MSG_SET_LEVEL, { level: C.LEVEL.HIGH });
  notice = waitBlocked(DOWNLOAD_WAIT_MS);
  dlTab = await startDownload();
  const np = await notice;
  ok("protection 18: level 4 blocks it anyway (no exceptions)", !!np, null);
  if (np) await np.click("#btnOk").catch(() => {});
  await dlTab.close();
  await send({ type: M.MSG_SET_DOWNLOAD_SETTINGS, settings: { trustedDomains: [] } });

  await popup(M.MSG_SET_LEVEL, { level: C.DEFAULT_STARTUP_LEVEL });
  await popup(M.MSG_SET_PROTECTION, { key: P.PROTECTION_KEY.BLOCK_RISKY_DOWNLOADS, enabled: false });
} catch (e) {
  didNotRun(e && e.message || String(e));
} finally {
  if (ctx) await ctx.close().catch(() => {});
  server.close();
}

console.log(failed ? `e2e-flows: ${failed} FAILED` : "e2e-flows: ALL PASS");
process.exit(failed ? EXIT.FAILED : EXIT.OK);
