// ── core/rule-builder.js ──────────────────────────────────────────────────────
// Pure rule construction — builds declarativeNetRequest rule arrays from state.
// No Chrome API calls, no storage access, no side effects.
// All functions take input and return a rules array.
//
// Public interface:
//   buildRules(state)  — builds the complete rule set from state, returns Rule[]
//
// Dependencies (must be loaded before this file):
//   data/constants.js  — RP_3P
//   data/state-storage.js — SITE_RULES_CAP (used indirectly via state shape)
//
// ── Rule ID map ───────────────────────────────────────────────────────────────
// ── Rule ID map ───────────────────────────────────────────────────────────────
// Global rules use idOffset = 0.
// Per-site rules use idOffset = 100000 + (i * 5000) — the 5000-wide slot safely
// covers the full local ID range used here (highest ID is 3299).
//
//   Range       Purpose                                          Cap
//   ─────────────────────────────────────────────────────────────────
//   1001–1005   Base safety blocks (HTTP, WS, ports, IP)          5
//   2000–2199   User domain whitelist  (single *d* pattern)      200
//   2200–2399   Free                                               —
//   2400–2499   TLD whitelist          (single *.tld* pattern)   100
//   2500–2599   Free                                               —
//   2600–2999   Built-in domain whitelist (single *d* pattern)   400
//   3000        CDN allow              (level 4 only)              1
//   3001        Block 3P frames        (levels 2–5)               1
//   3002        Block 3P scripts       (levels 3–5)               1
//   3100–3199   Free
//   3200–3299   TLD blacklist          (level 2 only)            100
//   4000–4199   Free
// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

// Builds base safety block rules (HTTP, insecure WS, non-standard ports, IP addresses).
// Applied at all levels >= 2. Returns Rule[].
function buildBaseSafetyRules(idOffset, scope) {
  var specs = [
    { id: 1001, regexFilter: "^http://",   resourceTypes: RP_3P },
    { id: 1002, regexFilter: "^ws://",     resourceTypes: ["websocket"] },
    { id: 1003, regexFilter: "^https?://[^/?#:]+:([1-9][0-9]?|[1-3][0-9]{2}|4[0-3][0-9]|44[0-2])([/?#]|$)", resourceTypes: RP_3P },
    { id: 1004, regexFilter: "^https?://[^/?#:]+:(44[4-9]|4[5-9][0-9]|[5-9][0-9]{2}|[1-9][0-9]{3,})([/?#]|$)", resourceTypes: RP_3P },
    { id: 1005, regexFilter: "^https?://[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+([/?#:]|$)", resourceTypes: RP_3P }
  ];
  return specs.map(function(spec) {
    return {
      id: idOffset + spec.id,
      priority: 50,
      action: { type: "block" },
      condition: Object.assign({
        regexFilter: spec.regexFilter,
        domainType: "thirdParty",
        isUrlFilterCaseSensitive: false,
        resourceTypes: spec.resourceTypes
      }, scope)
    };
  });
}

// Builds built-in domain allow rules (payment, video, CAPTCHA, JS-libs) for levels 2-5.
// Two patterns per domain: /* (path) and / (bare root).
// Allows both sub_frame and script so video players and JS-libraries work at all levels.
function buildBuiltinAllowRules(idOffset, scope, builtinDomains) {
  var rules = [];
  // Single *domain* pattern covers both bare root and any path — one rule per domain.
  // Range 2600-2999 gives 400 slots — plenty of headroom.
  (builtinDomains || []).slice(0, 400).forEach(function(d, i) {
    rules.push({ id: idOffset + 2600 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*" + d + "*", resourceTypes: ["sub_frame", "script"] }, scope) });
  });
  return rules;
}

// Builds TLD allow rules for level 3 (scripts + frames from whitelisted TLDs).
// Two patterns per TLD. Returns Rule[].
function buildTldAllowRules(idOffset, scope, tlds) {
  var rules = [];
  // Single *.tld* pattern covers bare root and any path — one rule per TLD.
  // Range 2400-2499 gives 100 slots — sufficient for all TLD combinations.
  tlds.slice(0, 100).forEach(function(tld, i) {
    rules.push({ id: idOffset + 2400 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*." + tld + "*", resourceTypes: ["script", "sub_frame"] }, scope) });
  });
  return rules;
}

// Builds CDN allow rule for level 4 (scripts only).
// JS-library domains are now covered by buildBuiltinAllowRules at all levels.
// Only the broad *cdn* URL match remains here — level 4 exclusive.
function buildCdnAllowRules(idOffset, scope) {
  var rules = [];
  rules.push({ id: idOffset + 3000, priority: 1000, action: { type: "allow" },
    condition: Object.assign({ urlFilter: "*cdn*", resourceTypes: ["script"] }, scope) });
  return rules;
}

// Builds user domain whitelist allow rules for levels 4 and 5.
// Two patterns per domain, full resource-type scope (RP_3P). Returns Rule[].
function buildDomainAllowRules(idOffset, scope, domains) {
  var rules = [];
  // Single *domain* pattern covers bare root and any path — one rule per domain.
  // Overflow into 2200-2399 available if list exceeds 200 user domains.
  domains.slice(0, 200).forEach(function(d, i) {
    rules.push({ id: idOffset + 2000 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*" + d + "*", resourceTypes: RP_3P }, scope) });
  });
  return rules;
}

// Builds TLD blacklist block rules for level 2 only.
// Blocks 3P scripts from risky/abused TLDs. Priority 15 — lower than the
// main frame/script blocks (20) so general blocks fire first. Returns Rule[].
function buildTldBlacklistRules(idOffset, scope, blockedTlds) {
  var rules = [];
  blockedTlds.slice(0, 100).forEach(function(tld, i) {
    rules.push({ id: idOffset + 3200 + i, priority: 15, action: { type: "block" },
      condition: Object.assign({
        urlFilter: "*." + tld + "/*",
        domainType: "thirdParty",
        resourceTypes: ["script", "webbundle"]
      }, scope) });
  });
  return rules;
}

// Builds the complete rule array for a single level.
// Used for both global rules (idOffset=0) and per-site rules (idOffset=100000+i*5000).
// Returns Rule[].
function rulesForLevel(level, tlds, domains, idOffset, initiatorDomains, excludedDomains, builtinDomains, blockedTlds) {
  if (level === 1) return [];   // L1 = allow all, no rules needed

  var siteScope  = initiatorDomains && initiatorDomains.length
    ? { initiatorDomains:         initiatorDomains  } : {};
  var globalExcl = excludedDomains  && excludedDomains.length
    ? { excludedInitiatorDomains: excludedDomains   } : {};
  var scope = initiatorDomains ? siteScope : globalExcl;

  var rules = [];
  rules = rules.concat(buildBaseSafetyRules(idOffset, scope));

  if (level >= 2) {
    rules = rules.concat(buildBuiltinAllowRules(idOffset, scope, builtinDomains));
  }
  if (level === 3) {
    rules = rules.concat(buildTldAllowRules(idOffset, scope, tlds));
  }
  if (level === 4) {
    rules = rules.concat(buildCdnAllowRules(idOffset, scope));
  }
  if (level === 4 || level === 5) {
    rules = rules.concat(buildDomainAllowRules(idOffset, scope, domains));
  }

  // Block 3P frames (levels 2-5) — the entire 3P blocking surface of this extension.
  // IMPORTANT: never extend blocking beyond sub_frame + script/webbundle — see RP_3P
  // comment in data/constants.js for the reason.
  rules.push({ id: idOffset + 3001, priority: 20, action: { type: "block" },
    condition: Object.assign({ domainType: "thirdParty", resourceTypes: ["sub_frame"] }, scope) });

  // Block 3P scripts (levels 3-5)
  if (level >= 3) {
    rules.push({ id: idOffset + 3002, priority: 20, action: { type: "block" },
      condition: Object.assign({ domainType: "thirdParty", resourceTypes: ["script", "webbundle"] }, scope) });
  }

  if (level === 2 && blockedTlds && blockedTlds.length) {
    rules = rules.concat(buildTldBlacklistRules(idOffset, scope, blockedTlds));
  }

  return rules;
}

// Builds the complete declarativeNetRequest rule set from state.
// Global rules exclude pinned hostnames; per-site rules target them specifically.
// Returns Rule[] ready to pass to updateDynamicRules().
function buildRules(state) {
  var level       = state.level;
  var tlds        = state.tlds        || [];
  var domains     = state.domains     || [];
  var siteRules   = state.siteRules   || {};
  var pinnedHosts = Object.keys(siteRules);
  var rules       = [];

  // Global rules — exclude all pinned hosts so their site-specific rules take priority
  rules = rules.concat(
    rulesForLevel(level, tlds, domains, 0, null, pinnedHosts, state.builtinDomains, state.blockedTlds)
  );

  // Per-site rules — offset 100000 + i*5000 to avoid ID collisions between sites.
  // The 5000-wide slot safely covers the full local ID range used by rulesForLevel (up to 4199).
  pinnedHosts.forEach(function(host, i) {
    var offset = 100000 + (i * 5000);
    rules = rules.concat(
      rulesForLevel(siteRules[host], tlds, domains, offset, [host], null, state.builtinDomains, state.blockedTlds)
    );
  });

  return rules;
}
