// ── core/online-checks.js ─────────────────────────────────────────────────────
// Stage 2 — ONLINE checks, run only for sites stage 1 already found suspicious.
// Only the registered domain / hostname leaves the machine.
//
// Public interface:
//   evaluateSite(local, dnsSettings) — Promise<full result>
//       local       = core/site-scorer.js scoreLocal() result (must be non-null)
//       dnsSettings = state.dns { first, second }
//     → { site, host, score, severity, signals[], checks: { rdap, dns: [] } }
//   clearScoreCache()                — release the in-memory cache
//
// Guards:
//   - every network call has a hard timeout (AbortController) and can only fail
//     to "unavailable" — an unreachable check is NEVER reported as safe
//   - results are cached per registered domain (cap SCORE_CACHE_CAP, TTL
//     SCORE_CACHE_TTL_MS, oldest evicted first)
// ─────────────────────────────────────────────────────────────────────────────

import {
  SCORE, RDAP_URL, RDAP_TIMEOUT_MS, RDAP_YOUNG_DAYS, RDAP_RECENT_DAYS, DNS_TIMEOUT_MS,
  DNS_PROVIDER, DNS_NONE, SCORE_CACHE_CAP, SCORE_CACHE_TTL_MS, LOG_PREFIX
} from "../data/constants.js";
import { combine, severityOf } from "./site-scorer.js";
import { isIpHost } from "../util/domain.js";

export const CHECK_STATUS = Object.freeze({ BLOCKED: "blocked", ALLOWED: "allowed", UNAVAILABLE: "unavailable", SKIPPED: "skipped" });
const DAY_MS = 86400000;

// ── Fetch with a hard timeout ────────────────────────────────────────────────
async function fetchWithTimeout(url, init, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal, credentials: "omit", cache: "no-store" });
  } finally {
    clearTimeout(timer);                                // release the timer on every path
  }
}

// ── RDAP domain age ──────────────────────────────────────────────────────────
async function checkRdap(site) {
  if (!site || isIpHost(site)) return { status: CHECK_STATUS.SKIPPED };
  try {
    const res = await fetchWithTimeout(RDAP_URL + encodeURIComponent(site), { headers: { Accept: "application/rdap+json" } }, RDAP_TIMEOUT_MS);
    if (!res.ok) return { status: CHECK_STATUS.UNAVAILABLE, reason: `HTTP ${res.status}` };
    const data = await res.json();
    const ev = Array.isArray(data.events) && data.events.find((e) => e.eventAction === "registration" || e.eventAction === "registered");
    const t = ev && Date.parse(ev.eventDate);
    if (!t) return { status: CHECK_STATUS.UNAVAILABLE, reason: "no registration date published" };
    return { status: CHECK_STATUS.ALLOWED, ageDays: Math.max(0, Math.floor((Date.now() - t) / DAY_MS)) };
  } catch (e) {
    return { status: CHECK_STATUS.UNAVAILABLE, reason: e && e.name === "AbortError" ? "timeout" : "network error" };
  }
}

// ── DNS-over-HTTPS (RFC 8484 wire format) ────────────────────────────────────
const DNS = Object.freeze({ TYPE_A: 1, TYPE_AAAA: 28, CLASS_IN: 1, RCODE_NXDOMAIN: 3, HEADER: 12, MAX_LABEL: 63, MAX_NAME: 255, PTR_FLAG: 0xC0, MAX_HOPS: 20 });

function encodeQuery(host) {
  const bytes = [0, 0, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0];   // id 0, RD, 1 question
  for (const label of host.split(".").filter(Boolean)) {
    const b = new TextEncoder().encode(label);
    if (!b.length || b.length > DNS.MAX_LABEL) return null;
    bytes.push(b.length, ...b);
  }
  bytes.push(0, 0, DNS.TYPE_A, 0, DNS.CLASS_IN);
  if (bytes.length - DNS.HEADER - 4 > DNS.MAX_NAME) return null;
  let bin = "";
  for (const x of bytes) bin += String.fromCharCode(x);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

// Skips a (possibly compressed) name; returns the offset after it, or -1.
function skipName(view, off) {
  for (let hops = 0; hops < DNS.MAX_HOPS && off < view.byteLength; hops++) {
    const len = view.getUint8(off);
    if (len === 0) return off + 1;
    if ((len & DNS.PTR_FLAG) === DNS.PTR_FLAG) return off + 2;
    off += 1 + len;
  }
  return -1;
}

function parseResponse(buf) {
  const view = new DataView(buf);
  if (view.byteLength < DNS.HEADER) return null;
  const rcode = view.getUint16(2) & 0x0f;
  const qd = view.getUint16(4), an = view.getUint16(6), ns = view.getUint16(8);
  let off = DNS.HEADER;
  for (let i = 0; i < qd; i++) { off = skipName(view, off); if (off < 0) return null; off += 4; }
  const addrs = [];
  for (let i = 0; i < an && off < view.byteLength; i++) {
    off = skipName(view, off); if (off < 0 || off + 10 > view.byteLength) return null;
    const type = view.getUint16(off), rdlen = view.getUint16(off + 8);
    off += 10;
    if (off + rdlen > view.byteLength) return null;
    if (type === DNS.TYPE_A && rdlen === 4) addrs.push([0, 1, 2, 3].map((k) => view.getUint8(off + k)).join("."));
    if (type === DNS.TYPE_AAAA && rdlen === 16) {
      let zero = true; for (let k = 0; k < 16; k++) if (view.getUint8(off + k)) zero = false;
      addrs.push(zero ? "::" : "ipv6");
    }
    off += rdlen;
  }
  return { rcode, an, ns, addrs };
}

async function checkDns(providerId, host) {
  const provider = Object.values(DNS_PROVIDER).find((p) => p.id === providerId);
  if (!provider || providerId === DNS_NONE) return { status: CHECK_STATUS.SKIPPED };
  const base = { provider: provider.id, label: provider.label };
  if (isIpHost(host)) return { ...base, status: CHECK_STATUS.SKIPPED };
  const q = encodeQuery(host);
  if (!q) return { ...base, status: CHECK_STATUS.UNAVAILABLE, reason: "invalid name" };
  try {
    const res = await fetchWithTimeout(`${provider.url}?dns=${q}`, { headers: { Accept: "application/dns-message" } }, DNS_TIMEOUT_MS);
    if (!res.ok) return { ...base, status: CHECK_STATUS.UNAVAILABLE, reason: `HTTP ${res.status}` };
    const msg = parseResponse(await res.arrayBuffer());
    if (!msg) return { ...base, status: CHECK_STATUS.UNAVAILABLE, reason: "unreadable answer" };
    if (provider.blockStyle === "nxdomain-no-authority" && msg.rcode === DNS.RCODE_NXDOMAIN) {
      return { ...base, status: msg.ns === 0 ? CHECK_STATUS.BLOCKED : CHECK_STATUS.UNAVAILABLE, reason: msg.ns === 0 ? "" : "domain does not exist" };
    }
    if (provider.blockStyle === "zero-ip" && msg.addrs.some((a) => a === "0.0.0.0" || a === "::")) {
      return { ...base, status: CHECK_STATUS.BLOCKED };
    }
    return { ...base, status: CHECK_STATUS.ALLOWED };
  } catch (e) {
    return { ...base, status: CHECK_STATUS.UNAVAILABLE, reason: e && e.name === "AbortError" ? "timeout" : "network error — your own DNS may block it" };
  }
}

// ── Cache (guarded: capped, TTL, oldest evicted) ─────────────────────────────
const _cache = new Map();   // site → { at, result }
function cacheGet(site) {
  const hit = _cache.get(site);
  if (!hit) return null;
  if (Date.now() - hit.at > SCORE_CACHE_TTL_MS) { _cache.delete(site); return null; }
  return hit.result;
}
function cachePut(site, result) {
  _cache.delete(site);
  _cache.set(site, { at: Date.now(), result });
  while (_cache.size > SCORE_CACHE_CAP) _cache.delete(_cache.keys().next().value);
}
export function clearScoreCache() { _cache.clear(); }

// ── Public ───────────────────────────────────────────────────────────────────
export async function evaluateSite(local, dnsSettings) {
  const key = `${local.host}|${dnsSettings.first}|${dnsSettings.second}`;
  const cached = cacheGet(key);
  if (cached) return cached;

  const [rdap, dns1, dns2] = await Promise.all([
    checkRdap(local.site),
    checkDns(dnsSettings.first, local.host),
    checkDns(dnsSettings.second, local.host)
  ]);

  const entries = local.entries.slice();
  const signals = [];
  if (rdap.status === CHECK_STATUS.ALLOWED) {
    const age = rdap.ageDays;
    const ageScore = age < RDAP_YOUNG_DAYS ? SCORE.RDAP_YOUNG : age < RDAP_RECENT_DAYS ? SCORE.RDAP_RECENT : 0;
    if (ageScore < 0) entries.push({ score: ageScore, label: `Domain registered ${age} days ago (RDAP)`, source: "RDAP" });
    signals.push(`Domain registered ${age} days ago (RDAP)`);
  } else if (rdap.status === CHECK_STATUS.UNAVAILABLE) {
    signals.push(`Domain age unavailable (${rdap.reason})`);
  }

  let { score } = combine(entries);
  [[dns1, "first"], [dns2, "second"]].forEach(([r, which]) => {
    if (r.status === CHECK_STATUS.BLOCKED) { score = SCORE.DNS_BLOCKED; signals.push(`Blocked by ${r.label} — ${which} DNS check`); }
    else if (r.status === CHECK_STATUS.ALLOWED) signals.push(`Clean on ${r.label} — ${which} DNS check`);
    else if (r.status === CHECK_STATUS.UNAVAILABLE) signals.push(`${r.label} check unavailable (${r.reason})`);
  });

  const result = {
    site: local.site, host: local.host, score, severity: severityOf(score),
    signals: [...local.signals, ...signals],
    checks: { rdap, dns: [dns1, dns2] }
  };
  cachePut(key, result);
  if (score !== local.score) console.info(LOG_PREFIX, `online checks moved ${local.host} from ${local.score} to ${score}`);
  return result;
}
