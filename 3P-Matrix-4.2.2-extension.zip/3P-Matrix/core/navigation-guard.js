// ── core/navigation-guard.js ──────────────────────────────────────────────────
// First-party site check on every top-level navigation — protection 10
// "Warn before opening suspicious sites" (PROTECTION_KEY.WARN_SUSPICIOUS_SITES).
// Active when the site's effective level ≥ its fromLevel (2) AND the user has not
// unticked it in the popup. Inactive → nothing is scored, no dialog, neutral badge.
// Stage 1 (local, ~0.4 ms) runs here; a suspicious site (score ≤ SUSPECT_AT)
// is replaced by the warning dialog page, which then asks for stage 2.
//
// Public interface:
//   checkNavigation(details, state) — webNavigation.onBeforeNavigate handler body
//   allowOnce(tabId, site)          — "Continue once": skip the check for this tab + site
//   releaseTab(tabId)               — tab closed: drop its one-time allowances
//   warningUrlFor(url)              — extension URL of the warning dialog for `url`
//
// Skipped (never scored): non-http(s), private/local hosts, the built-in
// whitelist, sites where protection 10 is not active (level 1 / allow list,
// or unticked), and sites allowed once in this tab.
// ─────────────────────────────────────────────────────────────────────────────

import { SEVERITY, WARNING_PAGE } from "../data/constants.js";
import { BUILTIN_ALL } from "../data/builtin-domains.js";
import { PROTECTION_KEY } from "../data/protections.js";
import { effectiveLevel, isProtectionActive } from "./policy.js";
import { scoreLocal } from "./site-scorer.js";
import { setRisk } from "./badge.js";
import { parseHttpUrl, registeredDomain, isInDomainList } from "../util/domain.js";

// tabId → Set<site> allowed once ("Continue once"). Bounded by open tabs.
const _allowedOnce = new Map();

export function allowOnce(tabId, site) {
  if (!_allowedOnce.has(tabId)) _allowedOnce.set(tabId, new Set());
  _allowedOnce.get(tabId).add(site);
}

export function releaseTab(tabId) { _allowedOnce.delete(tabId); }

export function warningUrlFor(url) {
  return chrome.runtime.getURL(WARNING_PAGE) + "?u=" + encodeURIComponent(url);
}

export function checkNavigation(details, state) {
  if (details.frameId !== 0 || details.tabId < 0) return;
  const p = parseHttpUrl(details.url);
  if (!p) return;
  const site = registeredDomain(p.host);

  if (!isProtectionActive(state, PROTECTION_KEY.WARN_SUSPICIOUS_SITES, effectiveLevel(state, p.host))) {
    setRisk(details.tabId, site, SEVERITY.NONE);               // level 1 / allow list / unticked
    return;
  }
  if (isInDomainList(p.host, BUILTIN_ALL)) { setRisk(details.tabId, site, SEVERITY.NONE); return; }
  const once = _allowedOnce.get(details.tabId);
  if (once && once.has(site)) return;                          // keep the risk colour, no dialog

  const local = scoreLocal(details.url);
  if (!local || local.severity === SEVERITY.NONE) { setRisk(details.tabId, site, SEVERITY.NONE); return; }

  setRisk(details.tabId, site, local.severity);
  chrome.tabs.update(details.tabId, { url: warningUrlFor(details.url) }).catch(() => {});
}
