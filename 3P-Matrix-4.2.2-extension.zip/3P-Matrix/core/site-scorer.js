// ── core/site-scorer.js ───────────────────────────────────────────────────────
// Stage 1 — LOCAL first-party site scoring (no network). Reuses
// DownloadSentinel 3.0.4's heuristics modules unchanged except for two marked
// patches (SketchyUrlCheck subdomain count, CombinationScoring port family).
//
// Public interface:
//   scoreLocal(url)          — { site, host, score, severity, signals[], entries[] } or null
//                              (null = not scorable: non-http(s), private/local host)
//   combine(entries)         — { score, severity } via DownloadSentinel CombinationScoring
//   severityOf(score)        — SEVERITY.*
//
// entries[] = DownloadSentinel-style { score, label, source } items (fed to
// CombinationScoring); signals[] = the same labels, worst first, for the UI.
// Measured cost: ~0.4 ms per domain (brand Levenshtein dominates).
// ─────────────────────────────────────────────────────────────────────────────

import { SCORE, SEVERITY, STANDARD_PORTS } from "../data/constants.js";
import { SPAM_TLDS, SPAM_TLD_EXCEPTIONS } from "../data/spam-tlds.js";
import { parseHttpUrl, registeredDomain, tldOf, isIpHost, isPrivateHost, isInDomainList } from "../util/domain.js";
import { SketchyUrlCheck } from "../lib/downloadsentinel/protection/SketchyUrlCheck.js";
import { FilenameUrlHeuristics } from "../lib/downloadsentinel/protection/FilenameUrlHeuristics.js";
import { CombinationScoring } from "../lib/downloadsentinel/protection/CombinationScoring.js";
import { HostList } from "../lib/downloadsentinel/util/HostList.js";
import { SuspiciousTlds } from "../lib/downloadsentinel/util/SuspiciousTlds.js";
import { SuspiciousDomains } from "../lib/downloadsentinel/util/SuspiciousDomains.js";
import { RiskyHostingSites } from "../lib/downloadsentinel/util/RiskyHostingSites.js";

const SPAM_TLD_SET = new Set(SPAM_TLDS);
const SPAM_EXCEPTION_SET = new Set(SPAM_TLD_EXCEPTIONS);
const SIGNAL_SUFFIX_RE = /\s*\(\+\d+\).*$/;          // strips DownloadSentinel's "(+15)" score suffix

const scaled = (risk, base) => Math.max(SCORE.FLOOR, Math.round((risk / 100) * base));

export function severityOf(score) {
  if (score < SCORE.PHISHING_BELOW) return SEVERITY.PHISHING;
  if (score <= SCORE.SUSPECT_AT) return SEVERITY.SUSPECT;
  return SEVERITY.NONE;
}

export function combine(entries) {
  const res = CombinationScoring.combineHostResults(entries);
  const score = Math.max(SCORE.FLOOR, res.score || 0);
  return { score, severity: severityOf(score) };
}

function tldEntry(host, site, tld) {
  if (SPAM_EXCEPTION_SET.has(site) || isInDomainList(host, SPAM_TLD_EXCEPTIONS)) return null;
  const dsHit = SuspiciousTlds.lookup(tld);
  const risk = Math.max(dsHit ? dsHit.score : 0, SPAM_TLD_SET.has(tld) ? SCORE.SPAM_TLD_RISK : 0);
  if (!risk) return null;
  return { score: scaled(risk, SCORE.TLD_BASE), label: `TLD .${tld} is on the abused-TLD list`, source: "TldList" };
}

export function scoreLocal(url) {
  const p = parseHttpUrl(url);
  if (!p || isPrivateHost(p.host)) return null;
  const host = p.host;
  const ip = isIpHost(host);
  const site = registeredDomain(host);
  const entries = [];

  if (ip) {
    entries.push({ score: SCORE.IP_HOST, label: "Site is a bare IP address, not a domain name", source: "IpAddressCheck" });
  } else {
    // Name-based checks (meaningless for an IP literal).
    const sketchy = SketchyUrlCheck.check(`${p.protocol}//${host}/`);   // host only — no path checks for pages
    if (sketchy.score > 0) {
      const top = (sketchy.signals[0] || "Suspicious name pattern").replace(SIGNAL_SUFFIX_RE, "").trim();
      entries.push({ score: scaled(sketchy.score, SCORE.SKETCHY_URL_BASE), label: top, source: "SketchyUrl" });
      for (const sig of sketchy.signals.slice(1)) {
        entries.push({ score: 0, label: sig.replace(SIGNAL_SUFFIX_RE, "").trim(), source: "SketchyUrl" });
      }
    }
    const hostHit = HostList.lookup(host);
    if (hostHit) entries.push({ score: scaled(hostHit.score, SCORE.HOST_LIST_BASE), label: `Free-hosting / dynamic-DNS domain (${hostHit.matchedDomain})`, source: "HostList" });
    const domHit = SuspiciousDomains.lookup(host);
    if (domHit) entries.push({ score: scaled(domHit.score, SCORE.DOMAIN_LIST_BASE), label: `Known suspicious domain (${domHit.matchedDomain})`, source: "DomainList" });
    const risky = RiskyHostingSites.lookup(host);
    if (risky) entries.push({ score: risky.score, label: `Hosted on a platform where anyone can publish (${risky.host})`, source: "RiskyHosting" });
    const tld = tldEntry(host, site, tldOf(host));
    if (tld) entries.push(tld);
    const homoglyph = FilenameUrlHeuristics.checkBrandHomoglyph(host);
    if (homoglyph) entries.push({ score: SCORE.BRAND_HOMOGLYPH, label: `Looks like the brand domain ${homoglyph.matchedBrand}`, source: "BrandHomoglyph" });
    const lookalike = FilenameUrlHeuristics.checkLookalikeTopSite(host);
    if (lookalike) entries.push({ score: SCORE.LOOKALIKE_TOP_SITE, label: `Looks like the popular site ${lookalike.resembles}`, source: "LookalikeTopSite" });
  }

  if (p.port && !STANDARD_PORTS.includes(Number(p.port))) {
    entries.push({ score: SCORE.NON_STANDARD_PORT, label: `Unusual port :${p.port}`, source: "NonStandardPort" });
  }
  if (p.protocol === "http:") {
    entries.push({ score: SCORE.PLAIN_HTTP, label: "Not encrypted (plain HTTP)", source: "ProtocolCheck" });
  }

  const scoring = entries.filter((e) => e.score < 0);
  const { score, severity } = combine(scoring);
  const signals = [...entries].sort((a, b) => a.score - b.score).map((e) => e.label);
  return { site, host, score, severity, signals, entries: scoring };
}
