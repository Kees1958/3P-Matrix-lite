// ── core/rule-matcher.js ──────────────────────────────────────────────────────
// Pure re-implementation of declarativeNetRequest matching for OUR OWN dynamic
// rules, used to decide whether a request that Chrome reports as
// net::ERR_BLOCKED_BY_CLIENT was blocked by 3P Matrix (counted) or by another
// extension (not counted). No Chrome API calls.
//
// Public interface:
//   compileRules(rules)                 — precompile once per applied rule set
//   matchOutcome(compiled, request, opaqueStandIn?) — { action: "block"|"allow"|null, ruleId }
//        request = { url, type, initiator }   (webRequest details fields)
//        opaqueStandIn = the tab's top-level host (core/tab-sites.js), used when the initiator
//        is opaque ("null"). 4.2.1: Chrome matches such a request against the opaque origin's
//        precursor (the site that created the sandboxed / data: / srcdoc frame); webRequest
//        only reports "null", and treating it as "no initiator" (= first-party) made our own
//        blocks look like someone else's — Show Matrix then showed them as allowed.
//
// Semantics implemented (exactly the subset our rule builder emits):
//   resourceTypes (absent = every type except main_frame), domainType thirdParty,
//   initiatorDomains / excludedInitiatorDomains, requestDomains /
//   excludedRequestDomains (domain or any parent, so a TLD entry covers the TLD),
//   regexFilter (case-insensitive), urlFilter with | anchors and * wildcards.
//   Highest priority wins; on equal priority "allow" beats "block" (Chrome's
//   documented action precedence). modifyHeaders rules never block — ignored.
// ─────────────────────────────────────────────────────────────────────────────

import { registeredDomain } from "../util/domain.js";

const COUNTED_ACTIONS = new Set(["block", "allow"]);
const ACTION_RANK = Object.freeze({ allow: 2, block: 1 });   // tie-break at equal priority
const DEFAULT_EXCLUDED_TYPE = "main_frame";
const OPAQUE_INITIATOR = "null";                               // webRequest's text for an opaque origin

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase().replace(/^\[|\]$/g, ""); } catch { return ""; }
}

// True when `host` or one of its parent domains is in `set`.
function domainIn(host, set) {
  if (!host || !set) return false;
  let h = host;
  for (;;) {
    if (set.has(h)) return true;
    const dot = h.indexOf(".");
    if (dot === -1) return false;
    h = h.slice(dot + 1);
  }
}

function urlFilterToRegExp(filter) {
  let src = filter;
  let head = "", tail = "";
  if (src.startsWith("|")) { head = "^"; src = src.slice(1); }
  if (src.endsWith("|"))   { tail = "$"; src = src.slice(0, -1); }
  const body = src.split("*").map((p) => p.replace(/[.+?^${}()[\]\\]/g, "\\$&").replace(/\|/g, "\\|")).join(".*");
  return new RegExp(head + body + tail, "i");
}

const toSet = (arr) => (Array.isArray(arr) ? new Set(arr) : null);

export function compileRules(rules) {
  const out = [];
  for (const r of rules || []) {
    if (!r || !r.action || !COUNTED_ACTIONS.has(r.action.type)) continue;
    const c = r.condition || {};
    out.push({
      id: r.id,
      priority: r.priority || 1,
      action: r.action.type,
      types: toSet(c.resourceTypes),
      thirdParty: c.domainType === "thirdParty",
      firstParty: c.domainType === "firstParty",
      initiators: toSet(c.initiatorDomains),
      exInitiators: toSet(c.excludedInitiatorDomains),
      requests: toSet(c.requestDomains),
      exRequests: toSet(c.excludedRequestDomains),
      regex: c.regexFilter ? new RegExp(c.regexFilter, "i") : null,
      urlRe: c.urlFilter ? urlFilterToRegExp(c.urlFilter) : null
    });
  }
  // Highest priority first, allow before block at equal priority → first match wins.
  out.sort((a, b) => b.priority - a.priority || ACTION_RANK[b.action] - ACTION_RANK[a.action]);
  return out;
}

function ruleMatches(rule, req, reqHost, initHost, isThirdParty) {
  if (rule.types ? !rule.types.has(req.type) : req.type === DEFAULT_EXCLUDED_TYPE) return false;
  if (rule.thirdParty && !isThirdParty) return false;
  if (rule.firstParty && isThirdParty) return false;
  if (rule.initiators && !domainIn(initHost, rule.initiators)) return false;
  if (rule.exInitiators && domainIn(initHost, rule.exInitiators)) return false;
  if (rule.requests && !domainIn(reqHost, rule.requests)) return false;
  if (rule.exRequests && domainIn(reqHost, rule.exRequests)) return false;
  if (rule.regex && !rule.regex.test(req.url)) return false;
  if (rule.urlRe && !rule.urlRe.test(req.url)) return false;
  return true;
}

export function matchOutcome(compiled, req, opaqueStandIn = "") {
  const reqHost = hostOf(req.url);
  const initHost = req.initiator === OPAQUE_INITIATOR ? String(opaqueStandIn || "").toLowerCase()
                 : req.initiator ? hostOf(req.initiator) : "";
  // No initiator (e.g. browser-initiated, or opaque with no stand-in) → DNR treats the request
  // as first-party.
  const isThirdParty = !!initHost && registeredDomain(reqHost) !== registeredDomain(initHost);
  for (const rule of compiled) {
    if (ruleMatches(rule, req, reqHost, initHost, isThirdParty)) return { action: rule.action, ruleId: rule.id };
  }
  return { action: null, ruleId: null };
}
