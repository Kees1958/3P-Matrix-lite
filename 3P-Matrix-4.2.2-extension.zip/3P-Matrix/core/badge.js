// ── core/badge.js ─────────────────────────────────────────────────────────────
// Toolbar badge + icon, per tab.
//   text   = requests blocked on this tab, counted HERE (not Chrome's built-in
//            action count, which also counts every modifyHeaders match)
//   colour = risk of the tab's current site: grey / orange / red (+ "!")
//   icon   = 3P-Matrix-lite brick wall in the colour of the tab's effective level
//
// Public interface:
//   noteBlocked(tabId)                  — one more blocked request on the tab
//   resetCount(tabId)                   — new top-level page committed
//   setRisk(tabId, site, severity)      — remember the risk of the site in the tab
//   clearRiskIfOtherSite(tabId, site)   — committed page belongs to another site
//   setLevelIcon(level, tabId?)         — global (no tabId) or per-tab icon
//   releaseTab(tabId)                   — tab closed: drop everything we hold for it
//
// State (in memory, lost on service-worker restart — counts then restart at 0):
//   _counts Map<tabId, number>   _risk Map<tabId, { site, severity }>
// Both are bounded by the number of open tabs: releaseTab() on tabs.onRemoved.
// ─────────────────────────────────────────────────────────────────────────────

import { BADGE_COLOR, BADGE_PHISHING_PREFIX, BADGE_MAX_COUNT, SEVERITY, LEVEL_INFO, ICON_SIZES, ICON_DIR } from "../data/constants.js";

const _counts = new Map();
const _risk = new Map();

function render(tabId) {
  if (tabId < 0) return;
  const n = _counts.get(tabId) || 0;
  const risk = (_risk.get(tabId) || {}).severity || SEVERITY.NONE;
  let text = n === 0 ? "" : n > BADGE_MAX_COUNT ? `${BADGE_MAX_COUNT}+` : String(n);
  if (risk === SEVERITY.PHISHING) text = BADGE_PHISHING_PREFIX + text;
  const color = risk === SEVERITY.PHISHING ? BADGE_COLOR.PHISHING : risk === SEVERITY.SUSPECT ? BADGE_COLOR.SUSPECT : BADGE_COLOR.NORMAL;
  // Best effort: the tab may close between the event and this call.
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
}

export function noteBlocked(tabId) {
  if (tabId < 0) return;
  _counts.set(tabId, (_counts.get(tabId) || 0) + 1);
  render(tabId);
}

export function resetCount(tabId) {
  _counts.set(tabId, 0);
  render(tabId);
}

export function getCount(tabId) { return _counts.get(tabId) || 0; }
export function getRisk(tabId) { return _risk.get(tabId) || null; }

export function setRisk(tabId, site, severity) {
  if (tabId < 0) return;
  if (severity === SEVERITY.NONE) _risk.delete(tabId); else _risk.set(tabId, { site, severity });
  render(tabId);
}

export function clearRiskIfOtherSite(tabId, site) {
  const r = _risk.get(tabId);
  if (r && r.site !== site) { _risk.delete(tabId); render(tabId); }
}

export function setLevelIcon(level, tabId) {
  const info = LEVEL_INFO[level - 1] || LEVEL_INFO[0];
  const path = Object.fromEntries(ICON_SIZES.map((s) => [String(s), `${ICON_DIR}/${info.icon}_${s}.png`]));
  const details = tabId === undefined ? { path } : { path, tabId };
  chrome.action.setIcon(details).catch(() => {});
}

export function releaseTab(tabId) {
  _counts.delete(tabId);
  _risk.delete(tabId);
}
