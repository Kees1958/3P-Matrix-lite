// ── core/safer-regions.js ─────────────────────────────────────────────────────────
// Safer regions (TLD whitelist) recomputation — thin async wrapper around
// 3P-Matrix-lite's tld-engine (BASE_TLDS + auto-added country codes + manual
// − excluded). The engine itself stays pure; this module supplies the two
// environment inputs (browser languages, time zone).
//
// Public interface:
//   computeSaferRegions(safeZone) — Promise<string[]> merged TLD list (capped)
//
// The auto-add scope is fixed (SAFER_REGIONS_AUTO_MODE = Continent, as uBlock Stripped
// Dynamic); the user edits only the added / removed TLDs. Auto-added TLDs on the HaGeZi
// abused-TLD list are dropped (SAFER_REGIONS_SKIP_ABUSED_TLDS); hand-added ones are kept.
// ─────────────────────────────────────────────────────────────────────────────

import { SAFE_ZONE_TLDS_CAP, SAFER_REGIONS_AUTO_MODE, SAFER_REGIONS_SKIP_ABUSED_TLDS, LOG_PREFIX } from "../data/constants.js";
import { SPAM_TLDS } from "../data/spam-tlds.js";
import { rebuildTldList, AUTO_TLD_MODE } from "./tld-engine.js";

const ABUSED_TLDS = new Set(SPAM_TLDS);   // built once at module load

// Guard: a typo in the constant must not silently switch the auto-add off — fall back to CONTINENT.
const AUTO_MODE = Object.values(AUTO_TLD_MODE).includes(SAFER_REGIONS_AUTO_MODE)
  ? SAFER_REGIONS_AUTO_MODE
  : (console.error(LOG_PREFIX, "invalid SAFER_REGIONS_AUTO_MODE", SAFER_REGIONS_AUTO_MODE), AUTO_TLD_MODE.CONTINENT);

function browserTimeZone() {
  try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ""; }
  catch { return ""; }                                   // guard: Intl unavailable — no guess
}

async function acceptLanguages() {
  try { return (await chrome.i18n.getAcceptLanguages()) || []; }
  catch { return []; }
}

export async function computeSaferRegions(safeZone) {
  const langs = await acceptLanguages();
  return new Promise((resolve) => {
    rebuildTldList(AUTO_MODE, langs, safeZone.manualTlds, safeZone.excludedTlds, (merged) => {
      const manual = new Set(safeZone.manualTlds || []);
      const kept = SAFER_REGIONS_SKIP_ABUSED_TLDS
        ? merged.filter((t) => manual.has(t) || !ABUSED_TLDS.has(t))
        : merged;
      resolve(kept.slice(0, SAFE_ZONE_TLDS_CAP));
    }, browserTimeZone());
  });
}
