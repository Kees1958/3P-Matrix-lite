// ── data/tld-constants.js ─────────────────────────────────────────────────────
// Language/TLD tables needed by core/tld-engine.js (ported from 3P-Matrix-lite
// 4.0.2 data/constants.js). Pure constants.
//
// The TLD blocklist is NOT here: level 2+ uses the generated HaGeZi list
// (data/spam-tlds.js) only.
// ─────────────────────────────────────────────────────────────────────────────

// EU official languages — decides whether "eu" joins the safer regions.
export const EU_LANGS = {
  "bg":1,"hr":1,"cs":1,"da":1,"nl":1,"et":1,"fi":1,"fr":1,"de":1,"el":1,
  "hu":1,"ga":1,"it":1,"lv":1,"lt":1,"mt":1,"pl":1,"pt":1,"ro":1,"sk":1,"sl":1,"es":1,"sv":1
};
