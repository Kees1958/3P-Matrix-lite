// ── data/protections.js ───────────────────────────────────────────────────────
// THE protections registry — single source of truth for the 16 selectable
// protections. The popup list, the counts, the DNR rule builder and the
// content-script builder all read this table; none of them keeps its own list.
//
// A protection is ACTIVE for a site when:
//     effectiveLevel(site) >= fromLevel   AND   not unticked by the user
//
// Removed in 0.2.3 (user keeps them in uBlock Stripped Dynamic): "Clear history at browser
// start" (deleteHistoryOnStart) and "Block tracking pings" (blockPings). Their keys are
// dropped from saved state by normalizeState(), which keeps only keys listed here.
//
// Added in 0.2.4: "Warn before opening suspicious sites" (warnSuspiciousSites, num 10) — the
// navigation-guard warning dialog, until then always on from level 2, is now a selectable
// protection. Old saved states have no entry for it, so it starts ticked (= previous behaviour).
// Level-3 protections renumbered 10–14 → 11–15 (keys unchanged).
//
// Added in 4.2: "Block 3P scripts and frames from abused TLDs" (blockAbusedTlds, num 11) — the
// HaGeZi abused-TLD block, until then an unconditional part of the level-2+ policy, is now a
// selectable protection. Old saved states have no entry for it, so it starts ticked (= previous
// behaviour). 4.2 renumbers so each group is consecutive: level-2 group 1–11 (abused TLDs = 11),
// level-3 group 11–15 → 12–16 (keys unchanged, so saved ticks carry over). `num` is display only.
// 4.2: protection 1 gains trustedExempt — the built-in whitelist's payment hosts may register a
// real payment handler on their own site, at BUILTIN_EXEMPT_LEVELS (3–4) only.
//
// Fields
//   key        storage key in state.disabledProtections (never rename — it is a contract)
//   num        display number (1–16)
//   label      popup text — a short, plain-language phrase; may wrap to two lines (0.2.4)
//   fromLevel  first level at which it applies (LEVEL.MILD or LEVEL.MEDIUM)
//   scope      SCOPE.EVERY_SITE | SCOPE.OUTSIDE_SAFER_REGIONS (the latter only differs at
//              level 3 — levels 4–5 apply it on every site, see SAFER_REGIONS_LEVELS)
//   mechanism  MECH.* — which builder implements it (several may apply)
//   scripts    content-script files (MAIN world, all frames, document_start)
//   matchHosts optional fixed host list the scripts are limited to
//   extraExcludes optional extra excludeMatches patterns
//   trustedExempt optional host list exempt from this protection on a first-party visit, at
//              BUILTIN_EXEMPT_LEVELS only (scope OUTSIDE_SAFER_REGIONS protections always use the
//              whole built-in whitelist for this; this field is for EVERY_SITE protections)
// ─────────────────────────────────────────────────────────────────────────────

import { LEVEL, NOEVAL_EXTRA_EXCLUDES } from "./constants.js";
import { HIGH_RISK_HOSTNAMES } from "./network-data.js";
import { BUILTIN_PAYMENT } from "./builtin-domains.js";

export const SCOPE = Object.freeze({ EVERY_SITE: "every", OUTSIDE_SAFER_REGIONS: "outside" });
export const MECH  = Object.freeze({
  SCRIPT:  "script",    // content script(s)
  DNR:     "dnr",       // dynamic block/allow rules
  HEADER:  "header",    // dynamic modifyHeaders rules
  NAVIGATION: "navigation" // top-level navigation check (core/navigation-guard.js) — no rules/scripts
});

// Keys other modules test directly (one place, so a typo cannot silently disable a check).
export const PROTECTION_KEY = Object.freeze({
  WARN_SUSPICIOUS_SITES: "warnSuspiciousSites",  // read by core/navigation-guard.js and the popup model
  BLOCK_ABUSED_TLDS:     "blockAbusedTlds"        // read by core/rule-builder.js (protection 11)
});

export const PROTECTION_GROUPS = Object.freeze([
  Object.freeze({ title: "On every site",          fromLevel: LEVEL.MILD }),
  // titleNoSaferRegions: shown at levels where the safer-regions list has no effect (4–5)
  Object.freeze({ title: "Outside safer regions",  titleNoSaferRegions: "Extra — on every site", fromLevel: LEVEL.MEDIUM })
]);

export const PROTECTIONS = Object.freeze([
  { key: "blockPaymentHandlers",  num: 1,  label: "Block sites from registering a fake payment handler",   fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT], scripts: ["security/sec-payment-handlers.js"], trustedExempt: BUILTIN_PAYMENT },
  { key: "blockWebBundles",       num: 2,  label: "Block Web Bundles (bundled resources that hide code)",  fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.DNR] },
  { key: "blockDialogSpam",       num: 3,  label: "Block alert/confirm/prompt popup scams",                fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT], scripts: ["security/sec-alertbuster.js", "security/sec-dialogbuster.js"] },
  { key: "blockLocalNetwork",     num: 4,  label: "Block pages from reaching your local network",          fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.DNR] },
  { key: "blockProtocolHandlers", num: 5,  label: "Block sites from registering custom protocol handlers", fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT], scripts: ["security/sec-protocol-handlers.js"] },
  { key: "blockSuspicious3p",     num: 6,  label: "Block 3P requests to raw IPs, odd ports or DDNS hosts", fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.DNR] },
  { key: "block3pHttp",           num: 7,  label: "Block 3P requests sent over plain, unencrypted HTTP",   fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.DNR] },
  { key: "blockClickFix",         num: 8,  label: "Block ClickFix-style clipboard hijacking scams",        fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT], scripts: ["security/sec-clickfix-clipboard.js"] },
  { key: "blockHighRiskEval",     num: 9,  label: "Block eval() on known high-risk (adult) sites",         fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT, MECH.HEADER], scripts: ["security/sec-adult-noeval.js"], matchHosts: HIGH_RISK_HOSTNAMES },
  { key: PROTECTION_KEY.WARN_SUSPICIOUS_SITES, num: 10, label: "Warn before opening a site that looks suspicious", fromLevel: LEVEL.MILD, scope: SCOPE.EVERY_SITE, mechanism: [MECH.NAVIGATION] },
  { key: PROTECTION_KEY.BLOCK_ABUSED_TLDS, num: 11, label: "Block 3P scripts and frames from abused TLDs", fromLevel: LEVEL.MILD, scope: SCOPE.EVERY_SITE, mechanism: [MECH.DNR] },
  { key: "blockScpPrivacy",       num: 12, label: "Block camera, mic, screen-share and clipboard reads",   fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.HEADER] },
  { key: "blockScpSecurity",      num: 13, label: "Block Bluetooth, Serial, HID and USB device access",    fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.HEADER] },
  { key: "blockSensorsNfc",       num: 14, label: "Block motion-sensor and NFC access",                    fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.HEADER, MECH.SCRIPT], scripts: ["security/sec-nfc.js"] },
  { key: "blockObfuscatedEval",   num: 15, label: "Block obfuscated or disguised eval() calls",            fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.SCRIPT], scripts: ["security/sec-noeval.js"], extraExcludes: NOEVAL_EXTRA_EXCLUDES },
  { key: "blockRedirectsDialogs", num: 16, label: "Block frames from redirecting the page or popping dialogs", fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.HEADER] }
].map((p) => Object.freeze(p)));

export const PROTECTION_KEYS = Object.freeze(PROTECTIONS.map((p) => p.key));
export const PROTECTION_BY_KEY = Object.freeze(Object.fromEntries(PROTECTIONS.map((p) => [p.key, p])));
