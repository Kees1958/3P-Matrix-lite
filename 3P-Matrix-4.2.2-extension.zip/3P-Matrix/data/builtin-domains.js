// ── data/builtin-domains.js ───────────────────────────────────────────────────
// Built-in whitelist: payment, sign-in (SSO), CAPTCHA, fraud prevention, video
// embeds, JS libraries, streaming/meeting/gaming embeds. Third-party scripts/
// frames from these hosts are allowed at levels 3 and 4 (never at level 5).
//
// Derived from 3P-Matrix-lite 4.0.2 BUILTIN_DOMAINS (hand-classified per type)
// with uBlock Stripped Dynamic 10.2.0's corrections applied:
//   - GREY hosts where anyone can publish are NOT trusted: jsdelivr.net,
//     unpkg.com, esm.sh, registry.npmjs.org (removed)
//   - googleapis.com no longer trusted as a whole — only ajax./maps./
//     translate./fonts.googleapis.com
//   - Microsoft/Apple sign-in hosts added (frames)
//
// 0.2.4: streaming / meeting / gaming embeds added (user request). This list is
// for THIRD-PARTY embeds (a widget one site loads from another); since 0.2.4 a
// first-party visit to one of these hosts is also exempt from protections 9 and
// 12–16 (levels 3–4 only), and since 4.2 a payment host may register a real
// payment handler (protection 1, levels 3–4 only). So only services with a
// genuine embeddable iframe/script are included; destination-only services with no such embed (Netflix, Disney+, Xbox,
// PlayStation, WhatsApp, Telegram, Slack, …) are deliberately left out — adding
// them here would have no practical effect. Hand-curated from general
// knowledge, not from a live source — review before relying on it, same as any
// other entry in this file.
//
// Generated once; edit by hand from here on. Each category sub-array is kept
// separate below (single source of truth per category); the exported lists are
// the union, deduplicated and sorted.
// ─────────────────────────────────────────────────────────────────────────────

// ── Payment, sign-in, CAPTCHA, fraud prevention, video embeds, JS libraries ──
// (the original list — unchanged by 0.2.4; 4.2 only splits its payment hosts into
// PAYMENT_* so protection 1 can exempt exactly those — same hosts, same types)
// Payment providers / wallets / bank-payment schemes (script + frame).
const PAYMENT_BOTH = Object.freeze([
  "adyen.com",
  "apple-pay-gateway-nc-pod.apple.com",
  "apple-pay-gateway.apple.com",
  "assets.braintreegateway.com",
  "authorize.net",
  "bambora.com",
  "bancontact.com",
  "banked.com",
  "beanstream.com",
  "billink.nl",
  "bizum.es",
  "buckaroo.nl",
  "ccv.eu",
  "cdn.checkout.com",
  "checkout.com",
  "checkout.stripe.com",
  "checkoutshopper-live.adyen.com",
  "clover.com",
  "cm.com",
  "comgate.cz",
  "computop.com",
  "cybersource.com",
  "elavon.com",
  "eps-ueberweisung.at",
  "euplatesc.ro",
  "every-pay.com",
  "fiserv.com",
  "fisglobal.com",
  "getswish.se",
  "gocardless.com",
  "googlepay.com",
  "gopay.com",
  "heidelpay.com",
  "helcim.com",
  "hooks.stripe.com",
  "ideal-checkout.nl",
  "ingenico.com",
  "js.mollie.com",
  "klarna.com",
  "lyra.com",
  "m.stripe.network",
  "makecommerce.net",
  "mobilepay.dk",
  "mollie.com",
  "moneris.com",
  "multi-safepay.com",
  "netopia-payments.com",
  "nexi.it",
  "noda.live",
  "onlinepaymentplatform.nl",
  "opayo.co.uk",
  "pay.google.com",
  "pay.nl",
  "paybox.com",
  "payone.com",
  "paypal.com",
  "paypalobjects.com",
  "payplug.com",
  "payu.com",
  "payu.pl",
  "plaid.com",
  "plugandpay.io",
  "postepay.it",
  "pronamicpay.com",
  "przelewy24.pl",
  "ratepay.com",
  "redsys.es",
  "riverty.com",
  "sagepay.com",
  "satispay.com",
  "siirto.fi",
  "sisow.nl",
  "swish.nu",
  "tikkie.nl",
  "tink.com",
  "tpay.com",
  "truelayer.com",
  "trustly.com",
  "twint.ch",
  "unzer.com",
  "verifone.cloud",
  "verifone.com",
  "vipps.no",
  "vippsmobilepay.com",
  "vyne.co.uk",
  "walleypay.com",
  "wero-wallet.eu",
  "worldline.com",
  "worldpay.com",
  "x.klarnacdn.net"
]);

// Sign-in, CAPTCHA, fraud prevention, video embeds, JS libraries (script + frame).
const CORE_BOTH = Object.freeze([
  "ajax.googleapis.com",
  "altcha.org",
  "arkoselabs.com",
  "auth0.com",
  "bcove.video",
  "brightcove.com",
  "captcha.eu",
  "cdn.jwplayer.com",
  "cdn.jwpltx.com",
  "challenges.cloudflare.com",
  "client-api.arkoselabs.com",
  "cloudflarestream.com",
  "content.jwplatform.com",
  "dailymotion.com",
  "dmcdn.net",
  "embed.mychannels.video",
  "ext-twitch.tv",
  "f.vimeocdn.com",
  "fast.wistia.com",
  "fonts.googleapis.com",
  "forter.com",
  "friendlycaptcha.com",
  "geetest.com",
  "geo.dailymotion.com",
  "googlevideo.com",
  "gstatic.com",
  "i.vimeocdn.com",
  "jtvnw.net",
  "jwpcdn.com",
  "jwplatform.com",
  "jwplayer.com",
  "kaltura.com",
  "loom.com",
  "loomcdn.com",
  "maps.googleapis.com",
  "mux.com",
  "okta.com",
  "onelogin.com",
  "openai.com",
  "panopto.com",
  "players.brightcove.net",
  "recaptcha.net",
  "riskified.com",
  "rumble.com",
  "seon.io",
  "sift.com",
  "signifyd.com",
  "sproutvideo.com",
  "static.geetest.com",
  "ted.com",
  "translate.googleapis.com",
  "turnstile.cloudflare.com",
  "videodelivery.net",
  "vimeocdn.com",
  "wistia.com",
  "wistia.net",
  "workos.com",
  "youtu.be",
  "youtube-nocookie.com",
  "youtube.com",
  "ytimg.com"
]);

// Payment SDK scripts (script only).
const PAYMENT_SCRIPT_ONLY = Object.freeze([
  "js.braintreegateway.com",
  "js.squareup.com",
  "js.stripe.com",
  "js.stripe.network"
]);

const CORE_SCRIPT_ONLY = Object.freeze([
  "ajax.microsoft.com",
  "code.jquery.com",
  "js.hcaptcha.com"
]);

const CORE_FRAME_ONLY = Object.freeze([
  "account.microsoft.com",
  "appleid.apple.com",
  "hcaptcha.com",
  "idmsa.apple.com",
  "login.live.com",
  "login.microsoftonline.com",
  "login.windows.net",
  "play.vidyard.com",
  "player.twitch.tv",
  "player.vimeo.com"
]);

// ── 0.2.4: streaming — services with a genuine embeddable audio/video widget ─
// (consumer destination sites with NO such embed — Netflix, Disney+, Hulu, Max,
// Prime Video, Paramount+, Peacock, Crunchyroll — are deliberately left out)
const STREAMING_BOTH = Object.freeze([
  "scdn.co",             // Spotify embed widget's CDN assets
  "soundcloud.com",      // w.soundcloud.com player + widget API script
  "spotify.com"          // open.spotify.com embed widget
]);
const STREAMING_FRAME_ONLY = Object.freeze([
  "deezer.com",          // widget.deezer.com embed
  "mixcloud.com",        // player-widget.mixcloud.com embed
  "music.apple.com"      // embed.music.apple.com embed
]);

// ── 0.2.4: meeting / video-call apps with a genuine embeddable widget ───────
// (apps opened directly rather than embedded — WhatsApp, Telegram, Signal,
// Slack, Google Meet (no public embed) — are deliberately left out)
const MEETING_BOTH = Object.freeze([
  "discordapp.com",      // Discord server widget (legacy host, still serves it)
  "discordapp.net",      // Discord widget/CDN assets
  "discord.com",         // Discord server widget (widget.json + iframe)
  "teams.microsoft.com", // Microsoft Teams meeting embed (narrow: not microsoft.com)
  "webex.com",           // Webex meeting embed
  "whereby.com",         // Whereby — built for third-party embedding
  "zoom.us"              // Zoom Web SDK meeting embed
]);

// ── 0.2.4: gaming platforms with a genuine embeddable widget ────────────────
// (destination-only platforms with no embed — Xbox, PlayStation, Nintendo,
// Epic Games, Riot Games — are deliberately left out)
const GAMING_BOTH = Object.freeze([
  "itch.io",             // itch.io game embed widget — very common on blogs
  "steamcommunity.com",  // Steam community widgets (profile, group)
  "steampowered.com"     // Steam store widget (store.steampowered.com/widget/)
]);

// ── Compose: union of every category, deduplicated and sorted ───────────────
function mergedSorted(...lists) {
  return Object.freeze([...new Set(lists.flat())].sort());
}

// Script AND frame allowed
export const BUILTIN_BOTH = mergedSorted(PAYMENT_BOTH, CORE_BOTH, STREAMING_BOTH, MEETING_BOTH, GAMING_BOTH);

// Script only
export const BUILTIN_SCRIPT_ONLY = mergedSorted(PAYMENT_SCRIPT_ONLY, CORE_SCRIPT_ONLY);

// Frame only
export const BUILTIN_FRAME_ONLY = mergedSorted(CORE_FRAME_ONLY, STREAMING_FRAME_ONLY);

// 4.2: payment hosts only (any type) — protection 1's trustedExempt list.
export const BUILTIN_PAYMENT = mergedSorted(PAYMENT_BOTH, PAYMENT_SCRIPT_ONLY);

// Every built-in host (any type) — used to skip first-party scoring.
export const BUILTIN_ALL = Object.freeze([...BUILTIN_BOTH, ...BUILTIN_SCRIPT_ONLY, ...BUILTIN_FRAME_ONLY]);

// 4.2.1: category per built-in host — Show Matrix "Internal whitelist" tooltip (as in
// 3P-Matrix-lite). Built from the same category sub-lists above, so it cannot drift.
// CORE_* mixes sign-in, CAPTCHA, fraud prevention, video and JS libraries, hence one label.
const CATEGORY_LISTS = Object.freeze([
  ["Payment",                                  [PAYMENT_BOTH, PAYMENT_SCRIPT_ONLY]],
  ["Sign-in, CAPTCHA, video or JS library",    [CORE_BOTH, CORE_SCRIPT_ONLY, CORE_FRAME_ONLY]],
  ["Streaming embed",                          [STREAMING_BOTH, STREAMING_FRAME_ONLY]],
  ["Meeting embed",                            [MEETING_BOTH]],
  ["Gaming embed",                             [GAMING_BOTH]]
]);
export const BUILTIN_CATEGORY = Object.freeze(Object.fromEntries(
  CATEGORY_LISTS.flatMap(([label, lists]) => lists.flat().map((h) => [h, label]))
));
