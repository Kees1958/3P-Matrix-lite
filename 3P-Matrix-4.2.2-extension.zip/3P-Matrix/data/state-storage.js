// ── data/state-storage.js ─────────────────────────────────────────────────────
// State schema, defaults, validation and chrome.storage.local access.
// THE only module that reads/writes the persistent state key.
//
// Public interface:
//   defaultState()           — a fresh, fully independent default state object
//   normalizeState(raw)      — returns a NEW validated state (never mutates raw)
//   loadState()              — Promise<state>  (always normalized)
//   saveState(state)         — Promise<void>   (normalizes before writing)
//   withStateLock(fn)        — serializes read-modify-write cycles (guard against
//                              two messages interleaving and losing an update)
//
// State shape:
//   schema               number   STATE_SCHEMA_VERSION
//   level                1..5     current global (session) level
//   prevLevel            1..5     level before the last slider move (lock restores it)
//   startupLevel         1..5     level applied at every browser start
//   siteLocks            { [registeredDomain]: level }   — allow list = sites locked at 1
//   siteLocksOrder       string[] insertion order for FIFO eviction (in sync with siteLocks)
//   disabledProtections  { [protectionKey]: true }       — unticked protections
//   safeZone             { manualTlds[], excludedTlds[], tlds[] } — the "safer regions"
//                        (auto-add scope is fixed, constants SAFER_REGIONS_AUTO_MODE; a stored
//                        autoTldMode from ≤ 0.2.3 is dropped here)
//                        (key name kept: storage keys are contracts)
//   dns                  { first, second }                — provider ids or DNS_NONE
//   matrixRules          { [siteKey]: { [domain]: { script, frame } } } — Show Matrix overrides
//                        (4.2; the pre-4.2 { code, all } shape is converted on load)
//                        (each scope "block" | "allow" | absent); capped at MATRIX_OVERRIDES_CAP pairs.
//                        siteKey is MATRIX_SITE_ALL ("*", 4.1 default — applies everywhere) or,
//                        for legacy/manual per-site rules, a literal host.
// ─────────────────────────────────────────────────────────────────────────────

import {
  STORAGE_KEY_STATE, STATE_SCHEMA_VERSION, LEVEL_MIN, LEVEL_MAX, DEFAULT_STARTUP_LEVEL,
  SITE_LOCKS_CAP, MANUAL_TLDS_CAP, SAFE_ZONE_TLDS_CAP,
  DNS_PROVIDER, DNS_NONE, DEFAULT_DNS_FIRST, DEFAULT_DNS_SECOND, LOG_PREFIX,
  MATRIX_SCOPE, MATRIX_LEGACY_SCOPES, MATRIX_ACTION, MATRIX_OVERRIDES_CAP, MATRIX_SITE_ALL
} from "./constants.js";
import { PROTECTION_KEYS } from "./protections.js";
import { BASE_TLDS } from "../core/tld-engine.js";

const DNS_IDS = new Set([...Object.values(DNS_PROVIDER).map((p) => p.id), DNS_NONE]);
const TLD_RE  = /^[a-z0-9-]{2,63}$|^xn--[a-z0-9-]{1,59}$/;
const HOST_RE = /^(?=.{1,253}$)[a-z0-9-]+(\.[a-z0-9-]+)+$/;

export function defaultState() {
  return {
    schema:              STATE_SCHEMA_VERSION,
    level:               DEFAULT_STARTUP_LEVEL,
    prevLevel:           DEFAULT_STARTUP_LEVEL,
    startupLevel:        DEFAULT_STARTUP_LEVEL,
    siteLocks:           {},
    siteLocksOrder:      [],
    disabledProtections: {},
    safeZone: {
      manualTlds:   [],
      excludedTlds: [],
      tlds:         BASE_TLDS.slice()       // replaced by the computed list on first boot
    },
    dns: { first: DEFAULT_DNS_FIRST, second: DEFAULT_DNS_SECOND },
    matrixRules: {}
  };
}

// ── Validation helpers (pure) ────────────────────────────────────────────────
function clampLevel(v, fallback) {
  const n = Number.parseInt(v, 10);
  return Number.isInteger(n) && n >= LEVEL_MIN && n <= LEVEL_MAX ? n : fallback;
}
function cleanTldList(list, cap) {
  if (!Array.isArray(list)) return [];
  const out = [];
  for (const t of list) {
    const s = String(t).trim().replace(/^\.+/, "").toLowerCase();
    if (TLD_RE.test(s) && !out.includes(s)) out.push(s);
    if (out.length >= cap) break;
  }
  return out;
}
export function isValidHost(h) { return typeof h === "string" && HOST_RE.test(h); }

// Returns a NEW, fully validated state object built from `raw` (any shape).
export function normalizeState(raw) {
  const d = defaultState();
  const r = (raw && typeof raw === "object") ? raw : {};
  const s = defaultState();

  s.level        = clampLevel(r.level, d.level);
  s.prevLevel    = clampLevel(r.prevLevel, s.level);
  s.startupLevel = clampLevel(r.startupLevel, d.startupLevel);

  // siteLocks + order — rebuilt together so they can never drift apart.
  const locks = (r.siteLocks && typeof r.siteLocks === "object") ? r.siteLocks : {};
  const order = Array.isArray(r.siteLocksOrder) ? r.siteLocksOrder : Object.keys(locks);
  for (const host of order) {
    if (!isValidHost(host) || Object.prototype.hasOwnProperty.call(s.siteLocks, host)) continue;
    const lvl = clampLevel(locks[host], null);
    if (lvl === null) continue;
    s.siteLocks[host] = lvl;
    s.siteLocksOrder.push(host);
  }
  while (s.siteLocksOrder.length > SITE_LOCKS_CAP) delete s.siteLocks[s.siteLocksOrder.shift()];

  // disabledProtections — only known keys survive.
  const dis = (r.disabledProtections && typeof r.disabledProtections === "object") ? r.disabledProtections : {};
  for (const key of PROTECTION_KEYS) if (dis[key] === true) s.disabledProtections[key] = true;

  // safeZone
  const z = (r.safeZone && typeof r.safeZone === "object") ? r.safeZone : {};
  s.safeZone.manualTlds   = cleanTldList(z.manualTlds, MANUAL_TLDS_CAP);
  s.safeZone.excludedTlds = cleanTldList(z.excludedTlds, SAFE_ZONE_TLDS_CAP);
  s.safeZone.tlds         = Array.isArray(z.tlds) ? cleanTldList(z.tlds, SAFE_ZONE_TLDS_CAP) : d.safeZone.tlds;

  // dns
  const dns = (r.dns && typeof r.dns === "object") ? r.dns : {};
  s.dns.first  = DNS_IDS.has(dns.first)  ? dns.first  : d.dns.first;
  s.dns.second = DNS_IDS.has(dns.second) ? dns.second : d.dns.second;
  if (s.dns.second !== DNS_NONE && s.dns.second === s.dns.first) s.dns.second = DNS_NONE; // never ask the same resolver twice

  // matrixRules — valid hosts, known scopes/actions only, empty entries dropped, capped.
  const mr = (r.matrixRules && typeof r.matrixRules === "object") ? r.matrixRules : {};
  const scopes = Object.values(MATRIX_SCOPE);
  const actions = new Set(Object.values(MATRIX_ACTION));
  let pairs = 0;
  for (const site of Object.keys(mr)) {
    const siteKeyOk = site === MATRIX_SITE_ALL || isValidHost(site);     // "*" (global) or a literal host
    if (!siteKeyOk || !mr[site] || typeof mr[site] !== "object") continue;
    for (const domain of Object.keys(mr[site])) {
      if (pairs >= MATRIX_OVERRIDES_CAP) break;
      const src = mr[site][domain];
      if (!isValidHost(domain) || !src || typeof src !== "object") continue;
      // 4.2 one-time conversion: a pre-4.2 entry ({ code, all }) sets every current scope that
      // the entry does not set itself — code first, else all (MATRIX_LEGACY_SCOPES order).
      const legacy = MATRIX_LEGACY_SCOPES.map((k) => src[k]).find((a) => actions.has(a));
      const entry = {};
      for (const sc of scopes) {
        if (actions.has(src[sc])) entry[sc] = src[sc];
        else if (legacy) entry[sc] = legacy;
      }
      if (!Object.keys(entry).length) continue;
      (s.matrixRules[site] = s.matrixRules[site] || {})[domain] = entry;
      pairs++;
    }
  }

  return s;
}

// ── Storage access ───────────────────────────────────────────────────────────
export async function loadState() {
  try {
    const stored = await chrome.storage.local.get(STORAGE_KEY_STATE);
    return normalizeState(stored[STORAGE_KEY_STATE]);
  } catch (e) {
    console.error(LOG_PREFIX, "loadState failed — using defaults:", e);
    return defaultState();
  }
}

export async function saveState(state) {
  const clean = normalizeState(state);
  await chrome.storage.local.set({ [STORAGE_KEY_STATE]: clean });
  return clean;
}

// ── Guard: serialize read-modify-write cycles ────────────────────────────────
// Each caller's fn(state) runs only after the previous one has finished
// (resolved OR rejected), so two quick popup clicks can never both read the
// same old state and overwrite each other. The chain is released after every
// step — a failure never blocks later callers.
let _chain = Promise.resolve();
export function withStateLock(fn) {
  const run = _chain.then(() => fn());
  _chain = run.then(() => undefined, () => undefined);
  return run;
}
