// ── data/constants.js ─────────────────────────────────────────────────────────
// 3P Matrix — content firewall
// THE single place for every switch, magic number, ID, priority, threshold,
// score, colour, storage key and timeout used by the extension. Pure data —
// never mutated at runtime (everything is frozen).
//
// Nothing else in the codebase may declare its own copy of a value that lives
// here; import it instead.
// ─────────────────────────────────────────────────────────────────────────────

// ── Identity ─────────────────────────────────────────────────────────────────
export const LOG_PREFIX = "[3PMCF]";

// ── Levels (enum + per-level presentation) ───────────────────────────────────
export const LEVEL = Object.freeze({
  ALLOW_ALL: 1,   // every protection off
  MILD:      2,   // protections 1–11 (10 = suspicious-site warning, 11 = abused-TLD block)
  MEDIUM:    3,   // + protections 12–16, block 3P scripts/frames outside safer regions
  HIGH:      4,   // + block 3P scripts/frames everywhere; CDN + built-in allowed
  STRICT:    5    // block 3P scripts/frames, no exceptions (4.2: never images/video/fonts/CSS)
});
export const LEVEL_MIN = LEVEL.ALLOW_ALL;
export const LEVEL_MAX = LEVEL.STRICT;
export const DEFAULT_STARTUP_LEVEL = LEVEL.MILD;     // spec 2026-10-16: startup level 2 by default
// Levels at which the safer-regions TLD list has any effect (spec 2026-10-16: level 3 only).
// There it allows 3P scripts/frames from those TLDs and exempts their sites from
// protections 12–16. Levels 4–5 apply 12–16 on every site and ignore the list; levels 1–2
// never used it. The popup shows the safer-regions panel and site label only at these levels.
export const SAFER_REGIONS_LEVELS = Object.freeze([LEVEL.MEDIUM]);
// Levels at which the built-in whitelist (data/builtin-domains.js) is trusted: its 3P scripts/
// frames are allowed AND a first-party visit to one of its hosts is exempt from protections
// 9/12–16 (and, for its payment hosts, from protection 1). Never level 2 or 5. Single switch
// read by core/rule-builder.js and core/script-builder.js (4.2: was two private copies).
export const BUILTIN_EXEMPT_LEVELS = Object.freeze([LEVEL.MEDIUM, LEVEL.HIGH]);

// Index = level - 1. Colours are 3P-Matrix-lite's; icons are its brick-wall set.
export const LEVEL_INFO = Object.freeze([
  Object.freeze({ level: 1, name: "Allow all",                       color: "#16A34A", icon: "icon_0" }),
  Object.freeze({ level: 2, name: "Mild protection",                 color: "#93C5FD", icon: "icon_1" }),
  Object.freeze({ level: 3, name: "Medium protection",               color: "#FACC15", icon: "icon_2" }),
  Object.freeze({ level: 4, name: "High protection",                 color: "#FB923C", icon: "icon_3" }),
  Object.freeze({ level: 5, name: "Strict — no 3P scripts or frames", color: "#C0392B", icon: "icon_4" })
]);
export const ICON_SIZES = Object.freeze([16, 32, 48, 128]);
export const ICON_DIR   = "icons";

// ── Storage ──────────────────────────────────────────────────────────────────
export const STORAGE_KEY_STATE   = "tldm_state";     // chrome.storage.local — whole persistent state
export const STATE_SCHEMA_VERSION = 1;
export const SITE_LOCKS_CAP       = 400;             // max locked sites (FIFO eviction of the oldest)
export const MANUAL_TLDS_CAP      = 100;             // max hand-added safer-region TLDs
export const ALLOW_LIST_LINE_MAX  = 253;             // max DNS name length — longer lines are ignored

// ── Safer regions (TLD whitelist) ────────────────────────────────────────────────
// Which country codes are added automatically — FIXED, no user control (0.2.4: the popup's
// 4-position "Auto-add country codes" slider is removed). Same default as uBlock Stripped Dynamic
// (since its 0.0.3): CONTINENT = the countries named by the browser's languages + every country on
// the user's continent that speaks one of them (or a readable relative). Value = core/tld-engine.js
// AUTO_TLD_MODE.CONTINENT (data/ cannot import core/; core/safer-regions.js checks it is valid).
export const SAFER_REGIONS_AUTO_MODE = 2;
// Never ADD a TLD from the HaGeZi abused-TLD list (data/spam-tlds.js) automatically — the base set
// already leaves biz/shop/store/site/online out; this extends the same rule to auto-added country
// codes (e.g. cf, cm, ga, gq, ml, ng, pw). A TLD the user adds by hand is always kept (their choice).
export const SAFER_REGIONS_SKIP_ABUSED_TLDS = true;
export const SAFE_ZONE_TLDS_CAP = 300;               // guard for DNR condition size

// ── DNR rule IDs ─────────────────────────────────────────────────────────────
// Every dynamic rule = GROUP_ID_STRIDE * groupIndex + local id.
//   groupIndex 0     = global rules (all sites not locked)
//   groupIndex 1..5  = sites locked at that level (one rule group per level, not per site)
export const GROUP_ID_STRIDE = 10000;
export const RULE_LOCAL_ID = Object.freeze({
  WEBBUNDLE:            10,  // protection 2
  LOCALNET_NAMES:       11,  // protection 4 — *.local / *.lan / *.internal / *.home.arpa
  LOCALNET_IPV4:        12,  // protection 4 — private IPv4 literals
  LOCALNET_IPV6:        13,  // protection 4 — private IPv6 literals
  SUSP_IP:              20,  // protection 6 — bare IP literal host
  SUSP_PORT_BLOCK:      22,  // protection 6 — explicit non-standard port (one regex, no allow twin)
  SUSP_HOSTING:         23,  // protection 6 — DDNS / free-hosting domains
  SUSP_HOSTING_REGEX:   24,  // protection 6 — byethost* regex
  HTTP_3P:              30,  // protection 7 — third-party plain HTTP
  SPAM_TLD_BLOCK:       40,  // protection 11 (L2+) — 3P scripts/frames from abused TLDs
  L3_BLOCK_CODE:        50,  // L3 — block 3P scripts + frames
  SAFEZONE_ALLOW:       51,  // L3 — allow 3P code from safer-region TLDs
  L4_BLOCK_CODE:        60,  // L4 — block 3P scripts + frames (4.2: was "all except passive")
  CDN_ALLOW:            61,  // L4 — allow 3P code with "cdn" in host
  L5_BLOCK_CODE:        70,  // L5 — block 3P scripts + frames, no exceptions (4.2: was every type)
  BUILTIN_ALLOW_SCRIPT: 80,  // L3/L4 — built-in whitelist, script-only domains
  BUILTIN_ALLOW_FRAME:  81,  // L3/L4 — built-in whitelist, frame-only domains
  BUILTIN_ALLOW_BOTH:   82,  // L3/L4 — built-in whitelist, script + frame domains
  HDR_PP_MAIN:          100, // protections 12–14 — Permissions-Policy on top-level pages
  HDR_PP_SUB:           101, // protections 12–14 — Permissions-Policy on frames
  HDR_CSP_MAIN:         102, // protection 16 — sandbox CSP on top-level pages
  HDR_CSP_SUB:          103, // protection 16 — sandbox CSP on frames
  HDR_HIGH_RISK:        110  // protection 9 — Permissions-Policy on high-risk sites
});
export const MATRIX_RULE_ID_BASE = 900000;            // Show Matrix overrides: 900000 … 900000 + MATRIX_RULES_MAX - 1

// ── DNR priorities (higher wins) ─────────────────────────────────────────────
export const PRIORITY = Object.freeze({
  LEVEL_BLOCK:       100,    // L3 / L4 3P scripts + frames block
  BUILTIN_ALLOW:     300,    // built-in whitelist
  CDN_ALLOW:         300,    // L4 cdn-host allow
  SPAM_TLD_BLOCK:    350,    // beats built-in/CDN allows
  SAFEZONE_ALLOW:    360,    // L3: safer regions override the abused-TLD block (spec)
  SECURITY_BLOCK:    1000,   // protections 2, 6, 7 — beat every allow above
  LOCALNET_BLOCK:    1002,   // explicit port cannot bypass it
  // 4.1: Show Matrix rules now default to global (every site); a site-scoped rule is a legacy
  // shape (kept for pre-4.1 saved data) and must always outrank a global rule for the same
  // (domain, scope) pair — hence two full tiers, SITE strictly above GLOBAL. Order within a
  // tier: 4.2 — Script and Frame columns cover disjoint resource types, so they never compete
  // and share one priority per tier.
  MATRIX_GLOBAL:      400000, // Show Matrix Script/Frame, global scope (beats every level/security rule)
  MATRIX_SITE:        400001, // Show Matrix Script/Frame, legacy site-scoped (beats every global matrix rule)
  STRICT_BLOCK:      500000, // L5 beats everything, matrix allows included
  HEADERS:           1       // modifyHeaders rules never compete with block/allow
});

// ── Resource types ───────────────────────────────────────────────────────────
export const RT = Object.freeze({
  CODE:     Object.freeze(["script", "sub_frame"]),
  PASSIVE:  Object.freeze(["image", "media", "font", "stylesheet"]),   // never targeted by any level (4.2)
  // Everything a page can load besides the top-level document (Chrome's ResourceType enum).
  ALL_SUB:  Object.freeze(["sub_frame", "stylesheet", "script", "image", "font", "object",
                           "xmlhttprequest", "ping", "csp_report", "media", "websocket",
                           "webtransport", "webbundle", "other"]),
  SUSP_HOSTING: Object.freeze(["sub_frame", "script", "websocket", "webtransport"])
});

// ── Third-party heuristics for DNR ───────────────────────────────────────────
export const STANDARD_PORTS = Object.freeze([80, 443, 8080, 8443]);
export const CDN_HOST_MARKER = "cdn";                                          // L4 cdn allow: substring of the HOST name
export const CDN_HOST_REGEX = "^[a-z][a-z0-9+.-]*://[^/]*cdn[^/]*(/|$)";        // "cdn" in host only
export const IP_LITERAL_REGEX = "^[a-z]+://(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}([:/]|$)|\\[[0-9a-fA-F:]+\\])";
// Any explicit port EXCEPT 80, 443, 8080, 8443 — one RE2 regex (no look-ahead available), so no
// high-priority "allow standard ports" twin rule is needed (that twin would also have overridden
// the TLD and level blocks for URLs written with an explicit :443).
export const NON_STANDARD_PORT_REGEX = "^[a-z]+://[^/:]+:(?:" + [
  "[0-9]",                                                            // 1 digit
  "[0-79][0-9]|8[1-9]",                                               // 2 digits, not 80
  "[0-35-9][0-9]{2}|4[0-35-9][0-9]|44[0-24-9]",                       // 3 digits, not 443
  "[0-79][0-9]{3}|8[1-35-9][0-9]{2}|80[0-79][0-9]|808[1-9]|84[0-35-9][0-9]|844[0-24-9]", // 4 digits, not 8080/8443
  "[0-9]{5}"                                                          // 5 digits
].join("|") + ")(?:[/?#]|$)";
export const BYETHOST_REGEX   = "^[a-z]+://([a-z0-9-]+\\.)*byethost[a-z0-9-]*\\.com([/:]|$)";

// ── Header values ────────────────────────────────────────────────────────────
export const PP_VALUE = Object.freeze({
  PRIVACY:  "camera=(), microphone=(), display-capture=(), clipboard-read=()",       // protection 12
  SECURITY: "bluetooth=(), serial=(), hid=(), usb=(), local-network-access=()",      // protection 13
  SENSORS:  "accelerometer=(), gyroscope=(), magnetometer=()"                          // protection 14 (NFC = script)
});
export const SANDBOX_CSP_VALUE = "sandbox allow-downloads allow-forms allow-orientation-lock allow-pointer-lock " +
  "allow-popups allow-presentation allow-same-origin allow-scripts allow-storage-access-by-user-activation"; // protection 16

// ── Content-script registration ──────────────────────────────────────────────
export const SCRIPT_ID_PREFIX = "tldm-";
export const NOEVAL_EXTRA_EXCLUDES = Object.freeze(["*://*/*login*", "*://*/*Login*", "*://*/*LOGIN*", "*://*/*.aspx*"]);

// ── Suspicious-site detection (stage 1 local / stage 2 online) ───────────────
export const SCORE = Object.freeze({
  SUSPECT_AT:           -30,   // ≤ this → orange badge + warning dialog (protection 10)
  PHISHING_BELOW:       -60,   // < this → red badge "!" + phishing dialog
  IP_HOST:              -30,   // first-party host is a bare public IP address
  NON_STANDARD_PORT:    -15,   // first-party URL uses a port outside STANDARD_PORTS
  PLAIN_HTTP:           -15,   // first-party page over plain HTTP
  SPAM_TLD_RISK:         60,   // 0-100 risk fed into the TLD family for HaGeZi-listed TLDs (→ −30)
  TLD_BASE:             -50,   // DownloadSentinel HOST_TLD_BASE_SCORE
  DOMAIN_LIST_BASE:     -70,   // DownloadSentinel HOST_DOMAIN_BASE_SCORE
  HOST_LIST_BASE:       -70,   // DownloadSentinel HOST_LIST_BASE_SCORE
  SKETCHY_URL_BASE:     -35,   // DownloadSentinel HOST_SKETCHY_URL_BASE
  BRAND_HOMOGLYPH:      -65,   // DownloadSentinel BRAND_HOMOGLYPH_SCORE
  LOOKALIKE_TOP_SITE:   -25,   // DownloadSentinel LOOKALIKE_TOP_SITE_SCORE
  RDAP_YOUNG:           -30,   // registered < RDAP_YOUNG_DAYS ago
  RDAP_RECENT:          -10,   // registered < RDAP_RECENT_DAYS ago
  DNS_BLOCKED:          -100,  // a threat-intel resolver blocks the domain (hard rule)
  FLOOR:                -100
});
export const SEVERITY = Object.freeze({ NONE: "none", SUSPECT: "suspect", PHISHING: "phishing" });
export const RDAP_YOUNG_DAYS  = 30;
export const RDAP_RECENT_DAYS = 90;
export const RDAP_URL         = "https://rdap.org/domain/";
export const RDAP_TIMEOUT_MS  = 4000;
export const DNS_TIMEOUT_MS   = 3000;
export const SCORE_CACHE_CAP     = 500;              // registered domains kept in memory
export const SCORE_CACHE_TTL_MS  = 6 * 60 * 60 * 1000; // 6 h

// Threat-intel DNS resolvers the user may pick as FIRST / SECOND check.
// blockStyle: how the resolver says "blocked":
//   "nxdomain-no-authority" — NXDOMAIN with an empty authority section (Quad9)
//   "zero-ip"               — answers 0.0.0.0 / :: (Cloudflare 1.1.1.2, Control D)
export const DNS_PROVIDER = Object.freeze({
  QUAD9:      Object.freeze({ id: "quad9",      label: "Quad9",                         host: "dns.quad9.net",               url: "https://dns.quad9.net/dns-query",               blockStyle: "nxdomain-no-authority" }),
  CLOUDFLARE: Object.freeze({ id: "cloudflare", label: "Cloudflare Security (malware)", host: "security.cloudflare-dns.com", url: "https://security.cloudflare-dns.com/dns-query", blockStyle: "zero-ip" }),
  CONTROLD:   Object.freeze({ id: "controld",   label: "Control D (malware)",           host: "freedns.controld.com",        url: "https://freedns.controld.com/p1",              blockStyle: "zero-ip" })
});
export const DNS_NONE = "none";
export const DEFAULT_DNS_FIRST  = DNS_PROVIDER.QUAD9.id;
export const DEFAULT_DNS_SECOND = DNS_PROVIDER.CLOUDFLARE.id;

// Hosts never scored as a first-party site (private / local network, loopback).
export const PRIVATE_HOST_SUFFIXES = Object.freeze([".local", ".lan", ".internal", ".home.arpa", ".localhost"]);

// ── Badge ────────────────────────────────────────────────────────────────────
export const BADGE_COLOR = Object.freeze({
  NORMAL:   "#666666",
  SUSPECT:  "#C2410C",
  PHISHING: "#B91C1C"
});
export const BADGE_PHISHING_PREFIX = "!";
export const BADGE_MAX_COUNT       = 999;            // shown as "999+" above this

// ── Show Matrix (Script / Frame overrides) ────────────────────────────────────────────────────
// 4.2: the combined 3P-code / 3P-all pair is replaced by two independent columns, Script and
// Frame, each cycling none → BLOCK → ALLOW on its own. Saved data in the old shape
// ({ code, all }) is converted once by data/state-storage.js normalizeState(): code (or, if
// unset, all) → both script and frame. An old 3P-all rule thus keeps its script/frame effect
// but no longer touches images/video/fonts/CSS — in line with the levels, which never do.
// 4.1: overrides are global by default (apply on every site) instead of per-site, so that a
// converted 3P-Matrix-lite rule — which was always global there — carries over faithfully, and
// so a blocked/allowed third party stays blocked/allowed no matter which first-party site you're
// on. matrixRules keeps its existing shape ({ [siteKey]: { [domain]: { code, all } } }); the one
// reserved siteKey MATRIX_SITE_ALL means "every site" instead of one literal host. A literal host
// key is still accepted on load (pre-4.1 data, or a future manual per-site override) and always
// wins over a global rule for the same domain — see the SITE vs GLOBAL priority tiers above.
export const MATRIX_SITE_ALL = "*";                                       // single declared sentinel
export const MATRIX_SCOPE = Object.freeze({ SCRIPT: "script", FRAME: "frame" });
// DNR resource type per scope (one type each — the columns never overlap).
export const MATRIX_SCOPE_RESOURCE_TYPE = Object.freeze({ [MATRIX_SCOPE.SCRIPT]: "script", [MATRIX_SCOPE.FRAME]: "sub_frame" });
// Column header / aria label per scope.
export const MATRIX_SCOPE_LABEL = Object.freeze({ [MATRIX_SCOPE.SCRIPT]: "Script", [MATRIX_SCOPE.FRAME]: "Frame" });
// Pre-4.2 saved keys, read only by normalizeState() for the one-time conversion. Order = precedence.
export const MATRIX_LEGACY_SCOPES = Object.freeze(["code", "all"]);
export const MATRIX_ACTION = Object.freeze({ BLOCK: "block", ALLOW: "allow" });
export const MATRIX_OVERRIDES_CAP   = 1000;          // (site, domain) pairs kept — new pairs refused above this
export const MATRIX_RULES_MAX       = 2000;          // DNR rules in the matrix band (2 per pair at most: Script + Frame)
export const MATRIX_DOMAINS_PER_TAB = 150;
export const TAB_SITES_CAP          = 500;           // core/tab-sites.js: tabs whose top-level host is remembered           // observed third-party rows per tab (oldest dropped first)
export const MATRIX_DURATION_MS     = 5 * 60 * 1000; // observation stops after 5 minutes
export const MATRIX_POLL_MS         = 800;           // panel refresh interval
export const MATRIX_TIMER_WARN_MS   = 60 * 1000;     // panel timer turns yellow in the last minute (3P-Matrix-lite)
export const MATRIX_CLOSE_GRACE_MS  = 5 * 1000;      // panel's own fallback: close itself this long after
                                                     // MATRIX_DURATION_MS if the service worker never did
export const MATRIX_WINDOW = Object.freeze({ width: 980, height: 720 });
// Observed resource types → fixed panel column (same 7 columns as uBlock Stripped Dynamic's panel).
export const MATRIX_TYPE_LABEL = Object.freeze({
  image: "image", media: "media", stylesheet: "css", script: "script", sub_frame: "frame",
  xmlhttprequest: "xhr",
  font: "other", websocket: "other", object: "other", ping: "other", csp_report: "other",
  webbundle: "other", other: "other"            // webtransport: not a webRequest filter type
});

// ── UI ───────────────────────────────────────────────────────────────────────
export const WARNING_PAGE = "ui/warning.html";
export const MATRIX_PAGE  = "ui/matrix.html";
