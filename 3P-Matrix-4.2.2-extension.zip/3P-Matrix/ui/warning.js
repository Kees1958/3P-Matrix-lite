// ── ui/warning.js — warning dialog controller ─────────────────────────────────
// Shows the suspicious site (from ?u=), asks the service worker for the full
// stage 1 + stage 2 evaluation, and sends the user's choice back.
// All site text goes into the DOM via textContent.
// ─────────────────────────────────────────────────────────────────────────────

import * as M from "../data/message-types.js";
import { SEVERITY, ICON_DIR } from "../data/constants.js";

// ── Severity presentation (single table) ─────────────────────────────────────
const SEVERITY_VIEW = Object.freeze({
  [SEVERITY.SUSPECT]: {
    color: "#FB923C", icon: "icon_3",
    title: "This site looks suspicious",
    intro: "The address shows signs that are common on scam and phishing sites. Check the address carefully before you log in or pay."
  },
  [SEVERITY.PHISHING]: {
    color: "#F87171", icon: "icon_4",
    title: "This site may be trying to trick you",
    intro: "The address shows several signs of a phishing site. Do not enter passwords, payment details or personal information here."
  }
});

const $ = (id) => document.getElementById(id);
const target = new URLSearchParams(location.search).get("u") || "";
let busy = false;                                         // guard: one action at a time

function setButtons(disabled) {
  ["btnBack", "btnTrust", "btnContinue"].forEach((id) => { $(id).disabled = disabled; });
}

function showSeverity(sev) {
  const v = SEVERITY_VIEW[sev] || SEVERITY_VIEW[SEVERITY.SUSPECT];
  document.documentElement.style.setProperty("--sev", v.color);
  $("warnIcon").src = `../${ICON_DIR}/${v.icon}_32.png`;
  $("warnTitle").textContent = v.title;
  $("warnIntro").textContent = v.intro;
  document.title = `3P Matrix — ${v.title}`;
}

function showSignals(list) {
  $("warnSignals").replaceChildren(...list.map((s) => { const li = document.createElement("li"); li.textContent = s; return li; }));
}

async function action(kind) {
  if (busy) return;
  busy = true;
  setButtons(true);
  try {
    const res = await chrome.runtime.sendMessage({ type: M.MSG_WARNING_ACTION, action: kind, url: target });
    if (!res || !res.ok) throw new Error(res && res.error);
  } catch (e) {
    console.warn("[3PMCF warning]", e);
    busy = false;                                         // release so the user can try again
    setButtons(false);
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  let host = "";
  try { host = new URL(target).host; } catch { /* malformed — leave empty */ }
  $("warnHost").textContent = host || target;
  showSeverity(SEVERITY.SUSPECT);

  $("btnBack").addEventListener("click", () => action(M.WARNING_ACTION.GO_BACK));
  $("btnTrust").addEventListener("click", () => action(M.WARNING_ACTION.TRUST));
  $("btnContinue").addEventListener("click", () => action(M.WARNING_ACTION.CONTINUE_ONCE));
  $("optionsLink").addEventListener("click", (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
  $("btnBack").focus();

  try {
    const res = await chrome.runtime.sendMessage({ type: M.MSG_EVALUATE_SITE, url: target });
    if (!res || !res.ok || !res.data) throw new Error(res && res.error || "not scorable");
    const r = res.data;
    showSeverity(r.severity === SEVERITY.NONE ? SEVERITY.SUSPECT : r.severity);
    $("warnScore").textContent = `risk score ${r.score}`;
    showSignals(r.signals);
  } catch (e) {
    $("warnScore").textContent = "score unavailable";
    console.warn("[3PMCF warning] evaluate", e);
  } finally {
    $("warnChecking").hidden = true;
  }
});
