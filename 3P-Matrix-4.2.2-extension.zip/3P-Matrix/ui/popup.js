// ── ui/popup.js — toolbar popup controller ────────────────────────────────────
// Renders the view model the service worker returns (MSG_GET_POPUP_STATE) and
// sends user actions back. Holds no business logic: every change round-trips
// through the service worker, which returns the fresh view model.
// All text goes into the DOM via textContent (host names are untrusted).
// ─────────────────────────────────────────────────────────────────────────────

import * as M from "../data/message-types.js";
import { LEVEL, ICON_DIR } from "../data/constants.js";
import { saferRegionsApply } from "../core/policy.js";

// ── Popup-only presentation constants ───────────────────────────────────────
const ALLOW_COLOR = "#16A34A";
const BLOCK_COLOR = "#F87171";
const NEUTRAL_COLOR = "#C0C7D4";
const SVG_NS = "http://www.w3.org/2000/svg";
const LOCK_PATH_CLOSED = "M8 11V7a4 4 0 0 1 8 0v4";
const LOCK_PATH_OPEN   = "M8 11V7a4 4 0 0 1 7.5-2";
const SAFER_OPEN_DEFAULT = true;          // 4.2: safer-regions panel starts expanded (TLD list visible at once)

// ── Popup state (guarded: initialised empty, replaced wholesale per response) ─
let tab = null;            // { id, url } of the active tab
let model = null;          // last view model from the service worker
let protOpen = false;      // Protections panel open
let safeOpen = SAFER_OPEN_DEFAULT;  // Safer-regions panel open
let busy = false;          // guard: ignore clicks while a request is in flight

const $ = (id) => document.getElementById(id);

function send(type, extra = {}) {
  return chrome.runtime.sendMessage({ type, tabId: tab && tab.id, url: tab && tab.url, ...extra })
    .then((res) => { if (!res || !res.ok) throw new Error(res && res.error || "no response"); return res.data; });
}

async function act(type, extra, { reloadTab = false } = {}) {
  if (busy) return;
  busy = true;
  try {
    model = await send(type, extra);
    render();
    if (reloadTab && tab && model.scorable) chrome.tabs.reload(tab.id);
  } catch (e) {
    console.warn("[3PMCF popup]", type, e);
  } finally {
    busy = false;                                              // release on every path
  }
}

// ── Active policy bullets (fixed order: allow · level-specific · block) ─────
// Protections 10 (suspicious-site warnings) and 11 (abused-TLD block, 4.2) are counted in `n`
// exactly like every other protection and get no bullet of their own — no protection does.
// 4.2: levels 3–5 target 3P scripts + frames only; images/video/fonts/CSS are never blocked.
function bulletsFor(m) {
  const c = m.levelInfo[m.level - 1].color;
  const n = m.counts.active === m.counts.total ? `${m.counts.total} protections` : `${m.counts.active} of ${m.counts.total} protections`;
  // 0.2.4: now also streaming/meeting/gaming embeds (data/builtin-domains.js) — kept to one line.
  const builtin = { c: ALLOW_COLOR, t: "Trusted: payment, sign-in, streaming, meetings, games" };
  switch (m.level) {
    case LEVEL.ALLOW_ALL: return [{ c: NEUTRAL_COLOR, t: "All traffic allowed — no protections" }];
    case LEVEL.MILD: return [
      { c, t: `${n} active` }];
    case LEVEL.MEDIUM: return [
      builtin,
      { c: ALLOW_COLOR, t: `3P code from ${m.safeZone.tlds.length} safer-region TLDs allowed` },
      { c, t: `${n} (5 outside safer regions)` },
      { c: BLOCK_COLOR, t: "Other 3P scripts & frames blocked" }];
    case LEVEL.HIGH: return [
      builtin,
      { c, t: "3P code from “cdn” hosts allowed" },
      { c, t: `${n} active` },
      { c: BLOCK_COLOR, t: "Other 3P scripts & frames blocked" }];
    default: return [
      { c, t: `${n} active` },
      { c: BLOCK_COLOR, t: "All 3P scripts & frames blocked — no exceptions" }];
  }
}

// ── DOM builders ─────────────────────────────────────────────────────────────
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

function lockSvg(closed, color) {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("width", "22"); svg.setAttribute("height", "22"); svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("fill", "none"); svg.setAttribute("stroke", color); svg.setAttribute("stroke-width", "2");
  svg.setAttribute("stroke-linecap", "round"); svg.setAttribute("stroke-linejoin", "round"); svg.setAttribute("aria-hidden", "true");
  const rect = document.createElementNS(SVG_NS, "rect");
  rect.setAttribute("x", "4"); rect.setAttribute("y", "11"); rect.setAttribute("width", "16"); rect.setAttribute("height", "10"); rect.setAttribute("rx", "2");
  const path = document.createElementNS(SVG_NS, "path");
  path.setAttribute("d", closed ? LOCK_PATH_CLOSED : LOCK_PATH_OPEN);
  svg.append(rect, path);
  return svg;
}

// ── Render ───────────────────────────────────────────────────────────────────
function render() {
  const m = model;
  if (!m) return;
  const info = m.levelInfo[m.level - 1];
  const locked = m.lockedLevel !== null;
  document.documentElement.style.setProperty("--accent", info.color);

  $("levelIcon").src = `../${ICON_DIR}/${info.icon}_32.png`;
  $("startupSelect").value = String(m.startupLevel);
  $("startupSelect").style.borderColor = m.levelInfo[m.startupLevel - 1].color;

  $("siteHost").textContent = m.host || "—";
  const zone = $("siteZone");
  const saferRelevant = saferRegionsApply(m.level);         // level 3 only
  zone.hidden = !saferRelevant || !m.scorable;
  zone.className = "site-zone " + (m.inSafeZone ? "in" : "out");
  zone.textContent = !m.scorable ? "" : m.inSafeZone ? "IN SAFER REGIONS" : "OUTSIDE SAFER REGIONS";

  const lockBtn = $("lockBtn");
  lockBtn.replaceChildren(lockSvg(locked, locked ? "#0F1117" : "#FFFFFF"));
  lockBtn.style.background = locked ? info.color : "var(--surface)";
  lockBtn.disabled = !m.scorable;
  const lockLabel = locked ? `Locked to level ${m.level} — click to unlock` : `Lock level ${m.level} for this site`;
  lockBtn.title = lockLabel; lockBtn.setAttribute("aria-label", lockLabel);

  $("levelNum").textContent = String(m.level);
  $("levelName").textContent = info.name;
  $("lockHint").hidden = !locked;

  // Level ticks
  $("trackFill").style.width = `calc((100% - 44px) * ${(m.level - 1) / 4})`;
  const ticks = [];
  for (let n = 1; n <= 5; n++) {
    const b = el("button", "tick");
    b.type = "button";
    b.disabled = locked;
    b.setAttribute("aria-label", `Level ${n} — ${m.levelInfo[n - 1].name}`);
    b.append(el("span", "dot" + (n === m.level ? " current" : n < m.level ? " past" : "")), el("span", "num" + (n === m.level ? " current" : ""), String(n)));
    b.addEventListener("click", () => act(M.MSG_SET_LEVEL, { level: n }, { reloadTab: true }));
    ticks.push(b);
  }
  $("tickRow").replaceChildren(...ticks);

  // Bullets
  $("bullets").replaceChildren(...bulletsFor(m).map((b) => {
    const row = el("div", "bullet");
    const dot = el("span", "b-dot"); dot.style.background = b.c;
    row.append(dot, el("span", "b-text", b.t));
    return row;
  }));

  // Protections panel
  const protBtn = $("protBtn");
  protBtn.hidden = m.level < LEVEL.MILD;
  protBtn.setAttribute("aria-expanded", String(protOpen));
  protBtn.textContent = `Protections ${protOpen ? "▲" : "▼"}`;
  const panel = $("protPanel");
  panel.hidden = !(protOpen && m.level >= LEVEL.MILD);
  panel.replaceChildren(...m.groups.filter((g) => m.level >= g.fromLevel).map((g) => {
    const wrap = el("div");
    const head = el("div", "prot-group-head");
    head.append(el("span", "", g.title), el("span", "from", `from L${g.fromLevel}`));
    wrap.append(head);
    g.items.forEach((it) => {
      const lab = el("label", "prot-item" + (it.enabled ? "" : " off"));
      const cb = el("input"); cb.type = "checkbox"; cb.checked = it.enabled;
      cb.addEventListener("change", () => act(M.MSG_SET_PROTECTION, { key: it.key, enabled: cb.checked }));
      lab.append(cb, el("span", "p-num", String(it.num)), el("span", "p-label", it.label));
      wrap.append(lab);
    });
    return wrap;
  }));

  // Safer regions
  $("safeZone").hidden = !saferRelevant;
  $("safeTitle").textContent = `Safer regions — ${m.safeZone.tlds.length} TLDs`;
  $("safeArrow").textContent = safeOpen ? "▲" : "▼";
  $("safeToggle").setAttribute("aria-expanded", String(safeOpen));
  $("safeBody").hidden = !safeOpen;
  $("tldTags").replaceChildren(...m.safeZone.tlds.map((t) => {
    const tag = el("span", "tag", t);
    const x = el("button", "", "×"); x.type = "button"; x.setAttribute("aria-label", `Remove ${t}`);
    x.addEventListener("click", () => act(M.MSG_SET_SAFE_ZONE, { removeTld: t }));
    tag.append(x);
    return tag;
  }));

  $("matrixBtn").disabled = !m.scorable;                       // web pages only

  $("blockedText").textContent = m.level === LEVEL.ALLOW_ALL ? "No requests blocked" : `${m.blocked} requests blocked on this tab`;
}

// ── Wiring ───────────────────────────────────────────────────────────────────
function wire() {
  $("startupSelect").addEventListener("change", (e) => act(M.MSG_SET_STARTUP_LEVEL, { level: Number(e.target.value) }));
  $("lockBtn").addEventListener("click", () => act(M.MSG_TOGGLE_LOCK, {}, { reloadTab: true }));
  $("protBtn").addEventListener("click", () => { protOpen = !protOpen; render(); });
  $("safeToggle").addEventListener("click", () => { safeOpen = !safeOpen; render(); });
  const addTld = () => {
    const v = $("tldInput").value.trim();
    if (!v) return;
    $("tldInput").value = "";
    act(M.MSG_SET_SAFE_ZONE, { addTld: v });
  };
  $("tldAdd").addEventListener("click", addTld);
  $("tldInput").addEventListener("keydown", (e) => { if (e.key === "Enter") addTld(); });
  $("tldDefault").addEventListener("click", () => act(M.MSG_SET_SAFE_ZONE, { restoreDefault: true }));
  $("optionsLink").addEventListener("click", (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
  $("matrixBtn").addEventListener("click", async () => {
    try { await send(M.MSG_OPEN_MATRIX); window.close(); }
    catch (e) { console.warn("[3PMCF popup] Show Matrix", e); }
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  wire();
  try {
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    tab = t ? { id: t.id, url: t.url || "" } : null;
    model = await send(M.MSG_GET_POPUP_STATE);
    render();
  } catch (e) {
    console.warn("[3PMCF popup] init", e);
  }
});
