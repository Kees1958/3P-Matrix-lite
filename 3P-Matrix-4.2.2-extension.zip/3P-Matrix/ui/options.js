// ── ui/options.js — options page controller ───────────────────────────────────
// DNS check choice, allow list (= sites locked at level 1), settings backup.
// Every change round-trips through the service worker.
// ─────────────────────────────────────────────────────────────────────────────

import * as M from "../data/message-types.js";

const STATUS_CLEAR_MS = 8000;          // how long a status line stays visible (summaries are long)
const EXPORT_FILE_NAME = "3p-matrix-settings.json";

const $ = (id) => document.getElementById(id);
let model = null;                      // last options model
const _statusTimers = new Map();       // element id → timer (released on every new message)

function send(type, extra = {}) {
  return chrome.runtime.sendMessage({ type, ...extra })
    .then((res) => { if (!res || !res.ok) throw new Error(res && res.error || "no response"); return res.data; });
}

function status(id, text) {
  clearTimeout(_statusTimers.get(id));
  $(id).textContent = text;
  _statusTimers.set(id, setTimeout(() => { $(id).textContent = ""; _statusTimers.delete(id); }, STATUS_CLEAR_MS));
}

function fillSelect(sel, value) {
  sel.replaceChildren(...model.providers.map((p) => {
    const o = document.createElement("option");
    o.value = p.id;
    o.textContent = p.host ? `${p.label} — ${p.host}` : p.label;
    o.selected = p.id === value;
    return o;
  }));
}

function render() {
  fillSelect($("dnsFirst"), model.dns.first);
  fillSelect($("dnsSecond"), model.dns.second);
  $("allowList").value = model.allowList;
}

async function saveDns() {
  try {
    model = await send(M.MSG_SET_DNS, { first: $("dnsFirst").value, second: $("dnsSecond").value });
    render();
    status("dnsStatus", model.dns.second === "none" && $("dnsSecond").value !== "none" ? "Second check cleared — it was the same as the first." : "Saved.");
  } catch (e) { status("dnsStatus", `Not saved: ${e.message}`); }
}

document.addEventListener("DOMContentLoaded", async () => {
  model = await send(M.MSG_GET_OPTIONS);
  render();

  $("dnsFirst").addEventListener("change", saveDns);
  $("dnsSecond").addEventListener("change", saveDns);

  $("allowSave").addEventListener("click", async () => {
    try { model = await send(M.MSG_SET_ALLOW_LIST, { text: $("allowList").value }); render(); status("allowStatus", "Allow list saved."); }
    catch (e) { status("allowStatus", `Not saved: ${e.message}`); }
  });
  $("allowRevert").addEventListener("click", () => { $("allowList").value = model.allowList; });

  $("exportAll").addEventListener("click", async () => {
    const data = await send(M.MSG_EXPORT_SETTINGS);
    const url = URL.createObjectURL(new Blob([JSON.stringify(data.file, null, 2)], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url; a.download = EXPORT_FILE_NAME; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 0);        // release the blob
    status("ioStatus", `Saved: ${data.summary}`);
  });
  $("importAll").addEventListener("click", () => $("importFile").click());
  $("importFile").addEventListener("change", async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";                                  // allow choosing the same file again
    if (!file) return;
    try {
      model = await send(M.MSG_IMPORT_SETTINGS, { settings: JSON.parse(await file.text()) });
      render(); status("ioStatus", `Restored: ${model.summary}`);
    } catch (err) { status("ioStatus", `Not restored: ${err.message}`); }
  });
  $("resetAll").addEventListener("click", async () => {
    if (!confirm("Reset every 3P Matrix setting to its default?")) return;
    model = await send(M.MSG_RESET_SETTINGS); render(); status("ioStatus", "All settings reset.");
  });
});
