// ── background.js — 3P Matrix service worker (lifecycle + thin router) ───────
// No business logic here: every branch delegates to a core/ or data/ module.
//
// Lifecycle
//   install          → default state, compute safer regions, apply
//   update / reload  → load state, level = startupLevel, recompute safer regions, apply
//   browser startup  → level = startupLevel, apply
//
// Events
//   webNavigation.onBeforeNavigate (top frame) → stage 1 site check → warning dialog (protection 10)
//   webNavigation.onCommitted (top frame)      → reset badge count, per-tab icon
//   webRequest.onErrorOccurred                 → count OUR blocks per tab (rule-matcher attribution);

//   tabs.onRemoved / windows.onRemoved         → release per-tab state and matrix panels (guards)
//
// All state mutations go through mutate(): load → change → save → apply, run
// under withStateLock() so two messages can never interleave.
// ─────────────────────────────────────────────────────────────────────────────

import { LEVEL, LEVEL_INFO, LEVEL_MIN, LEVEL_MAX, LOG_PREFIX, SITE_LOCKS_CAP,
         DNS_PROVIDER, DNS_NONE, SEVERITY, MANUAL_TLDS_CAP, ALLOW_LIST_LINE_MAX,
         MATRIX_PAGE, MATRIX_WINDOW, MATRIX_SCOPE, MATRIX_ACTION, MATRIX_OVERRIDES_CAP, MATRIX_SITE_ALL } from "./data/constants.js";
import * as M from "./data/message-types.js";
import { defaultState, loadState, saveState, normalizeState, withStateLock, isValidHost } from "./data/state-storage.js";
import { PROTECTIONS, PROTECTION_GROUPS, PROTECTION_BY_KEY } from "./data/protections.js";
import { effectiveLevel, lockedLevelOf, isProtectionEnabled, protectionCounts, saferRegionsApply } from "./core/policy.js";
import { applyState, getCompiledRules, getCompiledModeRules } from "./core/apply-manager.js";
import { buildMatrixRows } from "./core/matrix-disposition.js";
import { matchOutcome } from "./core/rule-matcher.js";
import { computeSaferRegions } from "./core/safer-regions.js";
import { scoreLocal } from "./core/site-scorer.js";
import { evaluateSite, clearScoreCache } from "./core/online-checks.js";
import * as Badge from "./core/badge.js";
import * as Guard from "./core/navigation-guard.js";
import * as Matrix from "./core/connection-matrix.js";
import * as TabSites from "./core/tab-sites.js";
import { toSettingsFile, fromSettingsFile, summarize } from "./data/settings-io.js";
import { parseHttpUrl, registeredDomain } from "./util/domain.js";

const BLOCKED_BY_CLIENT = "net::ERR_BLOCKED_BY_CLIENT";

// ── Core helpers ─────────────────────────────────────────────────────────────
async function commit(state) {
  const saved = await saveState(state);
  await applyState(saved);
  Badge.setLevelIcon(saved.level);
  await refreshActiveTabIcon(saved);
  return saved;
}

function mutate(change) {
  return withStateLock(async () => {
    const state = await loadState();
    const result = await change(state);
    const saved = await commit(state);
    return { state: saved, result };
  });
}

async function refreshActiveTabIcon(state) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const p = tab && parseHttpUrl(tab.url || "");
    if (tab && p) Badge.setLevelIcon(effectiveLevel(state, p.host), tab.id);
  } catch { /* no window yet at browser start — global icon is enough */ }
}

function clampLevel(v) {
  const n = Number.parseInt(v, 10);
  return Number.isInteger(n) && n >= LEVEL_MIN && n <= LEVEL_MAX ? n : null;
}

function lockSite(state, site, level) {
  if (!Object.prototype.hasOwnProperty.call(state.siteLocks, site)) {
    if (state.siteLocksOrder.length >= SITE_LOCKS_CAP) delete state.siteLocks[state.siteLocksOrder.shift()]; // FIFO
    state.siteLocksOrder.push(site);
  }
  state.siteLocks[site] = level;
}

function unlockSite(state, site) {
  delete state.siteLocks[site];
  state.siteLocksOrder = state.siteLocksOrder.filter((s) => s !== site);
}

// ── Lifecycle ────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener((details) => {
  withStateLock(async () => {
    const state = details.reason === "install" ? defaultState() : await loadState();
    state.level = state.startupLevel;
    state.prevLevel = state.startupLevel;
    // Every reason (install, update, reload): the list depends on code (base TLDs, auto-add
    // scope, country data) — 0.2.4 moves users of the removed slider to the fixed Continent scope.
    state.safeZone.tlds = await computeSaferRegions(state.safeZone);
    await commit(state);
  }).catch((e) => console.error(LOG_PREFIX, "onInstalled:", e));
});

chrome.runtime.onStartup.addListener(() => {
  withStateLock(async () => {
    const state = await loadState();
    state.level = state.startupLevel;
    state.prevLevel = state.startupLevel;
    await commit(state);
  }).catch((e) => console.error(LOG_PREFIX, "onStartup:", e));
});

// ── Navigation / request events (registered synchronously at top level) ─────
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  loadState().then((state) => Guard.checkNavigation(details, state));
});

chrome.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId !== 0) return;
  Badge.resetCount(details.tabId);
  const p = parseHttpUrl(details.url);
  TabSites.setTopHost(details.tabId, p ? p.host : "");
  Matrix.clearOnNavigation(details.tabId, p ? p.host : "");
  if (!p) return;
  Badge.clearRiskIfOtherSite(details.tabId, registeredDomain(p.host));
  loadState().then((state) => Badge.setLevelIcon(effectiveLevel(state, p.host), details.tabId));
});

chrome.webRequest.onErrorOccurred.addListener((details) => {
  if (details.error !== BLOCKED_BY_CLIENT || details.type === "main_frame" || details.tabId < 0) return;
  // Chrome reports ERR_BLOCKED_BY_CLIENT for blocks by ANY extension — the badge counts only
  // the requests our own rules block (core/rule-matcher.js replays DNR matching; an opaque
  // "null" initiator is matched as the tab's own site, as Chrome does).
  Promise.all([getCompiledRules(), TabSites.topHostOf(details.tabId)]).then(([compiled, topHost]) => {
    if (matchOutcome(compiled, details, topHost).action === "block") Badge.noteBlocked(details.tabId);
  }).catch((e) => console.warn(LOG_PREFIX, "block attribution failed:", e));
}, { urls: ["<all_urls>"] });

// Show Matrix panel windows: observed tabId → panel windowId (bounded by open panels).
const _matrixWindows = new Map();

// Stop observing a tab and close its panel window (tab closed, or 5-minute timeout).
function closeMatrixPanel(tabId) {
  Matrix.stopMatrix(tabId);
  const win = _matrixWindows.get(tabId);
  if (win !== undefined) { _matrixWindows.delete(tabId); chrome.windows.remove(win).catch(() => {}); }
}

chrome.tabs.onRemoved.addListener((tabId) => {
  Badge.releaseTab(tabId);
  Guard.releaseTab(tabId);
  TabSites.releaseTab(tabId);
  closeMatrixPanel(tabId);
});

chrome.windows.onRemoved.addListener((windowId) => {
  for (const [tabId, win] of _matrixWindows) {
    if (win === windowId) { _matrixWindows.delete(tabId); Matrix.stopMatrix(tabId); }
  }
});

// ── View models ──────────────────────────────────────────────────────────────
function popupModel(state, tabId, url) {
  const p = parseHttpUrl(url || "");
  const host = p ? p.host : "";
  const site = p ? registeredDomain(host) : "";
  const locked = p ? lockedLevelOf(state, host) : null;
  const level = p ? effectiveLevel(state, host) : state.level;
  const zoneTld = host.split(".").pop();
  return {
    host, site, scorable: !!p,
    inSafeZone: !!p && state.safeZone.tlds.includes(zoneTld),
    level, sessionLevel: state.level, startupLevel: state.startupLevel, lockedLevel: locked,
    levelInfo: LEVEL_INFO,
    counts: protectionCounts(state, level),
    groups: PROTECTION_GROUPS.map((g) => ({
      title: !saferRegionsApply(level) && g.titleNoSaferRegions ? g.titleNoSaferRegions : g.title,
      fromLevel: g.fromLevel,
      items: PROTECTIONS.filter((x) => x.fromLevel === g.fromLevel).map((x) => ({ key: x.key, num: x.num, label: x.label, enabled: isProtectionEnabled(state, x.key) }))
    })),
    safeZone: { tlds: state.safeZone.tlds },
    blocked: Badge.getCount(tabId),
    risk: (Badge.getRisk(tabId) || {}).severity || SEVERITY.NONE
  };
}

// Show Matrix view model: observed rows (core/connection-matrix.js) + the policy's decision per
// row (core/matrix-disposition.js, replayed through the rules Chrome has). Rows with an override
// but not seen (yet) are listed too, so an override can always be cleared from the panel.
async function matrixModel(state, tabId) {
  const data = Matrix.getMatrixData(tabId);
  const overrides = mergedMatrixOverrides(state, data.site);
  const entries = data.entries.slice();
  const seen = new Set(entries.map((e) => e.domain));
  for (const domain of Object.keys(overrides)) {
    if (!seen.has(domain)) entries.push({ domain, types: [], sampleUrls: {}, count: 0 });
  }
  const level = data.host ? effectiveLevel(state, data.host) : state.level;
  const [compiled, compiledMode] = await Promise.all([getCompiledRules(), getCompiledModeRules()]);
  const rows = buildMatrixRows({ entries, overrides, level, host: data.host, compiled, compiledMode });
  return { ...data, entries: rows, level, levelInfo: LEVEL_INFO };
}

function countMatrixPairs(state) {
  return Object.values(state.matrixRules).reduce((n, m) => n + Object.keys(m).length, 0);
}

// Combine the global ("*") matrix overrides with any legacy per-site ones for display: a
// site-scoped entry wins over the global one, scope by scope (script/frame handled independently),
// matching the priority tiers rule-builder.js enforces for the real DNR rules.
function mergedMatrixOverrides(state, site) {
  const global = state.matrixRules[MATRIX_SITE_ALL] || {};
  const perSite = (site && state.matrixRules[site]) || {};
  if (!Object.keys(perSite).length) return global;
  const merged = {};
  for (const domain of new Set([...Object.keys(global), ...Object.keys(perSite)])) {
    merged[domain] = { ...(global[domain] || {}), ...(perSite[domain] || {}) };
  }
  return merged;
}

function allowListText(state) {
  return state.siteLocksOrder.filter((s) => state.siteLocks[s] === LEVEL.ALLOW_ALL).join("\n");
}

function optionsModel(state) {
  return {
    dns: state.dns,
    providers: [...Object.values(DNS_PROVIDER).map((p) => ({ id: p.id, label: p.label, host: p.host })), { id: DNS_NONE, label: "None", host: "" }],
    allowList: allowListText(state)
  };
}

// ── Message router ───────────────────────────────────────────────────────────
const HANDLERS = {
  [M.MSG_GET_POPUP_STATE]: async (msg) => popupModel(await loadState(), msg.tabId, msg.url),

  [M.MSG_SET_LEVEL]: async (msg) => {
    const level = clampLevel(msg.level);
    if (level === null) throw new Error("bad level");
    const { state } = await mutate((s) => { if (s.level !== level) { s.prevLevel = s.level; s.level = level; } });
    return popupModel(state, msg.tabId, msg.url);
  },

  [M.MSG_SET_STARTUP_LEVEL]: async (msg) => {
    const level = clampLevel(msg.level);
    if (level === null) throw new Error("bad level");
    const { state } = await mutate((s) => { s.startupLevel = level; });
    return popupModel(state, msg.tabId, msg.url);
  },

  // Lock: pin the CURRENT session level to the site, then restore the session
  // level the user had before moving the slider (3P-Matrix-lite behaviour).
  [M.MSG_TOGGLE_LOCK]: async (msg) => {
    const p = parseHttpUrl(msg.url || "");
    if (!p) throw new Error("not a lockable page");
    const site = registeredDomain(p.host);
    const { state } = await mutate((s) => {
      if (Object.prototype.hasOwnProperty.call(s.siteLocks, site)) { unlockSite(s, site); return; }
      lockSite(s, site, s.level);
      s.level = s.prevLevel;
    });
    return popupModel(state, msg.tabId, msg.url);
  },

  [M.MSG_SET_PROTECTION]: async (msg) => {
    if (!PROTECTION_BY_KEY[msg.key]) throw new Error("unknown protection");
    const { state } = await mutate((s) => {
      if (msg.enabled) delete s.disabledProtections[msg.key]; else s.disabledProtections[msg.key] = true;
    });
    return popupModel(state, msg.tabId, msg.url);
  },

  [M.MSG_SET_SAFE_ZONE]: async (msg) => {
    const { state } = await mutate(async (s) => {
      const z = s.safeZone;
      if (msg.restoreDefault) { z.manualTlds = []; z.excludedTlds = []; }   // default = base TLDs + Continent
      if (typeof msg.addTld === "string") {
        const t = msg.addTld.trim().replace(/^\.+/, "").toLowerCase();
        z.excludedTlds = z.excludedTlds.filter((x) => x !== t);
        if (t && !z.manualTlds.includes(t) && z.manualTlds.length < MANUAL_TLDS_CAP) z.manualTlds.push(t);
      }
      if (typeof msg.removeTld === "string") {
        z.manualTlds = z.manualTlds.filter((x) => x !== msg.removeTld);
        if (!z.excludedTlds.includes(msg.removeTld)) z.excludedTlds.push(msg.removeTld);
      }
      z.tlds = await computeSaferRegions(z);
    });
    return popupModel(state, msg.tabId, msg.url);
  },

  // ── Show Matrix ──
  [M.MSG_OPEN_MATRIX]: async (msg) => {
    const p = parseHttpUrl(msg.url || "");
    if (!p || !Number.isInteger(msg.tabId)) throw new Error("Show Matrix works on web pages only");
    Matrix.startMatrix(msg.tabId, p.host, closeMatrixPanel);        // timeout closes the panel too
    const existing = _matrixWindows.get(msg.tabId);
    if (existing !== undefined) {
      try { await chrome.windows.update(existing, { focused: true }); }
      catch { _matrixWindows.delete(msg.tabId); }                    // stale — window closed elsewhere
    }
    if (!_matrixWindows.has(msg.tabId)) {
      const url = chrome.runtime.getURL(MATRIX_PAGE) + "?tabId=" + msg.tabId;
      const win = await chrome.windows.create({ url, type: "popup", width: MATRIX_WINDOW.width, height: MATRIX_WINDOW.height });
      _matrixWindows.set(msg.tabId, win.id);
    }
    await chrome.tabs.reload(msg.tabId).catch(() => {});          // see every request from the start
    return true;
  },

  [M.MSG_STOP_MATRIX]: async (msg) => { Matrix.stopMatrix(msg.tabId); return true; },

  [M.MSG_GET_MATRIX_DATA]: async (msg) => matrixModel(await loadState(), msg.tabId),

  [M.MSG_SET_MATRIX_RULE]: async (msg) => {
    const activeSite = Matrix.getMatrixData(msg.tabId).site;    // guard: Show Matrix must be tracking this tab
    const domain = String(msg.domain || "").toLowerCase();
    if (!activeSite || !isValidHost(domain) || !Object.values(MATRIX_SCOPE).includes(msg.scope)) throw new Error("bad matrix rule");
    const action = Object.values(MATRIX_ACTION).includes(msg.action) ? msg.action : null;
    const site = MATRIX_SITE_ALL;    // 4.1: Show Matrix overrides are global, not scoped to activeSite
    const { state } = await mutate((s) => {
      const forSite = s.matrixRules[site] || {};
      const entry = { ...(forSite[domain] || {}) };
      const isNewPair = !forSite[domain];
      if (action === null) delete entry[msg.scope]; else entry[msg.scope] = action;
      if (isNewPair && action !== null && countMatrixPairs(s) >= MATRIX_OVERRIDES_CAP) throw new Error("matrix override limit reached");
      if (Object.keys(entry).length) forSite[domain] = entry; else delete forSite[domain];
      if (Object.keys(forSite).length) s.matrixRules[site] = forSite; else delete s.matrixRules[site];
    });
    return matrixModel(state, msg.tabId);
  },

  [M.MSG_RELOAD_TAB]: async (msg) => { await chrome.tabs.reload(msg.tabId); return true; },

  [M.MSG_EVALUATE_SITE]: async (msg, sender) => {
    const state = await loadState();
    const local = scoreLocal(msg.url);
    if (!local) return null;
    const full = await evaluateSite(local, state.dns);
    if (sender.tab) Badge.setRisk(sender.tab.id, full.site, full.severity);
    return { ...full, levelInfo: LEVEL_INFO };
  },

  [M.MSG_WARNING_ACTION]: async (msg, sender) => {
    const tabId = sender.tab ? sender.tab.id : msg.tabId;
    const p = parseHttpUrl(msg.url || "");
    if (!p || tabId === undefined) throw new Error("bad warning action");
    const site = registeredDomain(p.host);
    if (msg.action === M.WARNING_ACTION.GO_BACK) {
      try { await chrome.tabs.goBack(tabId); }
      catch { await chrome.tabs.update(tabId, { url: "chrome://newtab/" }); }   // no history: open a new-tab page
      return true;
    }
    if (msg.action === M.WARNING_ACTION.TRUST) {
      await mutate((s) => lockSite(s, site, LEVEL.ALLOW_ALL));
      Badge.setRisk(tabId, site, SEVERITY.NONE);
    } else if (msg.action === M.WARNING_ACTION.CONTINUE_ONCE) {
      Guard.allowOnce(tabId, site);
    } else {
      throw new Error("unknown warning action");
    }
    await chrome.tabs.update(tabId, { url: p.url });
    return true;
  },

  [M.MSG_GET_OPTIONS]: async () => optionsModel(await loadState()),

  [M.MSG_SET_DNS]: async (msg) => {
    const { state } = await mutate((s) => { s.dns = { first: msg.first, second: msg.second }; });
    clearScoreCache();                                      // results depend on the chosen resolvers
    return optionsModel(state);
  },

  // The allow-list text is the authoritative list of LEVEL-1 locks only;
  // sites locked at other levels are never shown or touched here.
  [M.MSG_SET_ALLOW_LIST]: async (msg) => {
    const wanted = [];
    for (const line of String(msg.text || "").split(/\r?\n/)) {
      const h = line.trim().replace(/^https?:\/\//i, "").replace(/[/:?#].*$/, "").toLowerCase();
      if (!h || h.startsWith("#") || h.length > ALLOW_LIST_LINE_MAX || !isValidHost(h)) continue;
      const site = registeredDomain(h);
      if (!wanted.includes(site)) wanted.push(site);
    }
    const { state } = await mutate((s) => {
      s.siteLocksOrder.filter((x) => s.siteLocks[x] === LEVEL.ALLOW_ALL && !wanted.includes(x)).forEach((x) => unlockSite(s, x));
      wanted.forEach((site) => lockSite(s, site, LEVEL.ALLOW_ALL));
    });
    return optionsModel(state);
  },

  [M.MSG_EXPORT_SETTINGS]: async () => {
    const state = await loadState();
    return { file: toSettingsFile(state, chrome.runtime.getManifest().version), summary: summarize(state) };
  },

  [M.MSG_IMPORT_SETTINGS]: async (msg) => {
    const incoming = fromSettingsFile(msg.settings);                 // throws on a foreign file
    const { state } = await mutate(async (s) => {
      Object.assign(s, normalizeState(incoming));
      s.safeZone.tlds = await computeSaferRegions(s.safeZone);       // recomputed for this browser's languages
    });
    clearScoreCache();
    return { ...optionsModel(state), summary: summarize(state) };
  },

  [M.MSG_RESET_SETTINGS]: async () => {
    const { state } = await mutate(async (s) => {
      Object.assign(s, defaultState());
      s.safeZone.tlds = await computeSaferRegions(s.safeZone);
    });
    clearScoreCache();
    return optionsModel(state);
  }
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handler = msg && HANDLERS[msg.type];
  if (!handler) { sendResponse({ ok: false, error: "unknown message" }); return false; }
  handler(msg, sender)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((e) => { console.warn(LOG_PREFIX, msg.type, e); sendResponse({ ok: false, error: String(e && e.message || e) }); });
  return true;                                              // async response
});
