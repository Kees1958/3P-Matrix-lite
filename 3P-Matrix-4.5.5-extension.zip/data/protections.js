// ── data/protections.js ───────────────────────────────────────────────────────
// THE protections registry — single source of truth for the selectable
// protections (21 since 4.4.3; the count is always PROTECTIONS.length). The popup list, the counts, the DNR rule builder and the
// content-script builder all read this table; none of them keeps its own list.
//
// A protection is ACTIVE for a site when:
//     effectiveLevel(site) >= fromLevel   AND   not unticked by the user
//
// Removed in 0.2.3 (user keeps them in uBlock Stripped Dynamic): "Clear history at browser
// start" (deleteHistoryOnStart) and "Block tracking pings" (blockPings). Their keys are
// dropped from saved state by normalizeState(), which keeps only keys listed here.
//
// Added in 0.2.4: "Warn when opening suspicious sites" (4.2.3: was "before"; warnSuspiciousSites, num 10) — the
// navigation-guard warning dialog, until then always on from level 2, is now a selectable
// protection. Old saved states have no entry for it, so it starts ticked (= previous behaviour).
// Level-3 protections renumbered 10–14 → 11–15 (keys unchanged).
//
// Added in 4.2: "Block 3P scripts and frames from abused TLDs" (blockAbusedTlds, num 11) — the
// HaGeZi abused-TLD block, until then an unconditional part of the level-2+ policy, is now a
// selectable protection. Old saved states have no entry for it, so it starts ticked (= previous
// behaviour). 4.2 renumbers so each group is consecutive: level-2 group 1–11 (abused TLDs = 11),
// level-3 group 11–15 → 12–16 (keys unchanged, so saved ticks carry over). `num` is display only.
// 4.2: protection 1 gains trustedExempt — the built-in whitelist's payment hosts may register a
// real payment handler on their own site, at BUILTIN_EXEMPT_LEVELS (3–4) only.
//
// Added in 4.3.0: "Warn when a downloaded file looks risky" (warnRiskyDownloads, num 12) —
// DownloadSentinel 3.2.0's download protection (core/download-guard.js). Old saved states have no
// entry for it, so it starts ticked. Same 4.2 rule, each group consecutive: level-2 group 1–12,
// level-3 group 12–16 → 13–17 (keys unchanged, so saved ticks carry over). `num` is display only.
// Its "site" is the page the download came from (DownloadItem.referrer), else the download host:
// an allow-list site (locked at level 1) gets no download warnings, like every other protection.
//
// 4.3.2 (user request): display numbers 10 ⇄ 11 swapped — the two warnings now sit together at 11 and 12
// (abused-TLD block = 10, suspicious-site warning = 11, risky-download warning = 12); keys unchanged.
// Protection 17's label shortened to fit one popup line.
// Added in 4.3.2: "Block risky downloads (programs, scripts, archives)" (blockRiskyDownloads, num 18) —
// OFF by default (defaultOff). From level 3: outside safer regions at level 3 (the page the download
// came from decides), on every site at levels 4–5. A blocked file never reaches protection 12's check;
// 4.5.5: the blocked download is held (paused) until the user chooses — "Download anyway" continues the same
// download and then protection 12 always checks it (core/download-guard.js). Saved states from before 4.3.2 get it unticked by the schema-3 migration.
//
// Added in 4.4.3 (user request): three siblings of the obfuscated-eval() detector, one per API —
// "Block obfuscated Function() code generation" (blockObfuscatedFunction, num 18), "...setTimeout()
// string execution" (blockObfuscatedSetTimeout, num 19), "...setInterval() string execution"
// (blockObfuscatedSetInterval, num 20). Same scope/level as the eval() detector (outside safer
// regions, from Medium), same shape-only detection (util/ObfuscationShape.js) — not a blanket
// string-handler block like protection 9's fixed-host-list sec-adult-noeval.js. Old saved states
// have no entry for any of the three, so they start ticked.
// User request (same change): display numbers 16 ⇄ 17 swapped so the four obfuscation-style
// protections sit together (redirects/dialogs = 16, eval() = 17, Function() = 18, setTimeout() =
// 19, setInterval() = 20), and the risky-downloads block moves to the end (18 → 21). Keys unchanged
// (contract); every "protection 16/17/18" reference in code comments, docs and test labels that
// meant the OLD number was swept to the new one in the same change (constants.js, message-types.js,
// download-guard.js, download-settings.js, ui/download-blocked.js, README.md, e2e-flows.mjs test
// labels) — a past CHANGELOG_HISTORY.md entry describing an older release keeps ITS OLD numbers,
// since that is what was true when it was written.
//
// Fields
//   key        storage key in state.disabledProtections (never rename — it is a contract)
//   num        display number (1 … PROTECTIONS.length)
//   label      popup text — a short, plain-language phrase; may wrap to two lines (0.2.4)
//   fromLevel  first level at which it applies (LEVEL.MILD or LEVEL.MEDIUM)
//   scope      SCOPE.EVERY_SITE | SCOPE.OUTSIDE_SAFER_REGIONS (the latter only differs at
//              level 3 — levels 4–5 apply it on every site, see SAFER_REGIONS_LEVELS)
//   mechanism  MECH.* — which builder implements it (several may apply)
//   scripts    content-script files (MAIN world, all frames, document_start)
//   matchHosts optional fixed host list the scripts are limited to
//   extraExcludes optional extra excludeMatches patterns
//   defaultOff optional true = unticked on install, on reset and for states that predate it (4.3.2)
//   trustedExempt optional host list exempt from this protection on a first-party visit, at
//              BUILTIN_EXEMPT_LEVELS only (scope OUTSIDE_SAFER_REGIONS protections always use the
//              whole built-in whitelist for this; this field is for EVERY_SITE protections)
// ─────────────────────────────────────────────────────────────────────────────

import { LEVEL, NOEVAL_EXTRA_EXCLUDES } from "./constants.js";
import { HIGH_RISK_HOSTNAMES } from "./network-data.js";
import { BUILTIN_PAYMENT } from "./builtin-domains.js";

export const SCOPE = Object.freeze({ EVERY_SITE: "every", OUTSIDE_SAFER_REGIONS: "outside" });
export const MECH  = Object.freeze({
  SCRIPT:  "script",    // content script(s)
  DNR:     "dnr",       // dynamic block/allow rules
  HEADER:  "header",    // dynamic modifyHeaders rules
  NAVIGATION: "navigation", // top-level navigation check (core/navigation-guard.js) — no rules/scripts
  DOWNLOAD:   "download"    // finished-download check (core/download-guard.js) — no rules/scripts
});

// Every protection key, once (4.2.3, audit finding 8). Code refers to a protection ONLY through this
// enum — a typo is then a ReferenceError-like `undefined` that tools/check-protection-keys.mjs and
// isProtectionActive()'s guard both catch, never a silently disabled protection.
// Values are storage keys in state.disabledProtections — never rename a value (contract).
export const PROTECTION_KEY = Object.freeze({
  BLOCK_PAYMENT_HANDLERS:  "blockPaymentHandlers",
  BLOCK_WEB_BUNDLES:       "blockWebBundles",
  BLOCK_DIALOG_SPAM:       "blockDialogSpam",
  BLOCK_LOCAL_NETWORK:     "blockLocalNetwork",
  BLOCK_PROTOCOL_HANDLERS: "blockProtocolHandlers",
  BLOCK_SUSPICIOUS_3P:     "blockSuspicious3p",
  BLOCK_3P_HTTP:           "block3pHttp",
  BLOCK_CLICK_FIX:         "blockClickFix",
  BLOCK_HIGH_RISK_EVAL:    "blockHighRiskEval",
  WARN_SUSPICIOUS_SITES:   "warnSuspiciousSites",
  BLOCK_ABUSED_TLDS:       "blockAbusedTlds",
  WARN_RISKY_DOWNLOADS:    "warnRiskyDownloads",
  BLOCK_SCP_PRIVACY:       "blockScpPrivacy",
  BLOCK_SCP_SECURITY:      "blockScpSecurity",
  BLOCK_SENSORS_NFC:       "blockSensorsNfc",
  BLOCK_OBFUSCATED_EVAL:   "blockObfuscatedEval",
  BLOCK_REDIRECTS_DIALOGS: "blockRedirectsDialogs",
  BLOCK_RISKY_DOWNLOADS:   "blockRiskyDownloads",
  BLOCK_OBFUSCATED_FUNCTION:    "blockObfuscatedFunction",
  BLOCK_OBFUSCATED_SETTIMEOUT:  "blockObfuscatedSetTimeout",
  BLOCK_OBFUSCATED_SETINTERVAL: "blockObfuscatedSetInterval"
});

export const PROTECTION_GROUPS = Object.freeze([
  Object.freeze({ title: "On every site",          fromLevel: LEVEL.MILD }),
  // titleNoSaferRegions: shown at levels where the safer-regions list has no effect (4–5)
  Object.freeze({ title: "Outside safer regions",  titleNoSaferRegions: "Extra — on every site", fromLevel: LEVEL.MEDIUM })
]);

export const PROTECTIONS = Object.freeze([
  { key: PROTECTION_KEY.BLOCK_PAYMENT_HANDLERS,  num: 1,  label: "Block sites from registering a fake payment handler",   fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT], scripts: ["security/sec-payment-handlers.js"], trustedExempt: BUILTIN_PAYMENT },
  { key: PROTECTION_KEY.BLOCK_WEB_BUNDLES,       num: 2,  label: "Block Web Bundles (bundled resources that hide code)",  fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.DNR] },
  { key: PROTECTION_KEY.BLOCK_DIALOG_SPAM,       num: 3,  label: "Block alert/confirm/prompt popup scams",                fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT], scripts: ["security/sec-alertbuster.js", "security/sec-dialogbuster.js"] },
  { key: PROTECTION_KEY.BLOCK_LOCAL_NETWORK,     num: 4,  label: "Block pages from reaching your local network",          fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.DNR] },
  { key: PROTECTION_KEY.BLOCK_PROTOCOL_HANDLERS, num: 5,  label: "Block sites from registering custom protocol handlers", fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT], scripts: ["security/sec-protocol-handlers.js"] },
  { key: PROTECTION_KEY.BLOCK_SUSPICIOUS_3P,     num: 6,  label: "Block 3P requests to raw IPs, odd ports or DDNS hosts", fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.DNR] },
  { key: PROTECTION_KEY.BLOCK_3P_HTTP,           num: 7,  label: "Block 3P requests sent over plain, unencrypted HTTP",   fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.DNR] },
  { key: PROTECTION_KEY.BLOCK_CLICK_FIX,         num: 8,  label: "Block ClickFix-style clipboard hijacking scams",        fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT], scripts: ["security/sec-clickfix-clipboard.js"] },
  { key: PROTECTION_KEY.BLOCK_HIGH_RISK_EVAL,     num: 9,  label: "Block eval() on known high-risk (adult) sites",         fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.SCRIPT, MECH.HEADER], scripts: ["security/sec-adult-noeval.js"], matchHosts: HIGH_RISK_HOSTNAMES },
  { key: PROTECTION_KEY.BLOCK_ABUSED_TLDS, num: 10, label: "Block 3P scripts and frames from abused TLDs", fromLevel: LEVEL.MILD, scope: SCOPE.EVERY_SITE, mechanism: [MECH.DNR] },
  { key: PROTECTION_KEY.WARN_SUSPICIOUS_SITES, num: 11, label: "Warn when opening a site that looks suspicious", fromLevel: LEVEL.MILD, scope: SCOPE.EVERY_SITE, mechanism: [MECH.NAVIGATION] },
  { key: PROTECTION_KEY.WARN_RISKY_DOWNLOADS,    num: 12, label: "Warn when a downloaded file looks risky",               fromLevel: LEVEL.MILD,   scope: SCOPE.EVERY_SITE,        mechanism: [MECH.DOWNLOAD] },
  { key: PROTECTION_KEY.BLOCK_SCP_PRIVACY,       num: 13, label: "Block camera, mic, screen-share and clipboard reads",   fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.HEADER] },
  { key: PROTECTION_KEY.BLOCK_SCP_SECURITY,      num: 14, label: "Block Bluetooth, Serial, HID and USB device access",    fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.HEADER] },
  { key: PROTECTION_KEY.BLOCK_SENSORS_NFC,       num: 15, label: "Block motion-sensor and NFC access",                    fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.HEADER, MECH.SCRIPT], scripts: ["security/sec-nfc.js"] },
  { key: PROTECTION_KEY.BLOCK_REDIRECTS_DIALOGS, num: 16, label: "Block redirects and dialogs from frames",              fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.HEADER] },
  { key: PROTECTION_KEY.BLOCK_OBFUSCATED_EVAL,   num: 17, label: "Block obfuscated or disguised eval() calls",            fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.SCRIPT], scripts: ["security/sec-noeval.js"], extraExcludes: NOEVAL_EXTRA_EXCLUDES },
  { key: PROTECTION_KEY.BLOCK_OBFUSCATED_FUNCTION,    num: 18, label: "Block obfuscated Function() code generation",        fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.SCRIPT], scripts: ["security/sec-nofunction.js"], extraExcludes: NOEVAL_EXTRA_EXCLUDES },   // 4.4.3
  { key: PROTECTION_KEY.BLOCK_OBFUSCATED_SETTIMEOUT,  num: 19, label: "Block obfuscated setTimeout() string execution",     fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.SCRIPT], scripts: ["security/sec-nosettimeout.js"], extraExcludes: NOEVAL_EXTRA_EXCLUDES },
  { key: PROTECTION_KEY.BLOCK_OBFUSCATED_SETINTERVAL, num: 20, label: "Block obfuscated setInterval() string execution",    fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.SCRIPT], scripts: ["security/sec-nosetinterval.js"], extraExcludes: NOEVAL_EXTRA_EXCLUDES },
  { key: PROTECTION_KEY.BLOCK_RISKY_DOWNLOADS,   num: 21, label: "Block risky downloads (programs, scripts, archives)",   fromLevel: LEVEL.MEDIUM, scope: SCOPE.OUTSIDE_SAFER_REGIONS, mechanism: [MECH.DOWNLOAD], defaultOff: true }
].map((p) => Object.freeze(p)));

export const PROTECTION_KEYS = Object.freeze(PROTECTIONS.map((p) => p.key));
// Protections that start unticked (install, reset, and states that predate them — STATE_MIGRATIONS).
export const DEFAULT_OFF_KEYS = Object.freeze(PROTECTIONS.filter((p) => p.defaultOff).map((p) => p.key));
export const PROTECTION_BY_KEY = Object.freeze(Object.fromEntries(PROTECTIONS.map((p) => [p.key, p])));
