// ── background.js — 3P-Matrix-lite service worker (workflow orchestrator) ─────
//
// This file is a thin router and lifecycle manager only.
// All business logic lives in the tier modules loaded via importScripts() below.
//
// ── Module load order (bottom tier first) ────────────────────────────────────
//   Tier 5 data/   : constants.js, state-storage.js
//   Tier 4 util/   : tld-utils.js
//   Tier 3 core/   : rule-builder.js, site-rules.js, block-monitor.js
//   Tier 2 this file (background.js) — orchestration only
//   Tier 1 ui/     : popup.html / popup.js — never imported into SW
//
// ── State overview ────────────────────────────────────────────────────────────
//   Persisted (chrome.storage.local, key = STORAGE_KEY):
//     Full state object — see DEFAULT_STATE in data/state-storage.js
//   In-memory only (lost on SW restart, safe to lose):
//     activeSession, monitorEntries — block monitor session (block-monitor.js)
//
// ── Message types handled ─────────────────────────────────────────────────────
//   GET_STATE        — returns current state + rule count
//   SET_STATE        — validates + saves new state, applies rules
//   ADD_SITE_RULE    — pins a per-site level override
//   REMOVE_SITE_RULE — removes a per-site level override
//   SET_ICON         — updates the toolbar icon
//   START_MONITOR    — start block monitor session
//   STOP_MONITOR     — stop block monitor session
//   PAUSE_MONITOR    — pause block monitor listener
//   RESUME_MONITOR   — resume block monitor listener + reload
//   GET_MONITOR_DATA — fetch current FIFO entries + session metadata
//   ALLOW_MONITOR_DOMAIN — add observed domain to whitelist
// ─────────────────────────────────────────────────────────────────────────────

// ── Load modules (bottom tier first) ─────────────────────────────────────────
importScripts(
  "data/message-types.js",    // Tier 5: MSG_* message type constants
  "data/constants.js",      // Tier 5: RP_3P, JS_LIB_DOMAINS, BUILTIN_DOMAINS, blocked TLD lists
  "data/state-storage.js",  // Tier 5: DEFAULT_STATE, STORAGE_KEY, SITE_RULES_CAP, loadState(), saveState()
  "util/tld-utils.js",      // Tier 4: EU_LANGS, browserCountryTlds(), majorMinor()
  "core/rule-builder.js",   // Tier 3: buildRules(), rulesForLevel() and helpers
  "core/site-rules.js",     // Tier 3: addSiteRule(), removeSiteRule()
  "core/block-monitor.js"   // Tier 3: startMonitor, stopMonitor, pauseMonitor, resumeMonitor, allowMonitorDomain, startWatchdog
);

// ── Chrome API wrappers ───────────────────────────────────────────────────────
// These belong conceptually in a data/chrome-services.js but are small enough
// to live here until the extension grows to need that split.

// Updates the toolbar icon to reflect the current level (0-indexed icon filename).
function setIcon(level) {
  var idx = level - 1;
  try {
    chrome.action.setIcon({ path: {
      "16":  "icon_" + idx + "_16.png",
      "32":  "icon_" + idx + "_32.png",
      "48":  "icon_" + idx + "_48.png",
      "128": "icon_" + idx + "_128.png"
    }});
  } catch(e) {}
}

// Enables Chrome's built-in per-tab blocked request badge count.
// Always enabled — the badge always shows regardless of any toggle.
function enableBadgeCount() {
  if (!chrome.declarativeNetRequest ||
      typeof chrome.declarativeNetRequest.setExtensionActionOptions !== "function") return;
  var result = chrome.declarativeNetRequest.setExtensionActionOptions({
    displayActionCountAsBadgeText: true
  });
  if (result && typeof result.catch === "function") {
    result.catch(function(e) {
      console.warn("[3PM] setExtensionActionOptions:", e && e.message);
    });
  }
}

// ── applyState ────────────────────────────────────────────────────────────────
// Reads existing dynamic rules, replaces them all atomically with the new rule
// set built from state, then updates the icon.
// This is the single point where state changes are applied to Chrome DNR.
function applyState(s, cb) {
  chrome.declarativeNetRequest.getDynamicRules(function(existing) {
    var removeIds = existing.map(function(r) { return r.id; });
    var addRules  = buildRules(s);
    chrome.declarativeNetRequest.updateDynamicRules(
      { removeRuleIds: removeIds, addRules: addRules },
      function() {
        if (chrome.runtime.lastError) {
          console.warn("[3PM] updateDynamicRules:", chrome.runtime.lastError.message);
          if (cb) cb(0);
          return;
        }
        setIcon(s.level);
        if (cb) cb(addRules.length);
      }
    );
  });
}

// ── Boot helper ───────────────────────────────────────────────────────────────
// Shared boot sequence used by both onInstalled (update) and onStartup.
function bootFromStorage() {
  loadState(function(s) {
    var boot = Object.assign({}, s, { level: s.startupLevel || 1 });
    chrome.action.setBadgeBackgroundColor({ color: "#666666" });
    enableBadgeCount();
    saveState(boot, function() { applyState(boot); });
  });
}

// ── Block monitor — navigation hook ──────────────────────────────────────────
// Fires when the monitored tab commits to a new page. Marks the session start
// time so the 5-minute timer begins from actual page load, not from button press.
if (chrome.webNavigation && chrome.webNavigation.onCommitted) {
  chrome.webNavigation.onCommitted.addListener(function(details) {
    if (details.frameId !== 0) return; // top-level frame only
    markMonitorStarted(details.tabId);
  });
}

// ── Lifecycle ─────────────────────────────────────────────────────────────────
// ── Boot watchdog ─────────────────────────────────────────────────────────────
startWatchdog();

chrome.runtime.onInstalled.addListener(function(details) {
  var currentVersion    = chrome.runtime.getManifest().version;
  var currentMajorMinor = majorMinor(currentVersion);

  if (details.reason === "install") {
    // Fresh install — detect browser country TLDs and seed built-in domains
    browserCountryTlds(function(countryTlds) {
      var merged = DEFAULT_STATE.tlds.slice();
      countryTlds.forEach(function(tld) {
        if (merged.indexOf(tld) === -1) merged.push(tld);
      });
      var initState = Object.assign({}, DEFAULT_STATE, {
        tlds:              merged,
        builtinDomains:    BUILTIN_DOMAINS.slice(),
        whitelistDropdown: { tld: true, domain: true },
        lastShownVersion:  currentMajorMinor
      });
      chrome.action.setBadgeBackgroundColor({ color: "#666666" });
      enableBadgeCount();
      saveState(initState, function() { applyState(initState); });
    });
  } else {
    // Update / reload — reset to startupLevel, re-expand dropdowns on new major.minor
    chrome.storage.session.clear(function() {
      loadState(function(s) {
        var storedMajorMinor = majorMinor(s.lastShownVersion || "");
        var isNewMajorMinor  = storedMajorMinor !== currentMajorMinor;
        var boot = Object.assign({}, s, { level: s.startupLevel || 1 });
        if (isNewMajorMinor) {
          boot.whitelistDropdown = { tld: true, domain: true };
          boot.lastShownVersion  = currentMajorMinor;
        }
        chrome.action.setBadgeBackgroundColor({ color: "#666666" });
        enableBadgeCount();
        saveState(boot, function() { applyState(boot); });
      });
    });
  }
});

chrome.runtime.onStartup.addListener(bootFromStorage);

// ── Message router ────────────────────────────────────────────────────────────
// Thin router only — no business logic here. Each branch delegates immediately
// to a core or data function.
chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {

  if (msg.type === MSG_GET_STATE) {
    loadState(function(s) {
      chrome.declarativeNetRequest.getDynamicRules(function(rules) {
        sendResponse({ ok: true, state: s, ruleCount: rules.length });
      });
    });
    return true;
  }

  if (msg.type === MSG_SET_STATE) {
    var ns = Object.assign({}, DEFAULT_STATE, msg.state);
    if (ns.level < 1 || ns.level > 5)               ns.level        = 1;
    if (ns.startupLevel < 1 || ns.startupLevel > 5) ns.startupLevel = 1;
    if (!ns.siteRules)    ns.siteRules    = {};
    if (!ns.siteRulesOrder) ns.siteRulesOrder = Object.keys(ns.siteRules);
    saveState(ns, function() {
      applyState(ns, function(count) {
        sendResponse({ ok: true, ruleCount: count });
      });
    });
    return true;
  }

  if (msg.type === MSG_ADD_SITE_RULE) {
    loadState(function(s) {
      addSiteRule(s, msg.host, msg.level);
      saveState(s, function() {
        applyState(s, function(count) {
          sendResponse({ ok: true, ruleCount: count });
        });
      });
    });
    return true;
  }

  if (msg.type === MSG_REMOVE_SITE_RULE) {
    loadState(function(s) {
      removeSiteRule(s, msg.host);
      saveState(s, function() {
        applyState(s, function(count) {
          sendResponse({ ok: true, ruleCount: count });
        });
      });
    });
    return true;
  }

  if (msg.type === MSG_SET_ICON) {
    setIcon(msg.level);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === MSG_START_MONITOR) {
    // Check effective level: siteRules[host] if pinned, else state.level
    loadState(function(s) {
      var effectiveLevel = (msg.host && s.siteRules && s.siteRules[msg.host])
        ? s.siteRules[msg.host]
        : s.level;
      if (effectiveLevel < 2) {
        sendResponse({ ok: false, error: "Monitor only available at level 2 or higher" });
        return;
      }
      startMonitor(msg.tabId, msg.host, s, function(result) {
        sendResponse(result);
      });
    });
    return true;
  }

  if (msg.type === MSG_STOP_MONITOR) {
    stopMonitor(msg.reason || "stopped");
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === MSG_PAUSE_MONITOR) {
    pauseMonitor();
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === MSG_RESUME_MONITOR) {
    // Apply allowed domains first, then resume
    if (msg.state) {
      var ns = Object.assign({}, DEFAULT_STATE, msg.state);
      saveState(ns, function() {
        applyState(ns, function() {
          resumeMonitor(msg.tabId, ns, function(result) {
            sendResponse(result);
          });
        });
      });
    } else {
      loadState(function(s) {
        resumeMonitor(msg.tabId, s, function(result) {
          sendResponse(result);
        });
      });
    }
    return true;
  }

  if (msg.type === MSG_GET_MONITOR_DATA) {
    sendResponse({ ok: true, data: getMonitorData() });
    return true;
  }

  if (msg.type === MSG_ALLOW_MONITOR_DOMAIN) {
    loadState(function(s) {
      allowMonitorDomain(msg.domain, s, applyState, function(result) {
        sendResponse(result);
      });
    });
    return true;
  }

  sendResponse({ ok: false, error: "Unknown message type: " + msg.type });
});
