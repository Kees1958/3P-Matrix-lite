# 3P-Matrix-lite — Changelog

---

## 1.6.2 — 2025
**Bug fixes**
- Added `tabs` permission to manifest — without it, `chrome.tabs.query` silently returned nothing in the Chrome Web Store version, breaking popup initialisation entirely (slider, lock button, logger all non-functional). Developer mode was permissive and hid the bug.
- Removed `tabs` permission again in favour of routing all `tab.url` reads through the background service worker, which can read tab URLs via `<all_urls>` host_permissions without needing the explicit `tabs` permission. This avoids a prior store rejection where a reviewer found the `tabs` permission unnecessary.
- Fixed stale logs from a previous session appearing in a new logger session. When a prior session was still marked active in storage, clicking SHOW LOGS re-opened the logger without clearing old entries. Now every click always resets `logs`, `logHost` and `logStartTime` before opening the logger tab.
- Fixed `RULE_NAMES` TLD-block index: previously used `GENERIC_BLOCKED_TLDS.concat(WORLD_BLOCKED_TLDS)` to map rule IDs 3200+, but since WORLD already contains all GENERIC entries the concat double-counted them, misassigning rule names from ID 3236 onward. Now uses `WORLD_BLOCKED_TLDS` only (the superset).
- Fixed potential stale-log persistence across SW restarts: `logging: false` and `logs: []` are now written atomically in a single `chrome.storage.local.set()` call instead of two separate calls with a 3-second delay between them. A SW eviction between the two writes could previously leave stale logs in storage.

**Architecture**
- Added `GET_ACTIVE_TAB_INFO` and `RELOAD_ACTIVE_TAB` message handlers to background.js so popup.js and logger.js never call `chrome.tabs.query` directly.

---

## 1.6.1 — 2025
**Features**
- Logger now filters to only show traffic from the 1P domain that was active when SHOW LOGS was clicked. Previously all tabs' traffic was captured indiscriminately.
- Logger header now shows the logged domain name (passed as a URL parameter from the popup, avoiding storage/timing races).
- Removed the "Show blocked domains panel" checkbox (leftover from v2.0 blocked-panel experiment).

**Known limitation**
- `tabs` permission was missing from manifest, breaking the store version entirely (see 1.6.2).

---

## 1.6.0 — 2025
**Features**
- Level 3 (Easy medium mode) now allows both 3P scripts **and** 3P frames from whitelisted TLDs, not just scripts. Bullet text updated to reflect this.
- Removed the explanatory "(covers 95% of traffic...)" info line from the L3 Active Policy panel.

---

## 1.5.0 — 2025
**Features**
- Logger: added **Allow** column at levels 4 and 5. Blocked 3P-script rows get an Allow button that whitelists the script's own domain (extracted from the request URL, not the 1P calling domain) and immediately reloads the source tab.
- Logger: Allow column appears between the Action and Reason columns.
- Logger: domain header pill shows which 1P domain is being logged.

**Bug fixes**
- Allow button previously added the 1P calling domain instead of the 3P script domain. Fixed by extracting hostname from `e.url` rather than using `e.domain`.

---

## 1.4.0 — 2025
**Features**
- Request logger with 5-minute session countdown.
- Logger captures all allowed and blocked third-party traffic matching the extension's rules via `onRuleMatchedDebug`.
- Visibility-only catch-all allow rule (ID 3500) added so XHR/image/font/etc traffic is visible in the logger even though it is never blocked.
- SHOW LOGS button with active/pulsing state.

**Architecture**
- `declarativeNetRequestFeedback` permission added to support `onRuleMatchedDebug`.
- `LOG_TIMEOUT_MS` = 5 minutes, `MAX_LOGS` = 500 (FIFO eviction).
- SW restart recovery: reconstructs remaining log timeout from stored `logStartTime`.

---

## 1.3.x and earlier
- Core DNR rule engine with 5 levels.
- TLD whitelist (L3), domain whitelist (L4/L5), CDN allow (L4), built-in payment/video/CAPTCHA whitelist (L2–L4).
- Per-site lock rules with FIFO cap of 100 entries.
- Toolbar badge showing per-tab blocked request count via `displayActionCountAsBadgeText`.
- Auto TLD detection from browser language settings (BROWSER / CONTINENT / WORLDWIDE modes).
- TLD blacklist for L2 (NONE / USER / GENERIC / WORLD modes).
