// ── util/tld-utils.js ─────────────────────────────────────────────────────────
// Pure utility functions for TLD detection and version string parsing.
// No side effects, no state, no Chrome API calls (except chrome.i18n which
// is a pure query with no side effects).
//
// Public interface:
//   browserCountryTlds(cb)  — detects country TLDs from browser language settings
//   majorMinor(version)     — extracts "major.minor" from a version string
//
// Dependencies: none
// ─────────────────────────────────────────────────────────────────────────────

// EU official languages — used to detect whether to add "eu" to the TLD list.
// Source: EU official language list (23 languages).
var EU_LANGS = {
  "bg": true, "hr": true, "cs": true, "da": true, "nl": true, "et": true,
  "fi": true, "fr": true, "de": true, "el": true, "hu": true, "ga": true,
  "it": true, "lv": true, "lt": true, "mt": true, "pl": true, "pt": true,
  "ro": true, "sk": true, "sl": true, "es": true, "sv": true
};

// Reads the browser's accepted languages and extracts country-code TLDs.
// Also adds "eu" if any EU language is detected.
// Calls cb(tlds) with an array of TLD strings, e.g. ["nl", "be", "eu"].
function browserCountryTlds(cb) {
  chrome.i18n.getAcceptLanguages(function(langs) {
    var seen = {}, tlds = [], hasEuLang = false;
    (langs || []).forEach(function(lang) {
      var parts  = lang.toLowerCase().split("-");
      var region = parts.length > 1 ? parts[parts.length - 1] : parts[0];
      if (EU_LANGS[parts[0]]) hasEuLang = true;
      if (/^[a-z]{2,3}$/.test(region) && !seen[region]) {
        seen[region] = true;
        tlds.push(region);
      }
    });
    if (hasEuLang && tlds.indexOf("eu") === -1) tlds.push("eu");
    cb(tlds);
  });
}

// Extracts "major.minor" from a semver-style version string.
// e.g. "1.6.8" -> "1.6",  "2.0" -> "2.0",  "" -> "0.0"
function majorMinor(version) {
  var parts = (version || "").split(".");
  return (parts[0] || "0") + "." + (parts[1] || "0");
}
