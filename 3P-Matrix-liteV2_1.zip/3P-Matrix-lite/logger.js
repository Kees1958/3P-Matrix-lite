// ── Constants ─────────────────────────────────────────────────────────────────
var LOG_DURATION_MS = 5 * 60 * 1000;   // must match background.js LOG_TIMEOUT_MS

// ── URL params (passed by background.js when opening the popup window) ────────
var params    = new URLSearchParams(window.location.search);
var logHost   = params.get('host')  || '';
var startTime = parseInt(params.get('start') || '0', 10) || Date.now();
var initLevel = parseInt(params.get('level') || '1', 10);

// ── DOM refs ──────────────────────────────────────────────────────────────────
var timerBadge   = document.getElementById('timerBadge');
var stopBtn      = document.getElementById('stopBtn');
var logBody      = document.getElementById('logBody');
var sessionEnded = document.getElementById('sessionEnded');
var tableWrap    = document.getElementById('tableWrap');
var footerBar    = document.getElementById('footerBar');

var statTotal      = document.getElementById('statTotal');
var statScripts    = document.getElementById('statScripts');
var statFrames     = document.getElementById('statFrames');
var statIp         = document.getElementById('statIp');
var statHttp       = document.getElementById('statHttp');
var statPort       = document.getElementById('statPort');
var statStylesheet = document.getElementById('statStylesheet');

// ── In-memory log (no storage) ────────────────────────────────────────────────
var logs     = [];   // all entries this session; lost when window closes — intentional
var ended    = false;
var currentLevel = initLevel;
var sourceTabId  = null;  // fetched from background via GET_SOURCE_TAB_ID

// ── Helpers ───────────────────────────────────────────────────────────────────
function pad(n) { return n < 10 ? '0' + n : String(n); }

function setLoggedDomain(host) {
  var el = document.getElementById('loggedDomain');
  if (!el) return;
  el.textContent = host;
  el.style.display = host ? '' : 'none';
}

function formatTime(ms) {
  var s = Math.max(0, Math.ceil(ms / 1000));
  return Math.floor(s / 60) + ':' + pad(s % 60);
}

function formatTimestamp(ts) {
  var d = new Date(ts);
  return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function reasonClass(reason) {
  if (reason.indexOf('3P-script') === 0)     return 'script';
  if (reason.indexOf('3P-frame') === 0)      return 'frame';
  if (reason.indexOf('3P-XHR') === 0)        return 'xhr';
  if (reason.indexOf('3P-media') === 0)      return 'media';
  if (reason.indexOf('3P-image') === 0)      return 'image';
  if (reason.indexOf('3P-stylesheet') === 0) return 'stylesheet';
  if (reason.indexOf('3P-font') === 0)       return 'other';
  if (reason.indexOf('3P-ping') === 0)       return 'other';
  if (reason.indexOf('3P-ws') === 0)         return 'xhr';
  if (reason.indexOf('3P-object') === 0)     return 'other';
  if (reason.indexOf('3P-other') === 0)      return 'other';
  if (reason.indexOf('IP block') === 0)      return 'ip';
  if (reason.indexOf('HTTP block') === 0)    return 'http';
  if (reason.indexOf('port:') === 0)         return 'port';
  return 'other';
}

// ── Classify (moved from background.js) ──────────────────────────────────────
var RULE_NAMES = {
  1001: 'HTTP', 1002: 'WS', 1003: 'port', 1004: 'port',
  1005: 'IP', 3001: 'frame', 3002: 'script'
};

var JS_LIB_DOMAIN_COUNT = 7; // must match JS_LIB_DOMAINS.length in background.js
for (var i = 0; i < JS_LIB_DOMAIN_COUNT; i++) { RULE_NAMES[3100 + i] = 'js-lib'; }

// TLD blacklist entries use WORLD_BLOCKED_TLDS (36 entries)
var WORLD_BLOCKED_TLD_COUNT = 36;
for (var j = 0; j < WORLD_BLOCKED_TLD_COUNT; j++) { RULE_NAMES[3200 + j] = 'tld-block'; }

function sanitizeUrl(rawUrl) {
  try {
    var u = new URL(rawUrl);
    // Strip query string and hash
    u.search = ''; u.hash = '';
    // Also strip semicolon-separated path parameters used by ad trackers
    // e.g. /activity1;src=123;type=red;cat=dpg -> /activity1
    u.pathname = u.pathname.split(';')[0];
    return u.toString();
  } catch(e) { return rawUrl; }
}

function classify(rawUrl, reqType, ruleId) {
  var url;
  try { url = new URL(rawUrl); } catch(e) { return '3P-other'; }
  if (ruleId === 1001) return 'HTTP block';
  if (ruleId === 1002) return 'WS block';
  if (ruleId === 1003 || ruleId === 1004) return 'port:' + (url.port || '?');
  if (ruleId === 1005) return 'IP block';
  var typeLabel = {
    'script': '3P-script', 'sub_frame': '3P-frame', 'image': '3P-image',
    'xmlhttprequest': '3P-XHR', 'media': '3P-media', 'websocket': '3P-ws',
    'stylesheet': '3P-stylesheet', 'font': '3P-font', 'ping': '3P-ping',
    'main_frame': 'main-frame', 'object': '3P-object', 'other': '3P-other'
  }[reqType] || ('3P-' + reqType);
  var ruleName = RULE_NAMES[ruleId] || 'r' + ruleId;
  return typeLabel + ' [' + ruleName + ']';
}

// ── Stats ─────────────────────────────────────────────────────────────────────
function updateStats() {
  var counts = { script: 0, frame: 0, xhr: 0, media: 0, image: 0,
    stylesheet: 0, ip: 0, http: 0, port: 0, other: 0 };
  logs.forEach(function(e) {
    var rc = reasonClass(e.reason);
    if (counts[rc] !== undefined) counts[rc]++; else counts.other++;
  });
  statTotal.textContent      = logs.length;
  statScripts.textContent    = counts.script;
  statFrames.textContent     = counts.frame;
  document.getElementById('statXhr').textContent   = counts.xhr;
  document.getElementById('statMedia').textContent = counts.media;
  statStylesheet.textContent = counts.stylesheet;
  statIp.textContent         = counts.ip;
  statHttp.textContent       = counts.http;
  statPort.textContent       = counts.port;
}

// ── Append a single row (called per incoming LOG_ENTRY message) ───────────────
function appendRow(entry) {
  // Remove empty-state row if present
  var emptyRow = logBody.querySelector('.empty-row');
  if (emptyRow) emptyRow.remove();

  var rc = reasonClass(entry.reason);
  var showAllow = (currentLevel === 4 || currentLevel === 5);

  var tr = document.createElement('tr');

  var tdDomain = document.createElement('td');
  tdDomain.className = 'domain';
  tdDomain.textContent = entry.domain || '\u2014';
  tr.appendChild(tdDomain);

  // Allow column — only for 3P-scripts at L4/L5
  var tdAllow = document.createElement('td');
  tdAllow.className = 'allow-col';
  tdAllow.style.display = showAllow ? '' : 'none';
  var scriptHost = null;
  if (showAllow && rc === 'script' && entry.url) {
    try { scriptHost = new URL(entry.url).hostname || null; } catch(x) {}
  }
  if (scriptHost) {
    (function(host) {
      var btn = document.createElement('button');
      btn.className = 'allow-btn';
      btn.textContent = 'Allow';
      btn.title = 'Add ' + host + ' to domain whitelist and reload page';
      btn.dataset.domain = host;
      btn.addEventListener('click', function() {
        if (btn.classList.contains('done')) return;
        btn.textContent = '\u2026';
        btn.disabled = true;
        allowDomain(host, function(ok) {
          if (ok) {
            document.querySelectorAll('.allow-btn[data-domain="' + host + '"]')
              .forEach(function(b) { b.textContent = 'Added'; b.classList.add('done'); b.disabled = true; });
          } else {
            btn.textContent = 'Error';
            btn.disabled = false;
          }
        });
      });
      tdAllow.appendChild(btn);
    }(scriptHost));
  }
  tr.appendChild(tdAllow);

  var tdReason = document.createElement('td');
  tdReason.className = 'reason';
  var badge = document.createElement('span');
  badge.className = 'reason-badge ' + rc;
  badge.textContent = entry.reason;
  tdReason.appendChild(badge);
  tr.appendChild(tdReason);

  var tdUrl = document.createElement('td');
  tdUrl.className = 'url';
  tdUrl.textContent = entry.url;
  tr.appendChild(tdUrl);

  var tdTime = document.createElement('td');
  tdTime.className = 'time';
  tdTime.textContent = formatTimestamp(entry.time);
  tr.appendChild(tdTime);

  // Prepend — newest first
  logBody.insertBefore(tr, logBody.firstChild);
  updateStats();
}

// ── Allow domain ──────────────────────────────────────────────────────────────
function allowDomain(domain, cb) {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, function(resp) {
    if (chrome.runtime.lastError || !resp || !resp.ok) { cb(false); return; }
    var s = resp.state;
    var apex = domain.replace(/^www\./, '');
    if (s.domains.indexOf(apex) === -1) s.domains = s.domains.concat([apex]);
    chrome.runtime.sendMessage({ type: 'SET_STATE', state: s }, function(resp2) {
      if (chrome.runtime.lastError || !resp2 || !resp2.ok) { cb(false); return; }
      cb(true);
      // Reload source tab so whitelist takes effect immediately
      if (sourceTabId !== null) {
        chrome.tabs.reload(sourceTabId, {}, function() {
          if (chrome.runtime.lastError) {}
        });
      }
    });
  });
}

// ── Countdown ─────────────────────────────────────────────────────────────────
var countdownInt = null;

function startCountdown() {
  if (countdownInt) clearInterval(countdownInt);
  countdownInt = setInterval(function() {
    var remaining = LOG_DURATION_MS - (Date.now() - startTime);
    if (remaining <= 0) {
      clearInterval(countdownInt); countdownInt = null;
      timerBadge.textContent = '0:00';
      timerBadge.className   = 'timer-badge done';
      endSession();
      return;
    }
    timerBadge.textContent = formatTime(remaining);
    timerBadge.className   = remaining < 60000 ? 'timer-badge ending' : 'timer-badge';
  }, 500);
  // Set initial display immediately
  timerBadge.textContent = formatTime(LOG_DURATION_MS - (Date.now() - startTime));
}

// ── End session ───────────────────────────────────────────────────────────────
function endSession() {
  if (ended) return;
  ended = true;
  if (countdownInt) { clearInterval(countdownInt); countdownInt = null; }
  tableWrap.style.display = 'none';
  sessionEnded.classList.add('visible');
  footerBar.textContent = 'Session ended — window closing in 3 seconds';
  footerBar.classList.remove('warning');
  timerBadge.className = 'timer-badge done';
  setTimeout(function() { window.close(); }, 3000);
}

// ── Message listener — receives LOG_ENTRY pushes from background ──────────────
chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === 'LOG_ENTRY') {
    var reason = classify(msg.url, msg.reqType, msg.ruleId);
    appendRow({
      domain: msg.domain,
      reason: reason,
      url:    sanitizeUrl(msg.url),
      time:   msg.time
    });
  }
  if (msg.type === 'LOGGING_TIMEOUT') {
    endSession();
  }
});

// ── Stop button ───────────────────────────────────────────────────────────────
stopBtn.addEventListener('click', function() { endSession(); });

// ── Boot ──────────────────────────────────────────────────────────────────────
if (logHost) setLoggedDomain(logHost);

// Get source tab id from background for the Allow reload
chrome.runtime.sendMessage({ type: 'GET_SOURCE_TAB_ID' }, function(resp) {
  if (resp && resp.tabId) sourceTabId = resp.tabId;
});

// Set Allow column header visibility
var allowHeader = document.getElementById('allowColHeader');
if (allowHeader) allowHeader.style.display = (currentLevel === 4 || currentLevel === 5) ? '' : 'none';

footerBar.textContent = 'Logging active \u2014 blocked third-party requests are shown here';
startCountdown();
