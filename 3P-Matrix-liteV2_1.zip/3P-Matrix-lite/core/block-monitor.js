// ── core/block-monitor.js ─────────────────────────────────────────────────────
// Live third-party block monitor.
// Owns the webRequest listener, FIFO entry array, session object,
// timers, all stop conditions, and the watchdog.
//
// Public interface:
//   startMonitor(tabId, host, cb)     — start a new session (kills any existing one first)
//   stopMonitor(reason)               — full cleanup, notifies panel
//   pauseMonitor()                    — removeListener, freeze array, accumulate elapsed
//   resumeMonitor(tabId, cb)          — re-register listener, reload tab
//   getMonitorData()                  — returns { session, entries } snapshot
//   allowMonitorDomain(domain, state, cb) — add domain to state whitelist, save + apply
//   startWatchdog()                   — call once on SW boot; kills orphan sessions
//
// Dependencies (must be loaded before this file):
//   data/message-types.js — MSG_MONITOR_CLOSED
//   data/state-storage.js — saveState()
//   core/rule-builder.js  — buildRules() (via applyState in background.js)
//
// State owned by this module (all in-memory, lost on SW restart — safe because
// the webRequest listener is also lost on SW restart, so no orphan is possible):
//   activeSession  {object|null}  — see SESSION shape below
//   monitorEntries {Array}        — FIFO array, max MONITOR_CAP entries
//   _sessionTimer  {TimeoutID}    — 5-minute force-close timer
//   _watchdogTimer {IntervalID}   — orphan-session watchdog
//
// SESSION shape:
//   { tabId, host, startTime, paused, timeElapsed, state }
//   tabId       — tab that owns the session
//   host        — 1P hostname (fixed for the life of the session)
//   startTime   — Date.now() when onCommitted fired (set externally via markMonitorStarted)
//   paused      — boolean
//   timeElapsed — ms of active listening accumulated before pauses
//   state       — snapshot of extension state at session start (for classification)
// ─────────────────────────────────────────────────────────────────────────────

var MONITOR_CAP      = 100;          // max FIFO entries
var MONITOR_DURATION = 5 * 60 * 1000; // 5 minutes in ms
var WATCHDOG_INTERVAL = 5 * 60 * 1000; // watchdog checks every 5 minutes

var activeSession   = null;
var monitorEntries  = [];
var _seenDomains    = new Set(); // tracks domains already recorded this session
var _sessionTimer  = null;
var _watchdogTimer = null;

// ── Internal helpers ──────────────────────────────────────────────────────────

// Formats elapsed ms as "+m:ss.hh" (minutes:seconds.hundredths)
function _formatElapsed(ms) {
  var total = Math.floor(ms / 10);   // 10ms units
  var hh    = total % 100;
  var s     = Math.floor(total / 100) % 60;
  var m     = Math.floor(total / 6000);
  return "+" + m + ":" + (s < 10 ? "0" : "") + s + "." + (hh < 10 ? "0" : "") + hh;
}

// Extracts eTLD+1 from a full URL. Returns empty string on failure.
function _etldPlusOne(url) {
  try {
    var hostname = new URL(url).hostname.toLowerCase();
    var labels   = hostname.split(".");
    if (labels.length <= 2) return hostname;
    // Handle common multi-part suffixes (co.uk, com.au, etc.)
    var last2 = labels.slice(-2).join(".");
    var MULTI = [
      "co.uk","org.uk","ac.uk","gov.uk","co.jp","co.kr","co.nz","co.za",
      "com.au","net.au","org.au","com.br","com.cn","com.mx","com.tr",
      "co.in","co.id","com.sg"
    ];
    if (MULTI.indexOf(last2) !== -1 && labels.length >= 3) {
      return labels.slice(-3).join(".");
    }
    return last2;
  } catch(e) {
    return "";
  }
}

// Sends MSG_MONITOR_CLOSED to the monitor panel (fire-and-forget).
function _notifyPanel(reason) {
  try {
    chrome.runtime.sendMessage({ type: MSG_MONITOR_CLOSED, reason: reason }, function() {
      // Ignore errors — panel may already be closed
      if (chrome.runtime.lastError) {}
    });
  } catch(e) {}
}

// Core cleanup — called by every stop path.
function _cleanup(reason) {
  // Remove webRequest listener if registered
  if (_monitorListener) {
    try {
      chrome.webRequest.onBeforeRequest.removeListener(_monitorListener);
    } catch(e) {}
  }
  // Cancel timers
  if (_sessionTimer)  { clearTimeout(_sessionTimer);  _sessionTimer  = null; }
  // Reset state
  activeSession  = null;
  monitorEntries = [];
  // Notify panel — but NOT when the panel itself triggered the close.
  // Sending MSG_MONITOR_CLOSED back to a closing window causes Chromium to
  // open a new (empty) receiver context, producing the ghost panel users see.
  if (reason && reason !== "panel_closed") _notifyPanel(reason);
}

// Classifies whether our own DNR ruleset would block this request.
// Mirrors rule-builder.js rulesForLevel() exactly — same allow/block order,
// same conditions, referenced by rule ID where applicable.
// Returns true if we would block, false if we would allow.
//
// Decision order (highest DNR priority wins, mirrored here top-to-bottom):
//   1. Level 1            → allow all                          (no rules at L1)
//   2. Builtin whitelist  → allow  (rules 2600–2999, prio 1000, L2–5)
//   3. User whitelist     → allow  (rules 2000–2199, prio 1000, L2–5)
//   4. TLD whitelist      → allow  (rules 2400–2499, prio 1000, L3 only)
//   5. CDN allow          → allow  (rule  3000,      prio 1000, L4 scripts only)
//   6. Block 3P frames    → block  (rule  3001,      prio 20,   L2–5 sub_frame)
//   7. Block 3P scripts   → block  (rule  3002,      prio 20,   L3–5 script)
//   8. Implicit allow     → allow  (nothing matched — not our block)
function _wouldWeBlock(thirdPartyHost, resourceType, url) {
  if (!activeSession || !activeSession.state) return true; // no state — assume block
  var s = activeSession.state;

  // Use effective level — respects per-site pin stored in siteRules
  var level = (activeSession.host && s.siteRules && s.siteRules[activeSession.host])
    ? s.siteRules[activeSession.host]
    : (s.level || 1);

  // ── 1. Level 1 — no rules, allow everything ───────────────────────────────
  if (level === 1) return false;

  // ── 2. Builtin domain whitelist (rules 2600–2999, levels 2–5) ────────────
  // Fall back to BUILTIN_DOMAINS constant if state copy is null (pre-seed)
  var builtins = (s.builtinDomains && s.builtinDomains.length)
    ? s.builtinDomains
    : (typeof BUILTIN_DOMAINS !== "undefined" ? BUILTIN_DOMAINS : []);
  for (var i = 0; i < builtins.length; i++) {
    if (thirdPartyHost === builtins[i] || thirdPartyHost.endsWith("."+builtins[i])) return false;
  }

  // ── 3. User domain whitelist (rules 2000–2199, levels 2–5) ───────────────
  var domains = s.domains || [];
  for (var j = 0; j < domains.length; j++) {
    if (thirdPartyHost === domains[j] || thirdPartyHost.endsWith("."+domains[j])) return false;
  }

  // ── 4. TLD whitelist (rules 2400–2499, level 3 only) ─────────────────────
  if (level === 3) {
    var labels = thirdPartyHost.split(".");
    var tld    = labels[labels.length - 1];
    var tld2   = labels.length >= 2 ? labels.slice(-2).join(".") : tld;
    var tlds   = s.tlds || [];
    if (tlds.indexOf(tld) !== -1 || tlds.indexOf(tld2) !== -1) return false;
  }

  // ── 5. CDN allow (rule 3000, level 4 only, scripts only) ─────────────────
  if (level === 4 && resourceType === "script" && url.toLowerCase().indexOf("cdn") !== -1) return false;

  // ── 6. Block 3P frames (rule 3001, levels 2–5) ───────────────────────────
  if (resourceType === "frame") return true;

  // ── 7. Block 3P scripts (rule 3002, levels 3–5) ──────────────────────────
  if (resourceType === "script" && level >= 3) return true;

  // ── 8. Implicit allow — not blocked by our ruleset ───────────────────────
  return false;
}

// The webRequest listener function — kept as a named reference so removeListener works.
function _monitorListener(details) {
  if (!activeSession)                           return;
  if (details.tabId !== activeSession.tabId)    return;
  if (activeSession.paused)                     return;

  var thirdPartyHost = _etldPlusOne(details.url);
  if (!thirdPartyHost)                          return;

  // Skip if same site as the 1P host
  var firstPartyApex = _etldPlusOne("https://" + activeSession.host);
  if (thirdPartyHost === firstPartyApex)        return;

  var elapsed = _formatElapsed(
    activeSession.timeElapsed + (Date.now() - activeSession.startTime)
  );

  // Skip if our own ruleset would NOT block this — it was blocked by another extension
  if (!_wouldWeBlock(thirdPartyHost, details.type === "sub_frame" ? "frame" : "script", details.url)) return;

  // Skip if this domain has already been recorded this session
  if (_seenDomains.has(thirdPartyHost)) return;
  _seenDomains.add(thirdPartyHost);

  var entry = {
    host:    thirdPartyHost,
    type:    details.type === "sub_frame" ? "frame" : "script",
    elapsed: elapsed
  };

  // FIFO: drop oldest if at cap
  if (monitorEntries.length >= MONITOR_CAP) monitorEntries.shift();
  monitorEntries.push(entry);
}

// ── Public interface ──────────────────────────────────────────────────────────

// Starts a new monitor session. Kills any existing session first.
// tabId: the tab to monitor. host: the 1P hostname.
// state: current extension state snapshot for request classification.
// cb: called when ready.
function startMonitor(tabId, host, state, cb) {
  // Kill existing session before starting a new one
  if (activeSession) _cleanup("new_session");

  activeSession = {
    tabId:       tabId,
    host:        host,
    startTime:   Date.now(), // overwritten by markMonitorStarted() after page reload
    paused:      false,
    timeElapsed: 0,
    state:       state       // snapshot for _wouldWeBlock() classification
  };
  monitorEntries = [];
  _seenDomains.clear();

  // Register webRequest listener scoped to scripts and frames only
  chrome.webRequest.onBeforeRequest.addListener(
    _monitorListener,
    { urls: ["<all_urls>"], types: ["script", "sub_frame"] }
  );

  // Reload the tab — onCommitted will call markMonitorStarted()
  chrome.tabs.reload(tabId, {}, function() {
    if (cb) cb({ ok: true });
  });
}

// Called by background.js onCommitted handler when the monitored tab finishes
// navigating. This is the true start of the 5-minute session clock.
function markMonitorStarted(tabId) {
  if (!activeSession || activeSession.tabId !== tabId) return;
  activeSession.startTime   = Date.now();
  activeSession.timeElapsed = 0;

  // Start 5-minute force-close timer
  if (_sessionTimer) clearTimeout(_sessionTimer);
  _sessionTimer = setTimeout(function() {
    _cleanup("timeout");
  }, MONITOR_DURATION);
}

// Full cleanup — called on EXIT button, popup close, or level drop below 4.
function stopMonitor(reason) {
  _cleanup(reason || "stopped");
}

// Pauses the listener. Accumulates elapsed time. Timer keeps running.
function pauseMonitor() {
  if (!activeSession || activeSession.paused) return;
  try {
    chrome.webRequest.onBeforeRequest.removeListener(_monitorListener);
  } catch(e) {}
  // Accumulate elapsed active time before pausing
  activeSession.timeElapsed += Date.now() - activeSession.startTime;
  activeSession.paused = true;
}

// Resumes: applies whitelist changes (caller must do that), clears array,
// re-registers listener, reloads tab. Timer is NOT reset.
// state: updated state snapshot (user may have allowed domains while paused)
function resumeMonitor(tabId, state, cb) {
  if (!activeSession) { if (cb) cb({ ok: false, error: "No active session" }); return; }
  // Update state snapshot so classifier reflects any newly allowed domains
  if (state) activeSession.state = state;

  // Clear the entry array and seen-domains set for a fresh start
  monitorEntries = [];
  _seenDomains.clear();

  // Re-register the listener
  try {
    chrome.webRequest.onBeforeRequest.addListener(
      _monitorListener,
      { urls: ["<all_urls>"], types: ["script", "sub_frame"] }
    );
  } catch(e) {}

  activeSession.paused = false;
  // Reset startTime reference — timeElapsed already accumulated
  activeSession.startTime = Date.now();

  // Reload the tab
  chrome.tabs.reload(tabId, {}, function() {
    if (cb) cb({ ok: true });
  });
}

// Returns a snapshot of the current session metadata and entry array.
function getMonitorData() {
  if (!activeSession) return { session: null, entries: [] };
  var elapsed = activeSession.paused
    ? activeSession.timeElapsed
    : activeSession.timeElapsed + (Date.now() - activeSession.startTime);
  return {
    session: {
      tabId:       activeSession.tabId,
      host:        activeSession.host,
      paused:      activeSession.paused,
      elapsed:     elapsed,
      remaining:   Math.max(0, MONITOR_DURATION - elapsed)
    },
    entries: monitorEntries.slice() // defensive copy
  };
}

// Adds a domain to the state domain whitelist, saves and applies rules.
// Called when the user presses Allow in the paused panel.
function allowMonitorDomain(domain, state, applyStateFn, cb) {
  if (!domain) { if (cb) cb({ ok: false, error: "No domain" }); return; }
  if (!state.domains) state.domains = [];
  if (state.domains.indexOf(domain) === -1) {
    state.domains.push(domain);
  }
  saveState(state, function() {
    applyStateFn(state, function(count) {
      if (cb) cb({ ok: true, ruleCount: count });
    });
  });
}

// Watchdog: call once on SW boot. Kills any orphan session older than 5 minutes.
// In practice the 5-minute session timer handles cleanup; this is the fallback.
function startWatchdog() {
  if (_watchdogTimer) clearInterval(_watchdogTimer);
  _watchdogTimer = setInterval(function() {
    if (!activeSession) return;
    var elapsed = activeSession.timeElapsed + (Date.now() - activeSession.startTime);
    if (elapsed > MONITOR_DURATION) {
      _cleanup("timeout");
    }
  }, WATCHDOG_INTERVAL);
}
