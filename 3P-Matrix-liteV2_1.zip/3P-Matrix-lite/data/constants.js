// ── data/constants.js ─────────────────────────────────────────────────────────
// All static data lists used by the rule builder and state initialisation.
// Pure constants — never mutated at runtime.
//
// Consumed by:
//   core/rule-builder.js  — RP_3P
//   data/state-storage.js — BUILTIN_DOMAINS, GENERIC_BLOCKED_TLDS, WORLD_BLOCKED_TLDS
// ─────────────────────────────────────────────────────────────────────────────

// Full third-party resource type list.
// Used ONLY for base safety block rules and allow rules (TLD/domain/CDN whitelists).
// NEVER use this for block rules beyond sub_frame/script — see rule-builder.js for details.
var RP_3P = [
  "sub_frame", "stylesheet", "script", "image",
  "font", "object", "xmlhttprequest", "ping", "media", "websocket", "other"
];


// Low-quality/high-abuse TLDs used almost exclusively for spam, phishing, malware
// or throwaway sites. Used in the level-2 TLD blacklist.
var GENERIC_BLOCKED_TLDS = [
  "zip", "click", "cfd", "rest", "surf", "top", "icu", "shop", "xyz",
  "online", "site", "mov", "review", "download", "monster", "buzz", "fun"
];

// GENERIC list plus high-risk country/territory ccTLDs frequently abused for
// malware/phishing or operating under minimal oversight.
var WORLD_BLOCKED_TLDS = GENERIC_BLOCKED_TLDS.concat([
  "cc", "cm", "cn", "cx", "gq", "ir", "kp", "ly", "ml", "ms",
  "pk", "pw", "ru", "su", "tk", "tm", "to", "ws", "ye"
]);

// Built-in trusted third-party domains: payment processors, video embeds,
// CAPTCHA/bot-protection and fraud prevention.
// Seeded into state.builtinDomains on first install. Applied as sub_frame allow
// rules at levels 2, 3 and 4. Users can remove individual entries.
// Max 200 entries (ID ranges 2800-2999 and 4000-4199 — see rule-builder.js).
var BUILTIN_DOMAINS = [
  // Payment — core / international
  "js.stripe.com", "js.stripe.network", "m.stripe.network", "hooks.stripe.com",
  "checkout.stripe.com", "stripe.com",
  "paypal.com", "paypalobjects.com",
  "js.braintreegateway.com", "assets.braintreegateway.com",
  "checkout.com", "cdn.checkout.com",
  "adyen.com", "checkoutshopper-live.adyen.com",
  "klarna.com", "x.klarnacdn.net",
  "squareup.com", "js.squareup.com",
  "worldpay.com",
  "authorize.net", "cybersource.com",
  "verifone.com", "verifone.cloud",
  // Digital wallets
  "pay.google.com", "googlepay.com",
  "apple-pay-gateway.apple.com", "apple-pay-gateway-nc-pod.apple.com",
  // Open Banking
  "truelayer.com", "plaid.com", "tink.com", "banked.com", "vyne.co.uk",
  "trustly.com",
  // Payment — Benelux
  "mollie.com", "js.mollie.com", "ideal-checkout.nl",
  "wero-wallet.eu", "buckaroo.nl", "pay.nl", "sisow.nl",
  "multi-safepay.com", "cm.com", "tikkie.nl",
  "onlinepaymentplatform.nl", "billink.nl",
  "noda.live", "plugandpay.io", "pronamicpay.com",
  "worldline.com", "ingenico.com", "bancontact.com", "ccv.eu",
  // Payment — DACH
  "ratepay.com", "riverty.com", "computop.com", "unzer.com", "heidelpay.com",
  "payone.com", "twint.ch", "eps-ueberweisung.at",
  // Note: giropay.de was shut down December 2024 — intentionally excluded
  // Payment — France
  "lyra.com", "payplug.com", "paybox.com",
  // Payment — Italy
  "nexi.it", "satispay.com", "postepay.it",
  // Payment — Spain / Portugal
  "redsys.es", "bizum.es",
  // Payment — Nordics
  "vipps.no", "mobilepay.dk", "vippsmobilepay.com",
  "getswish.se", "swish.nu", "walleypay.com", "siirto.fi",
  // Payment — UK / Ireland
  "gocardless.com", "opayo.co.uk", "sagepay.com",
  // Payment — North America
  "moneris.com", "helcim.com", "bambora.com", "beanstream.com",
  "elavon.com", "fisglobal.com", "fiserv.com", "clover.com",
  // Payment — Poland
  "payu.com", "payu.pl", "przelewy24.pl", "tpay.com",
  // Payment — Czech / Slovakia
  "gopay.com", "comgate.cz",
  // Payment — Romania
  "netopia-payments.com", "euplatesc.ro",
  // Payment — Baltics
  "makecommerce.net", "every-pay.com",
  // JS libraries — merged from former JS_LIB_DOMAINS list (previously level 4 only,
  // now covered by built-in whitelist at all levels 2-5)
  "ajax.googleapis.com",   // Google Hosted Libraries (jQuery, Angular, etc)
  "ajax.microsoft.com",    // Microsoft Ajax CDN (legacy domain, still in use)
  "code.jquery.com",       // jQuery official CDN
  "jsdelivr.net",          // jsDelivr — 160B req/month, npm/GitHub packages
  "unpkg.com",             // unpkg — npm packages
  "esm.sh",                // ESM module CDN (no .sh in BASE_TLDS)
  "registry.npmjs.org",    // npm registry (occasionally loaded directly)

  // Video embeds — established hosted platforms only
  "youtube.com", "youtube-nocookie.com", "youtu.be", "ytimg.com", "googlevideo.com",
  "googleapis.com",  // Google API iframes (content-youtube.googleapis.com, etc)
  "vimeo.com", "player.vimeo.com", "f.vimeocdn.com", "i.vimeocdn.com", "vimeocdn.com",
  "wistia.com", "fast.wistia.com", "wistia.net",
  "dailymotion.com", "dmcdn.net",
  "jwplatform.com", "jwpcdn.com", "jwplayer.com",
  "cdn.jwplayer.com",                     // JW Player iframe CDN — Guardian, USA Today, Daily Mirror
  "content.jwplatform.com",               // JW Player legacy content delivery domain
  "brightcove.com", "players.brightcove.net",
  "loom.com", "loomcdn.com",
  "vidyard.com", "play.vidyard.com",
  "sproutvideo.com",
  // Live streaming
  "twitch.tv", "player.twitch.tv", "jtvnw.net", "ext-twitch.tv",
  // Enterprise/education video
  "kaltura.com", "panopto.com",
  // News publisher video players — proprietary embed domains
  // Brightcove: used by NYT, The Sun, Daily Telegraph, Globe & Mail, NZ Herald, Süddeutsche, De Telegraaf
  "bcove.video",                          // Brightcove CDN alias
  // JW Player / JWX: used by The Guardian, USA Today, Toronto Star, Daily Mirror
  "cdn.jwpltx.com",                       // JW Player analytics/tracking companion
  // MyChannels: DPG Media (AD, De Volkskrant, HLN, Het Nieuwsblad)
  "embed.mychannels.video",               // proprietary player — Dutch/Belgian press
  // Dailymotion: used by Le Monde, Le Figaro, La Libre, some Canadian French press
  "geo.dailymotion.com",                  // Dailymotion geo-routed CDN endpoint

  // Video infrastructure / delivery
  "cloudflarestream.com", "videodelivery.net",  // Cloudflare Stream
  "mux.com",                                     // Mux video platform
  // Other embeddable platforms
  "ted.com",
  "rumble.com",
  // Public broadcasters commonly embedded in EU/UK
  "bbc.co.uk", "bbc.com",
  "arte.tv",                                     // Franco-German public broadcaster
  // CAPTCHA / bot protection
  "google.com", "recaptcha.net", "gstatic.com",
  "hcaptcha.com", "js.hcaptcha.com",
  "challenges.cloudflare.com", "turnstile.cloudflare.com",
  "friendlycaptcha.com", "captcha.eu",
  "arkoselabs.com", "client-api.arkoselabs.com",
  "geetest.com", "static.geetest.com",
  "altcha.org",
  // Fraud prevention — commonly loaded as iframes during checkout flows
  "sift.com", "riskified.com", "forter.com", "signifyd.com", "seon.io"
];
