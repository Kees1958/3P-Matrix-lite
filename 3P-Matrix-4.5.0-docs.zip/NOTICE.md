# Notice — 3P Matrix — content firewall (docs)

Copyright (C) 2026 Kees1958 and co-authors. Distributed under the GNU General Public License v3 — the licence
text is `LICENSE.txt` in the extension package (3P-Matrix-<version>-extension.zip); third-party components and their
licences are listed in `THIRD_PARTY_LICENSES.md` there.

This package is documentation only. `Xplainer_Programming_principles_audit_v5.md` and the files in `sources/` are
taken unchanged from the source projects named in `README.md` (uBlock Stripped Dynamic, 3P-Matrix-lite,
DownloadSentinel — same authors, GPLv3 / own licences as stated there).
