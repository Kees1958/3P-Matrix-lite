# DownloadSentinel 3.0.4 — version index reconstructed from source comments

**This is NOT the real changelog.** No changelog file was included in the uploaded source zips, so this
index lists every source comment that names a version, grouped by version (newest first), with file and
line. Use it to trace when and why a piece of code changed. Replace it with the real CHANGELOG when
available.

Versions referenced: 9 · lines: 91

## v3.0.4

- `DownloadSentinel-EXTENSION-v3.0.4/protection/Quad9Protection.js:15` — * ── Wire format, not the JSON convenience format (v3.0.4) ────────────────
- `DownloadSentinel-EXTENSION-v3.0.4/protection/Quad9Protection.js:29` — * actually promises to keep working. See DOCS/CHANGELOG.md's v3.0.4 entry.

## v2.11.0

- `DownloadSentinel-EXTENSION-v3.0.4/background.js:268` — // referrer (v2.11.0 — FilenameUrlHeuristics.checkReferrerMismatch()):
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:310` — record.referrer                         // v2.11.0 — FilenameUrlHeuristics.checkReferrerMismatch()
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:401` — referrer:         downloadItem.referrer \|\| null, // v2.11.0 — FilenameUrlHeuristics.checkReferrerMismatch()
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:428` — record.referrer                                   // v2.11.0 — FilenameUrlHeuristics.checkReferrerMismatch()
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:492` — record.referrer                          // v2.11.0 — FilenameUrlHeuristics.checkReferrerMismatch()
- `DownloadSentinel-EXTENSION-v3.0.4/protection/BrowserProtection.js:157` — *        (v2.11.0 — passed through to FilenameUrlHeuristics.check
- `DownloadSentinel-EXTENSION-v3.0.4/protection/CombinationScoring.js:75` — // ── Heuristics plan "Later steps" (v2.11.0 — Step 5) ──────────────────
- `DownloadSentinel-EXTENSION-v3.0.4/protection/FilenameUrlHeuristics.js:4` — // Heuristics plan "Later steps" (v2.11.0 — Step 5, "Smaller filename and URL
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:6` — import { FilenameUrlHeuristics } from "./FilenameUrlHeuristics.js"; // RLO/padded-ext/brand-homoglyph/shortener/referrer — heuristics plan Step 5, v2.11.0
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:65` — *     21. RLO/bidi-override character in filename or URL (v2.11.0)
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:66` — *     22. Padded double extension, e.g. "invoice_pdf____.exe" (v2.11.0)
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:67` — *     23. Bigram homoglyph brand typosquat, e.g. "arnazon.com" (v2.11.0)
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:68` — *     24. URL-shortener host (v2.11.0, weak/contextual only)
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:69` — *     25. Referrer/download-host mismatch (v2.11.0, weak/contextual only,
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:196` — // ── Heuristics plan "Later steps" (v2.11.0 — Step 5) ──────────────────────
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:753` — // ── Checks 21-25: Filename/URL heuristics (heuristics plan Step 5, v2.11.0) ──
- `DownloadSentinel-EXTENSION-v3.0.4/util/BrandDomains.js:5` — * homoglyph typosquat check (heuristics plan "Later steps", v2.11.0).
- `DownloadSentinel-EXTENSION-v3.0.4/util/UrlShorteners.js:5` — * "Later steps", v2.11.0).
- `DownloadSentinel-TOOLS-v3.0.4/tests/CombinationScoring.test.js:273` — // v2.11.0 — heuristics plan "Later steps" Step 5
- `DownloadSentinel-TOOLS-v3.0.4/tools/fp-sweep.mjs:98` — // v2.11.0 — Step 5 filename/URL heuristics (RLO, padded double extension,

## v2.10.0

- `DownloadSentinel-EXTENSION-v3.0.4/util/FilterDataLoader.js:5` — * pure-data lists (heuristics-plan data split, v2.10.0 restructure).
- `DownloadSentinel-EXTENSION-v3.0.4/util/ListSetModule.js:8` — * EXTENSION/data/ split landed — see DOCS/CHANGELOG.md's v2.10.0 entry) —
- `DownloadSentinel-TOOLS-v3.0.4/tools/complete-check.mjs:13` — // DOCS/TOOLS/EXTENSION restructure (v2.10.0) note: this script lives in
- `DownloadSentinel-TOOLS-v3.0.4/tools/repoPaths.mjs:8` — // DOCS/CHANGELOG.md's v2.10.0 entry): given a script's own import.meta.url

## v2.9.0

- `DownloadSentinel-EXTENSION-v3.0.4/protection/CombinationScoring.js:4` — // Heuristics plan Step 3 (v2.9.0): combine several independent host-reputation
- `DownloadSentinel-EXTENSION-v3.0.4/protection/MimeCheck.js:12` — *     includes script extensions as of v2.9.0; see that CHANGELOG entry for
- `DownloadSentinel-EXTENSION-v3.0.4/protection/MimeCheck.js:60` — // v2.9.0 bug fix: scripts used to get a special -20 "possible
- `DownloadSentinel-EXTENSION-v3.0.4/protection/MimeCheck.js:67` — // pre-v2.9.0 "worst signal wins" model this penalty was invisible
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:5` — import { CombinationScoring } from "./CombinationScoring.js"; // combineHostResults() — heuristics plan Step 3, v2.9.0
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:23` — *         and stacks like everything else (v2.9.0 — see check 20 below;
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:24` — *         before v2.9.0 this was instead folded additively, capped at −20,
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:51` — *     20. Combination scoring (CombinationScoring.combineHostResults, v2.9.0)
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:128` — // (heuristics plan Step 3 / v2.9.0 — not yet implemented).
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:137` — // (Step 3 / v2.9.0 combination scoring — not yet implemented).
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:466` — // v2.9.0 (Step 3): RDAP is now its own independent HOST_AGE-family
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:470` — // replaces the pre-v2.9.0 rdapAdditive/rdapStandalone fold-in below).
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:513` — // "only when nothing else fired" (v2.9.0; see header comment).
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:547` — // rdapAdditive fold-in, is what lets it become decisive — v2.9.0).
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:857` — // v2.9.0 (Step 3): combine every signal gathered above instead of
- `DownloadSentinel-EXTENSION-v3.0.4/util/DangerousMimes.js:61` — "application/javascript":            ["js"], // v2.9.0 bug fix — this IS the
- `DownloadSentinel-EXTENSION-v3.0.4/util/HostList.js:16` — * v2.9.0 — see ScoringEngineV2.js's evaluateHostReputation / Combination
- `DownloadSentinel-TOOLS-v3.0.4/tests/MimeCheck.test.js:28` — // of misconfiguration. Under pre-v2.9.0 "worst signal wins" this was
- `DownloadSentinel-TOOLS-v3.0.4/tools/update-lists.mjs:56` — // logic (that's Step 3 / v2.9.0). A single hit from one of these lists alone

## v2.8.0

- `DownloadSentinel-EXTENSION-v3.0.4/background.js:271` — // sizeKnown (v2.8.0 — StagingCheck container-size check): Chrome
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:308` — record.filename,                        // v2.8.0 — StagingCheck.checkKeywords() filename
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:309` — record.sizeKnown,                       // v2.8.0 — StagingCheck.checkFormat() sizeKnown
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:426` — confirmedFilename,                                // v2.8.0 — StagingCheck filename
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:427` — record.sizeKnown,                                 // v2.8.0 — StagingCheck sizeKnown
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:440` — // sizeKnown (v2.8.0): totalBytes is typically still 0 at onCreated time
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:464` — // ── Size-newly-known signal (v2.8.0) ────────────────────────────────────
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:466` — // v2.8.0. Previously, when obfuscation was null, host reputation was
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:490` — confirmedFilename,                       // v2.8.0 — StagingCheck filename
- `DownloadSentinel-EXTENSION-v3.0.4/background.js:491` — true,                                    // v2.8.0 — size is now known
- `DownloadSentinel-EXTENSION-v3.0.4/protection/BrowserProtection.js:55` — import { StagingCheck } from "./StagingCheck.js"; // lure/command keywords + staging formats — v2.8.0 Step 2
- `DownloadSentinel-EXTENSION-v3.0.4/protection/BrowserProtection.js:151` — * @param {string} filename  - confirmed or suggested filename (v2.8.0 —
- `DownloadSentinel-EXTENSION-v3.0.4/protection/BrowserProtection.js:154` — *        size (v2.8.0 — passed through to StagingCheck.checkFormat());
- `DownloadSentinel-EXTENSION-v3.0.4/protection/BrowserProtection.js:199` — // ── Staging checks (heuristics plan Step 2, v2.8.0) ───────────────────
- `DownloadSentinel-EXTENSION-v3.0.4/protection/CombinationScoring.js:6` — // v2.8.0). Several real risk indicators firing together are worse than any
- `DownloadSentinel-EXTENSION-v3.0.4/protection/CombinationScoring.js:53` — // v2.8.0) when it is literally the only signal present.
- `DownloadSentinel-EXTENSION-v3.0.4/protection/CombinationScoring.js:185` — // Falls back to exactly the NEUTRAL entry alone, same as v2.8.0.
- `DownloadSentinel-EXTENSION-v3.0.4/protection/CombinationScoring.js:194` — // Exactly one family present — identical to v2.8.0's single-signal
- `DownloadSentinel-EXTENSION-v3.0.4/protection/CombinationScoring.js:195` — // output. RDAP is the one case needing a transform: v2.8.0 doubled
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:43` — *     18. Staging keywords (StagingCheck.checkKeywords, v2.8.0) — lure words,
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:47` — *     19. Staging file format (StagingCheck.checkFormat, v2.8.0) — first-stage
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:63` — *         byte identical to v2.8.0 — this is a hard invariant, tested
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:131` — // ── Staging keywords + staging formats (heuristics plan Step 2, v2.8.0) ──
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:441` — *        StagingCheck.checkKeywords(), { score, signals } (v2.8.0)
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:443` — *        StagingCheck.checkFormat(), { tier, label, source } or null (v2.8.0)
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:557` — // ── Check 18: Staging keywords (StagingCheck.checkKeywords — v2.8.0) ──
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:579` — // ── Check 19: Staging file format (StagingCheck.checkFormat — v2.8.0) ─
- `DownloadSentinel-EXTENSION-v3.0.4/protection/StagingCheck.js:4` — // Heuristics plan Step 2 (v2.8.0): staging-stage malware-delivery signals.
- `DownloadSentinel-EXTENSION-v3.0.4/protection/StagingCheck.js:179` — // RESOLVED (v2.8.0, alongside this module's own release — see CHANGELOG):
- `DownloadSentinel-EXTENSION-v3.0.4/util/DangerousExts.js:40` — // Heuristics plan Step 2b (v2.8.0) — first-stage "staging" formats
- `DownloadSentinel-EXTENSION-v3.0.4/util/DangerousExts.js:45` — // explicit "widen DangerousExts" decision made alongside v2.8.0 —
- `DownloadSentinel-TOOLS-v3.0.4/tools/fp-sweep.mjs:25` — // become a real gate once Step 2's staging checks land in v2.8.0).

## v2.7.0

- `DownloadSentinel-EXTENSION-v3.0.4/protection/BrowserProtection.js:54` — import { HostList } from "../util/HostList.js"; // merged HaGeZi/Kees list — v2.7.0 Step 1
- `DownloadSentinel-EXTENSION-v3.0.4/protection/BrowserProtection.js:174` — hostListHit: HostList.lookup(hostname), // v2.7.0 Step 1 — merged HaGeZi/Kees list
- `DownloadSentinel-EXTENSION-v3.0.4/protection/BrowserProtection.js:222` — const hostListHit = originalHeuristics // v2.7.0 Step 1 — same worst-of-two pattern as domainHit/tldHit
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:40` — *     17. Merged host-risk list (HostList.js, v2.7.0)  (list score × base −70,
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:120` — // ── Merged host-risk list (heuristics plan Step 1, v2.7.0) ────────────────
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:439` — *        (v2.7.0 — merged HaGeZi/Kees list; see SCORING_CONFIG.HOST_LIST_BASE_SCORE)
- `DownloadSentinel-EXTENSION-v3.0.4/protection/ScoringEngineV2.js:542` — // ── Check 4a: Merged host-risk list (HostList.js — v2.7.0 Step 1) ────
- `DownloadSentinel-EXTENSION-v3.0.4/util/HostList.js:6` — * Merged, deduplicated host-risk list (heuristics plan Step 1, v2.7.0):
- `DownloadSentinel-TOOLS-v3.0.4/tools/fp-sweep.mjs:6` — // Heuristics plan Step 0 (v2.7.0) — false-positive sweep.
- `DownloadSentinel-TOOLS-v3.0.4/tools/fp-sweep.mjs:24` — // informational only in v2.7.0 (no new detection was added this step; they
- `DownloadSentinel-TOOLS-v3.0.4/tools/update-lists.mjs:7` — // host-risk list described in the v2.7.0 heuristics plan (Step 1). This is a

## v2.6.1

- `DownloadSentinel-TOOLS-v3.0.4/tools/complete-check.mjs:110` — // `--ext .js`, not `.mjs`, since v2.6.1).

## v1.2.3

- `DownloadSentinel-TOOLS-v3.0.4/tests/StagingCheck.test.js:90` — finalUrl: "https://example.com/release-v1.2.3.zip",

## v0.39.0

- `DownloadSentinel-TOOLS-v3.0.4/tests/StagingCheck.test.js:41` — finalUrl: "https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh",

