# 3P-Matrix-lite 4.0.2 — version index reconstructed from source comments

**This is NOT the real changelog.** No changelog file was included in the uploaded source zips, so this
index lists every source comment that names a version, grouped by version (newest first), with file and
line. Use it to trace when and why a piece of code changed. Replace it with the real CHANGELOG when
available.

Versions referenced: 5 · lines: 5

## v3.7.5

- `3P-Matrix-lite-4_0_2-extension/core/rule-classifier.js:389` — // and the v3.7.5 CHANGELOG entry for the bug this fixes).

## v3.2.0

- `3P-Matrix-lite-4_0_2-extension/core/rule-classifier.js:11` — // (v3.2.0), background.js's MSG_GET_MATRIX_DATA handler also imports the

## v2.7.0

- `3P-Matrix-lite-4_0_2-extension/core/rule-classifier.js:7` — // in v2.7.0 once Show Matrix's purpose was clarified as full-visibility

## v2.4.0

- `3P-Matrix-lite-4_0_2-extension/core/rule-classifier.js:5` — // Extracted from core/block-monitor.js (v2.4.0) originally to be shared with

## v1.7.3

- `3P-Matrix-lite-4_0_2-extension/data/message-types.js:18` — // MSG_GET_ACTIVE_TAB_INFO and MSG_RELOAD_ACTIVE_TAB removed in v1.7.3 —

