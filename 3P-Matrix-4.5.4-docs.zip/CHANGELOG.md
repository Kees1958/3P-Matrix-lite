# 3P Matrix — content firewall — changelog

(Started with 4.5.4: earlier docs packages carried no CHANGELOG.md. Technical detail for 4.5.4 is in
PERF_4.5.3_chrome_engine_and_proposals.md section 6 and the principles doc, v13.)

## 4.5.4
- Faster and lighter: the extension wakes up less often, starts faster, and no longer rewrites its rules when a setting that does not affect them is saved.
- Pages are checked against fewer content-script patterns; the suspicious-site warning appears sooner.
- The badge count, risk colour and "Continue once" are kept while the browser stays open.
- Public Suffix List refreshed; every bundled list can now be rebuilt with this project's own tools.
- Backup files from 0.1.x/0.2.0 and Show Matrix overrides saved by 4.2.2 or older are no longer converted.
