// ── data/constants.js ─────────────────────────────────────────────────────────
// All static data lists used by the rule builder and state initialisation.
// Pure constants — never mutated at runtime.
//
// Consumed by:
//   core/tld-engine.js    — EU_LANGS (_TLD_ENGINE_EU_LANGS replaced), MULTI_PART_SUFFIXES
//   util/tld-utils.js     — EU_LANGS (replaces local copy)
//   ui/popup.js           — MULTI_PART_SUFFIXES (replaces local copy)
//   data/state-storage.js — BUILTIN_DOMAINS, GENERIC_BLOCKED_TLDS, WORLD_BLOCKED_TLDS
// ─────────────────────────────────────────────────────────────────────────────

// EU official languages — used to detect whether to add "eu" to the TLD list.
// Single source of truth: tld-engine.js and tld-utils.js both reference this.
// Source: EU official language list (23 languages).
export const EU_LANGS = {
  "bg":1,"hr":1,"cs":1,"da":1,"nl":1,"et":1,"fi":1,"fr":1,"de":1,"el":1,
  "hu":1,"ga":1,"it":1,"lv":1,"lt":1,"mt":1,"pl":1,"pt":1,"ro":1,"sk":1,"sl":1,"es":1,"sv":1
};

// Common multi-part public suffixes — single source of truth used by
// tld-engine.js (_etldPlusOne) and popup.js (getApexDomain).
// Anything not in this list falls back to the standard "last two labels" rule.
export const MULTI_PART_SUFFIXES = [
  "co.uk","org.uk","ac.uk","gov.uk","co.jp","co.kr","co.nz","co.za",
  "com.au","net.au","org.au","com.br","com.cn","com.mx","com.tr",
  "co.in","co.id","com.sg"
];

// Matches "cdn" only within a URL's HOST portion (the part before the first
// "/"), never in the path or query string — used by rule-builder.js's DNR
// CDN-allow rule (level 4). RE2 syntax (DNR's regexFilter dialect): scheme,
// "://", then any run of non-"/" characters containing "cdn", followed by
// either "/" or end-of-string. Kept as its own constant rather than
// duplicated inline, since background.js must validate this exact string via
// chrome.declarativeNetRequest.isRegexSupported() before rule-builder.js is
// allowed to use it — see background.js's checkCdnRegexSupport() and its
// graceful fallback to the old (looser but always-valid) urlFilter if this
// regex is ever rejected by a given Chrome version's DNR engine.
export const CDN_HOST_REGEX = "^[a-z][a-z0-9+.-]*://[^/]*cdn[^/]*(/|$)";

// ── Show Matrix ────────────────────────────────────────────────────────────────
// webRequest resource types Show Matrix observes — the FULL third-party
// resource set. This is deliberately everything: images, media (video/audio),
// stylesheets, fonts, plugins/objects, pings, and "other", matching how
// classic uMatrix showed every kind of third-party connection in its matrix
// view, not just script/frame/xhr/websocket.
export const MATRIX_RESOURCE_TYPES = [
  "sub_frame", "stylesheet", "script", "image", "font", "object",
  "xmlhttprequest", "ping", "csp_report", "media", "websocket", "webbundle", "other"
];

// Max FIFO entries per tab — oldest entry is evicted once this cap is hit.
export const MATRIX_CAP = 100;

// Session duration — Show Matrix auto-closes its panel after this long.
export const MATRIX_DURATION = 5 * 60 * 1000; // 5 minutes in ms


// Low-quality/high-abuse TLDs used almost exclusively for spam, phishing, malware
// or throwaway sites. Used in the level-2 TLD blacklist.
export const GENERIC_BLOCKED_TLDS = [
  "zip", "click", "cfd", "rest", "surf", "top", "icu", "shop", "xyz",
  "online", "site", "mov", "review", "download", "monster", "buzz", "fun"
];

// GENERIC list plus high-risk country/territory ccTLDs frequently abused for
// malware/phishing or operating under minimal oversight.
export const WORLD_BLOCKED_TLDS = GENERIC_BLOCKED_TLDS.concat([
  "cc", "cm", "cn", "cx", "gq", "ir", "kp", "ly", "ml", "ms",
  "pk", "pw", "ru", "su", "tk", "tm", "to", "ws", "ye"
]);

// Built-in trusted third-party domains: payment processors, video embeds,
// CAPTCHA/bot-protection, fraud prevention, and identity/SSO providers.
// Seeded into state.builtinDomains on first install (see background.js's
// onInstalled "install" branch). Applied as allow rules at levels 2-5 (see
// rule-builder.js's buildBuiltinAllowRules, called whenever level >= 2).
// Users can remove individual entries via state.builtinDomains.
// Max 400 entries (ID range 2600-2999 — see rule-builder.js's ID map).
//
// Split per-type (script vs frame) rather than a flat domain list, per
// explicit request — each entry only allows the specific resource type(s)
// it's actually verified to need, not both automatically. Hand-classified
// (not guessed) into three source lists (script-only: 12 domains,
// frame-only: 4, both: 147 — 163 total), revised from an earlier 186-domain
// pass after discovering unintended parent/child collisions (see
// CHANGELOG — 2 collisions remain, both known and documented there;
// domain-anchored DNR rules would eliminate them entirely if ever needed).
// Built-in trusted third-party domains: payment processors, video embeds,
// CAPTCHA/bot-protection, fraud prevention, and identity/SSO auth-as-a-service
// providers. Seeded into state.builtinDomains on first install (see
// background.js's onInstalled "install" branch). Applied as allow rules at
// levels 2-5 (see rule-builder.js's buildBuiltinAllowRules, called whenever
// level >= 2). Users can remove individual entries via state.builtinDomains.
// Max 400 entries (ID range 2600-2999 — see rule-builder.js's ID map).
//
// Split per-type (script vs frame) rather than a flat domain list, per
// explicit request — each entry only allows the specific resource type(s)
// it's actually verified to need, not both automatically. Auth-as-a-service
// providers (Auth0, Okta, OneLogin, WorkOS, plus openai.com's own login)
// are included unconditionally here — a site that's integrated one of these
// has made a deliberate, narrow-purpose choice, and blocking it means login
// simply doesn't work. Broader multi-purpose Identity/SSO platforms
// (Facebook, GitHub, LinkedIn, Apple, Microsoft account domains) are
// deliberately NOT here — see SIGNAL_DOMAINS below for those instead.
export const BUILTIN_DOMAINS = {
  // Payment — core / international
  "adyen.com": { script: true, frame: true },
  // JS libraries
  "ajax.microsoft.com": { script: true, frame: false },
  // CAPTCHA / bot protection
  "altcha.org": { script: true, frame: true },
  // Digital wallets
  "apple-pay-gateway-nc-pod.apple.com": { script: true, frame: true },
  "apple-pay-gateway.apple.com": { script: true, frame: true },
  // CAPTCHA / bot protection
  "arkoselabs.com": { script: true, frame: true },
  // Payment — core / international
  "assets.braintreegateway.com": { script: true, frame: true },
  // Identity / SSO — Auth-as-a-service
  "auth0.com": { script: true, frame: true },
  // Payment — core / international
  "authorize.net": { script: true, frame: true },
  // Payment — North America
  "bambora.com": { script: true, frame: true },
  // Payment — Benelux
  "bancontact.com": { script: true, frame: true },
  // Open Banking
  "banked.com": { script: true, frame: true },
  // News publisher video players (proprietary embed domains)
  "bcove.video": { script: true, frame: true },
  // Payment — North America
  "beanstream.com": { script: true, frame: true },
  // Payment — Benelux
  "billink.nl": { script: true, frame: true },
  // Payment — Spain / Portugal
  "bizum.es": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "brightcove.com": { script: true, frame: true },
  // Payment — Benelux
  "buckaroo.nl": { script: true, frame: true },
  // CAPTCHA / bot protection
  "captcha.eu": { script: true, frame: true },
  // Payment — Benelux
  "ccv.eu": { script: true, frame: true },
  // Payment — core / international
  "cdn.checkout.com": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "cdn.jwplayer.com": { script: true, frame: true },
  // News publisher video players (proprietary embed domains)
  "cdn.jwpltx.com": { script: true, frame: true },
  // CAPTCHA / bot protection
  "challenges.cloudflare.com": { script: true, frame: true },
  // Payment — core / international
  "checkout.com": { script: true, frame: true },
  "checkout.stripe.com": { script: true, frame: true },
  "checkoutshopper-live.adyen.com": { script: true, frame: true },
  // CAPTCHA / bot protection
  "client-api.arkoselabs.com": { script: true, frame: true },
  // Video infrastructure / delivery
  "cloudflarestream.com": { script: true, frame: true },
  // Payment — North America
  "clover.com": { script: true, frame: true },
  // Payment — Benelux
  "cm.com": { script: true, frame: true },
  // JS libraries
  "code.jquery.com": { script: true, frame: false },
  // Payment — Czech / Slovakia
  "comgate.cz": { script: true, frame: true },
  // Payment — DACH
  "computop.com": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "content.jwplatform.com": { script: true, frame: true },
  // Payment — core / international
  "cybersource.com": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "dailymotion.com": { script: true, frame: true },
  "dmcdn.net": { script: true, frame: true },
  // Payment — North America
  "elavon.com": { script: true, frame: true },
  // News publisher video players (proprietary embed domains)
  "embed.mychannels.video": { script: true, frame: true },
  // Payment — DACH
  "eps-ueberweisung.at": { script: true, frame: true },
  // JS libraries
  "esm.sh": { script: true, frame: false },
  // Payment — Romania
  "euplatesc.ro": { script: true, frame: true },
  // Payment — Baltics
  "every-pay.com": { script: true, frame: true },
  // Live streaming
  "ext-twitch.tv": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "f.vimeocdn.com": { script: true, frame: true },
  "fast.wistia.com": { script: true, frame: true },
  // Payment — North America
  "fiserv.com": { script: true, frame: true },
  "fisglobal.com": { script: true, frame: true },
  // Fraud prevention — commonly loaded as iframes during checkout flows
  "forter.com": { script: true, frame: true },
  // CAPTCHA / bot protection
  "friendlycaptcha.com": { script: true, frame: true },
  "geetest.com": { script: true, frame: true },
  // News publisher video players (proprietary embed domains)
  "geo.dailymotion.com": { script: true, frame: true },
  // Payment — Nordics
  "getswish.se": { script: true, frame: true },
  // Payment — UK / Ireland
  "gocardless.com": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "googleapis.com": { script: true, frame: true },
  // Digital wallets
  "googlepay.com": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "googlevideo.com": { script: true, frame: true },
  // Payment — Czech / Slovakia
  "gopay.com": { script: true, frame: true },
  // CAPTCHA / bot protection
  "gstatic.com": { script: true, frame: true },
  "hcaptcha.com": { script: false, frame: true },
  // Payment — DACH
  "heidelpay.com": { script: true, frame: true },
  // Payment — North America
  "helcim.com": { script: true, frame: true },
  // Payment — core / international
  "hooks.stripe.com": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "i.vimeocdn.com": { script: true, frame: true },
  // Payment — Benelux
  "ideal-checkout.nl": { script: true, frame: true },
  "ingenico.com": { script: true, frame: true },
  // Payment — core / international
  "js.braintreegateway.com": { script: true, frame: false },
  // CAPTCHA / bot protection
  "js.hcaptcha.com": { script: true, frame: false },
  // Payment — Benelux
  "js.mollie.com": { script: true, frame: true },
  // Payment — core / international
  "js.squareup.com": { script: true, frame: false },
  "js.stripe.com": { script: true, frame: false },
  "js.stripe.network": { script: true, frame: false },
  // JS libraries
  "jsdelivr.net": { script: true, frame: false },
  // Live streaming
  "jtvnw.net": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "jwpcdn.com": { script: true, frame: true },
  "jwplatform.com": { script: true, frame: true },
  "jwplayer.com": { script: true, frame: true },
  // Enterprise/education video
  "kaltura.com": { script: true, frame: true },
  // Payment — core / international
  "klarna.com": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "loom.com": { script: true, frame: true },
  "loomcdn.com": { script: true, frame: true },
  // Payment — France
  "lyra.com": { script: true, frame: true },
  // Payment — core / international
  "m.stripe.network": { script: true, frame: true },
  // Payment — Baltics
  "makecommerce.net": { script: true, frame: true },
  // Payment — Nordics
  "mobilepay.dk": { script: true, frame: true },
  // Payment — Benelux
  "mollie.com": { script: true, frame: true },
  // Payment — North America
  "moneris.com": { script: true, frame: true },
  // Payment — Benelux
  "multi-safepay.com": { script: true, frame: true },
  // Video infrastructure / delivery
  "mux.com": { script: true, frame: true },
  // Payment — Romania
  "netopia-payments.com": { script: true, frame: true },
  // Payment — Italy
  "nexi.it": { script: true, frame: true },
  // Payment — Benelux
  "noda.live": { script: true, frame: true },
  // Identity / SSO — Auth-as-a-service
  "okta.com": { script: true, frame: true },
  "onelogin.com": { script: true, frame: true },
  // Payment — Benelux
  "onlinepaymentplatform.nl": { script: true, frame: true },
  // Payment — UK / Ireland
  "opayo.co.uk": { script: true, frame: true },
  // Identity / SSO — Auth-as-a-service
  "openai.com": { script: true, frame: true },
  // Enterprise/education video
  "panopto.com": { script: true, frame: true },
  // Digital wallets
  "pay.google.com": { script: true, frame: true },
  // Payment — Benelux
  "pay.nl": { script: true, frame: true },
  // Payment — France
  "paybox.com": { script: true, frame: true },
  // Payment — DACH
  "payone.com": { script: true, frame: true },
  // Payment — core / international
  "paypal.com": { script: true, frame: true },
  "paypalobjects.com": { script: true, frame: true },
  // Payment — France
  "payplug.com": { script: true, frame: true },
  // Payment — Poland
  "payu.com": { script: true, frame: true },
  "payu.pl": { script: true, frame: true },
  // Open Banking
  "plaid.com": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "play.vidyard.com": { script: false, frame: true },
  // Live streaming
  "player.twitch.tv": { script: false, frame: true },
  // Video embeds — established hosted platforms only
  "player.vimeo.com": { script: false, frame: true },
  "players.brightcove.net": { script: true, frame: true },
  // Payment — Benelux
  "plugandpay.io": { script: true, frame: true },
  // Payment — Italy
  "postepay.it": { script: true, frame: true },
  // Payment — Benelux
  "pronamicpay.com": { script: true, frame: true },
  // Payment — Poland
  "przelewy24.pl": { script: true, frame: true },
  // Payment — DACH
  "ratepay.com": { script: true, frame: true },
  // CAPTCHA / bot protection
  "recaptcha.net": { script: true, frame: true },
  // Payment — Spain / Portugal
  "redsys.es": { script: true, frame: true },
  // JS libraries
  "registry.npmjs.org": { script: true, frame: false },
  // Fraud prevention — commonly loaded as iframes during checkout flows
  "riskified.com": { script: true, frame: true },
  // Payment — DACH
  "riverty.com": { script: true, frame: true },
  // Other embeddable platforms
  "rumble.com": { script: true, frame: true },
  // Payment — UK / Ireland
  "sagepay.com": { script: true, frame: true },
  // Payment — Italy
  "satispay.com": { script: true, frame: true },
  // Fraud prevention — commonly loaded as iframes during checkout flows
  "seon.io": { script: true, frame: true },
  "sift.com": { script: true, frame: true },
  "signifyd.com": { script: true, frame: true },
  // Payment — Nordics
  "siirto.fi": { script: true, frame: true },
  // Payment — Benelux
  "sisow.nl": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "sproutvideo.com": { script: true, frame: true },
  // CAPTCHA / bot protection
  "static.geetest.com": { script: true, frame: true },
  // Payment — Nordics
  "swish.nu": { script: true, frame: true },
  // Other embeddable platforms
  "ted.com": { script: true, frame: true },
  // Payment — Benelux
  "tikkie.nl": { script: true, frame: true },
  // Open Banking
  "tink.com": { script: true, frame: true },
  // Payment — Poland
  "tpay.com": { script: true, frame: true },
  // Open Banking
  "truelayer.com": { script: true, frame: true },
  "trustly.com": { script: true, frame: true },
  // CAPTCHA / bot protection
  "turnstile.cloudflare.com": { script: true, frame: true },
  // Payment — DACH
  "twint.ch": { script: true, frame: true },
  // JS libraries
  "unpkg.com": { script: true, frame: false },
  // Payment — DACH
  "unzer.com": { script: true, frame: true },
  // Payment — core / international
  "verifone.cloud": { script: true, frame: true },
  "verifone.com": { script: true, frame: true },
  // Video infrastructure / delivery
  "videodelivery.net": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "vimeocdn.com": { script: true, frame: true },
  // Payment — Nordics
  "vipps.no": { script: true, frame: true },
  "vippsmobilepay.com": { script: true, frame: true },
  // Open Banking
  "vyne.co.uk": { script: true, frame: true },
  // Payment — Nordics
  "walleypay.com": { script: true, frame: true },
  // Payment — Benelux
  "wero-wallet.eu": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "wistia.com": { script: true, frame: true },
  "wistia.net": { script: true, frame: true },
  // Identity / SSO — Auth-as-a-service
  "workos.com": { script: true, frame: true },
  // Payment — Benelux
  "worldline.com": { script: true, frame: true },
  // Payment — core / international
  "worldpay.com": { script: true, frame: true },
  "x.klarnacdn.net": { script: true, frame: true },
  // Video embeds — established hosted platforms only
  "youtu.be": { script: true, frame: true },
  "youtube-nocookie.com": { script: true, frame: true },
  "youtube.com": { script: true, frame: true },
  "ytimg.com": { script: true, frame: true },
};

// "Signal list" — domains commonly needed for "Login with X" flows, but
// deliberately NOT auto-allowed anywhere (unlike BUILTIN_DOMAINS above).
// These are broad, multi-purpose platforms (Facebook, GitHub, LinkedIn,
// Apple/Microsoft account domains) where blanket global whitelisting would
// be a much bigger privacy trade-off than the narrow-purpose auth-as-a-
// service providers above — blocking them by default is the right call,
// but the user should still be able to SEE that a domain is commonly
// needed for login, with better context than they'd otherwise have, and
// make the one-click decision themselves. Never generates a DNR rule —
// see core/rule-classifier.js's isSignalDomain() and the INTERNAL
// WHITELIST column's yellow state in Show Matrix.
export const SIGNAL_DOMAINS = {
  // Identity / SSO — Microsoft
  "account.microsoft.com": { script: false, frame: true },
  // Identity / SSO — Apple
  "appleid.apple.com": { script: false, frame: true },
  // Identity / SSO — Meta/Facebook
  "connect.facebook.net": { script: true, frame: false },
  "facebook.com": { script: false, frame: true },
  // Identity / SSO — GitHub
  "github.com": { script: false, frame: true },
  // Identity / SSO — Apple
  "idmsa.apple.com": { script: false, frame: true },
  // Identity / SSO — LinkedIn
  "linkedin.com": { script: false, frame: true },
  // Identity / SSO — Microsoft
  "login.live.com": { script: false, frame: true },
  "login.microsoftonline.com": { script: false, frame: true },
  "login.windows.net": { script: false, frame: true },
};

// Category lookup, kept separate from the script/frame flags above for
// readability — covers BOTH BUILTIN_DOMAINS and SIGNAL_DOMAINS (shared,
// since a domain is never in both). Used only for the INTERNAL WHITELIST
// column's explanatory tooltip in Show Matrix ("why was this domain
// trusted/flagged") — never consulted for the actual allow/block decision.
export const BUILTIN_DOMAIN_CATEGORY = {
  // Identity / SSO — Microsoft
  "account.microsoft.com": "Identity / SSO — Microsoft",
  // Payment — core / international
  "adyen.com": "Payment — core / international",
  // JS libraries
  "ajax.microsoft.com": "JS libraries",
  // CAPTCHA / bot protection
  "altcha.org": "CAPTCHA / bot protection",
  // Digital wallets
  "apple-pay-gateway-nc-pod.apple.com": "Digital wallets",
  "apple-pay-gateway.apple.com": "Digital wallets",
  // Identity / SSO — Apple
  "appleid.apple.com": "Identity / SSO — Apple",
  // CAPTCHA / bot protection
  "arkoselabs.com": "CAPTCHA / bot protection",
  // Payment — core / international
  "assets.braintreegateway.com": "Payment — core / international",
  // Identity / SSO — Auth-as-a-service
  "auth0.com": "Identity / SSO — Auth-as-a-service",
  // Payment — core / international
  "authorize.net": "Payment — core / international",
  // Payment — North America
  "bambora.com": "Payment — North America",
  // Payment — Benelux
  "bancontact.com": "Payment — Benelux",
  // Open Banking
  "banked.com": "Open Banking",
  // News publisher video players (proprietary embed domains)
  "bcove.video": "News publisher video players (proprietary embed domains)",
  // Payment — North America
  "beanstream.com": "Payment — North America",
  // Payment — Benelux
  "billink.nl": "Payment — Benelux",
  // Payment — Spain / Portugal
  "bizum.es": "Payment — Spain / Portugal",
  // Video embeds — established hosted platforms only
  "brightcove.com": "Video embeds — established hosted platforms only",
  // Payment — Benelux
  "buckaroo.nl": "Payment — Benelux",
  // CAPTCHA / bot protection
  "captcha.eu": "CAPTCHA / bot protection",
  // Payment — Benelux
  "ccv.eu": "Payment — Benelux",
  // Payment — core / international
  "cdn.checkout.com": "Payment — core / international",
  // Video embeds — established hosted platforms only
  "cdn.jwplayer.com": "Video embeds — established hosted platforms only",
  // News publisher video players (proprietary embed domains)
  "cdn.jwpltx.com": "News publisher video players (proprietary embed domains)",
  // CAPTCHA / bot protection
  "challenges.cloudflare.com": "CAPTCHA / bot protection",
  // Payment — core / international
  "checkout.com": "Payment — core / international",
  "checkout.stripe.com": "Payment — core / international",
  "checkoutshopper-live.adyen.com": "Payment — core / international",
  // CAPTCHA / bot protection
  "client-api.arkoselabs.com": "CAPTCHA / bot protection",
  // Video infrastructure / delivery
  "cloudflarestream.com": "Video infrastructure / delivery",
  // Payment — North America
  "clover.com": "Payment — North America",
  // Payment — Benelux
  "cm.com": "Payment — Benelux",
  // JS libraries
  "code.jquery.com": "JS libraries",
  // Payment — Czech / Slovakia
  "comgate.cz": "Payment — Czech / Slovakia",
  // Payment — DACH
  "computop.com": "Payment — DACH",
  // Identity / SSO — Meta/Facebook
  "connect.facebook.net": "Identity / SSO — Meta/Facebook",
  // Video embeds — established hosted platforms only
  "content.jwplatform.com": "Video embeds — established hosted platforms only",
  // Payment — core / international
  "cybersource.com": "Payment — core / international",
  // Video embeds — established hosted platforms only
  "dailymotion.com": "Video embeds — established hosted platforms only",
  "dmcdn.net": "Video embeds — established hosted platforms only",
  // Payment — North America
  "elavon.com": "Payment — North America",
  // News publisher video players (proprietary embed domains)
  "embed.mychannels.video": "News publisher video players (proprietary embed domains)",
  // Payment — DACH
  "eps-ueberweisung.at": "Payment — DACH",
  // JS libraries
  "esm.sh": "JS libraries",
  // Payment — Romania
  "euplatesc.ro": "Payment — Romania",
  // Payment — Baltics
  "every-pay.com": "Payment — Baltics",
  // Live streaming
  "ext-twitch.tv": "Live streaming",
  // Video embeds — established hosted platforms only
  "f.vimeocdn.com": "Video embeds — established hosted platforms only",
  // Identity / SSO — Meta/Facebook
  "facebook.com": "Identity / SSO — Meta/Facebook",
  // Video embeds — established hosted platforms only
  "fast.wistia.com": "Video embeds — established hosted platforms only",
  // Payment — North America
  "fiserv.com": "Payment — North America",
  "fisglobal.com": "Payment — North America",
  // Fraud prevention — commonly loaded as iframes during checkout flows
  "forter.com": "Fraud prevention — commonly loaded as iframes during checkout flows",
  // CAPTCHA / bot protection
  "friendlycaptcha.com": "CAPTCHA / bot protection",
  "geetest.com": "CAPTCHA / bot protection",
  // News publisher video players (proprietary embed domains)
  "geo.dailymotion.com": "News publisher video players (proprietary embed domains)",
  // Payment — Nordics
  "getswish.se": "Payment — Nordics",
  // Identity / SSO — GitHub
  "github.com": "Identity / SSO — GitHub",
  // Payment — UK / Ireland
  "gocardless.com": "Payment — UK / Ireland",
  // Video embeds — established hosted platforms only
  "googleapis.com": "Video embeds — established hosted platforms only",
  // Digital wallets
  "googlepay.com": "Digital wallets",
  // Video embeds — established hosted platforms only
  "googlevideo.com": "Video embeds — established hosted platforms only",
  // Payment — Czech / Slovakia
  "gopay.com": "Payment — Czech / Slovakia",
  // CAPTCHA / bot protection
  "gstatic.com": "CAPTCHA / bot protection",
  "hcaptcha.com": "CAPTCHA / bot protection",
  // Payment — DACH
  "heidelpay.com": "Payment — DACH",
  // Payment — North America
  "helcim.com": "Payment — North America",
  // Payment — core / international
  "hooks.stripe.com": "Payment — core / international",
  // Video embeds — established hosted platforms only
  "i.vimeocdn.com": "Video embeds — established hosted platforms only",
  // Payment — Benelux
  "ideal-checkout.nl": "Payment — Benelux",
  // Identity / SSO — Apple
  "idmsa.apple.com": "Identity / SSO — Apple",
  // Payment — Benelux
  "ingenico.com": "Payment — Benelux",
  // Payment — core / international
  "js.braintreegateway.com": "Payment — core / international",
  // CAPTCHA / bot protection
  "js.hcaptcha.com": "CAPTCHA / bot protection",
  // Payment — Benelux
  "js.mollie.com": "Payment — Benelux",
  // Payment — core / international
  "js.squareup.com": "Payment — core / international",
  "js.stripe.com": "Payment — core / international",
  "js.stripe.network": "Payment — core / international",
  // JS libraries
  "jsdelivr.net": "JS libraries",
  // Live streaming
  "jtvnw.net": "Live streaming",
  // Video embeds — established hosted platforms only
  "jwpcdn.com": "Video embeds — established hosted platforms only",
  "jwplatform.com": "Video embeds — established hosted platforms only",
  "jwplayer.com": "Video embeds — established hosted platforms only",
  // Enterprise/education video
  "kaltura.com": "Enterprise/education video",
  // Payment — core / international
  "klarna.com": "Payment — core / international",
  // Identity / SSO — LinkedIn
  "linkedin.com": "Identity / SSO — LinkedIn",
  // Identity / SSO — Microsoft
  "login.live.com": "Identity / SSO — Microsoft",
  "login.microsoftonline.com": "Identity / SSO — Microsoft",
  "login.windows.net": "Identity / SSO — Microsoft",
  // Video embeds — established hosted platforms only
  "loom.com": "Video embeds — established hosted platforms only",
  "loomcdn.com": "Video embeds — established hosted platforms only",
  // Payment — France
  "lyra.com": "Payment — France",
  // Payment — core / international
  "m.stripe.network": "Payment — core / international",
  // Payment — Baltics
  "makecommerce.net": "Payment — Baltics",
  // Payment — Nordics
  "mobilepay.dk": "Payment — Nordics",
  // Payment — Benelux
  "mollie.com": "Payment — Benelux",
  // Payment — North America
  "moneris.com": "Payment — North America",
  // Payment — Benelux
  "multi-safepay.com": "Payment — Benelux",
  // Video infrastructure / delivery
  "mux.com": "Video infrastructure / delivery",
  // Payment — Romania
  "netopia-payments.com": "Payment — Romania",
  // Payment — Italy
  "nexi.it": "Payment — Italy",
  // Payment — Benelux
  "noda.live": "Payment — Benelux",
  // Identity / SSO — Auth-as-a-service
  "okta.com": "Identity / SSO — Auth-as-a-service",
  "onelogin.com": "Identity / SSO — Auth-as-a-service",
  // Payment — Benelux
  "onlinepaymentplatform.nl": "Payment — Benelux",
  // Payment — UK / Ireland
  "opayo.co.uk": "Payment — UK / Ireland",
  // Identity / SSO — Auth-as-a-service
  "openai.com": "Identity / SSO — Auth-as-a-service",
  // Enterprise/education video
  "panopto.com": "Enterprise/education video",
  // Digital wallets
  "pay.google.com": "Digital wallets",
  // Payment — Benelux
  "pay.nl": "Payment — Benelux",
  // Payment — France
  "paybox.com": "Payment — France",
  // Payment — DACH
  "payone.com": "Payment — DACH",
  // Payment — core / international
  "paypal.com": "Payment — core / international",
  "paypalobjects.com": "Payment — core / international",
  // Payment — France
  "payplug.com": "Payment — France",
  // Payment — Poland
  "payu.com": "Payment — Poland",
  "payu.pl": "Payment — Poland",
  // Open Banking
  "plaid.com": "Open Banking",
  // Video embeds — established hosted platforms only
  "play.vidyard.com": "Video embeds — established hosted platforms only",
  // Live streaming
  "player.twitch.tv": "Live streaming",
  // Video embeds — established hosted platforms only
  "player.vimeo.com": "Video embeds — established hosted platforms only",
  "players.brightcove.net": "Video embeds — established hosted platforms only",
  // Payment — Benelux
  "plugandpay.io": "Payment — Benelux",
  // Payment — Italy
  "postepay.it": "Payment — Italy",
  // Payment — Benelux
  "pronamicpay.com": "Payment — Benelux",
  // Payment — Poland
  "przelewy24.pl": "Payment — Poland",
  // Payment — DACH
  "ratepay.com": "Payment — DACH",
  // CAPTCHA / bot protection
  "recaptcha.net": "CAPTCHA / bot protection",
  // Payment — Spain / Portugal
  "redsys.es": "Payment — Spain / Portugal",
  // JS libraries
  "registry.npmjs.org": "JS libraries",
  // Fraud prevention — commonly loaded as iframes during checkout flows
  "riskified.com": "Fraud prevention — commonly loaded as iframes during checkout flows",
  // Payment — DACH
  "riverty.com": "Payment — DACH",
  // Other embeddable platforms
  "rumble.com": "Other embeddable platforms",
  // Payment — UK / Ireland
  "sagepay.com": "Payment — UK / Ireland",
  // Payment — Italy
  "satispay.com": "Payment — Italy",
  // Fraud prevention — commonly loaded as iframes during checkout flows
  "seon.io": "Fraud prevention — commonly loaded as iframes during checkout flows",
  "sift.com": "Fraud prevention — commonly loaded as iframes during checkout flows",
  "signifyd.com": "Fraud prevention — commonly loaded as iframes during checkout flows",
  // Payment — Nordics
  "siirto.fi": "Payment — Nordics",
  // Payment — Benelux
  "sisow.nl": "Payment — Benelux",
  // Video embeds — established hosted platforms only
  "sproutvideo.com": "Video embeds — established hosted platforms only",
  // CAPTCHA / bot protection
  "static.geetest.com": "CAPTCHA / bot protection",
  // Payment — Nordics
  "swish.nu": "Payment — Nordics",
  // Other embeddable platforms
  "ted.com": "Other embeddable platforms",
  // Payment — Benelux
  "tikkie.nl": "Payment — Benelux",
  // Open Banking
  "tink.com": "Open Banking",
  // Payment — Poland
  "tpay.com": "Payment — Poland",
  // Open Banking
  "truelayer.com": "Open Banking",
  "trustly.com": "Open Banking",
  // CAPTCHA / bot protection
  "turnstile.cloudflare.com": "CAPTCHA / bot protection",
  // Payment — DACH
  "twint.ch": "Payment — DACH",
  // JS libraries
  "unpkg.com": "JS libraries",
  // Payment — DACH
  "unzer.com": "Payment — DACH",
  // Payment — core / international
  "verifone.cloud": "Payment — core / international",
  "verifone.com": "Payment — core / international",
  // Video infrastructure / delivery
  "videodelivery.net": "Video infrastructure / delivery",
  // Video embeds — established hosted platforms only
  "vimeocdn.com": "Video embeds — established hosted platforms only",
  // Payment — Nordics
  "vipps.no": "Payment — Nordics",
  "vippsmobilepay.com": "Payment — Nordics",
  // Open Banking
  "vyne.co.uk": "Open Banking",
  // Payment — Nordics
  "walleypay.com": "Payment — Nordics",
  // Payment — Benelux
  "wero-wallet.eu": "Payment — Benelux",
  // Video embeds — established hosted platforms only
  "wistia.com": "Video embeds — established hosted platforms only",
  "wistia.net": "Video embeds — established hosted platforms only",
  // Identity / SSO — Auth-as-a-service
  "workos.com": "Identity / SSO — Auth-as-a-service",
  // Payment — Benelux
  "worldline.com": "Payment — Benelux",
  // Payment — core / international
  "worldpay.com": "Payment — core / international",
  "x.klarnacdn.net": "Payment — core / international",
  // Video embeds — established hosted platforms only
  "youtu.be": "Video embeds — established hosted platforms only",
  "youtube-nocookie.com": "Video embeds — established hosted platforms only",
  "youtube.com": "Video embeds — established hosted platforms only",
  "ytimg.com": "Video embeds — established hosted platforms only",
};
