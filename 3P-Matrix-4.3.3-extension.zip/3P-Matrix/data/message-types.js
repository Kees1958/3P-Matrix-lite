// ── data/message-types.js ─────────────────────────────────────────────────────
// Named constants for every chrome.runtime message. A typo becomes a
// ReferenceError instead of a silently unhandled message.
// ─────────────────────────────────────────────────────────────────────────────

// popup → SW
export const MSG_GET_POPUP_STATE   = "GET_POPUP_STATE";    // { tabId } → view model for the popup
export const MSG_SET_LEVEL         = "SET_LEVEL";          // { level, tabId } — global session level
export const MSG_SET_STARTUP_LEVEL = "SET_STARTUP_LEVEL";  // { level }
export const MSG_TOGGLE_LOCK       = "TOGGLE_LOCK";        // { site, level, tabId } — lock/unlock a site
export const MSG_SET_PROTECTION    = "SET_PROTECTION";     // { key, enabled }
export const MSG_SET_SAFE_ZONE     = "SET_SAFE_ZONE";      // { addTld?, removeTld?, restoreDefault? }

// popup / matrix panel → SW (Show Matrix)
export const MSG_OPEN_MATRIX       = "OPEN_MATRIX";        // { tabId, url } — start observing, open the panel window, reload the tab
export const MSG_STOP_MATRIX       = "STOP_MATRIX";        // { tabId }
export const MSG_GET_MATRIX_DATA   = "GET_MATRIX_DATA";    // { tabId } → rows + overrides + level
export const MSG_SET_MATRIX_RULE   = "SET_MATRIX_RULE";    // { tabId, domain, scope, action|null }
export const MSG_RELOAD_TAB        = "RELOAD_TAB";         // { tabId }

// warning page → SW
export const MSG_EVALUATE_SITE     = "EVALUATE_SITE";      // { url } → full (stage 1 + 2) result
export const MSG_WARNING_ACTION    = "WARNING_ACTION";     // { action, url, tabId }

// download warning page / VirusTotal key prompt → SW (protection 12, 4.3.0)
export const MSG_GET_DOWNLOAD_CHECK  = "GET_DOWNLOAD_CHECK";  // {} → { record, look } for the sender's ?downloadId= (C28)
export const MSG_DISMISS_DOWNLOAD    = "DISMISS_DOWNLOAD";    // {} — the user is done: release the check
export const MSG_VT_KEY_PROMPT_DONE  = "VT_KEY_PROMPT_DONE";  // { dontShowAgain } — nudge closed
// download-blocked notice → SW (protection 18, 4.3.2) — the download id comes from the sender's URL (C28)
export const MSG_GET_BLOCKED_DOWNLOAD    = "GET_BLOCKED_DOWNLOAD";    // {} → notice model or null
export const MSG_BLOCKED_DOWNLOAD_ACTION = "BLOCKED_DOWNLOAD_ACTION"; // { action: BLOCKED_DOWNLOAD_ACTION.* }

// options page → SW
export const MSG_GET_OPTIONS       = "GET_OPTIONS";
export const MSG_SET_DNS           = "SET_DNS";            // { first, second }
export const MSG_SET_ALLOW_LIST    = "SET_ALLOW_LIST";     // { text }
export const MSG_SET_DOWNLOAD_SETTINGS = "SET_DOWNLOAD_SETTINGS"; // { settings: partial state.downloads, never vtApiKey }
export const MSG_SET_VT_KEY        = "SET_VT_KEY";         // { key } — "" clears the VirusTotal API key
export const MSG_EXPORT_SETTINGS   = "EXPORT_SETTINGS";
export const MSG_IMPORT_SETTINGS   = "IMPORT_SETTINGS";    // { settings }
export const MSG_RESET_SETTINGS    = "RESET_SETTINGS";

// Warning-dialog actions (MSG_WARNING_ACTION.action)
export const WARNING_ACTION = Object.freeze({
  GO_BACK:       "goBack",
  TRUST:         "trust",
  CONTINUE_ONCE: "continueOnce"
});

// Download-blocked notice actions (MSG_BLOCKED_DOWNLOAD_ACTION.action)
export const BLOCKED_DOWNLOAD_ACTION = Object.freeze({
  OK:               "ok",                // keep it blocked, close the notice
  DOWNLOAD_ANYWAY:  "downloadAnyway"     // download once more; protection 12 then checks it
});
