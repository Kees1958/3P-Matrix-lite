# Changelog History — 3P Matrix — content firewall

Full technical record of releases: what changed, why, how, known limitations and the source worked from.
Policy as in uBlock Stripped Dynamic (Xplainer_Programming_principles_audit_v5.md, B4): written for big
changes only, before the zip. The brief user-facing summary is CHANGELOG.md.

Release packages: `3P-Matrix-<ver>-extension.zip` (folder `3P-Matrix`), `3P-Matrix-<ver>-tools.zip`
(folder `3P-Matrix-tools`), `3P-Matrix-<ver>-docs.zip` (folder `3P-Matrix-docs`, first released with 0.2.2).

Source extensions (all uploaded 2026-10-16): 3P-Matrix-lite 4.0.2, uBlock Stripped Dynamic 10.2.1
(+ tools 2.0.18, docs), DownloadSentinel 3.0.4 (extension + tools). Their change histories are in `sources/`.

---

## 4.1.1 — dead-code cleanup; Show Matrix help text made bold+caps; "Req." renamed "REQUESTS"

Working from: 4.1.0. Zips changed: extension, tools (build-spam-tlds.mjs only), docs.

**What / why**: user asked to remove all dead/unused code from the extension.

**How (method)**: ESLint (`no-unused-vars`/`no-undef`, flat config, not part of the shipped tools —
ad hoc for this pass) over every `.js` file found zero unused locals or imports anywhere in the
codebase. A second pass cross-referenced every `export`ed symbol against the whole tree (including
`.html` files) for a second occurrence; combined with a per-file reachability check (every `security/`
content script is referenced by path string from `data/protections.js`; every `lib/downloadsentinel/`
module and its `*.default.js` counterpart is imported at least once), this found exactly 4 orphaned
exports in ~35 files — the codebase was already very clean.

**Removed**:
- `data/constants.js`: `EXT_SHORT_NAME`, `EXT_TAGLINE` (never imported; manifest.json's own `name`/
  `short_name`/`description` are separate literal strings and were never meant to read these back),
  `OPTIONS_PAGE` (never imported; the options page is opened by Chrome itself via manifest.json's
  `options_ui.page`, never from our own code).
- `data/spam-tlds.js` + `tools/build-spam-tlds.mjs`: `SPAM_TLDS_VERSION` — the HaGeZi list version,
  exported but never read anywhere; the same version string is already in the generated file's own
  header comment (line 2), so the export was pure duplication. Removed from the generator too, so it
  doesn't reappear on the next `node tools/build-spam-tlds.mjs` run. Verified: regenerating from the
  same input (`tools/spam-tlds-ublock.txt`) with the edited generator produces a byte-identical
  `data/spam-tlds.js` to the hand-edited version (diff clean).

**Also in this release**: user asked for the Show Matrix "Rules apply on every site…" help line to
stand out (bold, upper case) and for the "Req." column header to read "REQUESTS" in full.
`ui/matrix.css` `.mx-help-line` gets `font-weight: bold; text-transform: uppercase` (sentence stays
normal-case in the HTML source; CSS renders it upper case). `ui/matrix.html`'s `Req.` header text
changed to `REQUESTS`; `.col-num` width increased from 52px to 76px so the longer label doesn't wrap —
checked with a headless-browser screenshot of the empty panel, header sits on one line, Seen/Override
columns unaffected.

**Verified**: `node --check` over every `.js` file; the 4.1.0 Show Matrix verification script re-run
clean; ESLint re-run against the edited files, zero warnings; visual check via Playwright screenshot
(not part of the shipped tools — ad hoc for this pass).

**Not removed (flagged, not a clear case)**: nothing else qualified. If something later turns out
unused (a future refactor, a removed protection), re-run the same ESLint pass first.

**Verified**: full `node --check` over every `.js` file; the 4.1.0 Show Matrix verification script
re-run clean against the final tree; ESLint re-run against the two edited files, zero warnings.

## 4.1.0 — version renumbered to match 3P-Matrix-lite; Show Matrix overrides become global

Working from: 0.2.5. Zips changed: extension, docs. Tools repackaged unchanged (spam-tlds builder only).

**What / why**: the user asked to bring this extension's versioning in line with 3P-Matrix-lite (currently
4.0.2) and, separately, to review how Show Matrix overrides should carry across from lite — lite's
equivalent override is global (blocks/allows a third party on every site), while this extension's was
always scoped to the one site you set it on. Decided: make global the default behaviour here too, so a
converted lite rule needs no lossy translation and the two extensions' "block this third party" means
the same thing. A literal per-site rule (pre-4.1 saved data, or a future manual override) is still
supported and always outranks a global rule for the same third party — see `data/constants.js`.

**How**
- `data/constants.js`: new sentinel `MATRIX_SITE_ALL = "*"`, the single declared meaning of "every site"
  as a `matrixRules` key. `PRIORITY.MATRIX_ALL`/`MATRIX_CODE` split into four: `MATRIX_ALL_GLOBAL`,
  `MATRIX_CODE_GLOBAL`, `MATRIX_ALL_SITE`, `MATRIX_CODE_SITE` — site tier strictly above global tier,
  CODE still above ALL within each tier, so a legacy per-site rule always wins a conflict.
- `core/rule-builder.js` `buildMatrixRules()`: a `matrixRules` entry keyed `MATRIX_SITE_ALL` builds a DNR
  condition with no `initiatorDomains` at all (applies everywhere); any other key still sets
  `initiatorDomains: [siteKey]` as before, just on the SITE priority tier instead of the old flat one.
- `background.js` `MSG_SET_MATRIX_RULE`: now always writes to the `MATRIX_SITE_ALL` key instead of the
  tab's current host; the tab's host is still read as a guard (Show Matrix must be actively tracking that
  tab) but no longer used as the storage key. `matrixModel()` merges `matrixRules["*"]` with any legacy
  per-site entry for the currently observed site (new `mergedMatrixOverrides()`, site wins per scope) so
  the panel shows the correct effective state either way.
- `data/state-storage.js` `normalizeState()`: the matrixRules host-validity guard now accepts the literal
  `MATRIX_SITE_ALL` key in addition to a real hostname (everything else is still rejected and dropped,
  same as before).
- `ui/matrix.html` / `ui/matrix.js`: help text and header comment updated ("Rules apply on every site,
  not just this one") — no behavioural change in the UI itself, the 3P-code/3P-all buttons work exactly
  as before, only what they write changed.
- `data/settings-io.js`: comment only — `showMatrixRules`' shape in the settings-backup format is
  unchanged; `"*"` is just a valid siteKey now, so existing backups still round-trip.

**Verified**: a one-off Node script (not shipped) exercised `buildMatrixRules()` and `normalizeState()`
directly — global rule has no `initiatorDomains` and the GLOBAL priority; a legacy site rule keeps
`initiatorDomains` and the SITE priority; a global BLOCK and a conflicting legacy site ALLOW for the same
domain both produce a rule, with the site one's priority strictly higher; `normalizeState()` keeps a `"*"`
key and still drops an invalid one. A mutation check confirmed the test would have failed against the old
(always-per-site) `buildMatrixRules()`, so it genuinely exercises the new behaviour, not a tautology.

**Not done / deliberately out of scope**: no settings-file importer from 3P-Matrix-lite was built — lite
has no settings-export feature of its own to import from, and the user confirmed this release is scope
("feature/defaults parity", not a file converter). No further lite-vs-firewall defaults audit was done
beyond the Show Matrix question — raise anything else you want checked for parity as its own request.

## 0.2.5 — version bump: packages the full 0.2.4 working-copy session as its own release

Working from: 0.2.4 zips (packaged after only the protection-10/safer-regions-slider/Five-Eyes work).
Everything below happened in the same working session but after those zips went out, so it ships here
instead, to keep a clean record of what each zip actually contains.

## 0.2.4 — suspicious-site warning becomes protection 10; safer-regions slider removed; built-in
   whitelist gains streaming/meeting/gaming + a first-party exemption from protections 9/11–15

Working from: 0.2.3. Zips changed: extension, docs. Tools repackaged unchanged.

**What / why**: the user wants the warning for suspicious websites as one of the protections, selectable in
the popup, so "On every site" has 10 protections again (it had 9 after 0.2.3 removed two).

**How**
- `data/protections.js`: new entry `warnSuspiciousSites` (num 10, from L2, every site, new mechanism
  `MECH.NAVIGATION` — no DNR rules, no content script). New `PROTECTION_KEY` enum holds the key for modules
  that test it directly. Level-3 protections renumbered 10–14 → 11–15 (keys, rule ids, priorities unchanged).
- `core/navigation-guard.js`: the old gate `effectiveLevel < LEVEL.MILD` is replaced by
  `isProtectionActive(state, PROTECTION_KEY.WARN_SUSPICIOUS_SITES, effectiveLevel)` — same result while
  ticked; unticked = no stage 1 scoring, no warning dialog (so no stage 2 online checks), badge risk neutral.
  Honours locks: a site locked at L2+ is warned even at global L1, if the protection is ticked.
- `background.js` popupModel: `warningsOn` flag. `ui/popup.js`: bullet "Warnings for suspicious sites" (level
  colour) or "Warnings for suspicious sites off" (neutral) at every level ≥ 2; L4/L5 "N + domain warnings"
  became "N active" + that bullet (the warning is now inside N, so "+" would double count).
- `ui/options.html`: online-checks text says they belong to protection 10.
- Popup bullets (user: redundant once the warning became protection 10): `ui/popup.js` bulletsFor() drops the
  per-bullet `warn`/`warningBullet()` added earlier this release; L4/L5's "N + domain warnings" stays "N
  active" (already fixed in the first 0.2.4 pass). `background.js` popupModel: `warningsOn` removed (nothing
  read it any more) along with its now-unused `isProtectionActive`/`PROTECTION_KEY` imports.
- `ui/popup.css`: `.prot-item.off` no longer dims or strikes through the label (user: unreadable); the
  checkbox alone shows the state. The class is kept as a styling hook.
- Builders untouched: rule-builder and script-builder only act on DNR/HEADER/SCRIPT mechanisms.
- Old saved states have no `warnSuspiciousSites` entry in disabledProtections → ticked (previous behaviour).
  Settings files: no format change (protections.disabled is a key list).
- Stale numbers in comments fixed with the renumber (constants, rule-builder, suspicious-hosting.js said 8
  instead of 6, sec-nfc.js said 14 instead of 13). SPEC brought to the 15-protection list (was still 16).
- `manifest.json` 0.2.3 → 0.2.4. No permission change.

**Safer-regions slider removed** (user: "remove the slider from level 3 for the TLD whitelist and set it
standard the same way as uBlock Dynamic does"). uBlock Stripped Dynamic since 0.0.3 hardcodes 3P-Matrix-lite's
mode 2 "Continent" with no slider (its CHANGELOG_HISTORY 0.0.3: "Explicitly NOT ported: … 4-position slider").
- `data/constants.js`: `DEFAULT_AUTO_TLD_MODE` + `AUTO_TLD_LABELS` replaced by one fixed switch
  `SAFER_REGIONS_AUTO_MODE = 2` (= AUTO_TLD_MODE.CONTINENT). `core/safer-regions.js` guards it (invalid value →
  logged, CONTINENT used) and passes it to the unchanged pure engine `core/tld-engine.js` (comments only).
- State: `safeZone.autoTldMode` removed from the schema; normalizeState() drops a stored value (≤ 0.2.3).
- `background.js` onInstalled recomputes the list for EVERY reason (was install only), so updating users who
  had chosen None/Browser/Worldwide move to Continent at once; their added/removed TLDs are kept.
  MSG_SET_SAFE_ZONE: `autoTldMode` input gone; restoreDefault clears added/removed TLDs. popupModel no longer
  sends the mode or labels.
- Popup: slider, its label row and CSS removed; one intro line explains the default.
- Settings file: `saferRegions.autoAddCountryCodes` no longer written, ignored on restore (format stays v2 —
  missing/extra field is compatible). Summary line no longer shows the mode.
- HaGeZi guard (user: "keep them out when they are on HaGeZi"): `SAFER_REGIONS_SKIP_ABUSED_TLDS = true`;
  core/safer-regions.js drops merged TLDs that are in SPAM_TLDS unless hand-added (manualTlds). Of the 215
  possible auto-added ccTLDs, 7 are on the list today: cf cm ga gq ml ng pw. Test: fr-CM → none of them;
  hand-added cm kept; nl+en list unchanged (3/3).
**Built-in whitelist: streaming, meeting, gaming** (user: "the built-in whitelist should also contain
video and streaming"; follow-up: all three categories, since meeting/gaming weren't removed, just never
ported). `data/builtin-domains.js` restructured into CORE_* (payment/SSO/CAPTCHA/video/JS, unchanged) plus
new STREAMING_*/MEETING_*/GAMING_BOTH sub-arrays, composed into the existing BUILTIN_BOTH/SCRIPT_ONLY/
FRAME_ONLY exports via a dedupe-and-sort merge (`mergedSorted()`) — same exported shape, so every existing
consumer (rule-builder, script-builder, navigation-guard) needed no change for this part. Hand-curated,
not from a live source; limited to services with a genuine embeddable iframe/script (the point of THIS
list is third-party embeds) — Netflix/Disney+/Hulu/Max/Prime Video/Paramount+/Peacock/Crunchyroll (video),
Xbox/PlayStation/Nintendo/Epic/Riot (gaming) and WhatsApp/Telegram/Signal/Slack/Google Meet (meeting) have
no such embed and are deliberately left out — confirmed with the user this asymmetry was intentional
(uBD's own 99-domain list, not in the uploaded files, was not used verbatim).

**Built-in whitelist also exempts protections 9/11–15 on a first-party visit** (user correction: "it
should also apply on the protections" — an initial assumption that this list affects only third-party
embeds was wrong). Two call sites changed, both gated to levels 3–4 only (never 5, matching the existing
3P-content exemption's own level range — `BUILTIN_EXEMPT_LEVELS`/`BUILTIN_ALL` imported where needed):
- `core/rule-builder.js` headerRules(): `outsideSafe` (feeds the Permissions-Policy/CSP header rules for
  9, 11–13, 15) now merges the existing safer-regions-TLD exclusion with a new built-in-whitelist
  exclusion via `cond()`, independently of `saferRegionsApply` (which is level-3-only) — so built-in
  hosts are exempt at level 4 too, where the TLD exemption never applies.
- `core/script-builder.js` registrationsFor(): the SCOPE.OUTSIDE_SAFER_REGIONS content scripts
  (blockSensorsNfc's NFC half, blockObfuscatedEval) get a parallel `inBuiltin()`/`globalBuiltinExclude`
  alongside the existing `inSafer()`/`globalSaferExclude`, at both the per-lock (`runsOnLock`) and global
  (blanket `excludeMatches`) levels. A site locked at level 5 overrides the built-in exemption, same as it
  already overrode the safer-regions one — new rescue registration (id suffix `-builtin-locked`,
  mirroring the existing `-locked` safer-regions rescue) re-includes such a site, since the blanket
  level-3/4 built-in exclude would otherwise hide it.
- Most of the new streaming/meeting/gaming domains are `.com`/`.io`/`.net`, already in BASE_TLDS (the
  safer-regions default), so at level 3 they were already incidentally exempt; the real effect of this
  fix is at level 4 (where the TLD exemption never applies at all) and for `zoom.us` (`.us`, not a default
  TLD) at any level. Confirmed by testing with an empty safer-region TLD list to isolate the mechanism.
- `background.js`/`ui/popup.js`'s earlier 0.2.4 pass added a per-bullet line for protection 10 that
  duplicated its own name in the Protections list; removed (user: "it is part of the 15 protections so
  the text is redundant") — the aggregate "N of 15 protections active" count already covers it, same as
  every other single protection. `warningsOn` dropped from the popup view model; its now-unused
  `isProtectionActive`/`PROTECTION_KEY` imports removed from `background.js`.

**Tests (built-in whitelist)**: Node 21/21 — no duplicate or unsorted entries across the merged
categories, every new domain present, Netflix/Xbox absent. Header-rule test (5/5): zoom.us/discord.com
excluded from the Permissions-Policy main_frame condition at L3 and L4. Script-builder test (12/12, safer-
region list emptied to isolate the mechanism): zoom.us/discord.com excluded from blockObfuscatedEval's
content script at L2–4, not excluded at L5; the realistic-defaults case at L4 (where .com/.io overlap
doesn't apply) confirms zoom.us is excluded only because of the builtin fix; a site locked at L5 gets the
rescue registration and runs the protection; a site locked at L3 under global L1 is correctly held back
by its own builtin-exempt level, while a genuinely non-builtin site in the same scenario still runs.
Chromium (unpacked, dynamic rules + registered content scripts read back live): confirmed at L3 and L4.
Earlier 0.2.4 suites still pass (23 + 8 + 3).

- Clearer protection text (user: "the protections are very short... make them a little more clear"):
  `data/protections.js` PROTECTIONS[].label rewritten as plain sentences for all 15 (e.g. "No camera, mic,
  screen, clipboard-read" → "Block camera, mic, screen-share and clipboard reads"). `ui/popup.css`
  `.prot-item`/`.p-label` drop the single-line `white-space: nowrap; overflow: hidden; text-overflow:
  ellipsis` truncation (`align-items: flex-start`, line-height, small top margins on the checkbox/number
  so they sit level with the first line) — a label now wraps to two lines instead of being cut off with
  an ellipsis; only #15 needs it at 400px width. Purely a label/CSS change — `key`/`num`/`fromLevel`/
  mechanism untouched, so no test depends on label text; full 72-check suite re-run unaffected.
- Built-in-whitelist summary line (same request, "the description of the whitelist should be changed"):
  `ui/popup.js` bulletsFor() builtin bullet — was "Built-in whitelist: payment, login, CAPTCHA" (stale
  since the streaming/meeting/gaming addition above), now "Trusted: payment, sign-in, streaming,
  meetings, games". Checked by measuring scrollWidth vs clientWidth in Chromium (no ellipsis cutoff) —
  a longer draft that also named CAPTCHA was clipped and was shortened to fit.
- Popup layout (user request): `ui/popup.html` moves the two `.safe-intro` paragraphs to after `#tldTags`
  (was before the Add row). `ui/popup.css` `.tags` drops `max-height: 110px; overflow-y: auto` — the tag list
  grows to fit its content instead of scrolling inside a fixed box.
- `core/tld-engine.js` LANG_WORLD_DEFAULTS.en: `nz` added (user decision) — completes the Five Eyes for a bare
  "en" tag; the one deliberate difference from uBD's country-code default. Not on HaGeZi.
- Base TLDs unchanged: 3P Matrix keeps its 13 (uBD's 18 generic TLDs minus biz/shop/store/site/online, which
  are HaGeZi-abused — spec decision). Only the country-code part follows uBD.

**Tests (slider)**: Node 8/8 — default state has no mode; a 0.2.3 state with autoTldMode 0 normalises without it
and keeps its edits; nl-NL+en-US+en → base + nl, us, uk, ie, au, ca, eu, be, mt, im; added/removed honoured;
settings round trip; a 0.2.3 file with "WORLDWIDE" restores. Chromium at L3: no slider, 29 TLDs, Add/× /Default
work, stored safeZone = {manualTlds, excludedTlds, tlds}, no console errors. Earlier suite still 23/23.

**Tests**: unit (Node, chrome mocked) 23/23 — registry 15 entries, nums 1–15, group "On every site" = 10;
counts 10/10 at L2 and 15 at L3; old 0.2.3 state normalises with the warning ticked; DNR rules and script
registrations byte-identical with the warning on/off; guard: dialog at L2/L5 when ticked, none when unticked,
none at L1 or for allow-listed sites, dialog for a site locked at L4 under global L1. Chromium (unpacked
extension): suspicious URL → warning page; untick 10 in the popup → page opens without dialog, popup shows
"9 of 10 protections active · Warnings for suspicious sites off"; re-tick → dialog again; 5 scripts at L2.

WARNING FOR IMPLEMENTATION IMPACT: protection numbers 10–14 shown in the popup become 11–15.

**Known limitations**: the 0.2.3 upgrade-test limitation (content scripts not re-registered after swapping
unpacked files) is not addressed here; this release changes no content-script registrations.

## 0.2.3 — protections 1 and 2 removed
Working from: 0.2.2. Zips changed: extension, docs. Tools repackaged unchanged.

**What / why**: the user keeps "Clear history at browser start" (deleteHistoryOnStart) and "Block tracking
pings" (blockPings) in uBlock Stripped Dynamic and does not want them duplicated here.

**How**
- `data/protections.js`: both entries dropped, remaining 14 renumbered (num 1–14), `MECH.STARTUP` removed
  (no startup-mechanism protection is left). A comment records what was removed and when.
- `background.js`: `clearHistoryOncePerLaunch()` and its SESSION_KEY_BOOTED guard removed; onStartup now only
  restores the startup level and applies. `data/constants.js`: SESSION_KEY_BOOTED removed.
- `manifest.json`: `browsingData` permission dropped — an update that only REMOVES a permission does not
  disable the extension for existing users (the reverse would; see the principles doc, C36).
- Old saved state is cleaned automatically: `normalizeState()` keeps only keys in PROTECTION_KEYS, so
  `deleteHistoryOnStart` / `blockPings` entries in disabledProtections disappear on first load.
- Protection numbers in comments across constants, rule-builder, network-data and README renumbered with the
  registry (ids, priorities and keys unchanged — only display numbers shifted).
- `core/apply-manager.js` guard added (see limitations): our script ids are unregistered one at a time so a
  stale id from a previous version cannot abort the batch; after registering, the set is read back and, on a
  mismatch, re-registered one by one with per-id errors logged.

**Tests**: builders 9/9 protections at L2 and 14 at L3+; safer-levels 14/14; matcher 19/19; settings save +
restore round trip ("14 of 14 protections on"); Chromium fresh install registers the expected 5 scripts at L2
and 7 at L3.

WARNING FOR IMPLEMENTATION IMPACT: history is no longer cleared at browser start and tracking pings are no
longer blocked by 3P Matrix — uBlock Stripped Dynamic must cover both. The protection numbers users see in
the popup shift by two (old 3 = new 1).

**Known limitations**: in a test that upgrades an existing 0.2.2 profile to 0.2.3 by swapping the unpacked
files, no content scripts were registered afterwards (a fresh install is correct, and dynamic DNR rules were
applied). The apply-manager guard above did not change that result and the cause is not yet identified — it
may be an artifact of how the test fakes an update. Workaround: reload the extension in chrome://extensions
after updating. To investigate next: whether Chrome keeps the previous version's persisted registrations
(including `tldm-blockPings`, whose file no longer exists) in a state where getRegisteredContentScripts()
reports nothing while registerContentScripts() silently does not take effect.

---

## 0.2.2 — safer regions at level 3 only; Show Matrix auto-close; dead code removed
Working from: 0.2.1 working tree. Zips changed: extension, docs (new). Tools zip repackaged with unchanged content.

**What / why**
- Safer regions now have an effect at level 3 only (user decision 2026-10-16: "always apply the protections
  at level 4 and 5 and remove the TLD whitelist"). Before, protections 12–16 skipped safer-region sites at
  levels 3–5 because levels are cumulative; at 4–5 that was an unwanted exception.
- Popup: safer-regions panel + IN/OUTSIDE label hidden below level 3 (first step, user screenshot "irrelevant
  for level 2"), then also at 4–5.
- Show Matrix window now closes after the 5-minute observation (user asked whether that guard existed — it
  did not: observation stopped and memory was released, but the window stayed open and overrides in it failed
  with "bad matrix rule" because the observed site was gone).
- Old 3P-Matrix-lite level 2 TLD blocklist code removed (`rebuildBlockedTldList`, `ownCountryTlds`,
  `GENERIC_BLOCKED_TLDS`, `WORLD_BLOCKED_TLDS`) — unreferenced since the HaGeZi list replaced it.

**How**
- `data/constants.js` `SAFER_REGIONS_LEVELS = [LEVEL.MEDIUM]` (single switch); `core/policy.js`
  `saferRegionsApply(level)`. Used by:
  - `core/rule-builder.js` headerRules: `excludedRequestDomains: safeTlds` only when saferRegionsApply(group
    level); levelRules: safer-regions allow rule only then.
  - `core/script-builder.js` (rewritten): per protection, the global registration excludes the safer TLD
    patterns only when the GLOBAL level is 3; locked sites follow their locked level — locked-3 sites in safer
    regions are excluded/omitted, and sites in safer regions locked at 4–5 under a global level 3 get a second
    registration (id `tldm-<key>-locked`) because an excludeMatches TLD pattern cannot be re-included.
  - `ui/popup.js` panel/label visibility; `background.js` popupModel picks the group title
    (`PROTECTION_GROUPS[].titleNoSaferRegions` = "Extra — on every site").
- `SCOPE.OUTSIDE_SAFE_ZONE` renamed `SCOPE.OUTSIDE_SAFER_REGIONS` (internal enum; state key `safeZone` kept —
  storage contract).
- Show Matrix guards: `startMatrix(tabId, host, onExpire)` — the timeout releases data + listener, then
  `background.js closeMatrixPanel()` closes the window (shared with tabs.onRemoved). Panel side
  (`ui/matrix.js`): closes itself when the model reports `observing:false` (covers a service-worker restart,
  which loses the in-memory observation and `_matrixWindows`); last-resort timer re-armed every poll from the
  SW's `remaining` + `MATRIX_CLOSE_GRACE_MS` (5 s); both timers released on `pagehide`.
- Matrix help text: second sentence in `<span class="mx-help-line">` (display:block).

**Tests**: new `safer-levels-test` 14/14 (levels 3/4/5 global, mixed global/locked levels, rescue registration);
builders + matcher tests unchanged and passing; Chromium: all five levels apply without errors, panel only at
L3, L5 eval registration has no TLD excludes; matrix auto-close verified with an 8-second test build (timeout
path and silent-stop path).

WARNING FOR IMPLEMENTATION IMPACT: at levels 4–5, sites on safer-region TLDs (e.g. your own country) lose
camera/mic/Bluetooth/USB/sensors/NFC access and get the eval and frame-redirect protections — sites that need
those must be locked at level 3 or lower, or put on the allow list.

**Known limitations**: a 4–5-locked site in safer regions under a global level 3 gets the scripts in its own
frames only; third-party frames inside it that are themselves on safer TLDs stay excluded by the global TLD
pattern (the DNR header rules do cover them).

**tools 0.2.2:** no content change since 0.1.1 (build-spam-tlds.mjs + HaGeZi source list); repackaged under
the release version.

---

## 0.2.1 — settings backup format v2; Show Matrix column layout
Working from: 0.2.0. Zips changed: extension (tools repackaged unchanged).

**What / why**: the user reported that the safer-regions (TLD whitelist) settings and the Show Matrix changes
were lost in save/restore. Functionally the v1 backup (raw state) did round-trip, but it was unreadable and gave
no feedback, so it could not be checked. Show Matrix layout aligned with uBlock Stripped Dynamic's panel.

**How**
- New `data/settings-io.js` (pure): `toSettingsFile` / `fromSettingsFile` / `summarize`. Format
  `3p-matrix-settings` v2 with plain sections: startupLevel, protections.disabled, saferRegions
  {autoAddCountryCodes, addedTlds, removedTlds, activeTlds (informational, recomputed on restore)}, allowList,
  lockedSites, showMatrixRules, onlineChecks. v1 files (`{format, state}`) still accepted. Restore always runs
  `normalizeState()` and recomputes safer regions for this browser's languages.
- `normalizeState` validates `matrixRules` (valid hosts, known scopes/actions, capped at MATRIX_OVERRIDES_CAP).
- Matrix panel: Third-party domain | Override (3P-code, 3P-all) | Seen: 7 fixed columns (MATRIX_TYPE_ORDER:
  image, media, css, script, frame, xhr, other) | Req. Seen marks: mint #6EE7B7 square + dark ✓ (allowed),
  #EF4444 square + white ✕ (blocked by 3P Matrix). `webtransport` removed from MATRIX_TYPE_LABEL — not a valid
  webRequest filter type (listener registration failed).

**Tests**: io-test / io-ui-test (round trip, v1 import), matrix-test with css/xhr/image requests.

---

## 0.2.0 — Show Matrix; badge counts our blocks only; UI fixes
Working from: 0.1.1. Zips changed: extension (tools repackaged unchanged).

**What / why**
- Show Matrix built (was a disabled button in 0.1.1).
- Badge count equalled uBlock Dynamic's: `webRequest.onErrorOccurred` reports `net::ERR_BLOCKED_BY_CLIENT` for
  every extension's blocks. User chose option 1: count only 3P Matrix's blocks.
- Protections list was always visible; Show Matrix button not clickable; "safe zone" → "safer regions".

**How**
- `core/connection-matrix.js` (ported from 3P-Matrix-lite 4.0.2): per-tab buckets by registered domain, types
  seen + types blocked; capped 150 domains/tab; 5-minute observation; the webRequest.onBeforeRequest listener
  exists only while a tab is observed. `buildMatrixRules`: 3P-code (script+sub_frame) priority 400001, 3P-all
  400000, ids 900000+, only the L5 block-all (500000) outranks them.
- `core/rule-matcher.js`: replays DNR matching on OUR applied rules (resourceTypes, domainType,
  initiator/request domains incl. parents, regexFilter, urlFilter anchors/wildcards; highest priority wins,
  allow beats block at equal priority; ~9 µs/check). `apply-manager.js` keeps the compiled copy of exactly what
  Chrome has. Only outcome "block" is counted (badge and matrix red marks).
- `ui/common.css`: global `[hidden] { display:none !important }` guard (`.prot-panel {display:flex}` overrode
  the attribute).
- `core/safe-zone.js` → `core/safer-regions.js`; all UI/comments renamed (state key `safeZone` kept).
- Zips unpack to version-less folders `3P-Matrix` / `3P-Matrix-tools`.

---

## 0.1.1 — first prototype
Working from: the three source extensions above; spec `SPEC_levels_and_protections.md`.

Architecture: `data/constants.js` holds every switch/ID/priority/score; `data/protections.js` is the registry
of the 16 protections; pure builders (`core/policy.js`, `rule-builder.js`, `script-builder.js`); only
`core/apply-manager.js` writes to Chrome (serialized, coalesced, regexes validated with isRegexSupported).
Rules per GROUP (group 0 global excluding locked sites, groups 1–5 per locked level; id = 10000 × group +
local id). Non-standard-port block as one regex (an allow-twin rule would have overridden TLD/level blocks).
Detection: DownloadSentinel 3.0.4 heuristics (two marked patches: subdomain count beyond the public suffix,
NonStandardPort family) + CombinationScoring; stage 2 (RDAP + two DoH resolvers, RFC 8484 wire format) only
at score ≤ −30. Warning: `webNavigation.onBeforeNavigate` holds the tab on `ui/warning.html`. State: single
key `tldm_state`, `normalizeState`, `withStateLock`. Show Matrix reserved (button disabled).

Known gap: "paypa1" is not seen as a "paypal" typo (DownloadSentinel maps 1→i only).
