# 3P Matrix — content firewall · Levels & protections spec (agreed 2026-10-16)

(Project started as "TLD Browser Guard", then "TLD Matrix"; renamed to "3P Matrix — content firewall"
on 2026-10-16. Short name: 3P Matrix. Prototype folder: 3p-matrix, version 0.2.5.)
Wording: always "safer regions" (never "safe zone") in UI, docs and comments.
Zips unpack to version-less folders "3P-Matrix" and "3P-Matrix-tools".

Combines: 3P-Matrix-lite 4.0.2 (UI, icons, lock level, startup level, Show Matrix observation),
uBlock Stripped Dynamic 10.2.1 (Privacy & Security protections, allow list, per-site 3P-code / 3P-all
matrix overrides), DownloadSentinel 3.0.4 (domain-name heuristics).

## Levels (cumulative) — default startup level: 2

| Level | Name | Adds |
|---|---|---|
| 1 | Allow all | Nothing — every protection off |
| 2 | Mild protection | Protections 1–10 (below; 10 = suspicious-site warning: domain heuristics on EVERY first-party site, incl. the HaGeZi TLD list); 3P scripts AND frames from HaGeZi-listed TLDs blocked. No other 3P blocking. No safer regions. |
| 3 | Medium protection | Protections 11–15 outside safer regions; block 3P scripts & frames except safer-region TLDs + built-in whitelist. Safer regions override the TLD blocklist where they contradict. |
| 4 | High protection | Protections 11–15 on EVERY site (safer regions ignored). Block all 3P except image, media, font, stylesheet. Exceptions: built-in whitelist + 3P scripts AND frames with "cdn" in the HOST. |
| 5 | Strict | Protections 1–15 on every site. Block ALL 3P — no built-in whitelist, no matrix allows. |

Safer regions have an effect at LEVEL 3 ONLY (decided 2026-10-16; data/constants.js
SAFER_REGIONS_LEVELS, core/policy.js saferRegionsApply()).

## Protections (15, selectable)

Active = (level ≥ its starting level) AND (user has not unticked it). All ticked by default. Global setting
(not per site — per-site control is the lock level and the allow list). Ticked/unticked ONLY in the popup
"Protections" list, which opens from the Protections button (closed by default). Counts show
"N of 15 protections" when some are off.

One registry table (data/protections.js) per protection: key · label · from level · mechanism
(script / DNR block / DNR header / navigation check) · scope (every site / outside safer regions).

On every site, from L2 (uBD rows 3–10 + new HTTP rule + the suspicious-site warning).
0.2.3 removed "clear history at browser start" and "block tracking pings" (kept in uBlock Stripped Dynamic).
1 blockPaymentHandlers — block payment-handler install
2 blockWebBundles — block Web Bundles
3 blockDialogSpam — block alert/confirm/prompt scams
4 blockLocalNetwork — block access to local network
5 blockProtocolHandlers — block protocol-handler install
6 blockSuspicious3p — block suspicious 3P (IP, non-standard ports, DDNS/free hosting)
7 block3pHttp — NEW: block 3P plain-HTTP requests
8 blockClickFix — block ClickFix clipboard writes
9 blockHighRiskEval — strict eval + safer-region protections on high-risk sites
10 warnSuspiciousSites — warn before opening suspicious sites (0.2.4: the navigation-guard warning dialog,
   until then always on from L2). Unticked = no stage 1/2 checks, no warning dialog, neutral badge colour.

From L3 — outside safer regions at L3, on every site at L4–L5 (uBD rows 11–15).
Popup group title: "Outside safer regions" at L3, "Extra — on every site" at L4–L5.
11 blockScpPrivacy — Permissions-Policy camera/mic/display-capture/clipboard-read
12 blockScpSecurity — Permissions-Policy bluetooth/serial/hid/usb/local-network-access
13 blockSensorsNfc — REPLACES uBD row 13: motion sensors via Permissions-Policy (accelerometer, gyroscope,
   magnetometer) + NFC via script; plugins/battery/idle/window.name DROPPED
14 blockObfuscatedEval — obfuscated eval
15 blockRedirectsDialogs — sandbox: frame redirects + dialogs

## TLD blocklist (from L2)
Source: HaGeZi "The World's Most Abused TLDs", uBlock syntax — the ONLY TLD blocklist. The old
3P-Matrix-lite blocklist (None/User/Generic/World modes) is removed (0.2.2); not user-editable.
https://raw.githubusercontent.com/hagezi/dns-blocklists/refs/heads/main/adblock/spam-tlds-ublock.txt
(2026-10-15: 445 TLDs = 294 latin + 151 punycode; 166 lines carry ~domain exceptions for legitimate sites).
1. First-party visit to a listed TLD → heuristics signal / warning (the ~domain exceptions are not warned).
2. 3P scripts and frames from listed TLDs blocked (one DNR rule, requestDomains = TLD list,
   excludedRequestDomains = the exceptions).

## Safer regions (TLD whitelist) — level 3 only
3P-Matrix-lite tld-engine BASE_TLDS, MINUS `shop`, `store`, `site`, `online`, `biz`, + auto-added country codes.
Auto-add scope FIXED to Continent, the same default as uBlock Stripped Dynamic (0.2.4: the popup's 4-position
"Auto-add country codes" slider is removed; data/constants.js SAFER_REGIONS_AUTO_MODE): the countries named by
the browser's languages + every country on the user's continent that speaks one of them (or a readable
relative). Continent from the first language tag with a region, else the time zone. The user can still add and
remove TLDs in the popup; "Default" clears those edits. The list is recomputed on install AND update.
No fixed Five Eyes / EU group: a bare "en" tag adds uk/us/ie/au/ca/nz (nz added 0.2.4 — the only difference from uBD), Europeans
with an EU language get `eu`. Auto-added TLDs on the HaGeZi list are dropped (decided 2026-10-16:
SAFER_REGIONS_SKIP_ABUSED_TLDS; today cf, cm, ga, gq, ml, ng, pw); a TLD the user adds by hand is kept.
At L3 it controls: the 3P scripts/frames allow and the "outside safer regions" scope of protections 11–15.
At L1, L2, L4, L5 it has no effect; the popup editor and the IN/OUTSIDE SAFER REGIONS label show at L3 only.
Per-site locks follow the locked level (a .nl site locked at L4 gets 11–15 even when the global level is 3).
NOT a gate for the domain heuristics (most phishing uses .com). (State key stays `safeZone` — contract.)

## Built-in whitelist (data/builtin-domains.js)
Payment, sign-in (SSO), CAPTCHA, fraud prevention, video embeds, JS libraries — plus, since 0.2.4
(user request), streaming/meeting/gaming services with a genuine embeddable widget: Spotify,
SoundCloud, Deezer, Apple Music, Mixcloud (streaming); Zoom, Webex, Whereby, Microsoft Teams, Discord
(meeting); Steam, itch.io (gaming). Destination-only services with no embeddable widget (Netflix,
Disney+, Hulu, Max, Prime Video, Paramount+, Peacock, Crunchyroll, Xbox, PlayStation, Nintendo, Epic
Games, Riot Games, WhatsApp, Telegram, Signal, Slack, Google Meet) are deliberately left out — adding
them would have no effect, since nothing on this list is ever loaded as third-party content elsewhere.
Hand-curated from general knowledge, not a live/verified source.

Two independent effects, both at levels 3 and 4 only (never 5, matching the level table above):
1. Third-party scripts/frames from a listed host are allowed through the level 3/4 content block
   (BUILTIN_BOTH/SCRIPT_ONLY/FRAME_ONLY, DNR allow rules) — e.g. a Spotify embed on someone else's page.
2. Since 0.2.4 (user: "it should also apply on the protections" — corrects an initial assumption that
   this list only ever affected third-party embeds): a listed host is ALSO exempt from protections
   9/11–13/15 (the Permissions-Policy/CSP header rules in core/rule-builder.js, and the
   blockObfuscatedEval/blockSensorsNfc content scripts in core/script-builder.js) on a FIRST-PARTY visit
   — e.g. camera/mic is not blocked while you are actually on zoom.us or discord.com yourself. This is
   a second, independent exemption alongside the safer-regions TLD one (core/policy.js
   saferRegionsApply); the two are merged, not layered. A site locked at level 5 overrides this
   exemption, same as it overrides the safer-regions one — a deliberate per-site choice for maximum
   protection beats being on a trusted-services list.
Also used by core/navigation-guard.js (BUILTIN_ALL) to skip the suspicious-site scoring/warning dialog.

## Suspicious-site detection
Protection 10 (warnSuspiciousSites). Runs only while it is active for the site (effective level ≥ 2 and ticked).
Stage 1 (local, ~0.4 ms, every first-party visit from L2; skipped for allow list and built-in whitelist):
- DownloadSentinel heuristics: punycode, excessive subdomains (FIX: count labels beyond the public suffix),
  brand impersonation exact + fuzzy, lookalike characters, bigram homoglyphs + top-1M lookalike
  (a real top-1M site is never flagged), HostList, risky hosting, suspicious-TLD scores, HaGeZi TLD list.
- Address signals (one family, worst counts — IP+port never doubles):
  IP-address-only host −30 · non-standard port (not 80/443/8080/8443) −15.
  Private/local hosts exempt (10/8, 172.16/12, 192.168/16, 127/8, ::1, .local, .lan, .home.arpa).
- Plain HTTP first-party −15.
Stage 2 (network, ONLY when stage 1 ≤ −30; cached per registered domain):
- RDAP domain age (rdap.org) — ALWAYS ON, no option to disable.
- Threat-intel DNS (DoH, RFC 8484 wire format). User picks a FIRST and a SECOND resolver (or none) out of:
  - Quad9 — dns.quad9.net/dns-query (block = NXDOMAIN without authority)
  - Cloudflare Security 1.1.1.2, malware only — security.cloudflare-dns.com/dns-query (block = 0.0.0.0, verify)
  - Control D free, malware only — freedns.controld.com/p1 (block = 0.0.0.0 default, verify)
  Options page explains: why two out of three = pick the two the user does NOT already use as own DNS.
- Note: users running their own DNS with DoH-bypass blocking (e.g. NextDNS "Block Bypass Methods") must
  allow-list the chosen resolver host(s) there. Unreachable = "check unavailable", never "safe".
- Certificate-age (CT log) check: DROPPED.
Combination via DownloadSentinel CombinationScoring (families, geometric decay, combo rules).

## Warning
- NO warning banner in the popup. Every warning is a warning DIALOG.
- Protection 10; shown at score ≤ −30 (two severities: "suspicious" −30…−60, orange; "possible phishing" < −60, red).
- Not full screen: a centred dialog (max 560 px) on a dimmed background.
- Buttons, in this order, all solid with dark text:
  1. Go back to safety — yellow #FACC15
  2. Trust this site — mint #6EE7B7 (adds to allow list = locked at level 1)
  3. Continue once — bright orange #FF8A1F (this visit only, this tab)
- Mechanism: the tab is HELD — onBeforeNavigate redirects it to the extension's warning page, so the
  suspicious site never loads before the user chooses.

## Badge / icons
- Icons: 3P-Matrix-lite brick-wall icons, one colour per level (icon_0..4 → L1..L5). Warning dialog uses the
  orange (suspect) or red (phishing) icon.
- Badge background per tab: grey normal · orange suspect (≤ −30) · red + "!" phishing (< −60).
- Badge text = requests blocked by 3P MATRIX ONLY (decided 2026-10-16, option 1). Chrome reports
  net::ERR_BLOCKED_BY_CLIENT for every extension's blocks, so each such request is replayed against our
  own applied rules (core/rule-matcher.js: DNR matching semantics, highest priority wins, allow beats block
  at equal priority; ~9 µs per check). Counted only when our outcome is "block". Header rules never count.
  The Show Matrix "blocked" marks use the same attribution.

## Show Matrix
- Popup button → panel window (980×720) for the current tab; the tab is reloaded so every request is seen.
- Columns: Third-party domain | Override (3P-code, 3P-all) | Seen: 7 fixed type columns IMAGE, MEDIA, CSS,
  SCRIPT, FRAME, XHR, OTHER | Req. Seen cell = empty (not seen), mint rounded square + dark ✓ (seen,
  allowed), bright red square + white ✕ (blocked by 3P Matrix). Help text: second sentence ("Rules apply on
  every site, not just this one…") always on its own line.
- Overrides are GLOBAL by default (since 4.1.0): per third-party domain, two scopes, each cycling
  none → BLOCK → ALLOW: 3P-code (script + sub_frame, priority MATRIX_CODE_GLOBAL 400001) and 3P-all (all
  types, MATRIX_ALL_GLOBAL 400000) — stored under matrixRules key `MATRIX_SITE_ALL` ("*"). A literal
  per-site key is still supported (pre-4.1 saved data, or a manual override) on priorities
  MATRIX_CODE_SITE (400003) / MATRIX_ALL_SITE (400002) — strictly above the global tier, so it always wins
  a conflict for the same third party. Both tiers outrank every level/security rule; only the L5 block-all
  (500000) beats them (= no allows at L5).
- Stored in state.matrixRules (capped 1000 pairs across all keys), DNR ids 900000+.
- Guards: observation stops after 5 minutes (MATRIX_DURATION_MS) and the panel window is CLOSED then.
  Also closed when the tab closes; the panel closes itself as soon as observation has ended (covers a
  service-worker restart) and as a last resort MATRIX_CLOSE_GRACE_MS (5 s) after the countdown. Per-tab data
  capped at 150 domains; the webRequest listener exists only while a tab is observed.

## Settings backup (Options → Save / Restore), format v2 (0.2.1)
Readable sections: startupLevel · protections.disabled · saferRegions{addedTlds, removedTlds, activeTlds
(informational, recomputed)} (autoAddCountryCodes dropped in 0.2.4; ignored when restoring older files) · allowList · lockedSites · showMatrixRules ·
onlineChecks. v1 files (0.1.x / 0.2.0) still restore. Status line shows a one-line summary.

## Shared concepts
- Allow list: plain domain line = site locked at level 1. "Trust this site" (warning dialog) adds to it.
- Lock level / startup level: as 3P-Matrix-lite (lock pins the current level, then restores the previous
  session level).
- Certificate inspection itself is impossible with Chrome MV3 APIs (no getSecurityInfo).

## Architecture (4.1.0)
- data/constants.js holds every switch/ID/priority/score; data/protections.js is the protection registry.
- Pure builders: core/policy.js, core/rule-builder.js (incl. buildMatrixRules), core/script-builder.js,
  core/rule-matcher.js. Only core/apply-manager.js writes rules/scripts to Chrome (serialized +
  coalesced, regexes validated) and keeps the compiled copy for the matcher.
- Rules per GROUP, not per site: group 0 = global (excludes all locked sites), groups 1–5 = sites locked
  at that level. Rule id = 10000 × group + local id. Matrix band 900000+.
- Content scripts: one registration per script protection; when the global level is 3 and sites in safer
  regions are locked at 4–5, a second registration (id suffix "-locked") covers those sites.
- Non-standard port block: ONE regex excluding 80/443/8080/8443.
- Priorities: L5 500000 > matrix code site 400003 > matrix all site 400002 > matrix code global 400001 >
  matrix all global 400000 > local network 1002 > security 1000 > safer-regions allow 360 > abused-TLD 350
  > built-in/CDN allow 300 > level block 100. Headers priority 1.
- State: single storage key, normalizeState() validates every field, withStateLock() serializes updates.
- [hidden] always wins over component display rules (common.css guard).

## UI (mockup: Design canvas "TLD Browser Guard popup", 4 boards)
- Dark theme (3P-Matrix-lite). Header: level icon + "3P Matrix" + grey tagline "content firewall".
- Popup lines fit on one line ("3P code" = scripts & frames).
- Safer-regions editor in popup at L3 only: TLD tags (× removes), Add, Default — no auto-add slider.
- Options page: online checks (explanations, DNS first/second), allow list, settings backup.

## Open
- Known heuristic gap: "paypa1" is not seen as a "paypal" typo (DownloadSentinel maps 1→i only).
- Remote updates of the HaGeZi / hosting lists.
