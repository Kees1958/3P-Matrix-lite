# Changelog — 3P Matrix — content firewall

Short, per-release summary of what changed, without implementation detail. Lives in the docs package only
(as in uBlock Stripped Dynamic since 10.1.4). The full technical account is CHANGELOG_HISTORY.md.

## 4.2.2
- Show Matrix: larger status squares (✓ = allowed, ✕ = blocked) in every column; a totals line
  under the table; the explanation fits on 2 lines, with "rules apply on every site" in yellow.

## 4.2.1
- **Show Matrix uses the 3P-Matrix-lite layout and model again.** Columns: internal whitelist,
  level mode, image, media, stylesheet, SCRIPT, FRAME, fetch/xhr, other, requests. SCRIPT and FRAME
  show what the rules decide for that domain (green = allowed, red = blocked) — at level 4 every
  non-cdn script domain is red. Click a square to override it, click again to undo.
  "cdn" subdomains of non-cdn domains get their own row (level 4 treats them differently).
  The filter box is gone; Reload page and the "rules apply on every site" line stay.
- **Blocked-request count is more accurate**: requests from sandboxed or data: frames (common for
  ad scripts) are now counted as blocked by 3P Matrix when they are.
- Tools: `package-release-state.mjs` writes `package-release-state.json` (artifact hashes, versions,
  file counts, shipped permissions).

## 4.2.0
- **Abused-TLD block is now protection 11** — a normal checkbox, on by default (nothing changes unless
  you untick it). Its separate popup line is gone; it is counted in "N protections".
- **Protections renumbered** so each group is consecutive: 1–11 on every site, 12–16 outside safer
  regions (were 11–15). Your ticked/unticked choices carry over unchanged.
- **Levels 4 and 5 only block third-party scripts and frames** — never images, video, fonts or CSS.
  Level 4 still allows the built-in whitelist and "cdn" hosts; level 5 allows nothing.
- **Show Matrix: Script and Frame columns** replace 3P-code / 3P-all; each is set on its own. Buttons
  are larger (84×40). Older rules convert automatically: a 3P-code (or else 3P-all) rule sets both.
- **Trusted payment sites** (Stripe, PayPal, …) may register a real payment handler on their own site,
  at levels 3–4 only; protection 1 still blocks every other site.
- **Safer regions panel opens expanded**, so the TLD list is visible the moment the popup opens.
- **Level 5 name** now reads "Strict — no 3P scripts or frames".
- `fullvideosporn.com` added to protection 9's high-risk list (beyond the ported list).

## 4.1.1
- Dead-code cleanup: removed four unused pieces of data that nothing in the extension ever read
  (two unused identity strings, an unused page-path constant, an unused list-version string kept
  only as a duplicate of an existing comment). No behaviour change — nothing you can see is different.
- Show Matrix: the "Rules apply on every site…" help line is now bold and upper case, so it's hard
  to miss. The "Req." column header now reads "REQUESTS".

## 4.1.0
- **Renumbered from 0.2.5 to 4.1.0**, aligning this extension's version line with 3P-Matrix-lite's.
- **Show Matrix overrides (3P-code / 3P-all) are now global by default.** Setting one on a domain
  blocks/allows it on every site, not just the one you were looking at when you set it — matching how
  3P-Matrix-lite's equivalent feature always behaved. **Behaviour you will see:** an override you set
  while observing one site now also applies everywhere else; reload a page to see the effect, as before.
  A rule saved by an older version of this extension (site-specific) still works and still only applies
  to that one site — and always wins over a global rule for the same third party if both exist.

## 0.2.5
- Version bump only, packaging the 0.2.4 working-copy changes below that had not yet been zipped
  (safer-regions default fix, built-in whitelist, protection labels) as their own release.

## 0.2.4
- **Protection descriptions are clearer.** Each one now reads as a plain sentence ("Block sites from
  registering a fake payment handler") instead of a cryptic abbreviation ("Block payment-handler
  install"); a few now wrap to two lines instead of being cut off with "...".
- **The built-in-whitelist summary line is up to date** — it now mentions streaming, meetings and games,
  not just payment/sign-in/CAPTCHA, and still fits on one line.

- **Built-in whitelist: streaming, meeting and gaming apps with a real embeddable widget** are now
  trusted, same as payment and sign-in services already were: Spotify, SoundCloud, Deezer, Apple Music,
  Mixcloud; Zoom, Webex, Whereby, Microsoft Teams, Discord; Steam, itch.io. Services with no embeddable
  widget (Netflix, Disney+, Xbox, PlayStation, WhatsApp, Slack, Google Meet, …) are left out on purpose —
  they're never loaded as third-party content, so adding them would do nothing.
- **These trusted services are now also exempt from protections 9 and 11–15** (camera/mic, Bluetooth,
  obfuscated eval, frame redirects, …) when you visit them directly, not only as a third-party embed —
  at levels 3 and 4, same as the rest of the built-in whitelist. **Behaviour you will see:** if you were
  on, say, zoom.us or discord.com at level 4, camera/mic may have been blocked before; it no longer is,
  unless you've locked that site at level 5 yourself.

- **The suspicious-site warning is now protection 10** in the popup's Protections list ("Warn before opening
  suspicious sites"), so it can be switched off like any other protection. It stays on by default — nothing
  changes unless you untick it. Unticked, sites are no longer checked and no warning dialog appears.
  "On every site" now has 10 protections again; the level-3 protections are renumbered 11–15.
- **No more "Auto-add country codes" slider** in the level-3 safer-regions panel. The list is always built the
  same way as in uBlock Stripped Dynamic: common TLDs plus the country codes of your continent that speak your
  browser's languages. You can still add and remove TLDs, and Default undoes your edits. **Behaviour you will
  see:** if you had moved the slider away from Continent, your list switches to the Continent default after
  updating (your own added and removed TLDs are kept).
- With plain English in your Chrome languages, New Zealand (.nz) is now added too, so all Five Eyes
  countries (us, uk, ca, au, nz) are in your safer regions.
- Safer-regions panel: the explanation text now sits below the TLD list instead of above it, and the list no
  longer scrolls inside its own small box — every TLD is visible at once.
- Country codes on the HaGeZi abused-TLD list (today cf, cm, ga, gq, ml, ng, pw) are never added to the
  safer regions automatically — the same rule as for .biz, .shop, .store, .site and .online. You can still add
  one by hand.
- **No more redundant "Warnings for suspicious sites" bullet** in the popup summary — it was protection 10's
  own name shown twice (once as a bullet, once in the Protections list). The summary count ("N of 15
  protections active") already covers it, same as every other single protection.
- **Unticked protections stay readable:** no more strike-through or grey text, only the empty checkbox.

## 0.2.3
- **Two protections removed:** "Clear history at browser start" and "Block tracking pings" — keep using
  uBlock Stripped Dynamic for those. The remaining protections are renumbered 1–14, and the extension no
  longer asks for permission to clear your browsing history.

## 0.2.2
- **Safer regions now only matter at level 3.** Levels 4 and 5 apply all 16 protections on every site; the
  safer-regions TLD list is ignored there. **Behaviour you will see:** at level 4–5, sites on your own
  country's TLD (for example .nl) no longer get access to camera, microphone, Bluetooth/USB, motion
  sensors or NFC, and obfuscated scripts and frame redirects are blocked there too.
- The popup shows the safer-regions editor and the "in / outside safer regions" label at level 3 only. In
  the Protections list the second group is called "Extra — on every site" at level 4–5.
- Show Matrix closes itself when its 5 minutes are over (it used to stay open saying "stopped").
- Show Matrix help text: "Rules apply to this site only…" always starts on its own line.
- The old level 2 TLD blocklist (with its modes) is gone for good; the HaGeZi abused-TLD list is the only
  one. Nothing changes in what you see — the old list was already no longer used.

## 0.2.1
- **Save / restore settings** now includes your safer-regions settings and your Show Matrix rules. The
  backup file is readable, and the status line summarises what was saved or restored. Backups made with
  0.2.0 still restore.
- **Show Matrix layout:** the 3P-code and 3P-all buttons come right after the domain; seven fixed columns
  show which content types were seen — a mint square with a check when allowed, a red square with a cross
  when blocked by 3P Matrix.

## 0.2.0
- **Show Matrix** is available: see which third parties a page contacts, and block or allow their code
  (3P-code) or everything (3P-all) per site.
- The badge counts only requests blocked by 3P Matrix (not those blocked by other extensions).
- The Protections list opens only from its button; the Show Matrix button works.
- "Safe zone" is now called "safer regions" everywhere.
- Unpacked folders no longer carry the version number ("3P-Matrix", "3P-Matrix-tools").

## 0.1.1
- First prototype for testing: five levels with lock level and startup level (default 2), 16 selectable
  protections, the HaGeZi abused-TLD list from level 2, domain heuristics with online checks (domain age
  and two DNS threat-intelligence resolvers of your choice), warning dialog, allow list, settings backup.
