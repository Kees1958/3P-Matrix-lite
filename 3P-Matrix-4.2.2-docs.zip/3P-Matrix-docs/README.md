# 3P Matrix — content firewall · docs package 0.2.5

Project history and troubleshooting reference. Never uploaded anywhere; not part of the extension zip.

| File | What it is |
|---|---|
| `CHANGELOG.md` | Short, user-facing summary per 3P Matrix release (what, never how) |
| `CHANGELOG_HISTORY.md` | Technical record per 3P Matrix release: what, why, how, limitations, tests |
| `SPEC_levels_and_protections.md` | The agreed spec: levels, protections, detection, warning, Show Matrix, architecture |
| `Xplainer_Programming_principles_audit_v5.md` | Programming principles + audit checklist, taken unchanged from uBlock Stripped Dynamic 10.2.1 docs — the rules this project follows (structure, guards, state, security, packaging, changelogs) |
| `sources/uBlock-Stripped-Dynamic-10.2.1/` | That extension's `CHANGELOG.md` and `CHANGELOG_HISTORY.md` (unchanged copies) |
| `sources/3P-Matrix-lite-4.0.2/` | Version index rebuilt from source comments — no changelog was in the uploaded zip |
| `sources/DownloadSentinel-3.0.4/` | Version index rebuilt from source comments — its `DOCS/CHANGELOG.md` was not in the uploaded zips |

Troubleshooting: when 3P Matrix code says "ported from 3P-Matrix-lite 4.0.2", "uBlock Stripped Dynamic 10.2.1"
or "DownloadSentinel 3.0.4", the history of that code is in `sources/`. The two version indexes list every
source comment that names a version (file:line), newest first.
