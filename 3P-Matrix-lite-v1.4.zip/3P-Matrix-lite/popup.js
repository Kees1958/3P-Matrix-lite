// ── Level definitions ──────────────────────────────────────────────────────────
var LEVELS = [
  { name: "Easy mode \u2014 allow all", color: "#16A34A", showDomain: true, showTld: false,
    rules: [{ type: "allow", text: "All traffic allowed \u2014 no restrictions active" }] },
  { name: "Easy mode with enhanced security", color: "#93C5FD", showDomain: false, showTld: false,
    rules: [
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" }
    ]},
  { name: "Easy medium mode", color: "#FACC15", showDomain: false, showTld: true,
    rules: [
      { type: "allow", text: "##TLDWHITELIST##" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]},
  { name: "Medium mode \u2014 trust CDN\u2019s", color: "#FB923C", showDomain: true, showTld: false,
    rules: [
      { type: "allow", text: "3P-scripts for URL\u2019s with CDN in name are allowed" },
      { type: "allow", text: "Whitelisted domains are allowed as 3P" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]},
  { name: "Medium mode", color: "#C0392B", showDomain: true, showTld: false,
    rules: [
      { type: "allow", text: "Whitelisted domains are allowed as 3P" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Insecure HTTP connections are blocked" },
      { type: "block", text: "Non standard ports (not 443) are blocked" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]}
];

var LEVEL_COLORS = ["#16A34A","#93C5FD","#FACC15","#FB923C","#C0392B"];

var DEFAULT_STATE = {
  level: 1, startupLevel: 1,
  tlds: ["com","ai","edu","gov","io","net","org","cloud","dev","app","page"],
  domains: [], builtinDomains: null, autoTldMode: 1, manualTlds: [],
  excludedTlds: [],
  siteRules: {}, siteRulesOrder: [],
  whitelistDropdown: { tld: true, domain: true },
  lastShownVersion: "",
  blockedTldMode:    0,
  blockedTlds:       [],
  manualBlockedTlds: [],
  blockedTldDropdownOpen: false  // starts collapsed
};

var GENERIC_BLOCKED_TLDS = [
  "zip","click","cfd","rest","surf","top","icu","shop","xyz",
  "online","site","mov","review","download","monster","buzz","fun"
];
var WORLD_BLOCKED_TLDS = GENERIC_BLOCKED_TLDS.concat([
  "cc","cm","cn","cx","gq","ir","kp","ly","ml","ms",
  "pk","pw","ru","su","tk","tm","to","ws","ye"
]);
var BLOCKED_TLD_LABELS = ["NONE","USER","GENERIC","WORLD"];
var BLOCKED_TLD_HINTS  = [
  "No TLD script blocking active",
  "Block 3P scripts from your own list of risky TLDs",
  "Block 3P scripts from known low-quality / high-abuse TLDs",
  "Generic list plus high-risk country TLDs"
];

var state       = Object.assign({}, DEFAULT_STATE);
var domainPage  = 0, tldPage = 0;
var DOMAIN_PAGE_SIZE = 500, TLD_PAGE_SIZE = 500;
var currentHost    = "";  // exact hostname of the active tab
var lockDomain     = "";  // registrable (apex) domain used for locking — covers subdomains
var sessionLevel     = 0;  // current global level this session (0 = not yet initialised)
var prevSessionLevel = 0;  // level before last slider move — restored when lock is set

// Common multi-part public suffixes — kept short on purpose for a lite extension.
// Anything not in this list falls back to the standard "last two labels" rule.
var MULTI_PART_SUFFIXES = [
  'co.uk','org.uk','ac.uk','gov.uk','co.jp','co.kr','co.nz','co.za',
  'com.au','net.au','org.au','com.br','com.cn','com.mx','com.tr',
  'co.in','co.id','com.sg'
];

// Reduce a hostname to its registrable (apex) domain, e.g.
// "portal.www.tio.nl" -> "tio.nl", "www.example.co.uk" -> "example.co.uk"
function getApexDomain(hostname) {
  if (!hostname) return hostname;
  var labels = hostname.split('.');
  if (labels.length <= 2) return hostname;

  var lastTwo   = labels.slice(-2).join('.');
  var lastThree = labels.length >= 3 ? labels.slice(-3).join('.') : null;

  if (lastThree && MULTI_PART_SUFFIXES.indexOf(labels.slice(-2).join('.')) !== -1) {
    return lastThree;
  }
  return lastTwo;
}

// ── SVG icons ─────────────────────────────────────────────────────────────────
var SVG_LOCKED = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
  + '<path fill-rule="evenodd" clip-rule="evenodd" d="M4 6V4C4 1.79086 5.79086 0 8 0C10.2091 0 12 1.79086 12 4V6H14V16H2V6H4ZM6 4C6 2.89543 6.89543 2 8 2C9.10457 2 10 2.89543 10 4V6H6V4ZM7 13V9H9V13H7Z" fill="rgba(0,0,0,0.6)"/>'
  + '</svg>';

var SVG_UNLOCKED = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
  + '<path fill-rule="evenodd" clip-rule="evenodd" d="M11.5 2C10.6716 2 10 2.67157 10 3.5V6H13V16H1V6H8V3.5C8 1.567 9.567 0 11.5 0C13.433 0 15 1.567 15 3.5V4H13V3.5C13 2.67157 12.3284 2 11.5 2ZM9 10H5V12H9V10Z" fill="#ffffff"/>'
  + '</svg>';

// ── Auto TLD ──────────────────────────────────────────────────────────────────
var AUTO_TLD_LABELS = ["NONE", "BROWSER", "CONTINENT", "WORLDWIDE"];
var AUTO_TLD_HINTS  = [
  "No country codes added automatically",
  "Add country codes from your browser\u2019s language settings",
  "Same continent: adds countries sharing your browser language",
  "Worldwide: adds all countries sharing your browser language"
];
var LANG_TLD_MAP = {
  // continent = European/geographically close countries sharing this language
  // worldwide  = all countries where this language has significant official/primary use
  // Note: the base country itself is handled by LANG_DEFAULT_COUNTRY / LANG_WORLD_DEFAULTS,
  // so continent/worldwide only lists *additional* countries beyond the base.
  "nl": { continent: ["be"],                worldwide: ["be","sr","aw","cw","eu"] },
  "fr": { continent: ["be","ch","lu","mc"], worldwide: ["be","ch","lu","mc","ca","sn","ci","cm","mg","cd","tn","ma","dz","eu"] },
  "de": { continent: ["at","ch","li","lu"], worldwide: ["at","ch","li","lu","eu"] },
  // es: continent adds Andorra (Spanish-speaking European microstate); worldwide adds all Latin America
  "es": { continent: ["ad"],                worldwide: ["ad","mx","ar","co","pe","ve","cl","ec","gt","cu","bo","do","hn","py","sv","ni","cr","pa","uy","eu"] },
  "pt": { continent: [],                    worldwide: ["br","ao","mz","cv","gw","st","eu"] },
  "it": { continent: ["ch","sm","va"],      worldwide: ["ch","sm","va","eu"] },
  // en: continent = only European English-speaking countries (UK already base, ie/mt are neighbors)
  //     au/nz/ca are not on the European continent — they move to worldwide
  "en": { continent: ["ie","mt"],           worldwide: ["ie","mt","au","nz","ca","za","ng","gh","ke","ug","tz","sg","in","ph","jm"] },
  // sv: se is already the base country via LANG_DEFAULT_COUNTRY; fi is the only continental addition
  //     (Swedish is a co-official language of Finland)
  "sv": { continent: ["fi"],               worldwide: ["fi","eu"] },
  // da: fo (Faroe Islands) and gl (Greenland) are Danish-speaking territories — correct continent additions
  "da": { continent: ["fo","gl"],          worldwide: ["fo","gl","eu"] },
  "no": { continent: [],                   worldwide: ["eu"] },
  "fi": { continent: [],                   worldwide: ["eu"] },
  "pl": { continent: [],                   worldwide: ["eu"] },
  "ro": { continent: ["md"],               worldwide: ["md","eu"] },
  "el": { continent: ["cy"],               worldwide: ["cy","eu"] },
  "hu": { continent: [],                   worldwide: ["eu"] },
  "cs": { continent: ["sk"],               worldwide: ["sk","eu"] },
  "sk": { continent: ["cz"],               worldwide: ["cz","eu"] },
  "hr": { continent: ["rs","ba","me","si"],worldwide: ["rs","ba","me","si","eu"] },
  "sr": { continent: ["hr","ba","me","si"],worldwide: ["hr","ba","me","si","eu"] },
  "bg": { continent: [],                   worldwide: ["eu"] },
  // "ru" (Russian) excluded for geopolitical reasons — ru/by domains intentionally not added
  "uk": { continent: [],                   worldwide: ["eu"] },  // Ukrainian language (not "United Kingdom"); "by" excluded for geopolitical reasons
  "tr": { continent: [],                   worldwide: ["cy"] },
  "zh": { continent: ["hk","tw","sg"],     worldwide: ["hk","tw","sg","mo"] },
  "ja": { continent: [],                   worldwide: [] },
  "ko": { continent: [],                   worldwide: [] },
  "he": { continent: [],                   worldwide: [] },
  "th": { continent: [],                   worldwide: [] },
  "id": { continent: [],                   worldwide: [] },
  // hi: np (Nepal) is the only contiguous country where Hindi is widely spoken as primary
  //     pk/bd/lk are worldwide at best (Urdu/Bengali/Sinhala are those countries' primary languages)
  "hi": { continent: ["np"],               worldwide: ["np","pk","bd","lk"] },
  "vi": { continent: [],                   worldwide: [] }
};

// Explicit, unambiguous mapping from a bare 2-letter language code to its most likely
// default country, used ONLY when the browser reports a language with no region subtag
// (e.g. "nl" instead of "nl-NL"). Languages are deliberately omitted here when the
// language code does not reliably imply one specific country — for those, no TLD guess
// is made unless the browser provides an explicit region subtag (e.g. "es-MX").
//
// Why this matters: language code != country code in many cases. For example "sv" is the
// ISO code for Swedish, but "sv" is also the ccTLD for El Salvador — without this map, a
// bare "sv" browser language would have silently (and wrongly) added El Salvador's TLD.
// Likewise "uk" is Ukrainian, not "United Kingdom" (which uses ccTLD "uk" by coincidence).
var LANG_DEFAULT_COUNTRY = {
  "nl": "nl", "de": "de", "it": "it", "pl": "pl",
  "da": "dk", "fi": "fi", "el": "gr", "hu": "hu", "cs": "cz",
  "sk": "sk", "hr": "hr", "bg": "bg", "tr": "tr",
  "th": "th", "vi": "vn", "id": "id", "ja": "jp", "ko": "kr",
  "he": "il", "hi": "in"
  // Still omitted (ambiguous without a region subtag, no single safe default exists):
  //   sv  — Swedish ≠ El Salvador's "sv" ccTLD; needs "sv-SE"
  //   no  — could collide with Norway "no" only by region tag, kept out for consistency
  //   zh  — could be CN, TW, HK, SG
  //   uk  — Ukrainian language, "uk" ccTLD is United Kingdom — never auto-guess this
  //   ar  — could be any of 20+ Arabic-speaking countries
};

// World languages spoken natively or fluently across many countries, where readers commonly
// consume sources from several of those countries interchangeably (news, media, commerce).
// Bare language tags (no region subtag, e.g. "en" instead of "en-US") add this small cluster
// of the most-read source countries for that language — a deliberate exception to the
// "no guess without a region subtag" rule, since the security cost of these mainstream,
// well-known domains is minimal and the convenience is high.
var LANG_WORLD_DEFAULTS = {
  "en": ["uk", "us", "ie", "au", "ca"],   // BBC/UK, CNN/NYT/US, Ireland, Australia, Canada
  "fr": ["fr", "be", "ca"],               // France, Belgium, Canada (Quebec)
  "es": ["es", "mx", "ar"]                // Spain, Mexico, Argentina — three largest sources
};

// Explicit region-pairing table — hand-picked, deliberately short. Used only when the
// browser supplies a language WITH a region subtag (e.g. "en-IE", "en-US", "da-FO").
// A pairing is added here only when the region corresponds to a place that has its own
// distinct ISO language code / clearly separate national identity — meaning users there
// commonly read both their own region's sources and the larger parent country's sources.
//
// This deliberately excludes purely dialectal/regional variants of a language that all
// belong to one country (e.g. "ca-ES" — Catalan as spoken in Spain — only adds "es",
// since Catalan isn't a separate sovereign nation's primary language).
//
// Format: "lang-REGION" -> [extra country code to add alongside the region itself]
var REGION_PAIRINGS = {
  "en-ie": ["uk"],   // Ireland (own language code "ga"/Irish exists) <-> UK
  "en-uk": ["us"],   // UK <-> US, both major English source countries
  "en-gb": ["us"],
  "en-us": ["uk"],
  "da-fo": ["dk"],   // Faroe Islands (own language code "fo"/Faroese exists) <-> Denmark
  "en-im": ["uk"],   // Isle of Man <-> UK (no separate ISO language for Manx is in common use,
                      // but Isle of Man is a distinct Crown Dependency with its own ccTLD)
  "fr-ca": ["fr"],   // Canadian French <-> France
  "es-mx": ["es"],   // Mexican Spanish <-> Spain
  "pt-br": ["pt"]    // Brazilian Portuguese (own strong national identity) <-> Portugal
};

var BASE_TLDS = ["com","ai","edu","gov","io","net","org","cloud","dev","app","page"];

function computeAutoTlds(mode, browserLangs, cb) {
  if (mode === 0) { cb([]); return; }
  var EU_LANGS = { "bg":1,"hr":1,"cs":1,"da":1,"nl":1,"et":1,"fi":1,"fr":1,"de":1,"el":1,
    "hu":1,"ga":1,"it":1,"lv":1,"lt":1,"mt":1,"pl":1,"pt":1,"ro":1,"sk":1,"sl":1,"es":1,"sv":1 };
  var browserCountries = [], hasEuLang = false;
  browserLangs.forEach(function(lang) {
    var parts = lang.toLowerCase().split('-');
    var lc = parts[0];
    if (EU_LANGS[lc]) hasEuLang = true;

    if (parts.length > 1) {
      // Explicit region subtag present (e.g. "nl-BE" -> "be") — use it directly.
      var region = parts[parts.length - 1];
      if (/^[a-z]{2,3}$/.test(region) && browserCountries.indexOf(region) === -1)
        browserCountries.push(region);
      // Check the hand-picked region-pairing table for a companion country to add
      // alongside it (e.g. "en-IE" also adds "uk"; "da-FO" also adds "dk").
      var pairKey = lc + '-' + region;
      if (REGION_PAIRINGS[pairKey]) {
        REGION_PAIRINGS[pairKey].forEach(function(c) {
          if (browserCountries.indexOf(c) === -1) browserCountries.push(c);
        });
      }
    } else if (LANG_WORLD_DEFAULTS[lc]) {
      // Bare world-language tag (no region subtag) — add the small cluster of
      // most-read source countries for that language (see LANG_WORLD_DEFAULTS comment).
      LANG_WORLD_DEFAULTS[lc].forEach(function(c) {
        if (browserCountries.indexOf(c) === -1) browserCountries.push(c);
      });
    } else if (LANG_DEFAULT_COUNTRY[lc]) {
      // Bare tag for a language with one unambiguous default country.
      var dflt = LANG_DEFAULT_COUNTRY[lc];
      if (browserCountries.indexOf(dflt) === -1) browserCountries.push(dflt);
    }
  });
  if (hasEuLang && browserCountries.indexOf('eu') === -1) browserCountries.push('eu');
  if (mode === 1) { cb(browserCountries); return; }
  var extra = browserCountries.slice();
  browserLangs.forEach(function(lang) {
    var lc = lang.toLowerCase().split('-')[0];
    var map = LANG_TLD_MAP[lc];
    if (!map) return;
    (mode === 2 ? map.continent : map.worldwide).forEach(function(tld) {
      if (extra.indexOf(tld) === -1) extra.push(tld);
    });
  });
  cb(extra);
}

function rebuildTldList(mode, browserLangs, manualTlds, excludedTlds, cb) {
  computeAutoTlds(mode, browserLangs, function(autoTlds) {
    var merged = BASE_TLDS.slice();
    autoTlds.forEach(function(t) { if (merged.indexOf(t) === -1) merged.push(t); });
    (manualTlds || []).forEach(function(t) { if (merged.indexOf(t) === -1) merged.push(t); });
    // Drop anything the user explicitly removed, even if auto-detection or BASE_TLDS
    // would otherwise re-add it. BASE_TLDS itself is exempt — those are the extension's
    // core defaults and shouldn't be permanently excludable.
    if (excludedTlds && excludedTlds.length) {
      merged = merged.filter(function(t) {
        return BASE_TLDS.indexOf(t) !== -1 || excludedTlds.indexOf(t) === -1;
      });
    }
    cb(merged);
  });
}

// Rebuild the blocked TLD list from the current mode and manual additions.
// Mode 0=None (empty), 1=User (manual only), 2=Generic, 3=World.
function rebuildBlockedTldList(mode, manualBlockedTlds) {
  var base = [];
  if (mode === 2) base = GENERIC_BLOCKED_TLDS.slice();
  else if (mode === 3) base = WORLD_BLOCKED_TLDS.slice();
  var merged = base.slice();
  (manualBlockedTlds || []).forEach(function(t) {
    if (merged.indexOf(t) === -1) merged.push(t);
  });
  return merged;
}

function renderBlockedTags() {
  renderPage('blocked-tld-tags', state.blockedTlds, 0);
}

// ── Lock button ───────────────────────────────────────────────────────────────
// ── Whitelist dropdowns ───────────────────────────────────────────────────────
// Applies the current dropdown open/closed state for both TLD (L3) and domain (L4)
// panels. Called on boot and whenever the user toggles a dropdown.
function applyDropdownState() {
  var tldOpen       = state.whitelistDropdown && state.whitelistDropdown.tld    !== false;
  var domainOpen    = state.whitelistDropdown && state.whitelistDropdown.domain !== false;
  var blockedTldOpen = state.blockedTldDropdownOpen === true; // starts collapsed (false)

  var tldBtn     = document.getElementById('tldDropdownBtn');
  var tldContent = document.getElementById('tldDropdownContent');
  var domBtn     = document.getElementById('domainDropdownBtn');
  var domContent = document.getElementById('domainDropdownContent');
  var blkBtn     = document.getElementById('blockedTldDropdownBtn');
  var blkContent = document.getElementById('blockedTldDropdownContent');

  if (tldBtn && tldContent) {
    tldBtn.classList.toggle('open', tldOpen);
    tldContent.classList.toggle('collapsed', !tldOpen);
  }
  if (domBtn && domContent) {
    domBtn.classList.toggle('open', domainOpen);
    domContent.classList.toggle('collapsed', !domainOpen);
  }
  if (blkBtn && blkContent) {
    blkBtn.classList.toggle('open', blockedTldOpen);
    blkContent.classList.toggle('collapsed', !blockedTldOpen);
  }
}

function initDropdownToggle(btnId, contentId, stateKey) {
  var btn     = document.getElementById(btnId);
  var content = document.getElementById(contentId);
  if (!btn || !content) return;
  btn.addEventListener('click', function() {
    var nowOpen = content.classList.contains('collapsed');
    content.classList.toggle('collapsed', !nowOpen);
    btn.classList.toggle('open', nowOpen);
    if (stateKey === 'blockedTld') {
      // blockedTld dropdown state stored separately from whitelistDropdown
      state.blockedTldDropdownOpen = nowOpen;
    } else {
      if (!state.whitelistDropdown) state.whitelistDropdown = { tld: true, domain: true };
      state.whitelistDropdown[stateKey] = nowOpen;
    }
    pushState();
  });
}

function renderLockBtn() {
  var btn     = document.getElementById('lockBtn');
  var tooltip = document.getElementById('lockTooltip');
  if (!btn) return;

  var isPinned = lockDomain && state.siteRules && state.siteRules.hasOwnProperty(lockDomain);

  if (isPinned) {
    var pinnedLevel = state.siteRules[lockDomain];
    var color       = LEVEL_COLORS[pinnedLevel - 1];
    btn.innerHTML   = SVG_LOCKED;
    btn.style.background    = color;
    btn.classList.add('is-locked');
    tooltip.textContent = 'Locked to L' + pinnedLevel + ' \u2014 click to unlock';
  } else {
    btn.innerHTML   = SVG_UNLOCKED;
    btn.style.background    = 'var(--surface)';
    btn.classList.remove('is-locked');
    tooltip.textContent = 'Lock L' + sessionLevel + ' for this site';
  }
}

function handleLockClick() {
  if (!lockDomain) return;
  if (state.siteRules && state.siteRules.hasOwnProperty(lockDomain)) {
    // Unlock
    chrome.runtime.sendMessage({ type: "REMOVE_SITE_RULE", host: lockDomain }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok) {
        delete state.siteRules[lockDomain];
        state.siteRulesOrder = (state.siteRulesOrder || []).filter(function(h) { return h !== lockDomain; });
        updateRuleCount(resp.ruleCount);
        render();
        renderLockBtn();
        renderPinnedList();
      }
    });
  } else {
    // Lock to current level — capture host, level and restore target before async call
    // so concurrent state changes (e.g. auto-TLD mode) can't corrupt the restore.
    var lockedHost     = lockDomain;
    var lockedLevel    = sessionLevel;
    var restoreToLevel = prevSessionLevel;
    chrome.runtime.sendMessage({ type: "ADD_SITE_RULE", host: lockedHost, level: lockedLevel }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok) {
        if (!state.siteRules) state.siteRules = {};
        if (!state.siteRulesOrder) state.siteRulesOrder = [];
        // FIFO eviction mirror in popup state
        if (!state.siteRules.hasOwnProperty(lockedHost)) {
          if (state.siteRulesOrder.length >= 100) {
            var evicted = state.siteRulesOrder.shift();
            delete state.siteRules[evicted];
          }
          state.siteRulesOrder.push(lockedHost);
        }
        state.siteRules[lockedHost] = lockedLevel;
        // Restore session to the captured pre-lock level
        sessionLevel     = restoreToLevel;
        prevSessionLevel = restoreToLevel;
        state.level      = sessionLevel;
        chrome.storage.session.set({ sessionLevel: sessionLevel, prevSessionLevel: prevSessionLevel });
        // Update icon to restored session level and sync background global level
        chrome.runtime.sendMessage({ type: "SET_ICON", level: sessionLevel });
        chrome.runtime.sendMessage({ type: "SET_STATE", state: state });
        updateRuleCount(resp.ruleCount);
        render();
        renderLockBtn();
        renderPinnedList();
      }
    });
  }
}

// ── Pinned sites list (no UI — hidden FIFO list) ────────────────────────────
function renderPinnedList() { /* no panel — managed silently in background */ }

// ── Tabs ──────────────────────────────────────────────────────────────────────
function updateTabs(displayLevel) {
  var lvl              = LEVELS[(displayLevel || 1) - 1];
  var tabBar           = document.querySelector('.tab-bar');
  var domainTab        = document.querySelector('[data-tab="domain"]');
  var tldTab           = document.querySelector('[data-tab="tld"]');
  var domainPanel      = document.getElementById('panel-domain');
  var tldPanel         = document.getElementById('panel-tld');
  var blockedTldPanel  = document.getElementById('panel-blocked-tld');

  // Guard: if DOM elements missing, bail out
  if (!tabBar || !domainTab || !tldTab || !domainPanel || !tldPanel) return;

  // Always hide the blocked TLD panel except at L2
  if (blockedTldPanel) blockedTldPanel.style.display = (displayLevel === 2) ? 'block' : 'none';

  // L1: hide tab bar and all panels
  if (displayLevel === 1) {
    tabBar.style.display = 'none';
    domainPanel.classList.remove('active');
    tldPanel.classList.remove('active');
    return;
  }

  // L2: hide tab bar (no whitelist tabs needed) but show the blocked TLD panel below
  if (displayLevel === 2) {
    tabBar.style.display = 'none';
    domainPanel.classList.remove('active');
    tldPanel.classList.remove('active');
    return;
  }
  tabBar.style.display = '';

  // L3: TLD only
  if (displayLevel === 3) {
    domainTab.style.display = 'none';
    tldTab.style.display = '';
    domainTab.classList.remove('active');
    tldTab.classList.add('active');
    tldTab.style.borderBottomColor = lvl.color;
    domainPanel.classList.remove('active');
    tldPanel.classList.add('active');
    return;
  }

  // L4, L5: domain only
  tldTab.style.display = 'none';
  domainTab.style.display = '';
  tldTab.classList.remove('active');
  domainTab.classList.add('active');
  domainTab.style.borderBottomColor = lvl.color;
  tldPanel.classList.remove('active');
  domainPanel.classList.add('active');
}

// ── Render ────────────────────────────────────────────────────────────────────
function render() {
  // Guard: bail out if DOM not ready
  if (!document.getElementById('levelNum')) return;

  // If on a pinned site show its locked level in the slider, else show sessionLevel/state.level
  var isPinned   = lockDomain && state.siteRules && state.siteRules.hasOwnProperty(lockDomain);
  var displayVal = isPinned ? state.siteRules[lockDomain] : sessionLevel;
  var val        = displayVal || 1;
  var lvl        = LEVELS[val - 1];

  document.getElementById('levelNum').textContent  = val;
  document.getElementById('levelName').textContent = lvl.name;
  document.documentElement.style.setProperty('--accent', lvl.color);

  // Track fill
  var slider    = document.getElementById('slider');
  var trackFill = document.getElementById('trackFill');
  var fillPx    = 9 + ((slider.offsetWidth - 18) * (val - 1) / 4);
  trackFill.style.width      = fillPx + 'px';
  trackFill.style.background = lvl.color;

  // Disable slider and show hint when on a pinned site
  slider.disabled = isPinned;
  var hint = document.getElementById('siteLockHint');
  if (hint) hint.classList.toggle('visible', isPinned);

  // Ticks
  for (var i = 1; i <= 5; i++) {
    var tick = document.getElementById('tick-' + i);
    if (tick) tick.classList.toggle('active', i === val);
  }

  // Policy rules
  var html = '';
  // At L2: built-in whitelist frames line is first, JS-libraries line is second — inject both before the loop
  if (val === 2) {
    html += '<div class="rule-row"><div class="rule-dot allow"></div>'
      + '<div class="rule-text">Built-in whitelist allows 3P frames from payment services, '
      + 'video embeds and CAPTCHA\u2019s</div></div>';
    html += '<div class="rule-row"><div class="rule-dot allow"></div>'
      + '<div class="rule-text">Built-in whitelist allows important JS-libraries</div></div>';
    var blockedCount = (state.blockedTldMode > 0 && state.blockedTlds) ? state.blockedTlds.length : 0;
    html += '<div class="rule-row"><div class="rule-dot block"></div>'
      + '<div class="rule-text">Blocks 3P-scripts from ' + blockedCount + ' risky TLD\u2019s</div></div>';
  }
  for (var r = 0; r < lvl.rules.length; r++) {
    var rule = lvl.rules[r];
    var ruleText = rule.text;

    // ##TLDWHITELIST## — inject TLD count + info line + built-in lines all at once
    if (ruleText === '##TLDWHITELIST##') {
      html += '<div class="rule-row"><div class="rule-dot allow"></div>'
        + '<div class="rule-text">Allows 3P-scripts from ' + (state.tlds ? state.tlds.length : 0) + ' allowed TLD\u2019s</div></div>';
      html += '<div class="rule-row rule-info"><div class="rule-text rule-text-info">(covers 95% of traffic, but halves JS attack surface)</div></div>';
      html += '<div class="rule-row"><div class="rule-dot allow"></div>'
        + '<div class="rule-text">Built-in whitelist allows 3P frames from payment services, '
        + 'video embeds and CAPTCHA\u2019s</div></div>';
      html += '<div class="rule-row"><div class="rule-dot allow"></div>'
        + '<div class="rule-text">Built-in whitelist allows important JS-libraries</div></div>';
      continue;
    }

    if (rule.type === 'info') {
      html += '<div class="rule-row rule-info"><div class="rule-text rule-text-info">' + ruleText + '</div></div>';
    } else {
      var dot = (val === 1)
        ? '<div class="rule-hyphen">\u2013</div>'
        : '<div class="rule-dot ' + rule.type + '"></div>';
      html += '<div class="rule-row">' + dot + '<div class="rule-text">' + ruleText + '</div></div>';
    }
    // At L4: inject built-in lines after the first rule (CDN line)
    if (r === 0 && val === 4) {
      html += '<div class="rule-row"><div class="rule-dot allow"></div>'
        + '<div class="rule-text">Built-in whitelist allows 3P frames from payment services, '
        + 'video embeds and CAPTCHA\u2019s</div></div>';
      html += '<div class="rule-row"><div class="rule-dot allow"></div>'
        + '<div class="rule-text">Built-in whitelist allows important JS-libraries</div></div>';
    }
  }
  var ruleListEl = document.getElementById('ruleList');
  if (ruleListEl) ruleListEl.innerHTML = html;

  // Startup badge
  var badge = document.getElementById('startupBadge');
  if (badge) badge.style.borderColor = LEVELS[(state.startupLevel || 1) - 1].color;
  var sel = document.getElementById('startupSelect');
  if (sel) sel.value = String(state.startupLevel);

  // Hide "Show blocked domains panel" toggle at L1 — irrelevant when everything is allowed
  var badgeToggleRow = document.getElementById('badgeToggleRow');
  if (badgeToggleRow) badgeToggleRow.style.display = (val === 1) ? 'none' : 'flex';

  // Tab active underline color
  document.querySelectorAll('.tab-btn.active').forEach(function(btn) {
    btn.style.borderBottomColor = lvl.color;
  });

  // Add button colors
  var addBtns = document.querySelectorAll('.wl-add-btn');
  for (var b = 0; b < addBtns.length; b++) {
    addBtns[b].style.color      = (val === 5) ? '#FFFFFF' : '#000000';
    addBtns[b].style.background = lvl.color;
  }

  updateTabs(val);
  renderLockBtn();
}

// ── Push state ────────────────────────────────────────────────────────────────
function pushState() {
  if (typeof chrome === 'undefined' || !chrome.runtime) return;
  chrome.runtime.sendMessage({ type: "SET_STATE", state: state }, function(resp) {
    if (chrome.runtime.lastError) return;
    if (resp && resp.ok) updateRuleCount(resp.ruleCount);
  });
}

function updateRuleCount(n) {
  // no dedicated counter element in this version, ignore
}

// ── Paginated whitelist ───────────────────────────────────────────────────────
function renderDomainTags() {
  // Domain whitelist tab is only ever shown at L4/L5 — built-in trusted domains (L2 only)
  // are never mixed into this view since L2 has no whitelist UI at all.
  renderPage('domain-tags', state.domains, 0);
}

function renderPage(containerId, items, page) {
  var container = document.getElementById(containerId);
  var isTld     = containerId === 'tld-tags';
  if (!container) return;
  container.innerHTML = '';
  if (!items || items.length === 0) {
    var e = document.createElement('div'); e.className = 'wl-empty'; e.textContent = 'None added yet';
    container.appendChild(e);
    return;
  }
  var pageSize   = isTld ? TLD_PAGE_SIZE : DOMAIN_PAGE_SIZE;
  var totalPages = Math.ceil(items.length / pageSize);
  page = Math.max(0, Math.min(page, totalPages - 1));
  if (isTld) tldPage = page; else domainPage = page;
  var start = page * pageSize, end = Math.min(start + pageSize, items.length);
  for (var i = start; i < end; i++) {
    (function(v) {
      var tag = document.createElement('div'); tag.className = 'wl-tag';
      var LOWERCASE = {'ai':true,'io':true};
      var display = (v.length === 2 && !LOWERCASE[v]) ? v.toUpperCase() : v;
      tag.innerHTML = display + '<button class="wl-tag-remove" title="Remove">&times;</button>';
      tag.querySelector('.wl-tag-remove').addEventListener('click', function() {
        if (isTld) {
          state.tlds = state.tlds.filter(function(x) { return x !== v; });
          if (state.manualTlds) {
            state.manualTlds = state.manualTlds.filter(function(x) { return x !== v; });
          }
          // Remember the removal so auto-detection or manual re-typing won't silently
          // bring it back, unless it's one of the extension's core BASE_TLDS defaults.
          if (BASE_TLDS.indexOf(v) === -1) {
            if (!state.excludedTlds) state.excludedTlds = [];
            if (state.excludedTlds.indexOf(v) === -1) state.excludedTlds.push(v);
          }
          renderPage(containerId, state.tlds, tldPage);
        } else {
          state.domains = state.domains.filter(function(x) { return x !== v; });
          renderDomainTags();
        }
        pushState();
      });
      container.appendChild(tag);
    })(items[i]);
  }
}

function initWhitelist(inputId, btnId, tagsId, stateKey) {
  var input    = document.getElementById(inputId);
  var btn      = document.getElementById(btnId);
  var isTld    = stateKey === 'tlds';
  var sanitize = isTld
    ? function(v) { return v.replace(/^\.+/, '').toLowerCase(); }
    : function(v) { return v.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').toLowerCase(); };

  function addEntry() {
    var raw = sanitize(input.value.trim());
    if (!raw || state[stateKey].length >= 100 || state[stateKey].indexOf(raw) !== -1) {
      input.value = ''; return;
    }
    state[stateKey].push(raw);
    if (isTld) {
      renderPage(tagsId, state.tlds, Math.floor((state.tlds.length - 1) / TLD_PAGE_SIZE));
    } else {
      renderDomainTags();
    }
    input.value = ''; input.focus();
    pushState();
  }
  btn.addEventListener('click', addEntry);
  input.addEventListener('keydown', function(e) { if (e.key === 'Enter') addEntry(); });
  if (isTld) {
    renderPage(tagsId, state.tlds, 0);
  } else {
    renderDomainTags();
  }
}

// ── Boot ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {

  // Ticks
  var tickRow = document.getElementById('tickRow');
  for (var i = 1; i <= 5; i++) {
    var t = document.createElement('div');
    t.className = 'tick'; t.textContent = i; t.id = 'tick-' + i;
    tickRow.appendChild(t);
  }

  // Slider: pinned sites keep their lock, slider only changes global session level
  document.getElementById('slider').addEventListener('input', function() {
    var newLevel     = parseInt(this.value, 10);
    prevSessionLevel = sessionLevel;
    sessionLevel     = newLevel;
    state.level      = newLevel;
    chrome.storage.session.set({ sessionLevel: sessionLevel, prevSessionLevel: prevSessionLevel });

    // Auto-collapse both whitelist dropdowns when the user moves the slider —
    // so next time they arrive at L3 or L4 they see the compact version, not
    // the expanded one they may have already read.
    if (!state.whitelistDropdown) state.whitelistDropdown = { tld: true, domain: true };
    state.whitelistDropdown.tld    = false;
    state.whitelistDropdown.domain = false;

    render();
    applyDropdownState();
    chrome.runtime.sendMessage({ type: "SET_STATE", state: state }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok) {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
          if (tabs && tabs[0] && tabs[0].id) chrome.tabs.reload(tabs[0].id);
        });
      }
    });
  });

  // Startup select
  document.getElementById('startupSelect').addEventListener('change', function() {
    state.startupLevel = parseInt(this.value, 10);
    render(); pushState();
  });

  // Tabs
  document.querySelectorAll('.tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.tab-btn').forEach(function(b) {
        b.classList.remove('active'); b.style.borderBottomColor = '';
      });
      document.querySelectorAll('.tab-panel').forEach(function(p) { p.classList.remove('active'); });
      this.classList.add('active');
      this.style.borderBottomColor = LEVELS[state.level - 1].color;
      document.getElementById('panel-' + this.dataset.tab).classList.add('active');
    }.bind(btn));
  });

  initWhitelist('domain-input', 'domain-add', 'domain-tags', 'domains');
  initWhitelist('tld-input',    'tld-add',    'tld-tags',    'tlds');

  // Whitelist dropdown toggles — L3 TLD and L4 Domain panels
  initDropdownToggle('tldDropdownBtn',        'tldDropdownContent',        'tld');
  initDropdownToggle('domainDropdownBtn',     'domainDropdownContent',     'domain');
  initDropdownToggle('blockedTldDropdownBtn', 'blockedTldDropdownContent', 'blockedTld');

  // ── TLD Blacklist slider (Level 2) ──────────────────────────────────────────
  var blockedTldSliderEl = document.getElementById('blockedTldSlider');
  var blockedTldValueEl  = document.getElementById('blockedTldValue');
  var blockedTldHintEl   = document.getElementById('blockedTldHint');

  function updateBlockedTldSliderUI(mode) {
    if (blockedTldValueEl) blockedTldValueEl.textContent = BLOCKED_TLD_LABELS[mode];
    if (blockedTldHintEl)  blockedTldHintEl.textContent  = BLOCKED_TLD_HINTS[mode];
    if (blockedTldSliderEl) blockedTldSliderEl.value = mode;
  }

  function applyBlockedTldMode(mode) {
    state.blockedTldMode = mode;
    state.blockedTlds    = rebuildBlockedTldList(mode, state.manualBlockedTlds || []);
    renderBlockedTags();
    render(); // update Active Policy blocked TLD count
    pushState();
  }

  if (blockedTldSliderEl) {
    blockedTldSliderEl.addEventListener('input', function() {
      var mode = parseInt(this.value, 10);
      updateBlockedTldSliderUI(mode);
      applyBlockedTldMode(mode);
    });
  }

  // Blocked TLD manual add
  var blockedTldInput  = document.getElementById('blocked-tld-input');
  var blockedTldAddBtn = document.getElementById('blocked-tld-add');
  function addBlockedTld() {
    if (!blockedTldInput) return;
    var raw = blockedTldInput.value.trim().replace(/^\.+/, '').toLowerCase();
    if (!raw) return;
    if (!state.manualBlockedTlds) state.manualBlockedTlds = [];
    if (state.manualBlockedTlds.indexOf(raw) === -1) state.manualBlockedTlds.push(raw);
    if (state.blockedTlds.indexOf(raw) === -1) {
      state.blockedTlds.push(raw);
      renderBlockedTags();
      pushState();
    }
    blockedTldInput.value = ''; blockedTldInput.focus();
  }
  if (blockedTldAddBtn) blockedTldAddBtn.addEventListener('click', addBlockedTld);
  if (blockedTldInput)  blockedTldInput.addEventListener('keydown', function(e) { if (e.key === 'Enter') addBlockedTld(); });

  updateBlockedTldSliderUI(state.blockedTldMode || 0);
  renderBlockedTags();


  var domainRowsSelect = document.getElementById('domainRowsSelect');
  if (domainRowsSelect) {
    domainRowsSelect.addEventListener('change', function() {
      domainTags.style.height = this.value + 'px';
    });
  }

  // Auto TLD slider
  var autoSlider  = document.getElementById('autoTldSlider');
  var autoValue   = document.getElementById('autoTldValue');
  var autoHint    = document.getElementById('autoTldHint');
  var browserLangs = [];
  if (typeof chrome !== 'undefined' && chrome.i18n) {
    chrome.i18n.getAcceptLanguages(function(langs) { browserLangs = langs || []; });
  }
  function updateAutoSliderUI(mode) {
    autoValue.textContent = AUTO_TLD_LABELS[mode];
    autoHint.textContent  = AUTO_TLD_HINTS[mode];
    autoSlider.value      = mode;
  }
  function applyAutoTlds(mode) {
    chrome.i18n.getAcceptLanguages(function(langs) {
      browserLangs = langs || [];
      rebuildTldList(mode, browserLangs, state.manualTlds || [], state.excludedTlds || [], function(merged) {
        state.tlds = merged; state.autoTldMode = mode;
        renderPage('tld-tags', state.tlds, 0);
        render(); // update Active Policy TLD count
        pushState();
      });
    });
  }
  autoSlider.addEventListener('input', function() {
    var mode = parseInt(this.value, 10);
    updateAutoSliderUI(mode); applyAutoTlds(mode);
  });

  // Manual TLD add
  var tldInput  = document.getElementById('tld-input');
  var tldAddBtn = document.getElementById('tld-add');
  function addManualTld() {
    var raw = tldInput.value.trim().replace(/^\.+/, '').toLowerCase();
    if (!raw) return;
    if (!state.manualTlds) state.manualTlds = [];
    if (state.manualTlds.indexOf(raw) === -1) state.manualTlds.push(raw);
    // Re-adding a previously-excluded TLD clears the exclusion — explicit re-add wins.
    if (state.excludedTlds) {
      state.excludedTlds = state.excludedTlds.filter(function(x) { return x !== raw; });
    }
    if (state.tlds.indexOf(raw) === -1) {
      state.tlds.push(raw);
      renderPage('tld-tags', state.tlds, Math.floor((state.tlds.length - 1) / TLD_PAGE_SIZE));
      pushState();
    }
    tldInput.value = ''; tldInput.focus();
  }
  tldAddBtn.addEventListener('click', addManualTld);
  tldInput.addEventListener('keydown', function(e) { if (e.key === 'Enter') addManualTld(); });

  // Lock button
  document.getElementById('lockBtn').addEventListener('click', handleLockClick);

  // Log button
  var logBtn   = document.getElementById('logBtn');
  var clearBtn = document.getElementById('clearBtn');
  function updateLogBtn(logging) {
    if (logging) {
      logBtn.textContent = 'LOGGING\u2026'; logBtn.classList.add('active');
      clearBtn.style.display = '';
    } else {
      logBtn.textContent = 'SHOW LOGS'; logBtn.classList.remove('active');
      clearBtn.style.display = 'none';
    }
  }
  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.get({ logging: false }, function(s) { updateLogBtn(s.logging); });
  }
  logBtn.addEventListener('click', function() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;
    chrome.storage.local.get({ logging: false }, function(s) {
      if (s.logging) {
        chrome.tabs.create({ url: chrome.runtime.getURL('logger.html') });
      } else {
        chrome.storage.local.set({ logging: true, logStartTime: Date.now(), logs: [], logsCapHit: false }, function() {
          updateLogBtn(true);
          chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs && tabs[0]) chrome.tabs.reload(tabs[0].id);
          });
          chrome.tabs.create({ url: chrome.runtime.getURL('logger.html') });
          chrome.runtime.sendMessage({ type: "START_LOGGING" });
        });
      }
    });
  });
  clearBtn.addEventListener('click', function() {
    chrome.storage.local.set({ logs: [] });
  });
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.onMessage.addListener(function(msg) {
      if (msg.type === "LOGGING_STOPPED") updateLogBtn(false);
    });
  }

  // "Show blocked domains panel" toggle — controls a future panel feature (v2.0).
  // The toolbar badge count is now always active regardless of this toggle.
  var badgeToggle = document.getElementById('showBlockedCountToggle');
  if (badgeToggle) {
    badgeToggle.addEventListener('change', function() {
      state.showBlockedDomainsPanel = badgeToggle.checked;
      pushState();
    });
  }

  // Get current tab hostname
  if (typeof chrome !== 'undefined' && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0] && tabs[0].url) {
        try {
          var url = new URL(tabs[0].url);
          if (url.protocol === 'http:' || url.protocol === 'https:') {
            currentHost = url.hostname;
            lockDomain  = getApexDomain(currentHost);
          }
        } catch(e) {}
      }
      var hostnameEl = document.getElementById('siteHostname');
      if (hostnameEl) hostnameEl.textContent = currentHost || '—';
      renderLockBtn();
    });
  }

  // Sync with background — read session storage first, then persistent state
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.storage.session.get({ sessionLevel: 0, prevSessionLevel: 0 }, function(sess) {
      chrome.runtime.sendMessage({ type: "GET_STATE" }, function(resp) {
        if (chrome.runtime.lastError) return;
        if (resp && resp.ok && resp.state) {
          state = Object.assign({}, DEFAULT_STATE, resp.state);
          if (!state.startupLevel) state.startupLevel = 1;
          if (!state.autoTldMode && state.autoTldMode !== 0) state.autoTldMode = 1;
          if (!state.manualTlds)    state.manualTlds    = [];
          if (!state.excludedTlds)  state.excludedTlds  = [];
          if (!state.siteRules)     state.siteRules     = {};
          if (!state.siteRulesOrder) state.siteRulesOrder = Object.keys(state.siteRules);
          if (!state.whitelistDropdown) state.whitelistDropdown = { tld: true, domain: true };
          if (!state.blockedTlds)       state.blockedTlds       = [];
          if (!state.manualBlockedTlds) state.manualBlockedTlds = [];
          if (typeof state.blockedTldMode !== 'number') state.blockedTldMode = 0;
          BASE_TLDS.forEach(function(t) { if (state.tlds.indexOf(t) === -1) state.tlds.push(t); });

          // Initialise session levels:
          // - If already set this session, restore them
          // - If first open this session (both 0), initialise from startupLevel
          if (sess.sessionLevel) {
            sessionLevel     = sess.sessionLevel;
            prevSessionLevel = sess.prevSessionLevel || sess.sessionLevel;
          } else {
            sessionLevel     = state.startupLevel;
            prevSessionLevel = state.startupLevel;
            chrome.storage.session.set({ sessionLevel: sessionLevel, prevSessionLevel: prevSessionLevel });
          }

          // Update icon to reflect actual session level (without changing stored state)
          chrome.runtime.sendMessage({ type: "SET_ICON", level: sessionLevel });

          // Set slider: pinned site shows its locked level, otherwise show sessionLevel
          var _pinned = lockDomain && state.siteRules && state.siteRules.hasOwnProperty(lockDomain);
          document.getElementById('slider').value        = _pinned ? state.siteRules[lockDomain] : sessionLevel;
          document.getElementById('startupSelect').value = String(state.startupLevel);
          updateAutoSliderUI(state.autoTldMode);

          // Re-sync the auto-added TLD list from the browser's CURRENT language settings
          // using the latest mapping logic, rather than trusting whatever was saved to
          // storage by a previous version of this logic. Manual TLD entries are preserved.
          if (state.autoTldMode !== 0 && typeof chrome !== 'undefined' && chrome.i18n) {
            chrome.i18n.getAcceptLanguages(function(currentLangs) {
              rebuildTldList(state.autoTldMode, currentLangs || [], state.manualTlds || [], state.excludedTlds || [], function(merged) {
                state.tlds = merged;
                renderPage('tld-tags', state.tlds, 0);
                pushState();
              });
            });
          }

          render();
          renderDomainTags();
          renderPage('tld-tags',    state.tlds,    0);
          renderLockBtn();
          applyDropdownState();
          updateBlockedTldSliderUI(state.blockedTldMode || 0);
          renderBlockedTags();
          if (badgeToggle) badgeToggle.checked = state.showBlockedDomainsPanel === true;
        }
      });
    });
  }
});
