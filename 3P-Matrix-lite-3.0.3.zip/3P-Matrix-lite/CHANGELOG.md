# 3P-Matrix-lite — Changelog

---

## 3.0.3 — 2026-07-29
**Fix: Show blocks race condition — session appeared expired before it ever started**

Root cause: `getMonitorData()` computed `elapsed` the same way for both
`STARTING` and `RUNNING` phases — `session.timeElapsed + (Date.now() -
session.startTime)`. But `session.startTime` is `null` during `STARTING`
(the clock doesn't truly start until `markMonitorStarted()` fires, on the
reload's navigation actually committing) — `Date.now() - null` coerces to
`Date.now() - 0`, producing a huge "elapsed" value and therefore
`remaining: 0`.

If the monitor panel's very first poll landed in the (entirely plausible)
window between `startMonitor()` registering the listener/triggering the
reload and the reload's navigation actually committing, it would see
`remaining: 0`, render the countdown as already expired ("0:00", red),
and effectively look dead on arrival — reported as "the monitor does not
start."

This is a **race condition**, not a deterministic bug — whether it
manifested depended on how fast the reload's navigation committed
relative to the panel's first poll, so it could easily have appeared to
work in earlier casual testing purely by timing luck. It has been latent
since the phase-enum hardening in v2.5.0, not introduced by this
session's rename work.

**Fix**: `getMonitorData()` now only computes the live elapsed time while
`phase === RUNNING`; `STARTING` and `PAUSED` both report the frozen
`timeElapsed` (0, until the clock actually starts) instead.

Verified via direct simulation of the exact `startMonitor()` →
`markMonitorStarted()` sequence: before the fix, a poll taken between
those two calls returned `elapsed: 1785416156405, remaining: 0`; after
the fix, the same poll correctly returns `elapsed: 0, remaining: 300000`
(the full 5 minutes).

---

## 3.0.2 — 2026-07-29
**Full "Scout" → "Matrix" naming cleanup, domain/request counter, and a live filter box**

**Naming cleanup** — internal identifiers previously kept as "scout" (a
deliberate compromise flagged when Show Matrix was first renamed from
Snoop Scout) are now fully renamed to match the user-facing name:
- Files: `core/connection-scout.js` → `core/connection-matrix.js`,
  `ui/scout-panel.html` → `ui/matrix-panel.html`,
  `ui/scout-panel.js` → `ui/matrix-panel.js`
- Constants: `SCOUT_RESOURCE_TYPES` → `MATRIX_RESOURCE_TYPES`,
  `SCOUT_CAP` → `MATRIX_CAP`, `SCOUT_DURATION` → `MATRIX_DURATION`
- Message types: `MSG_START_SCOUT` → `MSG_START_MATRIX`,
  `MSG_STOP_SCOUT` → `MSG_STOP_MATRIX`,
  `MSG_GET_SCOUT_DATA` → `MSG_GET_MATRIX_DATA`,
  `MSG_SCOUT_CLOSED` → `MSG_MATRIX_CLOSED`
- Functions: `startScout`→`startMatrix`, `stopScout`→`stopMatrix`,
  `getScoutData`→`getMatrixData`,
  `clearScoutOnNavigation`→`clearMatrixOnNavigation`,
  `clearScoutOnTabClosed`→`clearMatrixOnTabClosed`,
  `startScoutWatchdog`→`startMatrixWatchdog`,
  `_scoutListener`→`_matrixListener`
- `ScoutController` → `MatrixController` (popup.js); button id
  `snoopScoutBtn` → `showMatrixBtn` (now matches its own CSS class)

Confirmed no collision with the extension's own "3P-Matrix" branding
before starting — no existing identifier used "matrix" as a name. Full
sweep afterward (syntax, ESLint, HTML balance, manifest validity, C20/
C20a message-routing checks, and an end-to-end functional simulation of
the renamed module) all pass; a project-wide case-insensitive search
confirms zero remaining "scout" references anywhere in the codebase
(CHANGELOG history excepted, since that's a historical record).

**New: live filter box** in the Show Matrix panel — a text input above
the table that filters visible rows by domain substring match, live on
every keystroke (no round-trip to the background script; filtering
happens against the already-fetched entry list client-side). Distinct
empty-state message when the filter matches nothing ("No domains match
...") vs. genuinely no connections observed yet.

**New: domain/request counter** in the panel header ("N domains · M
requests"), reflecting true totals regardless of the filter box above.
`connection-matrix.js` now tracks a `requestCount` per tab bucket,
incremented once per qualifying `_scoutListener` (now `_matrixListener`)
event — deliberately NOT incremented by the cookie-detection listeners,
since those fire on separate stages of a request the main listener may
have already counted, which would have double- or triple-counted the
same underlying request.

**Removed**: the WebRTC data-channel disclaimer line from the panel
footnote (per request, as a tribute to original uMatrix's simplicity).

---

## 3.0.0 — 2026-07-29
**Show Matrix: stylesheet column restored, positioned after media**

Re-added the dedicated `stylesheet` column (folded into "other" as of
2.10.1's exact-uMatrix-match pass), based on a real observed pattern: many
adult sites — which lean heavily on third-party ad-tech/widget
infrastructure rather than mainstream self-hosted advertising — showed
elevated third-party stylesheet traffic. That's a legitimate, visible
signal about how much embedded external infrastructure a page pulls in,
distinct from the CSS-content-inspection concern (NoScript's "Block
CSS-based scanners") that this tool still can't address, since
`webRequest` only sees that a stylesheet request happened, never its
content.

Column order: cookie / image / media / **stylesheet** / script / frame /
fetch-xhr / other. Panel widened 900px → 960px for the 8th column.

Font/object/ping/csp_report/webbundle/websocket remain folded into
"other."

**Version bump to 3.0.0** at the user's explicit request, marking this as
a deliberate milestone rather than continuing the 2.x patch/minor
sequence — no breaking changes accompany this jump; it's a version-number
decision, not a compatibility one.

---

## 2.10.1 — 2026-07-29
**Show Matrix: exact match to original uMatrix's column set + cookie-detection performance note**

- Dropped the dedicated `stylesheet` column — folds back into `other`
  alongside font/object/ping/csp_report/webbundle/websocket. Column set
  now matches original uMatrix exactly: cookie / image / media / script /
  frame / fetch-xhr / other.
- Panel narrowed 960px → 900px for one fewer column.
- Added a footnote line: cookie detection (via `extraHeaders`) has a real
  Chrome-documented performance cost under Manifest V3 — recommends using
  Show Matrix on-demand rather than leaving it running continuously.

---

## 2.10.0 — 2026-07-29
**Added: cookie column (tribute to original uMatrix's column set)**

Unlike every other column, `cookie` is not a `webRequest.ResourceType` —
it's a signal derived from inspecting the `Cookie` (outgoing) and
`Set-Cookie` (incoming) HTTP headers, which requires two additional
listener stages beyond the existing `onBeforeRequest`:

- `onBeforeSendHeaders` — detects an outgoing `Cookie` header (the browser
  sending a previously-stored cookie back to that third party)
- `onHeadersReceived` — detects an incoming `Set-Cookie` header (that
  third party asking the browser to store a new cookie)

Both require the `'extraHeaders'` extraInfoSpec — Chrome hides
Cookie/Set-Cookie from webRequest listeners by default (since Chrome 72)
unless explicitly requested. **Real, documented Chrome performance cost**
to specifying `extraHeaders`; accepted as the tradeoff for having this
signal at all. Neither listener requests `'blocking'`, so this stays
compatible with Manifest V3's restriction on blocking webRequest for
non-policy-installed extensions.

Refactored `_scoutListener`'s third-party-host resolution and
entry-lookup-or-create logic into shared helpers (`_thirdPartyHostFor`,
`_getOrCreateEntry`), since the two new cookie listeners need identical
logic — avoids three copies of the same skip/dedup logic.

Verified via simulation: a script request with no cookie header stays
untagged; a request with an outgoing `Cookie` header gets tagged; a
response with an incoming `Set-Cookie` header gets tagged; a request with
headers present but no cookie-related header stays untagged.

Column order updated to roughly follow original uMatrix's sequence:
cookie / image / media / script / frame / stylesheet / fetch-xhr / other
(stylesheet retained from the earlier round; websocket remains folded
into "other" per the previous decision). Panel widened 890px → 960px for
the 8th column.

---

## 2.9.3 — 2026-07-29
**Show Matrix: websocket folded into "other", media kept — matching original uMatrix's column set**

- Removed the dedicated `websocket` column; it now collapses into `other`
  alongside font/object/ping/csp_report/webbundle.
- Kept `media` as its own column, since original uMatrix had one.
- Table is now 6 type columns: script / frame / image / media /
  stylesheet / fetch-xhr / other (7 including domain).
- Panel window narrowed 960px → 890px for the one fewer column.

---

## 2.9.2 — 2026-07-29
**Fix: webbundle/csp_report were invisible instead of collapsing into "other"**

`SCOUT_RESOURCE_TYPES` didn't include `webbundle` or `csp_report` at all,
so Chrome never delivered those events to the listener in the first
place — they weren't "other," they were invisible. Added both to the
filter and to `_typeLabel()`'s "other" collapse group, alongside
font/object/ping.

**Confirmed `webtransport` is deliberately NOT added**: pulled Chrome's
actual current `webRequest.ResourceType` enum directly from their
documentation — `"webtransport"` is not a member of it (only
`declarativeNetRequest.ResourceType`, a different API, includes it).
Adding a type string to the listener's filter that isn't a real
`webRequest.ResourceType` value risked breaking the listener registration
entirely. WebTransport handshakes (which `webRequest` does document
intercepting, per Chrome's own release notes) most likely already surface
as `"other"` given the enum's actual contents.

Only `stylesheet` gets its own column, per this round's direction — no
separate columns for webbundle/webtransport/csp_report; all fold into
"other" alongside font/object/ping.

---

## 2.9.1 — 2026-07-29
**Show Matrix: added stylesheet column, removed websocket disclaimer**

- `stylesheet` now gets its own table column instead of collapsing into
  "other" — 8 type columns total (script/frame/image/media/stylesheet/
  fetch-xhr/websocket/other). `font`/`object`/`ping` still collapse into
  "other".
- Removed the "Websocket only shows that a connection opened..." sentence
  from the panel footnote. The WebRTC limitation note remains.
- Panel window widened 900px → 960px; column width 58px → 64px to
  comfortably fit the new column.

---

## 2.9.0 — 2026-07-29
**Renamed Snoop Scout → Show Matrix; removed field-heuristics feature;
removed pre-launch confirm dialog; always reloads; full uMatrix-style
resource-type coverage**

After the field-classification heuristics repeatedly failed to detect
fields that were clearly visible on real pages (Ziggo's login form,
notably) — and it became clear the underlying question ("which
third-party connection is *this* field's data actually going to?") wasn't
answerable with the DOM-inventory approach that had been built — that
whole feature direction was abandoned rather than patched further.

**Removed entirely:**
- `core/field-classifier.js`, `core/field-scanner-core.js`,
  `data/field-patterns.js`, and the whole `content/` directory
- The `scripting` permission (no longer needed — no content-script
  injection happens anymore)
- The "Looking at" panel section and its chips
- The pre-launch reload-vs-passive confirm dialog (`scoutConfirmOverlay`
  and its CSS/JS wiring) — no more Cancel/NO-RELOAD/YES-RELOAD choice

**Renamed:** the feature is now **Show Matrix**, not Snoop Scout, in every
user-facing string (button, panel title, tooltip). Internal file/module
names (`scout-panel.*`, `connection-scout.js`, message type names like
`START_SCOUT`) were deliberately **not** renamed, to limit the size of
this change — flagged explicitly rather than done silently.

**Behavior change:** launching Show Matrix now **always reloads** the tab
immediately, matching Show blocks' original behavior — no more passive
("continue without reload") option.

**Expanded resource-type coverage**, matching classic uMatrix's full
matrix view rather than a narrow subset: `SCOUT_RESOURCE_TYPES` now
covers the complete set (script, frame, image, media, stylesheet, font,
object, fetch/xhr, websocket, ping, other) instead of just
script/frame/fetch-xhr/websocket. The panel table gained **image**,
**media**, and **other** columns (stylesheet/font/object/ping collapse
into "other" to keep the table readable) — 7 type columns total. Panel
window widened 700px → 900px to fit them.

No message types, storage keys renamed. `MSG_REPORT_PAGE_FIELDS` removed
(no longer has a producer or consumer).

---

## 2.8.2 — 2026-07-29
**Fix: "No form fields detected" on real login pages (Ziggo)**

A visible email + password login form was reported as having no fields at
all. Two compounding causes, both fixed:

1. **SPA rendering timing.** A single one-shot scan can miss forms that a
   JS framework renders after the page's "load" event fires (common —
   many SPAs ship an empty root `<div>` in the initial HTML). Fixed by
   adding a debounced `MutationObserver` in `content/field-scanner.js`
   that re-scans and re-reports as the DOM changes, instead of scanning
   once and stopping.
2. **Iframe-scoped forms.** The scanner only ever looked at the top-level
   document. `chrome.scripting.executeScript` is now called with
   `{allFrames: true}` — the extension's `<all_urls>` host permission
   allows this to reach cross-origin iframes too, something a page's own
   script could never do under the same-origin policy.

Multi-frame reporting required a structural change: `connection-scout.js`
now stores one field-scan summary **per frame** (`pageFieldsByFrame: Map
<frameId, summary>`, keyed via `chrome.runtime.MessageSender.frameId`)
rather than a single value that the most recent report would silently
overwrite. `getScoutData()` merges all frames' summaries (counts summed,
field lists concatenated) for the popup. Verified via simulation: two
frames reporting independently, one frame re-scanning without clobbering
the other's data, and a full clear on navigation.

**Known remaining limitation:** an iframe that navigates to a new URL
*within itself* (without a full top-level page navigation) won't get a
fresh scanner injection — the navigation hooks only fire for the
top-level frame. The `MutationObserver` still catches same-document DOM
changes within that iframe; only an iframe-internal *navigation* falls
outside current coverage.

---

## 2.8.1 — 2026-07-29
**Fix: field scanner injected too early to see any form fields**

The field-scanner (re-)injection on navigation was hooked to
`webNavigation.onCommitted`, which fires at the very start of a
navigation — before the DOM is built or any page JS has run. Injecting
there meant the scanner almost always scanned an empty document, so
"Looking at" showed nothing regardless of which page was tested.

Moved field-scanner (re-)injection to its own `webNavigation.onCompleted`
listener, which fires once the page has actually finished loading —
`onCommitted` is still used for the monitor timer-start and Scout
entry-clearing, which are correct to do early. The reload path (Scout's
"YES-RELOAD" choice) is affected by this too, since it relied entirely on
the navigation hook to trigger the re-scan after the reload.

The very first scan on a passive ("NO-RELOAD") Scout start was not
affected — it injects immediately against the page's current, already-
loaded DOM at the moment the button is clicked.

---

## 2.8.0 — 2026-07-29
**New: "Looking at" field-classification heuristics**

Snoop Scout's panel now shows a page-level summary of detected form fields,
classified as sensitive (password, card number, CVC, expiry, passport
number) or form (name, email, phone, address, zip, city, company,
username), via a new content-script-based scanner.

New files:
- `data/field-patterns.js` — regex patterns sourced directly from
  Chromium's `autofill_regex_constants.cc.utf8` and Firefox's
  `HeuristicsRegExp.sys.mjs` (real production autofill heuristics, not
  invented). Covers English plus the 7 EU languages both browsers actually
  cover: German, French, Spanish, Italian, Portuguese, Dutch, Polish.
  **Deliberately does not guess translations for the other ~17 EU official
  languages** (Swedish, Danish, Finnish, Greek, Czech, Slovak, Slovenian,
  Croatian, Romanian, Bulgarian, Hungarian, Estonian, Latvian, Lithuanian,
  Maltese, Irish, and others) — a wrong translation of "password" would be
  worse than an honest, visible gap for a feature whose entire point is
  catching sensitive fields. Stated explicitly in the panel's footnote and
  in the file's own header comment.
- `core/field-classifier.js` — pure classifier: structural signals
  (`type="password"`, standards-compliant `autocomplete` tokens) checked
  before any regex, per Chromium's own design principle that input type is
  more reliable across languages than name-based matching. Verified with
  25 test cases spanning every covered language.
- `core/field-scanner-core.js` — pure DOM-scanning logic (no `chrome.*`
  API usage), verified against a synthetic multi-language test form via
  jsdom.
- `content/field-scanner.js` — the actual injectable content script.
  Written as a **classic script** using dynamic `import()` rather than
  static `import`/`export`, since `chrome.scripting.executeScript({files})`
  cannot execute ES modules directly.

**Wiring:** injected on Scout start (immediately for a passive start; via
the existing navigation hook once a reload completes) and re-injected on
every subsequent navigation, but only for tabs actually being Scouted.
Reports back via a new `REPORT_PAGE_FIELDS` message, validated against
`sender.tab.id` (not spoofable by the page itself), stored per-tab in
`connection-scout.js`, and reset on navigation like the rest of that
module's per-page state.

**Scope, stated plainly in the panel:** this is a page-level field
inventory, not yet correlated to which specific third-party domain each
field's data is actually sent to — that harder network-payload correlation
remains future work.

**New permission:** `scripting` (required for on-demand content-script
injection). Not a static, always-on content script — only injected while
Snoop Scout is actively observing a tab, matching this extension's
guard-conscious, init-on-demand design elsewhere.

---

**Removed: Snoop Scout's "This tab" column**

`onThisTab` was hardcoded `true` at the single place an entry is ever
created — `connection-scout.js` tracks one isolated bucket per tab, so
there was no code path where it could ever be anything else. The column
implied a cross-tab "also seen elsewhere" comparison that was never
actually built (and would require a genuinely different, persistent
cross-tab storage model with its own retention/privacy tradeoffs to build
properly — see conversation notes). Removed rather than left showing a
value that was never meaningfully computed. Table is now: domain / script /
frame / fetch-xhr / websocket.

---

## 2.7.2 — 2026-07-29
**Scout confirm dialog: color swap + reload-failure visibility**

- Swapped the confirm dialog's button colors: "Reload & capture all" is now
  yellow, "Continue without reload" is now green.
- `chrome.tabs.reload()` in the `START_SCOUT` handler previously had no
  error checking at all — if it silently failed (restricted page, tab
  closed in the interim, etc.) there was no way to tell. Now checks
  `chrome.runtime.lastError` and logs a `console.warn` on failure, so a
  real failure is visible in the service worker console instead of looking
  identical to a successful no-op. Simulated the handler logic directly
  (mocked `chrome.tabs.reload`) to confirm the call itself fires correctly
  given `reload: true` — the reported "reload doesn't reload" issue could
  not be reproduced at the logic level, so this diagnostic is the next step
  pending confirmation from the actual browser console.

---

## 2.7.1 — 2026-07-29
**Snoop Scout: pre-launch reload-vs-passive confirm dialog + capability footnote**

Snoop Scout was found to miss requests that fired before the panel was
opened (webRequest can't retroactively see traffic it wasn't registered
for), producing a visibly incomplete picture compared to a reload-triggered
monitor like Show blocks. Rather than silently reloading (breaking the
passive-by-default design) or silently staying incomplete, added a confirm
dialog every time Snoop Scout is launched:

- **Cancel** — no action
- **Continue without reload** — today's existing passive behavior, observes from the moment the panel opens
- **Reload & capture all** — reloads the tab (listener is registered first, so nothing between registration and reload is lost) for a complete picture from page-load start

Reuses the existing `.monitor-confirm-*` CSS/markup pattern from the Show
blocks dialog rather than introducing new styling.

**Deliberately not suppressible** — unlike the Show blocks dialog's "hide
this warning" checkbox, this one has no persisted skip. The reload-vs-
passive tradeoff (an in-progress checkout or form submission could be
interrupted by a reload) has real, situational consequences each time,
and passive was chosen as Snoop Scout's *default* specifically so this
decision could be made consciously per use rather than defaulted away.

`background.js`'s `START_SCOUT` handler now accepts a `reload` flag and
calls `chrome.tabs.reload()` only when the user chose that option.

**Capability-limits footnote** — added a small, persistent note at the
bottom of the Scout panel (not a one-time popup) stating that WebSocket
only shows connection-opened, not individual messages, and that WebRTC data
channels aren't visible at all. Chosen over adding this to the confirm
dialog so it doesn't compete for attention with the actual reload decision,
and stays available for reference any time results are being read, not
just at launch.

---

## 2.7.0 — 2026-07-29
**Fix: Snoop Scout no longer filters by block/allow outcome**

Reverted the block/allow classifier filtering added in 2.5.0/2.6.0.
`core/connection-scout.js` no longer imports or calls `wouldBlock()` at all —
Snoop Scout now records every observed script/frame/fetch-xhr/websocket
connection regardless of what our own ruleset would do with it. Show blocks
and Snoop Scout serve genuinely different purposes (the reviewable-blocked
subset vs. full traffic visibility), not the same classification split both
ways, and the earlier filtering was a misreading of that split.

`startScout(tabId, host, cb)` no longer takes a `state` snapshot parameter
(nothing left to classify against) — `background.js`'s `START_SCOUT` handler
simplified accordingly, no longer round-tripping through `loadState()`.

Verified via a mocked-`chrome.webRequest` simulation harness (not just read
through) before and after the fix, which also caught and fixed an unrelated
defensive gap: `_typeLabel()` previously passed an unrecognized resourceType
through unchanged instead of dropping it — harmless in practice today since
Chrome's own `addListener` types filter should prevent it from ever firing,
but now hardened rather than assumed.

**UI polish:**
- All three policy-action buttons (Snoop Scout / Show blocks / Import allow)
  now share one `--level-color` custom property driven by
  `LEVELS[level-1].color` — same color as each other and as the slider/tab-
  underline, instead of three independently hardcoded colors.
- Snoop Scout column header "On this tab" → "This tab", with `white-space:
  nowrap` applied to all column headers so labels never wrap across lines.
- Snoop Scout button tooltip updated to "See what third-party this page is
  connecting to."

---

## 2.6.0 — 2026-07-29
**Snoop Scout: countdown timer + column label fix**

Added a 5-minute countdown to Snoop Scout, matching Show blocks' timer in
both duration and belt-and-suspenders structure:
- `SCOUT_DURATION` constant (`data/constants.js`), independent from
  `MONITOR_DURATION` so the two features can diverge later without coupling.
- `core/connection-scout.js`: each tab bucket now carries its own
  `startTime`/`timeoutHandle`; the panel auto-closes and notifies via the
  already-wired `MSG_SCOUT_CLOSED` broadcast (reason `"timeout"`) when the
  5 minutes elapse.
- `startScoutWatchdog()` added as the same fallback-interval pattern as
  `block-monitor.js`'s `startWatchdog()`, started once at SW boot.
- `ui/scout-panel.js`/`.html`: countdown clock in the header, ported from
  `monitor-panel.js`'s `startClock`/`formatClock` (yellow at 1 minute
  remaining, red + "■" on expiry).

**Fix: "On this tab" column** — renamed to "This tab" and given a fixed
width + `white-space: nowrap` (applied to all column headers, not just this
one) so it reliably renders on a single line instead of wrapping across
up to three.

---

## 2.5.0 — 2026-07-29
**New: Snoop Scout — passive allowed-connections observer**

Adds a second, always-visible panel button ("Snoop Scout") next to Show blocks /
Import allow in the Active policy row. Where Show blocks reports third-party
requests our own ruleset **would block**, Snoop Scout reports the ones it
**would allow** — script, frame, fetch/xhr, and websocket connections — for the
active tab, in a live table (domain / on-this-tab / per-type checkmarks).

Both features now share one classifier: the block/allow decision logic
(`_wouldWeBlock`/`wouldBlock`) was extracted out of `core/block-monitor.js` into
a new `core/rule-classifier.js`, so "blocked" and "allowed" can never silently
drift into two different opinions about the same request.

New files: `core/rule-classifier.js`, `core/connection-scout.js`,
`ui/scout-panel.html`, `ui/scout-panel.js`.
New message types: `START_SCOUT`, `STOP_SCOUT`, `GET_SCOUT_DATA`, `SCOUT_CLOSED`.
New constants: `SCOUT_RESOURCE_TYPES`, `SCOUT_CAP` (`data/constants.js`).
`manifest.json`: added `ui/scout-panel.html` to `web_accessible_resources`.

Snoop Scout has no pause/resume/timer — it tracks a tab for as long as its
panel stays open, and releases that tab's memory the moment the panel closes
or the tab does (guarded via `tabs.onRemoved` and `webNavigation.onCommitted`
in `background.js`).

*Known limitation, unchanged for this release:* `chrome.webRequest` only sees
the WebSocket handshake, not individual messages sent after the socket opens,
and cannot see WebRTC data channels at all. The websocket column reflects
"a connection was opened," not per-message traffic.

---

**Hardening: `core/block-monitor.js` session state → explicit phase enum**

Replaced the `activeSession` (null-or-object) + separate `.paused` boolean
shape with a single `session` state vector gated by an explicit `phase` enum
(`idle` / `starting` / `running` / `paused`) and a `_assertPhase()` guard
checked at the top of every transition function. An out-of-order call (e.g.
`resumeMonitor()` with no paused session) now logs a warning and safely
no-ops instead of silently acting on stale/undefined state.

Ported from a more hardened sibling implementation of this same module found
in a related codebase — that file explicitly documents mirroring *this*
module's original `sessionTimeoutHandle`/`watchdogHandle` design, so this is
a return port of its own structural improvement, not a new design. Its
separate Privacy Inspector feature's `chrome.storage.session`-based
persistence-across-SW-restart guard was deliberately **not** ported: that
guard exists there because its capture mechanism is a persistent
content-script probe that keeps firing after a service-worker restart,
whereas this module's `chrome.webRequest` listener does not survive a
restart at all — listener and session die together, so there is no
orphaned-event case to guard against here. Revisit this decision if either
`block-monitor.js` or `connection-scout.js` ever moves to a persistent-probe
capture model.

*Two real (and correct) behavior changes fall out of this restructuring —
noted explicitly per project convention, not silent:*
- **Pause now actually freezes the countdown.** Previously `pauseMonitor()`
  accumulated elapsed time into `timeElapsed` but never cleared the primary
  timer, so the 5-minute force-close kept ticking in the background while
  paused; `resumeMonitor()` also never re-armed it. A user who paused to
  review blocked domains could get force-closed moments after resuming even
  if they'd only been reviewing for a minute. The timer is now cleared on
  pause and re-armed for the *remaining* duration on resume.
- **The watchdog no longer double-counts elapsed time for a paused session.**
  It previously read `activeSession.startTime`, which pause left stale (never
  reset), and added `Date.now() - <stale startTime>` on top of the
  already-accumulated `timeElapsed` — inflating the apparent elapsed time the
  longer a session stayed paused, and risking an incorrect `timeout` cleanup
  of a session the user was actively reviewing. The watchdog now only
  evaluates elapsed time while `phase === "running"`.

No message types, storage keys, or public function signatures changed —
`startMonitor`/`stopMonitor`/`pauseMonitor`/`resumeMonitor`/`getMonitorData`/
`allowMonitorDomain`/`startWatchdog`/`markMonitorStarted` keep their existing
names and call contracts; `ui/monitor-panel.js` required no changes.

---

## 2.4.0 — 2026-07-27
**New: Identity/SSO whitelist category (built-in domains)**

Added a dedicated "Identity / SSO" section to `BUILTIN_DOMAINS` in
`data/constants.js`, applied at Levels 2–5 like the existing payment/video/CAPTCHA
categories. Covers Google, Microsoft, Apple, Facebook, GitHub and LinkedIn identity
domains, plus common auth-as-a-service platforms (Auth0, Okta, OneLogin, WorkOS) and
`openai.com` itself.

*Why:* third-party "Sign in with X" flows frequently rely on a hidden or interactive
iframe (silent session check, OIDC token relay, account picker) served from the
identity provider's domain. Previously only `google.com`/`googleapis.com`/`gstatic.com`
were covered (filed under CAPTCHA, not identity) and every other provider was
unlisted — so at Level 2 (which blocks all third-party frames outside the built-in
whitelist) a fresh sign-in could fail while an already-established session on the
provider's own site did not need that iframe and worked fine. This matches a reported
case: Google-account sign-in into a third-party site failed cold at Level 2 but
succeeded once already logged into the Google account directly.

No rule-engine or schema changes — this is purely additional entries in the existing
built-in-domain list, applied through the existing `buildBuiltinAllowRules()` path.
Existing installs will pick up the new entries automatically only on **fresh
install**; users who installed a prior version keep whatever `builtinDomains` list
was seeded into their `chrome.storage.local` at that time (see `loadState()` in
`data/state-storage.js` — the seed only fires when `builtinDomains` is `null`/
`undefined`). Existing users should remove the extension's storage or add the
missing domains manually via the popup's domain whitelist to pick up this change.

---

## 2.3.0 — 2026-07-24
**`var` → `let`/`const` modernization complete (no behavior changes)**

Finished converting the remaining, higher-risk files: `background.js`,
`core/block-monitor.js`, `ui/monitor-panel.js`, and `ui/popup.js` (146 occurrences —
the largest file). The codebase is now 100% `var`-free, and `.eslintrc.json` enables
`no-var` and `prefer-const` permanently (previously excluded while this work was in
progress).

`background.js` and `core/block-monitor.js` were converted manually, checking every
variable individually for real reassignment (module-scope session state like
`activeSession`, `monitorEntries`, `_sessionTimer` — which genuinely get reassigned
through the session lifecycle — correctly became `let`; everything else became
`const`). Both were desk-tested afterward: `background.js` by dispatching all 11
message types through its listener and confirming identical responses;
`core/block-monitor.js` with a dedicated test covering the full session lifecycle
(start → block detection with builtin/user whitelist checks and dedup → pause →
resume → stop), all 15 assertions passing.

`ui/monitor-panel.js` and `ui/popup.js` were converted using ESLint's own scope
analysis (`no-var`/`prefer-const` with `--fix`) rather than manual regex — at this
scale, real JS scope analysis is more reliable than pattern matching. Both were
checked for closures inside `for`-loops before running the fix (none of the 6 raw
loops across these two files capture their loop counter in an async callback, so
`var`→`let` cannot change behavior here) — `ui/popup.js`'s domain/TLD tag list
already used a manual IIFE workaround for the classic loop-closure bug, which is left
in place unchanged. Both files were then desk-tested in a simulated browser
environment (jsdom + a stubbed `chrome` API): `monitor-panel.js` for polling, table
rendering, and pause/resume; `popup.js` for tick rendering, level-based rule-list
rendering at two different levels, and tag removal via the IIFE-wrapped loop — all
assertions passing with zero runtime errors.

---

## 2.2.1 — 2026-07-24
**`var` → `let`/`const` modernization (steps 1–3 of a staged plan; no behavior changes)**

Converted `var` to `let`/`const` in the lower-risk files first — those with no
`for`-loop closures, where `var` vs `let` genuinely cannot change behavior. Every
conversion was checked individually against actual reassignment before choosing
`const` (never reassigned) vs `let` (reassigned) — this was not a blanket
find-and-replace. Two real reassignment patterns were caught and correctly kept as
`let`: `rules` in `core/rule-builder.js` (`rules = rules.concat(...)`, used to build
up a rule array from several sub-builders) and `base`/`merged` in
`core/tld-engine.js`'s TLD-list functions (conditionally reassigned per mode).

Files fully converted: `data/message-types.js`, `data/constants.js`,
`data/state-storage.js`, `util/tld-utils.js`, `core/rule-builder.js`,
`core/tld-engine.js`, `core/site-rules.js`.

`core/site-rules.js` was additionally verified with a dedicated desk test
(add/update/remove/FIFO-eviction-at-cap/empty-state scenarios) — all passed
identically to the pre-conversion behavior.

Remaining `var` usage — `background.js`, `core/block-monitor.js`,
`ui/monitor-panel.js`, `ui/popup.js` — involves real `for`-loops and closures where
`var`→`let` conversion can change behavior (usually by fixing a latent bug) and
needs case-by-case verification; deferred to a later pass. `.eslintrc.json` still
intentionally omits `no-var` until that work is done.

---

## 2.2.0 — 2026-07-24
**ESLint added; ES module migration; real bugs fixed; new feature**

*ES module migration*
- The whole codebase now uses real `import`/`export` instead of `importScripts`/`<script>`
  load order and an implicit shared global scope. The service worker loads with
  `"type": "module"`, and both UI pages load their controller as a single
  `<script type="module">`. Each file now imports exactly what it uses directly.
- Internal `var` usage inside function bodies was deliberately left untouched — this
  codebase uses `var` pervasively (not just at module boundaries, unlike a previous
  ESLint pass on a different extension), so a blanket `var` → `let`/`const` rewrite
  was treated as a separate decision, not bundled into this migration. `.eslintrc.json`
  intentionally omits `no-var` for now.
- `.eslintrc.json` added (`eslint:recommended`, `sourceType: "module"`) — resolves
  cross-file references natively; no manually-maintained globals list needed.

*Fixed: `DEFAULT_STATE` duplication removed for good*
- `ui/popup.js` kept its own literal copy of `DEFAULT_STATE`, separate from
  `data/state-storage.js`'s copy — the exact duplication that caused the divergence
  fixed manually in 2.1.2. Verified before removing it: both copies were currently
  identical, and `state-storage.js`'s copy is only ever read by its own
  `loadState`/`saveState`, which `popup.js` never calls (it talks to the service
  worker via messages instead) — so nothing depended on which copy was in scope.
  `popup.js` now imports `DEFAULT_STATE` from `state-storage.js`; the "must stay in
  sync" comment and the manual-sync risk it warned about are both gone.

*Fixed: `domainTags` undefined-variable bug*
- `ui/popup.js`'s domain-rows-select handler referenced a bare `domainTags`
  identifier that was never declared anywhere — the actual element has
  `id="domain-tags"`. Fixed by caching the real element reference.

*Fixed: domain pagination reset bug*
- `renderDomainTags()` always re-rendered at page 0 after adding/removing a domain
  tag, instead of preserving the current page like the equivalent TLD code does with
  `tldPage`. The `domainPage` variable was being tracked correctly but never actually
  consulted. Now uses `domainPage`, matching the TLD behavior.

*Fixed: `ns` redeclared in background.js*
- Two separate `var ns` declarations in the same function scope (different `if`
  branches for `MSG_SET_STATE` and `MSG_RESUME_MONITOR`). Harmless at runtime — the
  branches are mutually exclusive — but a real `no-redeclare` violation. Both are now
  `const`, scoped to their own block.

*Fixed: `no-prototype-builtins` (8 occurrences)*
- Direct `.hasOwnProperty()` calls in `core/site-rules.js` and `ui/popup.js` replaced
  with `Object.prototype.hasOwnProperty.call(...)`.

*Cleaned up: dead state removed*
- `ui/monitor-panel.js`: `_knownEntries` (written on every poll, never read — the
  actual refresh-comparison logic uses `_lastCount` instead) and `_currentState`
  (declared, never assigned or read) removed.
- Two empty blocks (an intentional `lastError` swallow in `core/block-monitor.js`,
  an intentional URL-parse `catch` in `ui/popup.js`) documented with clarifying
  comments rather than left bare.

*New: duplicate monitor-window prevention*
- The "Show Blocks" button had no click-guard — clicking it more than once while the
  popup stayed open (there was no cooldown or disabled state) opened a new monitor
  window every time. `_winId` was already being tracked for exactly this purpose but
  was never actually checked before creating a new window (a real, unused-variable
  bug caught by ESLint). Fixed: `_launch()` now focuses the existing monitor window
  if one is already open, and only creates a new one if none exists or the tracked
  window was closed independently (detected via `chrome.runtime.lastError`, which
  clears the stale id and creates a fresh window).

---

## 2.1.2 — 2026-07-15
**Code quality — no behaviour changes**

*Duplicated constants removed*
- `EU_LANGS` was defined in three places (`util/tld-utils.js`, `core/tld-engine.js`, and implicitly via `tld-utils.js`). Moved to `data/constants.js` as the single source of truth. `util/tld-utils.js` and `core/tld-engine.js` now reference it from there.
- `MULTI_PART_SUFFIXES` was defined twice verbatim (in `core/block-monitor.js` as an inline local `MULTI` array, and in `ui/popup.js`). Moved to `data/constants.js`. Both files now reference the shared constant.
- `LEVEL_COLORS` in `ui/popup.js` duplicated the colour values already stored in `LEVELS[].color`. Removed `LEVEL_COLORS`; the one call site now uses `LEVELS[pinnedLevel - 1].color` directly.

*DEFAULT_STATE divergence fixed*
- `ui/popup.js` and `data/state-storage.js` each held a copy of `DEFAULT_STATE` that had diverged: `state-storage.js` had `showBlockedCount` that `popup.js` was missing; `popup.js` had `blockedTldDropdownOpen` that `state-storage.js` was missing. Both copies are now fully in sync. A warning comment has been added to `popup.js` requiring any future key addition to be mirrored in both files.

*Storage key constants*
- The raw string literals `"monitorHideWarning"`, `"sessionLevel"` and `"prevSessionLevel"` were scattered as repeated raw strings across `ui/popup.js` and `ui/monitor-panel.js`. Named constants `LOCAL_KEY_HIDE_WARNING`, `SESSION_KEY_LEVEL` and `SESSION_KEY_PREV_LEVEL` are now declared in `data/state-storage.js` and used everywhere.

*Double message send fixed*
- The Import Allow save handler in `ui/popup.js` was firing `MSG_SET_STATE` twice for the same state object (once with a callback, once fire-and-forget). The redundant second send has been removed.

*Silent catch blocks documented*
- All `catch(e) {}` blocks in `background.js`, `core/block-monitor.js` and `ui/monitor-panel.js` now carry an explanatory comment confirming they are intentional and describing why the error is safely ignored.

*CSS tokens*
- `--radius: 6px` and `--radius-sm: 4px` added to `:root` in `ui/popup.html` to match `ui/monitor-panel.html`. Raw `6px` values in `popup.html` now have a matching variable (consumers will be migrated in a future pass).
- Dead CSS rule `.rule-text.dim` removed from `ui/popup.html` — it was identical to `.rule-text` and had no visual effect.

*Stale files removed*
- `logger.html` and `logger.js` removed from extension root — they were legacy artefacts unreferenced by the manifest or any other file.
- Root-level `popup.html` and `popup.js` removed — superseded by `ui/popup.html` and `ui/popup.js` since v2.0; the manifest correctly points to `ui/`.

*_seenDomains bound documented*
- Added a comment to `_seenDomains` in `core/block-monitor.js` explaining its implicit size bound (capped indirectly by `MONITOR_CAP` and `_wouldWeBlock()` filtering; cleared on start/resume).

---

## 1.6.2 — 2025
**Bug fixes**
- Added `tabs` permission to manifest — without it, `chrome.tabs.query` silently returned nothing in the Chrome Web Store version, breaking popup initialisation entirely (slider, lock button, logger all non-functional). Developer mode was permissive and hid the bug.
- Removed `tabs` permission again in favour of routing all `tab.url` reads through the background service worker, which can read tab URLs via `<all_urls>` host_permissions without needing the explicit `tabs` permission. This avoids a prior store rejection where a reviewer found the `tabs` permission unnecessary.
- Fixed stale logs from a previous session appearing in a new logger session. When a prior session was still marked active in storage, clicking SHOW LOGS re-opened the logger without clearing old entries. Now every click always resets `logs`, `logHost` and `logStartTime` before opening the logger tab.
- Fixed `RULE_NAMES` TLD-block index: previously used `GENERIC_BLOCKED_TLDS.concat(WORLD_BLOCKED_TLDS)` to map rule IDs 3200+, but since WORLD already contains all GENERIC entries the concat double-counted them, misassigning rule names from ID 3236 onward. Now uses `WORLD_BLOCKED_TLDS` only (the superset).
- Fixed potential stale-log persistence across SW restarts: `logging: false` and `logs: []` are now written atomically in a single `chrome.storage.local.set()` call instead of two separate calls with a 3-second delay between them. A SW eviction between the two writes could previously leave stale logs in storage.

**Architecture**
- Added `GET_ACTIVE_TAB_INFO` and `RELOAD_ACTIVE_TAB` message handlers to background.js so popup.js and logger.js never call `chrome.tabs.query` directly.

---

## 1.6.1 — 2025
**Features**
- Logger now filters to only show traffic from the 1P domain that was active when SHOW LOGS was clicked. Previously all tabs' traffic was captured indiscriminately.
- Logger header now shows the logged domain name (passed as a URL parameter from the popup, avoiding storage/timing races).
- Removed the "Show blocked domains panel" checkbox (leftover from v2.0 blocked-panel experiment).

**Known limitation**
- `tabs` permission was missing from manifest, breaking the store version entirely (see 1.6.2).

---

## 1.6.0 — 2025
**Features**
- Level 3 (Easy medium mode) now allows both 3P scripts **and** 3P frames from whitelisted TLDs, not just scripts. Bullet text updated to reflect this.
- Removed the explanatory "(covers 95% of traffic...)" info line from the L3 Active Policy panel.

---

## 1.5.0 — 2025
**Features**
- Logger: added **Allow** column at levels 4 and 5. Blocked 3P-script rows get an Allow button that whitelists the script's own domain (extracted from the request URL, not the 1P calling domain) and immediately reloads the source tab.
- Logger: Allow column appears between the Action and Reason columns.
- Logger: domain header pill shows which 1P domain is being logged.

**Bug fixes**
- Allow button previously added the 1P calling domain instead of the 3P script domain. Fixed by extracting hostname from `e.url` rather than using `e.domain`.

---

## 1.4.0 — 2025
**Features**
- Request logger with 5-minute session countdown.
- Logger captures all allowed and blocked third-party traffic matching the extension's rules via `onRuleMatchedDebug`.
- Visibility-only catch-all allow rule (ID 3500) added so XHR/image/font/etc traffic is visible in the logger even though it is never blocked.
- SHOW LOGS button with active/pulsing state.

**Architecture**
- `declarativeNetRequestFeedback` permission added to support `onRuleMatchedDebug`.
- `LOG_TIMEOUT_MS` = 5 minutes, `MAX_LOGS` = 500 (FIFO eviction).
- SW restart recovery: reconstructs remaining log timeout from stored `logStartTime`.

---

## 1.3.x and earlier
- Core DNR rule engine with 5 levels.
- TLD whitelist (L3), domain whitelist (L4/L5), CDN allow (L4), built-in payment/video/CAPTCHA whitelist (L2–L4).
- Per-site lock rules with FIFO cap of 100 entries.
- Toolbar badge showing per-tab blocked request count via `displayActionCountAsBadgeText`.
- Auto TLD detection from browser language settings (BROWSER / CONTINENT / WORLDWIDE modes).
- TLD blacklist for L2 (NONE / USER / GENERIC / WORLD modes).
