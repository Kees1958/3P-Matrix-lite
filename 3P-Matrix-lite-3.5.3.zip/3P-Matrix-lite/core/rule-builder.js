// ── core/rule-builder.js ──────────────────────────────────────────────────────
// Pure rule construction — builds declarativeNetRequest rule arrays from state.
// No Chrome API calls, no storage access, no side effects.
// All functions take input and return a rules array.
//
// Public interface:
//   buildRules(state, cdnRegexSupported)  — builds the complete rule set from
//     state, returns Rule[]. cdnRegexSupported (boolean, default false) is
//     checked and cached once by background.js's checkCdnRegexSupport() via
//     chrome.declarativeNetRequest.isRegexSupported() — never assumed here,
//     since this module stays free of Chrome API calls by design.
// ─────────────────────────────────────────────────────────────────────────────

import { RP_3P, CDN_HOST_REGEX } from "../data/constants.js";

// ── Rule ID map ───────────────────────────────────────────────────────────────
// Global rules use idOffset = 0.
// Per-site rules use idOffset = 100000 + (i * 5000) — the 5000-wide slot safely
// covers the full local ID range used here (highest ID is 3299).
//
//   Range       Purpose                                          Cap
//   ─────────────────────────────────────────────────────────────────
//   1003        Non-standard port block (allows 80, 443, 8080, 8443)
//   1005        IP address block
//   (1001, 1002, 1004 freed — HTTP/WS rules removed, port rules merged)
//   2000–2199   Free — was User domain whitelist, retired (see CHANGELOG)
//   2200–2399   Free                                               —
//   2400–2499   TLD whitelist          (single *.tld* pattern)   100
//   2500–2599   Free                                               —
//   2600–2999   Built-in domain whitelist (single *d* pattern)   400
//   3000        CDN allow              (level 4 only)              1
//   3001        Block 3P frames        (levels 2–5)               1
//   3002        Block 3P scripts       (levels 3–5)               1
//   3100–3199   Free
//   3200–3299   TLD blacklist          (level 2 only)            100
//   4000–4099   Matrix frame overrides  (per-domain allow/block)  100
//   4100–4199   Matrix script overrides (per-domain allow/block)  100
// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

// Builds base safety block rules (non-standard ports, IP addresses).
// HTTP and WS checks removed. Allowed ports: 80, 443, 8080, 8443.
// Applied at all levels >= 2. Returns Rule[].
function buildBaseSafetyRules(idOffset, scope) {
  const specs = [
    // Block any explicit port that is not 80, 443, 8080 or 8443
    { id: 1003, regexFilter: "^https?://[^/?#:]+:([1-9]|[1-7][0-9]|8[1-9]|9[0-9]|[1-3][0-9]{2}|4[0-3][0-9]|44[0-24-9]|4[5-9][0-9]|[5-9][0-9]{2}|[1-7][0-9]{3}|80[0-7][0-9]|808[1-9]|80[9][0-9]|8[1-3][0-9]{2}|84[0-3][0-9]|844[0-24-9]|84[5-9][0-9]|8[5-9][0-9]{2}|9[0-9]{3}|[1-9][0-9]{4,})([/?#]|$)", resourceTypes: RP_3P },
    { id: 1005, regexFilter: "^https?://[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+([/?#:]|$)", resourceTypes: RP_3P }
  ];
  return specs.map(function(spec) {
    return {
      id: idOffset + spec.id,
      priority: 50,
      action: { type: "block" },
      condition: Object.assign({
        regexFilter: spec.regexFilter,
        domainType: "thirdParty",
        isUrlFilterCaseSensitive: false,
        resourceTypes: spec.resourceTypes
      }, scope)
    };
  });
}

// Builds built-in domain allow rules (payment, video, CAPTCHA, JS-libs) for levels 2-5.
// Two patterns per domain: /* (path) and / (bare root).
// Allows both sub_frame and script so video players and JS-libraries work at all levels.
function buildBuiltinAllowRules(idOffset, scope, builtinDomains) {
  const rules = [];
  // Single *domain* pattern covers both bare root and any path — one rule per domain.
  // Range 2600-2999 gives 400 slots — plenty of headroom.
  (builtinDomains || []).slice(0, 400).forEach(function(d, i) {
    rules.push({ id: idOffset + 2600 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*" + d + "*", resourceTypes: ["sub_frame", "script"] }, scope) });
  });
  return rules;
}

// Builds TLD allow rules for level 3 (scripts + frames from whitelisted TLDs).
// Two patterns per TLD. Returns Rule[].
function buildTldAllowRules(idOffset, scope, tlds) {
  const rules = [];
  // Single *.tld* pattern covers bare root and any path — one rule per TLD.
  // Range 2400-2499 gives 100 slots — sufficient for all TLD combinations.
  tlds.slice(0, 100).forEach(function(tld, i) {
    rules.push({ id: idOffset + 2400 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*." + tld + "*", resourceTypes: ["script", "sub_frame"] }, scope) });
  });
  return rules;
}

// Builds CDN allow rule for level 4 (scripts only).
// JS-library domains are now covered by buildBuiltinAllowRules at all levels.
// Only the broad *cdn* URL match remains here — level 4 exclusive.
// Builds the level-4 CDN allow rule. Uses a host-scoped regex ("cdn" only
// within the domain, never the path/query) when Chrome's DNR engine supports
// it — checked once and cached by background.js's checkCdnRegexSupport(),
// never assumed. Falls back to the old, looser, always-valid urlFilter
// ("cdn" anywhere in the full URL) if the regex was rejected for any reason —
// degraded precision is fine; a broken ruleset from an invalid regex in an
// atomic updateDynamicRules() batch is not.
function buildCdnAllowRules(idOffset, scope, cdnRegexSupported) {
  const rules = [];
  const condition = cdnRegexSupported
    ? Object.assign({ regexFilter: CDN_HOST_REGEX, isUrlFilterCaseSensitive: false, resourceTypes: ["script"] }, scope)
    : Object.assign({ urlFilter: "*cdn*", resourceTypes: ["script"] }, scope);
  rules.push({ id: idOffset + 3000, priority: 1000, action: { type: "allow" }, condition: condition });
  return rules;
}

// Builds TLD blacklist block rules for level 2 only.
// Blocks 3P scripts from risky/abused TLDs. Priority 15 — lower than the
// main frame/script blocks (20) so general blocks fire first. Returns Rule[].
function buildTldBlacklistRules(idOffset, scope, blockedTlds) {
  const rules = [];
  blockedTlds.slice(0, 100).forEach(function(tld, i) {
    rules.push({ id: idOffset + 3200 + i, priority: 15, action: { type: "block" },
      condition: Object.assign({
        urlFilter: "*." + tld + "/*",
        domainType: "thirdParty",
        resourceTypes: ["script", "webbundle"]
      }, scope) });
  });
  return rules;
}

// Builds the interactive Matrix's per-domain, per-type allow/block overrides.
// This is a genuinely new rule TIER, not a variant of the existing domain
// whitelist: it's the only mechanism in this codebase that can BLOCK a
// domain the built-in/TLD/CDN allowlist would otherwise permit — hence
// priority 2000 for its block half, higher than every existing allow rule
// (1000) so a user block override always wins regardless of what else would
// have allowed it. Its allow half sits at the same 1000 tier as the existing
// allow rules — no need to outrank them, since nothing HIGHER than 1000
// currently exists to conflict with (block-frame/script sit at 20).
//
// Independent per resource type: a domain can have its frame blocked while
// its script is allowed, or vice versa — matrixRules[domain] is
// { frame?: "allow"|"block", script?: "allow"|"block" }, either key
// optional and independent of the other.
//
// Two separate ID ranges (frame vs script) rather than one shared range,
// so a domain needing both overrides doesn't need special-case ID math —
// each type's rules are numbered independently within their own 100-slot band.
function buildMatrixOverrideRules(idOffset, scope, matrixRules) {
  const rules = [];
  const domains = Object.keys(matrixRules || {}).slice(0, 100);

  let frameIdx = 0;
  domains.forEach(function(d) {
    const action = matrixRules[d] && matrixRules[d].frame;
    if (action !== "allow" && action !== "block") return; // no override for this type
    rules.push({
      id: idOffset + 4000 + frameIdx,
      priority: action === "block" ? 2000 : 1000,
      action: { type: action },
      condition: Object.assign({ urlFilter: "*" + d + "*", domainType: "thirdParty", resourceTypes: ["sub_frame"] }, scope)
    });
    frameIdx++;
  });

  let scriptIdx = 0;
  domains.forEach(function(d) {
    const action = matrixRules[d] && matrixRules[d].script;
    if (action !== "allow" && action !== "block") return; // no override for this type
    rules.push({
      id: idOffset + 4100 + scriptIdx,
      priority: action === "block" ? 2000 : 1000,
      action: { type: action },
      condition: Object.assign({ urlFilter: "*" + d + "*", domainType: "thirdParty", resourceTypes: ["script", "webbundle"] }, scope)
    });
    scriptIdx++;
  });

  return rules;
}

// Builds the complete rule array for a single level.
// Used for both global rules (idOffset=0) and per-site rules (idOffset=100000+i*5000).
// Returns Rule[].
function rulesForLevel(level, tlds, domains, idOffset, initiatorDomains, excludedDomains, builtinDomains, blockedTlds, matrixRules, cdnRegexSupported) {
  if (level === 1) return [];   // L1 = allow all, no rules needed

  const siteScope  = initiatorDomains && initiatorDomains.length
    ? { initiatorDomains:         initiatorDomains  } : {};
  const globalExcl = excludedDomains  && excludedDomains.length
    ? { excludedInitiatorDomains: excludedDomains   } : {};
  const scope = initiatorDomains ? siteScope : globalExcl;

  let rules = [];
  rules = rules.concat(buildBaseSafetyRules(idOffset, scope));

  if (level >= 2) {
    rules = rules.concat(buildBuiltinAllowRules(idOffset, scope, builtinDomains));
  }
  if (level === 3) {
    rules = rules.concat(buildTldAllowRules(idOffset, scope, tlds));
  }
  if (level === 4) {
    rules = rules.concat(buildCdnAllowRules(idOffset, scope, cdnRegexSupported));
  }
  // Domain whitelist (formerly buildDomainAllowRules, using the `domains`
  // param) was retired along with its UI — existing entries were migrated
  // once into state.matrixRules (see background.js's migration on update),
  // which buildMatrixOverrideRules() below now handles instead. `domains`
  // is kept as an unused parameter rather than touching every call site for
  // a parameter that costs nothing to leave unused.

  // Block 3P frames (levels 2-5) — the entire 3P blocking surface of this extension.
  // IMPORTANT: never extend blocking beyond sub_frame + script/webbundle — see RP_3P
  // comment in data/constants.js for the reason.
  rules.push({ id: idOffset + 3001, priority: 20, action: { type: "block" },
    condition: Object.assign({ domainType: "thirdParty", resourceTypes: ["sub_frame"] }, scope) });

  // Block 3P scripts (levels 3-5)
  if (level >= 3) {
    rules.push({ id: idOffset + 3002, priority: 20, action: { type: "block" },
      condition: Object.assign({ domainType: "thirdParty", resourceTypes: ["script", "webbundle"] }, scope) });
  }

  if (level === 2 && blockedTlds && blockedTlds.length) {
    rules = rules.concat(buildTldBlacklistRules(idOffset, scope, blockedTlds));
  }

  // Interactive Matrix per-domain overrides — applies at every level reached
  // here (L1 already returned early above, since nothing is blockable there
  // per the feature's own design: no overrides are possible/offered at L1).
  if (matrixRules && Object.keys(matrixRules).length) {
    rules = rules.concat(buildMatrixOverrideRules(idOffset, scope, matrixRules));
  }

  return rules;
}

// Builds the complete declarativeNetRequest rule set from state.
// Global rules exclude pinned hostnames; per-site rules target them specifically.
// Returns Rule[] ready to pass to updateDynamicRules().
export function buildRules(state, cdnRegexSupported) {
  const level       = state.level;
  const tlds        = state.tlds        || [];
  const domains     = state.domains     || [];
  const siteRules   = state.siteRules   || {};
  const matrixRules = state.matrixRules || {};
  const pinnedHosts = Object.keys(siteRules);
  let rules         = [];

  // Global rules — exclude all pinned hosts so their site-specific rules take priority
  rules = rules.concat(
    rulesForLevel(level, tlds, domains, 0, null, pinnedHosts, state.builtinDomains, state.blockedTlds, matrixRules, cdnRegexSupported)
  );

  // Per-site rules — offset 100000 + i*5000 to avoid ID collisions between sites.
  // The 5000-wide slot safely covers the full local ID range used by rulesForLevel (up to 4199).
  pinnedHosts.forEach(function(host, i) {
    const offset = 100000 + (i * 5000);
    rules = rules.concat(
      rulesForLevel(siteRules[host], tlds, domains, offset, [host], null, state.builtinDomains, state.blockedTlds, matrixRules, cdnRegexSupported)
    );
  });

  return rules;
}
