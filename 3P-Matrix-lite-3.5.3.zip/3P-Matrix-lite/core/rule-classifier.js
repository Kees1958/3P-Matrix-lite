// ── core/rule-classifier.js ───────────────────────────────────────────────────
// Shared request classifier — the single source of truth for "would our own
// DNR ruleset block this request, given the current state?"
//
// Extracted from core/block-monitor.js (v2.4.0) originally to be shared with
// core/connection-matrix.js (Show Matrix) as well — that sharing was reverted
// in v2.7.0 once Show Matrix's purpose was clarified as full-visibility
// traffic observation (blocked or not), not an allowed-only view filtered by
// this classifier. Show Matrix now only imports etldPlusOne() from this file
// for its own traffic-observation entries — but as of the Mode redesign
// (v3.2.0), background.js's MSG_GET_MATRIX_DATA handler also imports the
// individual mechanism-check helpers below directly, to compute WHICH
// specific mechanism governs each domain's Mode coloring. wouldBlock() itself
// is built FROM these same helpers, so both consumers can never drift into
// different opinions about the same domain.
// See CHANGELOG.md and the audit notes (C21) for the fuller history.
//
// Public interface:
//   etldPlusOne(url)                                    — eTLD+1 host extraction
//   getEffectiveLevel(state, activeHost)                — resolves per-site pin if any
//   isBuiltinWhitelisted(thirdPartyHost, state)          — boolean
//   isTldWhitelisted(thirdPartyHost, state)              — boolean (level-independent check;
//                                                          caller decides whether level 3 applies it)
//   isTldBlacklisted(thirdPartyHost, state)              — boolean (ditto, level 2)
//   isCdnMatch(url)                                      — boolean (ditto, level 4 + script-only)
//   wouldBlock(thirdPartyHost, resourceType, url, state, activeHost) — boolean
//
// Dependencies: data/constants.js (MULTI_PART_SUFFIXES, BUILTIN_DOMAINS)
// ─────────────────────────────────────────────────────────────────────────────

import { MULTI_PART_SUFFIXES, BUILTIN_DOMAINS } from "../data/constants.js";

// Extracts eTLD+1 from a full URL. Returns empty string on failure.
export function etldPlusOne(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    const labels   = hostname.split(".");
    if (labels.length <= 2) return hostname;
    // Handle common multi-part suffixes (co.uk, com.au, etc.)
    const last2 = labels.slice(-2).join(".");
    // MULTI_PART_SUFFIXES loaded from data/constants.js — single source of truth.
    if (MULTI_PART_SUFFIXES.indexOf(last2) !== -1 && labels.length >= 3) {
      return labels.slice(-3).join(".");
    }
    return last2;
  } catch(e) {
    return "";
  }
}

// Resolves the effective protection level — respects a per-site pin stored
// in state.siteRules, falling back to the global state.level.
export function getEffectiveLevel(state, activeHost) {
  if (!state) return 1;
  return (activeHost && state.siteRules && state.siteRules[activeHost])
    ? state.siteRules[activeHost]
    : (state.level || 1);
}

// Builtin domain whitelist match (rules 2600–2999, levels 2–5). Level-
// independent — caller decides whether/how to use this at a given level
// (wouldBlock applies it at every level ≥2; Mode's coloring treats it as the
// highest-priority "always green" signal regardless of level).
export function isBuiltinWhitelisted(thirdPartyHost, state) {
  const builtins = (state && state.builtinDomains && state.builtinDomains.length)
    ? state.builtinDomains
    : (typeof BUILTIN_DOMAINS !== "undefined" ? BUILTIN_DOMAINS : []);
  for (let i = 0; i < builtins.length; i++) {
    if (thirdPartyHost === builtins[i] || thirdPartyHost.endsWith("."+builtins[i])) return true;
  }
  return false;
}

// TLD whitelist match (rules 2400–2499) — the mechanism level 3 uses.
// Level-independent check; wouldBlock() only applies it when level===3.
export function isTldWhitelisted(thirdPartyHost, state) {
  const labels = thirdPartyHost.split(".");
  const tld    = labels[labels.length - 1];
  const tld2   = labels.length >= 2 ? labels.slice(-2).join(".") : tld;
  const tlds   = (state && state.tlds) || [];
  return tlds.indexOf(tld) !== -1 || tlds.indexOf(tld2) !== -1;
}

// TLD blacklist match (rules 3200+) — the mechanism level 2 uses to block
// scripts (frames are blocked unconditionally at L2 regardless of this).
// Level-independent check; wouldBlock() only applies it when level===2.
export function isTldBlacklisted(thirdPartyHost, state) {
  const labels = thirdPartyHost.split(".");
  const tld    = labels[labels.length - 1];
  const tld2   = labels.length >= 2 ? labels.slice(-2).join(".") : tld;
  const blocked = (state && state.blockedTlds) || [];
  return blocked.indexOf(tld) !== -1 || blocked.indexOf(tld2) !== -1;
}

// CDN allow match (rule 3000) — the mechanism level 4 uses to allow scripts
// (frames are blocked unconditionally at L4 regardless of this — see
// buildCdnAllowRules() in rule-builder.js, which is script-only).
// Checks the HOSTNAME only, not the full URL — an earlier version checked
// the whole URL, which meant "cdn" appearing anywhere in a request's path
// or query string (nothing to do with the domain itself) produced a false
// match. Plain JS URL parsing has no DNR/regex complexity limits to worry
// about, unlike the DNR-side version of this same check in rule-builder.js.
export function isCdnMatch(url) {
  if (!url) return false;
  try {
    return new URL(url).hostname.toLowerCase().indexOf("cdn") !== -1;
  } catch(e) {
    return false; // malformed URL — treat as no match, not a crash
  }
}

// Computes the interactive Matrix's per-domain Mode disposition — a single
// combined signal per domain now (not split into Allow/Block columns), and
// deliberately dropped the per-level color scheme entirely: Mode just shows
// whether the level's own mechanism would allow or block this domain, full
// stop, using the same fixed green/red/grey language as SCRIPT/FRAME.
//
//   "allow" — the level's own mechanism (TLD blacklist/whitelist, CDN match,
//             block-only at L5, or "always allow" at L1) would allow this domain
//   "block" — same mechanism would block it
//   overridden — true if EITHER a script or frame per-type override exists
//             for this domain, OR the domain is on the built-in whitelist —
//             either way, something other than the level's own TLD/CDN
//             mechanism is what's actually deciding this domain's fate, so
//             Mode greys out rather than showing a mechanism-based color
//             that wouldn't actually explain what's happening. Never true
//             at L1 — nothing is being overruled there, since L1's own
//             mechanism already is "always allow."
//   applicable — false only if `state` itself is missing (defensive
//             fallback); every real level, including L1, has a real answer.
//
// Deliberately does NOT consider built-in whitelist status — that has its
// own dedicated signal (the INTERNAL WHITELIST column).
//
//   L1 — always allow   L2 — TLD blacklist   L3 — TLD whitelist
//   L4 — CDN match       L5 — always block
//
// thirdPartyHost, url, state, activeHost — same meaning as wouldBlock()'s
// parameters; url is only actually used at level 4 (isCdnMatch).
export function getModeState(thirdPartyHost, url, state, activeHost) {
  if (!state) return { applicable: false, winnerSide: "block", overridden: false };
  const level = getEffectiveLevel(state, activeHost);

  // L1 genuinely always allows — that's a real, reportable answer (green),
  // not "nothing to report." Overrides are ignored at L1, matching
  // wouldBlock()'s L1 behavior elsewhere (nothing is blockable there at all).
  if (level === 1) return { applicable: true, winnerSide: "allow", overridden: false };

  let winnerSide;
  if (level === 2)      winnerSide = isTldBlacklisted(thirdPartyHost, state) ? "block" : "allow";
  else if (level === 3) winnerSide = isTldWhitelisted(thirdPartyHost, state) ? "allow" : "block";
  else if (level === 4) winnerSide = isCdnMatch(url) ? "allow" : "block";
  else                   winnerSide = "block"; // level 5

  const rule = state.matrixRules && state.matrixRules[thirdPartyHost];
  const hasTypeOverride = !!(rule && (rule.frame || rule.script));
  const isBuiltin = isBuiltinWhitelisted(thirdPartyHost, state);
  const overridden = hasTypeOverride || isBuiltin;

  return { applicable: true, winnerSide: winnerSide, overridden: overridden };
}
// Mirrors rule-builder.js rulesForLevel() exactly — same allow/block order,
// same conditions, referenced by rule ID where applicable. Built from the
// individually-exported mechanism checks above, so this decision and Mode's
// per-domain coloring (background.js) can never drift into different
// opinions about the same domain.
// Returns true if we would block, false if we would allow.
//
// thirdPartyHost — eTLD+1 of the request URL (from etldPlusOne())
// resourceType   — "frame" | "script" (normalise sub_frame -> "frame" before calling)
// url            — full request URL (needed for the CDN substring check)
// state          — extension state snapshot (level, siteRules, domains, tlds, builtinDomains, matrixRules)
// activeHost     — the 1P hostname the session/matrix is scoped to (for the site-rules lookup)
//
// Decision order (highest DNR priority wins, mirrored here top-to-bottom):
//   1. Level 1            → allow all                          (no rules at L1)
//   2. Matrix override    → allow/block (per state.matrixRules) (prio 1000/2000, L2–5 — see rule-builder.js's buildMatrixOverrideRules)
//   3. Builtin whitelist  → allow  (rules 2600–2999, prio 1000, L2–5)
//   4. TLD whitelist      → allow  (rules 2400–2499, prio 1000, L3 only)
//   5. CDN allow          → allow  (rule  3000,      prio 1000, L4 scripts only)
//   6. Block 3P frames    → block  (rule  3001,      prio 20,   L2–5 sub_frame)
//   7. Block 3P scripts   → block  (rule  3002,      prio 20,   L3–5 script)
//   8. Implicit allow     → allow  (nothing matched — not our block)
export function wouldBlock(thirdPartyHost, resourceType, url, state, activeHost) {
  if (!state) return true; // no state — assume block

  const level = getEffectiveLevel(state, activeHost);

  // ── 1. Level 1 — no rules, allow everything ───────────────────────────────
  if (level === 1) return false;

  // ── 2. Matrix override — always wins over everything below, per the ──────
  // interactive Matrix feature's design ("Domain rules always overwrite MODE
  // rules"). Checked here so Show blocks and the Matrix's own cell coloring
  // both reflect the exact same effective disposition — one classifier,
  // never two independently-drifting opinions about the same request.
  if (state.matrixRules && state.matrixRules[thirdPartyHost]) {
    const override = state.matrixRules[thirdPartyHost][resourceType];
    if (override === "block") return true;
    if (override === "allow") return false;
  }

  // ── 3. Builtin domain whitelist (rules 2600–2999, levels 2–5) ────────────
  if (isBuiltinWhitelisted(thirdPartyHost, state)) return false;

  // ── 4. TLD whitelist (rules 2400–2499, level 3 only) ─────────────────────
  if (level === 3 && isTldWhitelisted(thirdPartyHost, state)) return false;

  // ── 5. CDN allow (rule 3000, level 4 only, scripts only) ─────────────────
  if (level === 4 && resourceType === "script" && isCdnMatch(url)) return false;

  // ── 6. Block 3P frames (rule 3001, levels 2–5) ───────────────────────────
  if (resourceType === "frame") return true;

  // ── 7. Block 3P scripts (rule 3002, levels 3–5) ──────────────────────────
  if (resourceType === "script" && level >= 3) return true;

  // ── 8. Implicit allow — not blocked by our ruleset ───────────────────────
  return false;
}
