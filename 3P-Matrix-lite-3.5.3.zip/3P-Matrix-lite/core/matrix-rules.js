// ── core/matrix-rules.js ──────────────────────────────────────────────────────
// State mutation for the interactive Matrix's per-domain, per-type overrides.
// Mirrors core/block-monitor.js's allowMonitorDomain() exactly in shape
// (mutate state, saveState, then applyStateFn to rebuild + push DNR rules,
// then callback) — same pattern, applied to a different piece of state.
//
// Public interface:
//   setMatrixRule(domain, type, action, state, applyStateFn, cb)
//     domain — third-party eTLD+1 host
//     type   — "frame" | "script" (the only two overridable resource types)
//     action — "allow" | "block" | null (null = clear/unselect, revert to
//              the level's default disposition for that domain+type)
// ─────────────────────────────────────────────────────────────────────────────

import { saveState } from "../data/state-storage.js";

export function setMatrixRule(domain, type, action, state, applyStateFn, cb) {
  if (!domain || (type !== "frame" && type !== "script")) {
    if (cb) cb({ ok: false, error: "Invalid domain or type" });
    return;
  }
  if (action !== "allow" && action !== "block" && action !== null) {
    if (cb) cb({ ok: false, error: "Invalid action" });
    return;
  }

  if (!state.matrixRules) state.matrixRules = {};

  if (action === null) {
    // Clear/unselect — revert to the level's default disposition.
    if (state.matrixRules[domain]) {
      delete state.matrixRules[domain][type];
      // Drop the domain entry entirely once it holds no overrides at all,
      // rather than leaving an empty {} object behind indefinitely.
      if (Object.keys(state.matrixRules[domain]).length === 0) {
        delete state.matrixRules[domain];
      }
    }
  } else {
    if (!state.matrixRules[domain]) state.matrixRules[domain] = {};
    state.matrixRules[domain][type] = action;
  }

  saveState(state, function() {
    applyStateFn(state, function(count) {
      if (cb) cb({ ok: true, ruleCount: count });
    });
  });
}

// Sets/clears BOTH frame and script together, atomically (one state write,
// one rule rebuild). This is the actual entry point the UI uses now — a
// single "Domain" allow/block column, not independent per-type controls
// (an earlier revision of this feature had per-type columns; simplified
// per the design decision that domain-level overrides are easier to reason
// about, and setMatrixRule() above is kept only as the lower-level primitive
// this function is built from — it's still exported in case per-type
// control is ever wanted again).
export function setMatrixDomainRule(domain, action, state, applyStateFn, cb) {
  if (!domain) { if (cb) cb({ ok: false, error: "No domain" }); return; }
  if (action !== "allow" && action !== "block" && action !== null) {
    if (cb) cb({ ok: false, error: "Invalid action" });
    return;
  }

  if (!state.matrixRules) state.matrixRules = {};

  if (action === null) {
    delete state.matrixRules[domain];
  } else {
    state.matrixRules[domain] = { frame: action, script: action };
  }

  saveState(state, function() {
    applyStateFn(state, function(count) {
      if (cb) cb({ ok: true, ruleCount: count });
    });
  });
}
