// ── ui/matrix-panel.js ──────────────────────────────────────────────────────────
// Show Matrix panel UI.
// Renders the live table of third-party connections for one tab, plus:
//   - an informational Mode legend (explains the level's own default colors)
//   - the interactive "Domain" allow/block column — the only clickable
//     control, setting one override that covers BOTH frame and script
//     together (core/matrix-rules.js's setMatrixDomainRule)
//   - informational script/frame split cells reflecting that override's
//     effect (grey on the side it overruled)
// plus a countdown clock (same MATRIX_DURATION as the SW side — see
// core/connection-matrix.js). No pause/resume, unlike monitor-panel.js.
//
// The tabId/host/level being observed are passed in the panel URL's query
// string (set by ui/popup.js when it opens this window).
//
// Communicates with the SW via chrome.runtime.sendMessage using MSG_* constants.
// ─────────────────────────────────────────────────────────────────────────────

import { MSG_GET_MATRIX_DATA, MSG_STOP_MATRIX, MSG_MATRIX_CLOSED, MSG_SET_MATRIX_RULE } from "../data/message-types.js";

const POLL_MS = 800;    // how often to fetch new entries from SW
const WARN_MS = 60000;  // turn timer yellow at 1 minute remaining

// ── Guarded module state — initialised empty, cleared/released explicitly ────
let _pollInterval  = null; // setInterval handle for live data polling
let _clockInterval = null; // setInterval handle for the countdown display
let _clockStarted  = false; // guard: only start the clock once, from the first poll response
let _isStopped     = false;
const _tabId  = _readIntParam("tabId");
const _host   = _readStringParam("host", "—");
const _level  = _readIntParam("level") || 1;

// ── Panel branding color — reflects the ACTUAL protection level now, ────────
// instead of a fixed cyan. Same hex values as popup.js's LEVELS array /
// matrix-panel.html's --lvl1-green.. --lvl5-red tokens. Applied once at init
// via a CSS custom property (--level-color) rather than hardcoded per
// element, so every branding element (title, timer, Close button, filter
// focus ring) stays in sync from one place.
const LEVEL_BRAND_COLOR = {
  1: "var(--lvl1-green)",
  2: "var(--lvl2-blue)",
  3: "var(--lvl3-yellow)",
  4: "var(--lvl4-orange)",
  5: "var(--lvl5-red)"
};

// ── URL param helpers ─────────────────────────────────────────────────────────

function _readIntParam(name) {
  const params = new URLSearchParams(window.location.search);
  const raw = params.get(name);
  const n = raw ? parseInt(raw, 10) : NaN;
  return isNaN(n) ? null : n;
}

function _readStringParam(name, fallback) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name) || fallback;
}

// ── Messaging helper ──────────────────────────────────────────────────────────

function send(msg, cb) {
  try {
    chrome.runtime.sendMessage(msg, function(resp) {
      if (chrome.runtime.lastError) { if (cb) cb(null); return; }
      if (cb) cb(resp);
    });
  } catch(e) {
    if (cb) cb(null);
  }
}

// ── DOM refs ──────────────────────────────────────────────────────────────────

const elHost       = document.getElementById("panelHost");
const elBtnClose    = document.getElementById("btnClose");
const elThead       = document.getElementById("matrixThead");
const elEntryBody   = document.getElementById("entryBody");
const elEmptyState  = document.getElementById("emptyState");
const elTimer       = document.getElementById("timerDisplay");
const elTimerIcon   = document.getElementById("timerIcon");
const elStats       = document.getElementById("panelStats");
const elFilterInput = document.getElementById("filterInput");

// ── Filter state ──────────────────────────────────────────────────────────────
let _lastEntries = [];
let _filterText  = "";

// ── Column model ──────────────────────────────────────────────────────────────
// Groups, not a flat list — each group has 1 sub-column (rendered as a single
// rowspan=2 header cell) or 2 sub-columns (rendered as a colspan=2 group
// header + two Allow/Block sub-headers below it). flattenGroups() derives the
// flat per-cell list every row uses, so header and body are still generated
// from one single source of truth — just a two-level one now, to support
// real grouped headers (MODE / DOMAIN / SCRIPT / FRAME) instead of
// abbreviated flat labels.
//
// Sub-column kinds:
//   "domain"       — the domain name itself
//   "single"       — plain checkmark/dash, non-interactive (image/media/
//                    stylesheet/fetch-xhr/other)
//   "internal-whitelist" — single informational column, LEFT of Mode. Green
//                    if this domain is in the extension's built-in trusted
//                    list; grey if built-in-listed but a per-type override
//                    exists for it (the built-in status is no longer the
//                    sole/deciding factor for at least one type); blank if
//                    not built-in-listed at all. Never clickable.
//   "mode"         — Mode legend, ONE column at every level, fixed green
//                    (allow) / red (block) / grey (overridden — a script or
//                    frame per-type override exists, or the domain is on
//                    the built-in whitelist; either way something other
//                    than the level's own mechanism is deciding this
//                    domain's fate). Per-level coloring (blue at L2, yellow
//                    at L3, etc.) was tried and reverted per explicit
//                    feedback — back to universal colors, same language as
//                    SCRIPT/FRAME. See core/rule-classifier.js's getModeState().
//   "type-allow" / "type-block" — the interactive script/frame split-cell
//                    halves — per-domain, per-type, clickable per
//                    isHalfClickable() below. Sets/clears an override via
//                    core/matrix-rules.js's setMatrixRule(domain, type, action).
function buildColumnGroups(level) {
  const groups = [];

  groups.push({ label: "Domains connected", subs: [
    { key: "domain", kind: "domain", label: "Domains connected" }
  ]});

  // ── Internal whitelist (informational, single column, left of Mode) ──────
  if (level !== 1) {
    groups.push({ label: ["INTERNAL", "WHITELIST"], subs: [
      { key: "internal-whitelist", kind: "internal-whitelist", label: ["INTERNAL", "WHITELIST"],
        title: "Internal whitelist — informational: green if this domain is in the extension's built-in trusted list, grey if that status is currently overridden for a type, blank otherwise" }
    ]});
  }

  // ── Mode legend (informational) — always ONE column, every level ─────────
  groups.push({ label: "Mode", subs: [
    { key: "mode", kind: "mode", label: "Mode",
      title: "Mode — informational: green/red shows what this level's own mechanism would do, grey if a script or frame override exists for this domain, blank at level 1 (no rules exist there at all)" }
  ]});

  // ── Plain observation columns (before script/frame) ───────────────────────
  ["image", "media", "stylesheet"].forEach(function(t) {
    groups.push({ label: t, subs: [{ key: t, kind: "single", type: t, label: t }] });
  });

  // ── script / frame — interactive again, always split into two halves ─────
  // (the Domain column that briefly replaced this per-type clickability has
  // been removed — see CHANGELOG for why. Reinstates the original per-type
  // control, independent for script vs frame.)
  ["script", "frame"].forEach(function(t) {
    groups.push({ label: t.toUpperCase(), subs: [
      { key: t + "-allow", kind: "type-allow", type: t, label: "Allow",
        title: "Click to allow this domain's " + t },
      { key: t + "-block", kind: "type-block", type: t, label: "Block",
        title: "Click to block this domain's " + t }
    ]});
  });

  // ── Remaining plain observation columns ──────────────────────────────────
  ["fetch/xhr", "other"].forEach(function(t) {
    groups.push({ label: t, subs: [{ key: t, kind: "single", type: t, label: t }] });
  });

  return groups;
}

// Derives the flat per-cell list from the grouped model — used by
// renderEntry() to build each row's cells in the same order the header uses.
// Marks the first sub of every group except the very first with groupStart,
// for the vertical divider border between groups.
function flattenColumns(groups) {
  const flat = [];
  groups.forEach(function(g, gi) {
    g.subs.forEach(function(sub, si) {
      flat.push(Object.assign({}, sub, { groupStart: (gi > 0 && si === 0) }));
    });
  });
  return flat;
}

const _groups  = buildColumnGroups(_level);
const _columns = flattenColumns(_groups);

// ── Header ────────────────────────────────────────────────────────────────────
// Two real rows: row 1 holds either a rowspan=2 single header (1-sub groups)
// or a colspan=2 group super-header (2-sub groups: MODE/DOMAIN/SCRIPT/FRAME);
// row 2 holds only the Allow/Block sub-headers for the 2-sub groups. See
// matrix-panel.html's sticky-positioning comment for why both rows have a
// fixed height.
function buildHeader() {
  const row1 = document.createElement("tr");
  const row2 = document.createElement("tr");

  // Renders a th's label — either plain text, or (for a 2-line label like
  // ["INTERNAL", "WHITELIST"]) two stacked block-level spans.
  function _setLabel(th, label) {
    if (Array.isArray(label)) {
      th.innerHTML = "";
      label.forEach(function(line) {
        const span = document.createElement("span");
        span.className = "th-line";
        span.textContent = line;
        th.appendChild(span);
      });
    } else {
      th.textContent = label;
    }
  }

  _groups.forEach(function(g, gi) {
    const isGroupStart = gi > 0;
    if (g.subs.length === 1) {
      const th = document.createElement("th");
      _setLabel(th, g.subs[0].label);
      th.rowSpan = 2;
      if (g.subs[0].title) th.title = g.subs[0].title;
      if (g.subs[0].kind === "domain") th.classList.add("th-domain");
      if (isGroupStart) th.classList.add("group-start");
      row1.appendChild(th);
    } else {
      const th = document.createElement("th");
      _setLabel(th, g.label);
      th.colSpan = g.subs.length;
      if (isGroupStart) th.classList.add("group-start");
      row1.appendChild(th);

      g.subs.forEach(function(sub, si) {
        const subTh = document.createElement("th");
        _setLabel(subTh, sub.label);
        if (sub.title) subTh.title = sub.title;
        if (si === 0) subTh.classList.add("group-start");
        row2.appendChild(subTh);
      });
    }
  });

  elThead.innerHTML = "";
  elThead.appendChild(row1);
  elThead.appendChild(row2);
}

// ── Clock — ported from monitor-panel.js's identical startClock/formatClock ──

function formatClock(ms) {
  const total = Math.floor(Math.max(0, ms) / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return m + ":" + (s < 10 ? "0" : "") + s;
}

function startClock(remainingMs) {
  if (_clockInterval) clearInterval(_clockInterval);
  const deadline = Date.now() + remainingMs;

  _clockInterval = setInterval(function() {
    if (_isStopped) return;
    const left = deadline - Date.now();
    elTimer.textContent = formatClock(left);

    if (left <= 0) {
      elTimer.classList.add("expired");
      elTimerIcon.textContent = "■";
      clearInterval(_clockInterval);
    } else if (left <= WARN_MS) {
      elTimer.classList.add("warning");
    }
  }, 500);
}

// ── Interactivity rules — apply to the Domain column, the only clickable ────
// pair now (script/frame are purely informational — see column model above).
// L1: Domain column doesn't exist at all (see buildColumnModel) — nothing to gate.
// L2: only the allow-half is clickable (block is default-only at this level —
//     matches the design spec's "user can only click on allow" for L2).
// L3-5: both halves clickable.
function isHalfClickable(level, half) {
  if (level === 1) return false;
  if (level === 2) return half === "allow";
  return true;
}

// ── Entry rendering ───────────────────────────────────────────────────────────

function renderEntry(entry) {
  const tr = document.createElement("tr");
  const cells = [];

  _columns.forEach(function(col) {
    if (col.kind === "domain") {
      const td = document.createElement("td");
      td.className = "td-domain";
      td.textContent = entry.domain; // textContent, not innerHTML — domain is safe (URL hostname charset) but no reason to risk it
      cells.push(td);
      return;
    }

    if (col.kind === "mode") {
      // One column, fixed green/red (universal, not level-specific — an
      // earlier attempt at per-level coloring was reverted per explicit
      // feedback), universal grey for overridden — see
      // core/rule-classifier.js's getModeState() and background.js's
      // enrichment step. entry.mode is a single string:
      // "allow" | "block" | "grey" (or "empty" as a defensive fallback,
      // though that shouldn't occur in practice — see getModeState()).
      const td = document.createElement("td");
      if (col.groupStart) td.className = "group-start";
      const state = entry.mode || "empty";

      const swatch = document.createElement("span");
      swatch.className = "mini-square";
      if (state === "allow") {
        swatch.classList.add("filled", "fill-green");
      } else if (state === "block") {
        swatch.classList.add("filled", "fill-red");
      } else if (state === "grey") {
        swatch.classList.add("filled", "fill-grey");
      }
      // "empty" — bare outline square, no fill.
      td.appendChild(swatch);
      cells.push(td);
      return;
    }

    if (col.kind === "internal-whitelist") {
      // Informational, never clickable. "green" (built-in trusted, no
      // override), "grey" (built-in trusted but a per-type override exists
      // for it), or "empty" (not built-in trusted at all) — computed in
      // background.js's enrichment step.
      const td = document.createElement("td");
      if (col.groupStart) td.className = "group-start";
      const state = entry.internalWhitelist || "empty";

      const swatch = document.createElement("span");
      swatch.className = "mini-square";
      if (state === "green") {
        swatch.classList.add("filled", "fill-green");
      } else if (state === "grey") {
        swatch.classList.add("filled", "fill-grey");
      }
      td.appendChild(swatch);
      cells.push(td);
      return;
    }

    if (col.kind === "single") {
      const td = document.createElement("td");
      if (col.groupStart) td.className = "group-start";
      const has = entry.types.indexOf(col.type) !== -1;
      const span = document.createElement("span");
      span.className = "td-check" + (has ? "" : " empty");
      span.textContent = has ? "✓" : "—";
      td.appendChild(span);
      cells.push(td);
      return;
    }

    if (col.kind === "type-allow" || col.kind === "type-block") {
      // Interactive again — per-domain, per-type. Fixed green (allow) / red
      // (block) regardless of protection level, since Mode already explains
      // the level-specific color scheme; these show the plain literal
      // outcome. The non-active half is always blank now — an earlier
      // version greyed it out when overridden, but the active half's color
      // already communicates that clearly enough on its own (per explicit
      // feedback, across every level).
      const td = document.createElement("td");
      const half = col.kind === "type-allow" ? "allow" : "block";
      const disposition = col.type === "frame" ? entry.frameDisposition : entry.scriptDisposition;
      const clickable = isHalfClickable(_level, half);

      if (!disposition) {
        // Type never observed for this domain — same empty state as a
        // plain unobserved column, and not clickable (nothing to act on
        // for a type that hasn't been seen yet).
        td.className = col.groupStart ? "group-start" : "";
        td.innerHTML = '<span class="td-check empty">—</span>';
        cells.push(td);
        return;
      }

      const isActive     = disposition.effective === half;
      const isOverridden = disposition.overridden;

      td.className = "td-half" +
        (col.groupStart ? " group-start" : "") +
        (clickable ? " clickable" : "");
      td.dataset.domain = entry.domain;
      td.dataset.type    = col.type;
      td.dataset.half    = half;
      td.dataset.overrideAction = isOverridden ? disposition.effective : "";

      const square = document.createElement("span");
      square.className = "mini-square";
      if (isActive) {
        square.classList.add("filled", half === "allow" ? "fill-green" : "fill-red");
      }
      // Non-active half stays a bare unfilled square — blank, not grey,
      // regardless of isOverridden.
      td.appendChild(square);
      cells.push(td);
      return;
    }
  });

  cells.forEach(function(td) { tr.appendChild(td); });
  return tr;
}

function refreshTable(entries) {
  _lastEntries = entries;
  _renderFilteredTable();
}

function _renderFilteredTable() {
  const needle = _filterText.trim().toLowerCase();
  const visible = needle
    ? _lastEntries.filter(function(e) { return e.domain.toLowerCase().indexOf(needle) !== -1; })
    : _lastEntries;

  elEntryBody.innerHTML = "";
  for (let i = 0; i < visible.length; i++) {
    elEntryBody.appendChild(renderEntry(visible[i]));
  }

  if (visible.length) {
    elEmptyState.style.display = "none";
  } else if (needle && _lastEntries.length) {
    elEmptyState.style.display = "block";
    elEmptyState.querySelector(".empty-sub").textContent = "No domains match \"" + _filterText.trim() + "\".";
  } else {
    elEmptyState.style.display = "block";
    elEmptyState.querySelector(".empty-sub").textContent = "Third-party connections appear here as the page loads.";
  }
}

function renderStats(domainCount, requestCount) {
  const d = domainCount || 0;
  const r = requestCount || 0;
  elStats.textContent = d + " domain" + (d === 1 ? "" : "s") + " · " + r + " request" + (r === 1 ? "" : "s");
}

// ── Click-to-override — event delegation on the tbody, so re-rendering the ──
// table on every poll never requires re-attaching per-cell listeners.
// Script/Frame cells carry the .clickable class — each type independent.
elEntryBody.addEventListener("click", function(e) {
  const cell = e.target.closest(".td-half.clickable");
  if (!cell) return;

  const domain = cell.dataset.domain;
  const type   = cell.dataset.type;
  const half   = cell.dataset.half; // the action this half represents: "allow" | "block"
  const currentOverride = cell.dataset.overrideAction; // "" | "allow" | "block"

  // Toggle: clicking the half that's already the active override clears it
  // (reverts to the level's default for this type); clicking anything else
  // sets that override for this type only — independent from the other type.
  const newAction = (currentOverride === half) ? null : half;

  send({ type: MSG_SET_MATRIX_RULE, domain: domain, resourceType: type, action: newAction }, function(resp) {
    if (!resp || !resp.ok) return;
    poll(); // immediate refresh — don't wait for the next 800ms tick
  });
});

// ── Poll ──────────────────────────────────────────────────────────────────────

function startPolling() {
  if (_pollInterval) clearInterval(_pollInterval);
  _pollInterval = setInterval(poll, POLL_MS);
  poll(); // immediate first fetch
}

function stopPolling() {
  if (_pollInterval) { clearInterval(_pollInterval); _pollInterval = null; }
}

function poll() {
  if (_tabId === null || _isStopped) return;
  send({ type: MSG_GET_MATRIX_DATA, tabId: _tabId }, function(resp) {
    if (!resp || !resp.ok || !resp.data) return;
    refreshTable(resp.data.entries || []);
    renderStats(resp.data.domainCount, resp.data.requestCount);
    if (!_clockStarted && typeof resp.data.remaining === "number") {
      _clockStarted = true;
      startClock(resp.data.remaining);
    }
  });
}

// ── Close ─────────────────────────────────────────────────────────────────────

function releaseAndClose() {
  if (_isStopped) { window.close(); return; }
  _isStopped = true;
  stopPolling();
  if (_clockInterval) { clearInterval(_clockInterval); _clockInterval = null; }
  if (_tabId !== null) {
    send({ type: MSG_STOP_MATRIX, tabId: _tabId }, function() { window.close(); });
  } else {
    window.close();
  }
}

elBtnClose.addEventListener("click", releaseAndClose);

// ── Filter input ──────────────────────────────────────────────────────────────
elFilterInput.addEventListener("input", function() {
  _filterText = elFilterInput.value;
  _renderFilteredTable();
});

// ── SW-initiated close (tab closed, or countdown expired, while panel open) ──

function handleForceClosed(reason) {
  if (_isStopped) return;
  _isStopped = true;
  stopPolling();
  if (_clockInterval) { clearInterval(_clockInterval); _clockInterval = null; }
  elTimer.classList.add("expired");
  elTimerIcon.textContent = "■";
  elEmptyState.style.display = "block";
  const reasonText = {
    tab_closed: "The observed tab was closed.",
    timeout:    "Time limit reached — session closed."
  };
  elEmptyState.querySelector(".empty-sub").textContent = reasonText[reason] || "Show Matrix session ended.";
  setTimeout(function() { window.close(); }, 1200);
}

chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === MSG_MATRIX_CLOSED && msg.tabId === _tabId) {
    handleForceClosed(msg.reason);
  }
});

// ── Init ──────────────────────────────────────────────────────────────────────

(function init() {
  elHost.textContent = _host;
  document.body.style.setProperty('--level-color', LEVEL_BRAND_COLOR[_level] || LEVEL_BRAND_COLOR[1]);
  buildHeader();
  if (_tabId === null) {
    elEmptyState.querySelector(".empty-sub").textContent = "No tab to observe — please reopen from the popup.";
    return;
  }
  startPolling();
})();

// ── Release on window close ───────────────────────────────────────────────────
window.addEventListener('beforeunload', function() {
  if (_isStopped) return;
  if (_tabId === null) return;
  try {
    chrome.runtime.sendMessage({ type: MSG_STOP_MATRIX, tabId: _tabId });
  } catch(e) {
    // Intentional: beforeunload gives very little time; SW cleanup is best-effort.
  }
});
