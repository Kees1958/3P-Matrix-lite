# 3P Matrix — content firewall · Levels & protections spec (agreed 2026-10-16; in line with the code as of 4.3.7, 2026-10-24)

(Project started as "TLD Browser Guard", then "TLD Matrix"; renamed to "3P Matrix — content firewall"
on 2026-10-16. Short name: 3P Matrix. Version line aligned with 3P-Matrix-lite since 4.1.0; current 4.3.0.)
Wording: always "safer regions" (never "safe zone") in UI, docs and comments.
Zips unpack to version-less folders "3P-Matrix" and "3P-Matrix-tools".

Combines: 3P-Matrix-lite 4.0.2 (UI, icons, lock level, startup level, Show Matrix observation),
uBlock Stripped Dynamic 10.2.1 (Privacy & Security protections, allow list), DownloadSentinel 3.3.1
(domain-name heuristics; since 4.3.0 also its download protection = protection 12, with all its options). uBD's per-site matrix overrides and its `$worryfree` / `$saferregions`
exemptions are NOT part of 3P Matrix (removed 4.2.3; tools/check-shipped-terms.mjs keeps them out).

## Levels (cumulative) — default startup level: 2

| Level | Name | Adds |
|---|---|---|
| 1 | Allow all | Nothing — every protection off |
| 2 | Mild protection | Protections 1–12 on every site (10 = abused-TLD block — see 11 for the suspicious-site warning; domain heuristics on EVERY first-party site, incl. the HaGeZi TLD list; 11 = 3P scripts AND frames from HaGeZi-listed TLDs blocked; 12 = risky-download warning, DownloadSentinel 3.3.1). No other 3P blocking. No safer regions. |
| 3 | Medium protection | + protections 13–18 outside safer regions; block 3P scripts & frames except safer-region TLDs + built-in whitelist. Safer regions override the TLD blocklist where they contradict. |
| 4 | High protection | Protections 13–18 on EVERY site (safer regions ignored). Block 3P scripts & frames. Exceptions: built-in whitelist + 3P scripts AND frames with "cdn" in the HOST. |
| 5 | Strict | Protections 1–18 on every site. Block 3P scripts & frames — no built-in whitelist, no cdn allow, no Show Matrix allows. |

Since 4.2 no level ever blocks third-party images, video, fonts or stylesheets (RT.CODE = script + sub_frame).
Safer regions have an effect at LEVEL 3 ONLY (decided 2026-10-16; data/constants.js
SAFER_REGIONS_LEVELS, core/policy.js saferRegionsApply()).

## Protections (17, selectable)

Active = (level ≥ its starting level) AND (user has not unticked it). All ticked by default. Global setting
(not per site — per-site control is the lock level and the allow list). Ticked/unticked ONLY in the popup
"Protections" list, which opens from the Protections button (closed by default). Counts show
"N of 18 protections" when some are off; at level 3 the bullet adds "(N of 6 outside safer regions)" —
every count is derived from the registry (C39a), never typed.

One registry table (data/protections.js) per protection: key (PROTECTION_KEY enum — the only way code
names a protection) · num · label · from level · mechanism (script / DNR block / DNR header / navigation
check) · scope (every site / outside safer regions). tools/check-protection-keys.mjs keeps enum, registry
and numbering (1…N, no gaps) consistent.

Group 1 — on every site, from L2 (uBD rows 3–10 + new HTTP rule + suspicious-site warning + abused TLDs).
0.2.3 removed "clear history at browser start" and "block tracking pings" (kept in uBlock Stripped Dynamic).
1 blockPaymentHandlers — block payment-handler install (4.2: built-in payment hosts exempt on their own site, L3–4)
2 blockWebBundles — block Web Bundles
3 blockDialogSpam — block alert/confirm/prompt scams
4 blockLocalNetwork — block access to local network
5 blockProtocolHandlers — block protocol-handler install
6 blockSuspicious3p — block suspicious 3P (IP, non-standard ports, DDNS/free hosting)
7 block3pHttp — block 3P plain-HTTP requests
8 blockClickFix — block ClickFix clipboard writes
9 blockHighRiskEval — strict eval + Permissions-Policy on high-risk sites
10 blockAbusedTlds — block 3P scripts and frames from HaGeZi-listed TLDs (4.2: was an unconditional part of L2+)
11 warnSuspiciousSites — "Warn when opening a site that looks suspicious" (0.2.4: selectable; 4.2.3: was
   "before"). Unticked = no stage 1/2 checks, no warning dialog, neutral badge colour. 4.3.2: number 10 → 11 (the warnings sit together at 11–12).
12 warnRiskyDownloads — "Warn when a downloaded file looks risky" (4.3.0) — see "Download protection" below

Group 2 — from L3: outside safer regions at L3, on every site at L4–L5 (uBD rows 11–15; renumbered 12–16 in 4.2,
13–17 in 4.3.0 — keys unchanged). 4.3.2: + 18 blockRiskyDownloads (off by default).
Popup group title: "Outside safer regions" at L3, "Extra — on every site" at L4–L5.
13 blockScpPrivacy — Permissions-Policy camera/mic/display-capture/clipboard-read
14 blockScpSecurity — Permissions-Policy bluetooth/serial/hid/usb/local-network-access
15 blockSensorsNfc — REPLACES uBD row 13: motion sensors via Permissions-Policy (accelerometer, gyroscope,
   magnetometer) + NFC via script; plugins/battery/idle/window.name DROPPED
16 blockObfuscatedEval — obfuscated eval
17 blockRedirectsDialogs — sandbox: frame redirects + dialogs (4.3.2 label: "Block redirects and dialogs from frames", one popup line)
18 blockRiskyDownloads — "Block risky downloads (programs, scripts, archives)" (4.3.2) — OFF by default; see "Download protection"

## TLD blocklist (from L2)
Source: HaGeZi "The World's Most Abused TLDs", uBlock syntax — the ONLY TLD blocklist. The old
3P-Matrix-lite blocklist (None/User/Generic/World modes) is removed (0.2.2); not user-editable.
https://raw.githubusercontent.com/hagezi/dns-blocklists/refs/heads/main/adblock/spam-tlds-ublock.txt
(2026-10-15: 445 TLDs = 294 latin + 151 punycode; 166 lines carry ~domain exceptions for legitimate sites).
1. First-party visit to a listed TLD → heuristics signal / warning (the ~domain exceptions are not warned).
2. 3P scripts and frames from listed TLDs blocked (one DNR rule, requestDomains = TLD list,
   excludedRequestDomains = the exceptions).

## Safer regions (TLD whitelist) — level 3 only
3P-Matrix-lite tld-engine BASE_TLDS, MINUS `shop`, `store`, `site`, `online`, `biz`, + auto-added country codes.
Auto-add scope FIXED to Continent, the same default as uBlock Stripped Dynamic (0.2.4: the popup's 4-position
"Auto-add country codes" slider is removed; data/constants.js SAFER_REGIONS_AUTO_MODE): the countries named by
the browser's languages + every country on the user's continent that speaks one of them (or a readable
relative). Continent from the first language tag with a region, else the time zone. The user can still add and
remove TLDs in the popup; "Default" clears those edits. The list is recomputed on install AND update.
No fixed Five Eyes / EU group: a bare "en" tag adds uk/us/ie/au/ca/nz (nz added 0.2.4 — the only difference from uBD), Europeans
with an EU language get `eu`. Auto-added TLDs on the HaGeZi list are dropped (decided 2026-10-16:
SAFER_REGIONS_SKIP_ABUSED_TLDS; today cf, cm, ga, gq, ml, ng, pw); a TLD the user adds by hand is kept.
At L3 it controls: the 3P scripts/frames allow and the "outside safer regions" scope of protections 13–18.
At L1, L2, L4, L5 it has no effect; the popup editor and the IN/OUTSIDE SAFER REGIONS label show at L3 only.
Per-site locks follow the locked level (a .nl site locked at L4 gets 13–18 even when the global level is 3).
NOT a gate for the domain heuristics (most phishing uses .com). (State key stays `safeZone` — contract.)

## Built-in whitelist (data/builtin-domains.js)
Payment, sign-in (SSO), CAPTCHA, fraud prevention, video embeds, JS libraries — plus, since 0.2.4
(user request), streaming/meeting/gaming services with a genuine embeddable widget: Spotify,
SoundCloud, Deezer, Apple Music, Mixcloud (streaming); Zoom, Webex, Whereby, Microsoft Teams, Discord
(meeting); Steam, itch.io (gaming). Destination-only services with no embeddable widget (Netflix,
Disney+, Hulu, Max, Prime Video, Paramount+, Peacock, Crunchyroll, Xbox, PlayStation, Nintendo, Epic
Games, Riot Games, WhatsApp, Telegram, Signal, Slack, Google Meet) are deliberately left out — adding
them would have no effect, since nothing on this list is ever loaded as third-party content elsewhere.
Hand-curated from general knowledge, not a live/verified source.

Two independent effects, both at levels 3 and 4 only (never 5, matching the level table above):
1. Third-party scripts/frames from a listed host are allowed through the level 3/4 content block
   (BUILTIN_BOTH/SCRIPT_ONLY/FRAME_ONLY, DNR allow rules) — e.g. a Spotify embed on someone else's page.
2. Since 0.2.4 (user: "it should also apply on the protections" — corrects an initial assumption that
   this list only ever affected third-party embeds): a listed host is ALSO exempt from protections
   9 and 13–17 (the Permissions-Policy/CSP header rules in core/rule-builder.js, and the
   blockObfuscatedEval/blockSensorsNfc content scripts in core/script-builder.js) on a FIRST-PARTY visit,
   and its payment hosts (BUILTIN_PAYMENT) from protection 1 (4.2)
   — e.g. camera/mic is not blocked while you are actually on zoom.us or discord.com yourself. This is
   a second, independent exemption alongside the safer-regions TLD one (core/policy.js
   saferRegionsApply); the two are merged, not layered. A site locked at level 5 overrides this
   exemption, same as it overrides the safer-regions one — a deliberate per-site choice for maximum
   protection beats being on a trusted-services list.
Also used by core/navigation-guard.js (BUILTIN_ALL) to skip the suspicious-site scoring/warning dialog.

## Suspicious-site detection
Protection 11 (warnSuspiciousSites; num 10 until 4.3.1). Runs only while it is active for the site (effective level ≥ 2 and ticked).
Stage 1 (local, ~0.4 ms, every first-party visit from L2; skipped for allow list and built-in whitelist):
- DownloadSentinel heuristics: punycode, excessive subdomains (FIX: count labels beyond the public suffix),
  brand names as separate words + fuzzy (≥ 7 letters, 534-brand list), ONE look-alike check (4.3.0, DS 3.2.0
  LookalikeDomainCheck — project doc DESIGN_lookalike_check.md: a popular site itself is never flagged; brand hit
  −65 "Looks like the brand site …", top-site hit −45 "Looks like the popular site …"; top-sites list = CrUX top
  100,000 + brand websites), HostList, risky hosting, suspicious-TLD scores, HaGeZi TLD list.
- Address signals (one family, worst counts — IP+port never doubles):
  IP-address-only host −30 · non-standard port (not 80/443/8080/8443) −15.
  Private/local hosts exempt (10/8, 172.16/12, 192.168/16, 127/8, ::1, .local, .lan, .home.arpa).
- Plain HTTP first-party −15.
Stage 2 (network, ONLY when stage 1 ≤ −30; cached per registered domain):
- RDAP domain age (rdap.org) — ALWAYS ON, no option to disable. Asked for the registered domain (PSL).
  Skipped (no call, no score) for a hosting-platform subdomain (PSL private section) or a ccTLD without RDAP
  (IANA bootstrap) — DS util/DomainAge.js since 4.3.4, same rule for downloads. Scores (4.3.4 = DS): failed /
  timeout (3 s) 0 · answered without a date −10 · < 30 days −30 · 30–90 days −10 · older 0.
- Threat-intel DNS (DoH, RFC 8484 wire format). User picks a FIRST and a SECOND resolver (or none) out of:
  - Quad9 — dns.quad9.net/dns-query (block = NXDOMAIN without authority)
  - Cloudflare Security 1.1.1.2, malware only — security.cloudflare-dns.com/dns-query (block = 0.0.0.0, verify)
  - Control D free, malware only — freedns.controld.com/p1 (block = 0.0.0.0 default, verify)
  - DNS4EU Protective (4.3.7) — protective.joindns4.eu/dns-query (block = A 51.15.69.11, its block page; verified
    2026-10-24). Also applies court-ordered blocks.
  - CleanBrowsing Security Filter (4.3.7) — doh.cleanbrowsing.org/doh/security-filter/ (block = no answer + authority
    SOA with MNAME *.rpz.noc.org; a non-existent name has the registry's SOA; verified 2026-10-24)
  A/AAAA or CNAME answer = resolved (4.3.4). Providers and block styles: DS APP.DNS_PROVIDERS / DNS_BLOCK_STYLE.
  Defaults: Quad9 + Cloudflare; France (time zone Europe/Paris + overseas, DS DNS_REGION_DEFAULTS) Control D +
  Cloudflare (4.3.7). No permission prompt: <all_urls> covers every resolver.
  Options page: "two of five" — pick two the user does NOT already use as own DNS.
- Note: users running their own DNS with DoH-bypass blocking (e.g. NextDNS "Block Bypass Methods") must
  allow-list the chosen resolver host(s) there. Unreachable = "check unavailable", never "safe".
- Certificate-age (CT log) check: DROPPED.
Combination via DownloadSentinel CombinationScoring (families, geometric decay, combo rules).

## Download protection (protection 12, 4.3.0 — DownloadSentinel 3.3.1 since 4.3.7, 3.3.0 since 4.3.4, full feature set)
- Decided 2026-10-20 (user): full DownloadSentinel parity; DS's own warning page (ported, 3P Matrix dark theme);
  "downloads" as a REQUIRED permission (WARNING: existing users get 3P Matrix disabled by Chrome until they
  re-approve — C36, accepted); the vendored DS library upgraded 3.0.4 → 3.2.0 for sites and downloads alike (→ 3.3.0 in 4.3.4).
- Gate: protection 12 active at the effective level of the download's SITE = the page it came from
  (DownloadItem.referrer), else the download host (blob: addresses unwrapped to their page origin). Allow-list page
  (level 1) → no download warning. Level 1 → none. 4.3.3: a page on the built-in whitelist → no check (as 11).
- Monitored types, checks, scores, time budget: DownloadSentinel's own (FilenameAnalysis.classifyDownload,
  BrowserProtection.checkHostReputation, ScoringEngineV2/SCORING_CONFIG, APP.VT_WAIT_BUDGET_MS). The download is
  never paused or blocked; at completion a maximized warning window opens (or nothing, "Silent when probably safe").
- Trusted download domains (DS "Do not check"): built-in app stores (always) + up to 12 user hosts (default
  sharepoint.com). DS's "Trust AI downloads" category: added 4.3.4, removed 4.3.6 (user decision).
  Matched on the file host, else the referring page (data:, blob:null — DS DownloadTrust, 4.3.4).
  Independent of the allow list (that one is about the page, this one about the file host).
- VirusTotal: optional API key (Options, write-only — the model only reports "key set"; never in a settings backup;
  kept on restore; cleared by Reset). Startup nudge window when no key (DS VtKeyPromptPolicy). No key: the VT
  box says "Reputation lookup at VirusTotal skipped" + key link. Late verdict (DS one-shot retry 3 s + 7 s):
  pushed to the open page (MSG_DOWNLOAD_VT_UPDATE); a closed window reopens only when the score gets worse.
- Options (DS's, no longer locked without a key since 4.3.4, as DS 3.3.0): silent-when-safe threshold, FP reduction, trusted domains,
  personalize warning page (colour, title). DNS: ONE shared choice (Options → online checks) for sites and downloads.
- No remote list refresh (DS 3.3.0 removed FilterDataLoader, 4.3.4); bundled lists only.
- Protection 18 (4.3.2, user decisions 2026-10-20): OFF by default (registry defaultOff; schema-3 migration unticks
  it for older states and old backups). Active from L3: outside safer regions at L3 (the PAGE the download came
  from decides, same "site" as 12), every site at L4–L5. Blocks only the risky types protection 12 monitors
  (FilenameAnalysis.classifyDownload); the download is cancelled (a finished tiny file removed) BEFORE protection
  12, so no check runs for it. A notice window (ui/download-blocked.*, site-warning look) offers OK and "Download
  anyway": a one-time pass (60 s) and a new download, which skips 18 and is ALWAYS checked by protection 12 —
  even with 12 unticked. Exemptions at L3 ONLY (DOWNLOAD_BLOCK_EXEMPT_LEVELS): a page on the built-in whitelist,
  or a file host on the trusted download domains (app stores + user list). L4–L5: no exception (only the allow
  list — a level-1 lock — is outside its reach).
- Not ported: DS popup (its master switch = protection 12's tick; its VT switch = Options checkbox), DS's unwired
  "submit URL to VT again" flow. lib = DS 3.3.0 byte-identical (no Settings/Storage/MessageTypes; GovSuffixes
  used at runtime by the look-alike check since 4.3.4).

## Warning
- NO warning banner in the popup. Every warning is a warning DIALOG.
- Protection 11; shown at score ≤ −30 (two severities: "suspicious" −30…−60, orange; "possible phishing" < −60, red).
- Not full screen: a centred dialog (max 560 px) on a dimmed background.
- Buttons, in this order, all solid with dark text:
  1. Go back — yellow #FACC15 (4.3.0: was "Go back to safety")
  2. Trust this site — mint #6EE7B7 (adds to allow list = locked at level 1)
  3. Continue once — bright orange #FF8A1F (this visit only, this tab)
- Mechanism: on onBeforeNavigate the tab is redirected to the extension's warning page as fast as possible.
  Chrome cannot hold a navigation from an extension, so the first request to the site may already have been
  sent; the user is always warned before using the page (decided 2026-10-19: warning is what counts —
  protection renamed "Warn when opening…").

## Badge / icons
- Icons: 3P-Matrix-lite brick-wall icons, one colour per level (icon_0..4 → L1..L5). Warning dialog uses the
  orange (suspect) or red (phishing) icon.
- Badge background per tab: grey normal · orange suspect (≤ −30) · red + "!" phishing (< −60).
- Badge text = requests blocked by 3P MATRIX ONLY (decided 2026-10-16, option 1). Chrome reports
  net::ERR_BLOCKED_BY_CLIENT for every extension's blocks, so each such request is replayed against our
  own applied rules (core/rule-matcher.js: DNR matching semantics, highest priority wins, allow beats block
  at equal priority; ~9 µs per check). Counted only when our outcome is "block". Header rules never count.
  The Show Matrix "blocked" marks use the same attribution.

## Show Matrix
- Popup button → panel window (980×720) for the current tab; the tab is reloaded so every request is seen.
- Columns (3P-Matrix-lite 4.0.2 layout and model, 4.2.1): Domains connected · Internal whitelist · Level mode ·
  image · media · stylesheet · SCRIPT · FRAME · fetch/xhr · other · requests. A "cdn" subdomain of a non-cdn
  domain, or a host that is itself a built-in entry, gets its own row. SCRIPT / FRAME show the policy's real
  decision (green ✓ allow, red ✕ block), replayed through the rules Chrome has (core/matrix-disposition.js +
  core/rule-matcher.js) — not what happened to be observed. Level mode = the level's own rules without built-in
  allows or overrides (grey when something else decides). Click a SCRIPT/FRAME square: set the opposite as an
  override; click again: clear. Totals line under the table; "rules apply on every site" in the help text.
- Overrides are ALWAYS GLOBAL (uMatrix / 3P-Matrix-lite model; global since 4.1.0, only global since
  4.2.3): per third-party domain, two scopes (since 4.2: Script = script, Frame = sub_frame), each set on
  its own; one priority PRIORITY.MATRIX (400000) — stored under matrixRules key `MATRIX_SITE_ALL` ("*").
  Per-site keys (0.2.x data, taken over by mistake from uBlock Stripped Dynamic's per-site matrix) are no
  longer supported: the schema-2 migration merges them into "*" once (per scope the per-site value wins;
  COMPAT-REMOVE ≥4.5).
  Overrides outrank every level/security rule; only the L5 code block (500000) beats them (= no allows at L5).
- Stored in state.matrixRules (capped 1000 domains), DNR ids 900000+.
- Guards: observation stops after 5 minutes (MATRIX_DURATION_MS) and the panel window is CLOSED then.
  Also closed when the tab closes; the panel closes itself as soon as observation has ended (covers a
  service-worker restart) and as a last resort MATRIX_CLOSE_GRACE_MS (5 s) after the countdown. Per-tab data
  capped at 150 domains; the webRequest listener exists only while a tab is observed.

## Settings backup (Options → Save / Restore), format v2 (0.2.1)
Readable sections: startupLevel · protections.disabled · saferRegions{addedTlds, removedTlds, activeTlds
(informational, recomputed)} (autoAddCountryCodes dropped in 0.2.4; ignored when restoring older files) · allowList · lockedSites · showMatrixRules ·
onlineChecks. v1 files (0.1.x / 0.2.0) still restore (COMPAT-REMOVE ≥4.5). Status line shows a one-line summary.

## Shared concepts
- Allow list: plain domain line = site locked at level 1. "Trust this site" (warning dialog) adds to it.
- Lock level / startup level: as 3P-Matrix-lite (lock pins the current level, then restores the previous
  session level).
- Certificate inspection itself is impossible with Chrome MV3 APIs (no getSecurityInfo).

## Architecture (4.3.0)
- data/constants.js holds every switch/ID/priority/score/Chrome-defined value; data/protections.js is the
  protection registry (PROTECTION_KEY enum). No typed number outside a named constant
  (tools/check-magic-numbers.mjs). The data layer never imports core/.
- background.js = lifecycle + event listeners + thin router (input validation, sender check, delegation).
  Logic lives in core/: site-locks (locks, allow list), matrix-overrides, matrix-windows (panel lifecycle),
  view-models (what each page receives), safer-regions (compute + edit), navigation-guard, online-checks …
- Pure builders: core/policy.js, core/rule-builder.js (incl. buildMatrixRules), core/script-builder.js,
  core/rule-matcher.js. Only core/apply-manager.js writes rules/scripts to Chrome (serialized +
  coalesced, regexes validated) and keeps the compiled copy for the matcher.
- Rules per GROUP, not per site: group 0 = global (excludes all locked sites), groups 1–5 = sites locked
  at that level. Rule id = 10000 × group + local id. Matrix band 900000+.
- Content scripts: one registration per script protection, plus at most ONE rescue registration per site
  (SCRIPT_ID_SUFFIX.SAFER_LOCKED / BUILTIN_LOCKED) for locked sites a blanket exclude would otherwise skip.
  MAIN-world scripts cannot import constants: each declares its own LOG_PREFIX copy, kept equal by
  tools/check-shipped-terms.mjs.
- Non-standard port block: ONE regex excluding 80/443/8080/8443.
- Priorities: L5 500000 > Show Matrix 400000 > local network 1002 > security 1000 > safer-regions allow 360 > abused-TLD 350
  > built-in/CDN allow 300 > level block 100. Headers priority 1.
- State: single storage key, schema STATE_SCHEMA_VERSION (2 since 4.2.3); normalizeState() first runs the
  ordered STATE_MIGRATIONS list (data without a schema = 1), then validates every field; withStateLock()
  serializes updates.
- UI text never repeats a constant: numbers/labels a page shows come from ui/derived-text.js
  (data-derived placeholders); action outcomes appear in a status line (ui/status-line.js), never only in the
  console. [hidden] always wins over component display rules (common.css guard).

## UI (mockup: Design canvas "TLD Browser Guard popup", 4 boards)
- Dark theme (3P-Matrix-lite). Header: level icon + "3P Matrix" + grey tagline "content firewall".
- Popup lines fit on one line ("3P code" = scripts & frames).
- Popup width 440 px; "Active policy" buttons in this order: Show Matrix, Protections, Options (4.3.5 — Options was a footer link).
- Safer-regions editor in popup at L3 only: TLD tags (× removes), Add, Default — no auto-add slider.
- Options page: online checks (explanations, DNS first/second), allow list, settings backup.

## Open
- Resolved 4.3.0: "paypa1.com" → "Looks like the brand site paypal.com" (unified look-alike check).
- Remote updates of the HaGeZi abused-TLD list (none; DS dropped its FilterDataLoader in 3.3.0).
- core/online-checks.js (sites) and DS DnsThreatProtection/RdapProtection (downloads) are two implementations of
  the same DoH/RDAP checks (one shared provider table since 4.3.0). Kept as two (user, 4.3.4, item 21); scoring
  and skip rule now the same (DS DomainAge, RDAP rule above).
