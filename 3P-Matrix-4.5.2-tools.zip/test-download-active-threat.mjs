#!/usr/bin/env node
// ── test-download-active-threat.mjs ─────────────────────────────────────────
// Unit test (4.5.1, C42) for core/download-guard.js's applyActiveThreatFloor() — the download-path
// sibling of test-site-scorer.mjs's active-threat cases, added after a real incident: the 4.5.0
// GitHub/GitLab campaign-host feature was wired into the SITE warning (core/site-scorer.js) and
// shipped, without ever checking whether the DOWNLOAD warning (core/download-guard.js) — the only
// other place in this codebase that scores a URL's host (C39a consumer inventory) — also needed it.
// It did: a direct download of a real malware link went completely unwarned.
//
// This test exercises ONLY applyActiveThreatFloor(), the pure function added for this — it is not a
// test of core/download-guard.js as a whole (chrome.downloads/alarms/windows are not mocked here;
// that module has no test coverage beyond this one function, before or after this change, and this
// file does not claim otherwise).
//
// Usage:  node test-download-active-threat.mjs --extension ../3P-Matrix
// Exit:   0 = all pass · 1 = a case failed · 2 = did not run (C38)
// ─────────────────────────────────────────────────────────────────────────────

import { existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

// ── Settings (one place) ─────────────────────────────────────────────────────
const EXIT = Object.freeze({ OK: 0, FAILED: 1, DID_NOT_RUN: 2 });

function arg(name) { const i = process.argv.indexOf(`--${name}`); return i === -1 ? null : process.argv[i + 1]; }
const ext = resolve(arg("extension") || join("..", "3P-Matrix"));
if (!existsSync(join(ext, "manifest.json"))) {
  console.error(`test-download-active-threat: DID NOT RUN — not an extension folder: ${ext}`);
  process.exit(EXIT.DID_NOT_RUN);
}
const load = (rel) => import(pathToFileURL(join(ext, rel)).href);
const { applyActiveThreatFloor } = await load("core/download-guard.js");
const { SCORE } = await load("data/constants.js");

let failed = 0;
function ok(name, cond, detail) {
  if (cond) console.log(`  PASS ${name}`);
  else { failed++; console.log(`  FAIL ${name}  ${detail ?? ""}`); }
}

// A stand-in for what BrowserProtection.checkHostReputation() would have returned before this
// function runs — only the fields applyActiveThreatFloor() actually reads/returns are given real
// values; the rest mirror the real shape loosely enough to catch a shape mismatch.
function dsResult(score, breakdown = []) {
  return { score, breakdown, classification: "unknown", label: "", hardRuleApplied: null };
}

// 1. A download not on the campaign list: DS's own result passes through completely unchanged.
{
  const input = dsResult(-5, [{ score: -5, label: "Hosted on a platform where anyone can publish", source: "RiskyHosting" }]);
  const out = applyActiveThreatFloor(input, "https://example.com/setup.exe");
  ok("non-campaign download: result object is untouched", out === input, JSON.stringify(out));
}

// 2. CDN host (no path-shape gate), delivery extension: floored to SCORE.ACTIVE_THREAT_HOST, entry added.
{
  const input = dsResult(-5, [{ score: -5, label: "platform", source: "RiskyHosting" }]);
  const out = applyActiveThreatFloor(input, "https://raw.githubusercontent.com/user/repo/main/payload.zip");
  ok("raw.githubusercontent.com .zip: score floored", out.score === SCORE.ACTIVE_THREAT_HOST, `got ${out.score}`);
  ok("raw.githubusercontent.com .zip: breakdown carries the ActiveThreatHost entry",
     out.breakdown.some((e) => e.source === "ActiveThreatHost"), JSON.stringify(out.breakdown));
}

// 3. CDN host, non-delivery extension: no match, result unchanged.
{
  const input = dsResult(-5, [{ score: -5, label: "platform", source: "RiskyHosting" }]);
  const out = applyActiveThreatFloor(input, "https://raw.githubusercontent.com/user/repo/main/README.md");
  ok("raw.githubusercontent.com README: untouched", out === input, JSON.stringify(out));
}

// 4. github.com /releases/download/ + ext: floored, same as the site-visit case.
{
  const input = dsResult(-5, [{ score: -5, label: "platform", source: "RiskyHosting" }]);
  const out = applyActiveThreatFloor(input, "https://github.com/user/repo/releases/download/v1/tool.exe");
  ok("github.com releases/download .exe: score floored", out.score === SCORE.ACTIVE_THREAT_HOST, `got ${out.score}`);
}

// 5. github.com /archive/refs/heads/ ("Download ZIP"), SOLE signal: disclaimer present, explained:true
//    (required by ui/download-warning.js's own rendering rule — a score-0 row with no `explained`
//    flag is silently dropped there, unlike ui/warning.js which shows every row regardless of score).
{
  const input = dsResult(0, []);
  const out = applyActiveThreatFloor(input, "https://github.com/user/repo/archive/refs/heads/main.zip");
  const note = out.breakdown.find((e) => e.source === "ActiveThreatHostNote");
  ok("Download ZIP, sole signal: disclaimer entry present and explained:true",
     !!note && note.explained === true && note.score === 0, JSON.stringify(out.breakdown));
}

// 6. Same shape, but DS already found another negative signal (riskyHosting pre-existing on this
//    host is normal for these hosts): disclaimer suppressed, exactly like the site-visit case.
{
  const input = dsResult(-5, [{ score: -5, label: "Hosted on a platform where anyone can publish", source: "RiskyHosting" }]);
  const out = applyActiveThreatFloor(input, "https://github.com/user/repo/archive/refs/heads/main.zip");
  ok("Download ZIP, corroborated by another signal: disclaimer suppressed",
     out.score === SCORE.ACTIVE_THREAT_HOST && !out.breakdown.some((e) => e.source === "ActiveThreatHostNote"),
     JSON.stringify(out.breakdown));
}

// 7. gitlab.com -/raw/ + ext: floored.
{
  const input = dsResult(-15, [{ score: -15, label: "platform", source: "RiskyHosting" }]);
  const out = applyActiveThreatFloor(input, "https://gitlab.com/user/repo/-/raw/main/payload.exe");
  ok("gitlab.com -/raw/ .exe: score floored", out.score === SCORE.ACTIVE_THREAT_HOST, `got ${out.score}`);
}

// 8. The floor never RAISES a worse (more negative) DS score — e.g. a VT-confirmed-malicious host
//    result that was already below SCORE.ACTIVE_THREAT_HOST stays at its own, worse score.
{
  const worse = SCORE.ACTIVE_THREAT_HOST - 20;
  const input = dsResult(worse, [{ score: worse, label: "already worse", source: "RiskyHosting" }]);
  const out = applyActiveThreatFloor(input, "https://github.com/user/repo/releases/download/v1/tool.exe");
  ok("floor never raises an already-worse score", out.score === worse, `got ${out.score}`);
}

console.log(failed ? `test-download-active-threat: ${failed} FAILED` : "test-download-active-threat: all passed");
process.exit(failed ? EXIT.FAILED : EXIT.OK);
