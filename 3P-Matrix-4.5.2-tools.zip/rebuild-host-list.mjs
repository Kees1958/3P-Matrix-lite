#!/usr/bin/env node
// ── tools/rebuild-host-list.mjs ──────────────────────────────────────────────────
// Rebuilds lib/downloadsentinel/util/HostList.default.js — the merged, deduplicated host-risk table
// (HaGeZi DynDNS + HaGeZi Badware Hoster + Kees1958 "Suspicious websites") that feeds both
// core/site-scorer.js's site-visit check and core/download-guard.js's download check.
//
// 4.5.1 audit gap (C39a/C27): this list WAS registered in data-sources.json but had never actually
// been rebuilt by anything in THIS project's tools — the only script that did it,
// DownloadSentinel's own tools/update-lists.mjs, hardcodes an EXT_ROOT = REPO_ROOT/EXTENSION
// sibling-folder layout (its own standalone repo's shape) that matches neither the DS tools artifact
// itself (no EXTENSION/ tree ships in it) nor 3P-Matrix's real layout (lib/downloadsentinel/{util,...}).
// Per the user's explicit "don't touch DS" instruction, that script is left exactly as it is — this is
// a NEW, independent script, native to this project, that ports its merge logic (C21: same method,
// not reinvented) against 3P-Matrix's own files and own import paths.
//
// Method (ported from DownloadSentinel tools/update-lists.mjs, same scores/sources):
//   1. Read the three raw lists (cached under tools/lists-raw/, or re-fetch with --fetch).
//   2. Drop any domain already covered by this extension's OWN hand-curated modules
//      (lib/downloadsentinel/util/SuspiciousDomains.js, RiskyHostingSites.js) — "existing entries win
//      on overlap, no double counting" (same rule DS's own tool applies).
//   3. Union the rest; on a cross-list collision keep the worst (highest) score, combine source tags.
//   4. Write lib/downloadsentinel/util/HostList.default.js in the exact generated-file shape the
//      runtime module (HostList.js) already expects — byte-identical shape to a DS-tool rebuild.
//   5. Record the rebuild in data-sources.json (same convention as update-top-sites.mjs).
//
// Usage:  node rebuild-host-list.mjs [--extension ../3P-Matrix] [--fetch]
//         Without --fetch, reads the cached raw files in tools/lists-raw/ (seeded once from the
//         DownloadSentinel tools zip's own cache — see lists-raw/README.md).
// Exit:   0 = written · 1 = refused (sanity guard) · 2 = did not run (download/parse/folder)
// ─────────────────────────────────────────────────────────────────────────────

import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { join, resolve, dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

// ── Settings (one place) ─────────────────────────────────────────────────────
const HERE = dirname(fileURLToPath(import.meta.url));
const EXIT = Object.freeze({ OK: 0, REFUSED: 1, DID_NOT_RUN: 2 });
const LIST_ID = "host-list";
const REGISTER_FILE = join(HERE, "data-sources.json");
const DEFAULT_EXTENSION = join(HERE, "..", "3P-Matrix");
const LIB_UTIL = join("lib", "downloadsentinel", "util");
const RAW_DIR = join(HERE, "lists-raw");
const JSON_INDENT = 2;
const VERSION_MINOR_RE = /^(\d+\.\d+)/;
const MIN_PER_LIST = 50;                             // guard: refuse a truncated/format-changed download

// Per-list source + base score — identical to DownloadSentinel tools/update-lists.mjs's SOURCES.
const SOURCES = Object.freeze({
  HAGEZI_DYNDNS:   { url: "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/dyndns-onlydomains.txt",
                      rawFile: "hagezi-dyndns.txt", tag: "HaGeZi-DynDNS", score: 60 },
  HAGEZI_HOSTER:   { url: "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/hoster-onlydomains.txt",
                      rawFile: "hagezi-hoster.txt", tag: "HaGeZi-Hoster", score: 65 },
  KEES_SUSPICIOUS: { url: "https://raw.githubusercontent.com/Kees1958/W3C_annual_most_used_survey_blocklist/refs/heads/master/Suspicious%20websites.txt",
                      rawFile: "kees-suspicious.txt", tag: "Kees-Suspicious", score: 50 },
});
const KEES_RULE_RE = /^\|\|([a-z0-9.-]+)\^\$script,subdocument,websocket,third-party$/i;

function didNotRun(msg) { console.error(`rebuild-host-list: DID NOT RUN — ${msg}`); process.exit(EXIT.DID_NOT_RUN); }
function refuse(msg) { console.error(`rebuild-host-list: REFUSED — ${msg}`); process.exit(EXIT.REFUSED); }
function arg(name) { const i = process.argv.indexOf(`--${name}`); return i === -1 ? null : process.argv[i + 1]; }
const SHOULD_FETCH = process.argv.includes("--fetch");

function parseHageziOnlyDomains(text) {
  const domains = [];
  for (const rawLine of text.split("\n")) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    domains.push(line.toLowerCase());
  }
  return domains;
}

function parseKeesSuspicious(text) {
  const domains = [];
  for (const rawLine of text.split("\n")) {
    const line = rawLine.trim();
    if (!line || line.startsWith("!") || line.startsWith("[")) continue;
    const m = KEES_RULE_RE.exec(line);
    if (m) domains.push(m[1].toLowerCase());
  }
  return domains;
}

async function readRaw(source) {
  const dest = join(RAW_DIR, source.rawFile);
  if (SHOULD_FETCH) {
    try {
      const res = await fetch(source.url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      if (text.length < 500) throw new Error(`implausibly small (${text.length} bytes)`);
      mkdirSync(RAW_DIR, { recursive: true });
      writeFileSync(dest, text, "utf8");
      return text;
    } catch (e) { didNotRun(`${source.tag}: fetch failed (${e.message})`); }
  }
  if (!existsSync(dest)) didNotRun(`${source.tag}: no cached raw file at ${dest} — run with --fetch, or seed lists-raw/ from the DS tools zip cache`);
  const text = readFileSync(dest, "utf8");
  if (text.length < 500) didNotRun(`${source.tag}: cached raw file implausibly small (${text.length} bytes)`);
  return text;
}

function buildMergedList(listResults, isAlreadyCovered) {
  const merged = new Map();
  const stats = {};
  for (const { sourceKey, domains } of listResults) {
    const source = SOURCES[sourceKey];
    let newCount = 0, coveredCount = 0;
    for (const domain of domains) {
      if (isAlreadyCovered(domain)) { coveredCount++; continue; }
      newCount++;
      const existing = merged.get(domain);
      if (!existing) merged.set(domain, { score: source.score, sources: new Set([source.tag]) });
      else { existing.sources.add(source.tag); existing.score = Math.max(existing.score, source.score); }
    }
    stats[sourceKey] = { total: domains.length, new: newCount, alreadyCovered: coveredCount };
  }
  return { merged, stats };
}

function render(data, meta) {
  const entries = [...data.entries()].sort(([a], [b]) => a.localeCompare(b));
  const obj = {};
  for (const [domain, { score, sources }] of entries) obj[domain] = { score, source: [...sources].sort().join("+") };
  return `"use strict";

/**
 * HostList.default.js — GENERATED FILE. Do not hand-edit; rebuild with
 * 3P-Matrix-tools/rebuild-host-list.mjs (once per minor release — data-sources.json).
 *
 * Merged, deduplicated host-risk table: HaGeZi DynDNS + HaGeZi Badware Hoster + Kees1958
 * "Suspicious websites" (risk score only, never a block). Entries already covered by this
 * extension's own SuspiciousDomains.js / RiskyHostingSites.js are excluded (those modules already
 * score them, usually with more nuance — no double counting).
 * Content: ${entries.length} distinct domains.
 * Generated: ${meta.generatedAt}
 */
export const HostListDefault = ${JSON.stringify(obj, null, 4)};
`;
}

async function main() {
  const ext = resolve(arg("extension") || DEFAULT_EXTENSION);
  if (!existsSync(join(ext, "manifest.json"))) didNotRun(`not an extension folder: ${ext}`);
  let registerFile;
  try { registerFile = JSON.parse(readFileSync(REGISTER_FILE, "utf8")); } catch (e) { didNotRun(`cannot read ${REGISTER_FILE}: ${e.message}`); }
  const register = registerFile.lists && registerFile.lists[LIST_ID];
  if (!register) didNotRun(`no "${LIST_ID}" entry in data-sources.json`);

  let SuspiciousDomains, RiskyHostingSites;
  try {
    ({ SuspiciousDomains } = await import(pathToFileURL(join(ext, LIB_UTIL, "SuspiciousDomains.js")).href));
    ({ RiskyHostingSites } = await import(pathToFileURL(join(ext, LIB_UTIL, "RiskyHostingSites.js")).href));
  } catch (e) { didNotRun(`cannot import the extension's SuspiciousDomains/RiskyHostingSites: ${e.message}`); }

  const isAlreadyCovered = (domain) => SuspiciousDomains.lookup(domain) !== null || RiskyHostingSites.lookup(domain) !== null;

  const dyndnsText = await readRaw(SOURCES.HAGEZI_DYNDNS);
  const hosterText = await readRaw(SOURCES.HAGEZI_HOSTER);
  const keesText   = await readRaw(SOURCES.KEES_SUSPICIOUS);

  const dyndnsDomains = parseHageziOnlyDomains(dyndnsText);
  const hosterDomains = parseHageziOnlyDomains(hosterText);
  const keesDomains   = parseKeesSuspicious(keesText);

  for (const [name, domains] of [["HaGeZi-DynDNS", dyndnsDomains], ["HaGeZi-Hoster", hosterDomains], ["Kees-Suspicious", keesDomains]]) {
    if (domains.length < MIN_PER_LIST) refuse(`${name}: parsed only ${domains.length} domains — expected hundreds+ (format may have changed upstream)`);
  }

  const { merged, stats } = buildMergedList([
    { sourceKey: "HAGEZI_DYNDNS",   domains: dyndnsDomains },
    { sourceKey: "HAGEZI_HOSTER",   domains: hosterDomains },
    { sourceKey: "KEES_SUSPICIOUS", domains: keesDomains },
  ], isAlreadyCovered);

  for (const [key, s] of Object.entries(stats)) {
    console.log(`  ${SOURCES[key].tag.padEnd(16)} ${s.total} total  →  ${s.alreadyCovered} already covered  →  ${s.new} new`);
  }
  console.log(`  UNION (deduplicated)   ${merged.size}`);

  const generatedAt = new Date().toISOString();
  const target = join(ext, register.file);
  writeFileSync(target, render(merged, { generatedAt }));

  const manifest = JSON.parse(readFileSync(join(ext, "manifest.json"), "utf8"));
  const versionMinor = (VERSION_MINOR_RE.exec(manifest.version) || [])[1] || manifest.version;
  const previous = { entries: register.entries };
  Object.assign(register, {
    sourceRelease: `merge generated ${generatedAt.slice(0, 10)}`,
    entries: merged.size,
    updatedForVersion: versionMinor,
    updatedAt: generatedAt.slice(0, 10),
    tool: "rebuild-host-list.mjs",
  });
  writeFileSync(REGISTER_FILE, JSON.stringify(registerFile, null, JSON_INDENT) + "\n");

  console.log(`\nrebuild-host-list: wrote ${register.file} — ${merged.size} domains (was ${previous.entries}), recorded for ${versionMinor}`);
  process.exit(EXIT.OK);
}

await main();
