# Changelog — 3P Matrix — content firewall

Short, per-release summary of what changed, without implementation detail. Lives in the docs package only
(as in uBlock Stripped Dynamic since 10.1.4). The full technical account is CHANGELOG_HISTORY.md.

## 4.4.9
- **Site warning (protection 11) now flags GitHub's raw-content/release-asset/codeload hosts as an active
  threat, not just a generic "open platform".** Prompted by a live SmartLoader malware campaign distributing
  .zip payloads from throwaway GitHub repos via raw.githubusercontent.com, release-assets.githubusercontent.com,
  codeload.github.com, objects.githubusercontent.com and media.githubusercontent.com (observed via
  urlhaus.abuse.ch). These hosts were already scored as "anyone can publish here" (too weak alone to open the
  warning dialog, by design); now they also carry a stronger, dedicated score that opens the dialog on its own
  at protection levels Medium and up (not Mild, which still needs a second signal).
  - Kept out of the shared DownloadSentinel library on purpose (that code is reused unchanged) — a short,
    reviewable, 3P-Matrix-only list (data/active-threat-hosts.js) instead.
  - Plain github.com is NOT on the list (too broad; the file-serving hosts above are what the payload actually
    comes from).
- No other behaviour changed.

## 4.4.8
- **Suspicious-hosting list (protection 6, DDNS/free-hosting) refreshed from upstream.** Kees1958's
  "Suspicious websites" list moved to v2027.3 and was pruned from 1616 to 561 domains; we now ship exactly
  that list instead of the older, larger snapshot.
  - Upstream also added an explicit "excluded on purpose" section for domains that are too widely used as
    legitimate third-party embeds to block safely (sites.google.com, firebaseapp.com, herokuapp.com,
    workers.dev, blob.core.windows.net, web.core.windows.net, backblazeb2.com, r2.dev). None of these were
    in our list before, so nothing changes in practice — this just confirms the list stays safe.
  - The `byethost*` regex rule is unchanged (matches upstream's regex rule verbatim).
- No other behaviour changed.

## 4.4.7
- **Built-in whitelist extended (about 135 hosts), after a category-by-category review of a user whitelist.**
  - Payment, card networks, 3-D Secure, buy-now-pay-later and billing providers (e.g. Stripe, Square, Braintree,
    Adyen-family, Visa, Mastercard, Chargebee, Paddle) — script and frame, and they count as payment hosts.
  - Fraud prevention, bot protection, CAPTCHA and sign-in (e.g. DataDome, HUMAN/PerimeterX, Fingerprint, Descope,
    Stytch, Aliyun CAPTCHA, Microsoft msauth/msftauth) — script and frame.
  - Video and audio players (Plyr, Fluid Player, Video.js, Flowplayer, Captivate, Reddit embed …) — script and frame.
  - Platform vendor asset hosts, **script only and never the main domain**: aspnetcdn.com, gfx.ms, office.net,
    awsstatic.com, cdn-apple.com, githubassets.com, dropboxstatic.com.
  - Curated libraries, **script only**: cdnjs, Bootstrap, Font Awesome, DataTables, Plotly, d3, three.js, Tailwind, Typekit, Material Design Icons.
- **Left out on purpose:** broad domains (google.com, microsoft.com, apple.com, icloud.com, yahoo.com, outlook.com),
  destination-only streaming, retail, news and Asian-platform hosts, SaaS/marketing widgets, ad-tech, open or
  self-service hosts (jsdelivr, unpkg, esm.sh, cloudfront …) and community mirrors such as cdn.bootcss.com
  (named in the 2024 polyfill.io attack).
- No other behaviour changed.

## 4.4.6
- **One button scheme in all three warning windows — colour follows the risk, and risk rises left to
  right.** Green = the safe choice, dark grey with bright yellow bold text = careful (this visit only),
  solid orange = you accept the risk / it is permanent. **Every button now has exactly the same size**
  (176 × 44 px) in all three windows.
  - **Site warning:** **Go back** green · **Continue once** dark grey + yellow · **Trust this site** orange
    (it used to be green, and Go back yellow).
  - **Download warning:** **Check download at VT** green, now first and the default · **Proceed anyway** orange.
  - **Blocked-download notice:** **OK, cancel** green (was "OK") · **Download anyway** orange.
- The default button no longer shows a focus ring on load (it made the green button look bigger); the ring
  appears once you press Tab or an arrow key. Enter still works on the default button.
- `THIRD_PARTY_LICENSES.md` completed: the three newer obfuscation scripts (4.4.3), the suspicious-hosting list and the built-in
  whitelist now name their sources. No new third-party code in 4.4.5 / 4.4.6. The copyright line (Kees1958 and
  co-authors) is now stated in `THIRD_PARTY_LICENSES.md` and the README; the tools and docs packages carry a `NOTICE.md`.
- No behaviour changed.

## 4.4.5
- **Fixed: a site lock now holds for everything the locked page loads, including embedded frames.**
  Word Online on SharePoint stayed on its loading screen even with the site locked at level 1: the
  editor lives in a frame from another site (officeapps.live.com) and its requests were judged by the
  *session* level, not the lock. The toolbar badge counted 26 blocks while the popup said "No requests
  blocked".
  - **Level 1 lock:** the whole page, frames included, is allowed outright — whatever the session level is.
  - **Level 2–5 lock:** the lock's level now applies to the whole tab (frames included), also when the
    session level is higher *or* lower. It follows the tab: navigating away, unlocking or closing the tab
    ends it.
- **The popup always shows the real number of blocked requests** (it used to say "No requests blocked"
  at level 1 whatever happened).
- **Locks on shared hosts are per tenant.** `hogeschooltio-my.sharepoint.com` is now its own site, so a
  lock (or allow-list entry) no longer opens every other organisation's SharePoint. A lock on plain
  `sharepoint.com` is carried over, on upgrade, to the SharePoint hosts you have open in tabs at that moment
  (same level); for a tenant that isn't open, lock its host again when you next need it.
- Known limits: requests that start in the few milliseconds before a tab is recognised, and requests
  without a tab (a site's own service worker), still follow the session level.

## 4.4.4
- **New setting: "Silent when inconclusive"** (Download protection, just above "Silent when
  probably safe") — **off by default.** It splits out the staged, false-positive-reduction-based
  quiet behaviour added in 4.4.1: when a download is neither clearly safe (auto-allow) nor clearly
  risky (an exception), it used to stay quiet below the false-positive setting's threshold. Now
  that staying-quiet behaviour only happens when you turn this on; off (the default), every such
  download gets a warning window, whatever its score — matching how downloads worked before 4.4.1.
  "Silent when probably safe" and the exceptions that always warn are unaffected either way.

## 4.4.3
- **Three new protections, siblings of the "block obfuscated eval()" detector** — and the
  obfuscation-style protections now sit together, so three existing display numbers move (keys
  unchanged, your ticks carry over):
  - **18 — Block obfuscated Function() code generation.** `Function()` / `new Function()` calls whose
    body looks like real obfuscation (a packed bootstrap, a long base64 blob, a char-code array, or
    enough renamed `_0x..` identifiers). `new Function("a", "b", "return a + b")` is never flagged —
    dynamic code generation alone proves nothing.
  - **19 — Block obfuscated setTimeout() string execution** and **20 — …setInterval() string
    execution.** The browser runs a STRING first argument as code, same as `eval()`; these block that
    string only when it matches the same obfuscation shapes. A function reference, or an ordinary
    non-obfuscated string, is never touched — `setTimeout(() => refresh(), 1000)` and
    `setInterval(checkStatus, 5000)` pass through unaffected.
  - Same scope and level as the eval() detector (outside safer regions, from Medium) — not a blanket
    block like protection 9's fixed-host-list eval/timer block on known high-risk sites.
  - Old saved states have no entry for any of the three, so they start ticked.
  - **Renumbered (your request):** "Block redirects and dialogs from frames" 17 → **16**, "Block
    obfuscated or disguised eval() calls" 16 → **17** (the two sit together with the three new ones
    now, 16–20), and "Block risky downloads" 18 → **21** (moves to the end).

## 4.4.2
- **The settings backup now contains your VirusTotal key**, so a restore gives a working setup on another
  computer. Keep the backup file private — it is plain text and now holds a secret. Restoring an older file,
  or one saved before you entered a key, leaves the key in this browser untouched.
- **Fixed: a VirusTotal key typed in Options was lost** when you pressed the Save button of the Downloads card
  instead of the key's own Save — the field was cleared without a word. That Save now saves the key as well,
  and an invalid key is reported instead of silently dropped.
- **Fewer interruptions, but never for the dangerous cases.** Warnings are now staged:
  - **Sites:** the dialog opens from score −45 at level 2, −30 at level 3 (as before), −20 at level 4, −15 at
    level 5. Below that line a suspicious site gets the orange badge only. An imitation of a brand or popular site
    (also a brand name on vercel.app, github.io, …) always gets the dialog, at every level.
  - **Downloads:** the warning window opens from score −45 (false-positive setting High), −30 (Medium), −15 (Low),
    always (None). It always opens, whatever the score, when VirusTotal or a DNS check flags it, it imitates a brand,
    the file itself looks deceptive or is a script, the link came from a chat or webmail, or the domain is very new.
    Ordinary vendor downloads (CCleaner, Firefox, VLC mirrors, …) no longer interrupt at Medium.
- Downloads now also recognise a brand name on an open platform (e.g. a file from `paypal-login.vercel.app`).
- Options explain the new lines (derived from the settings, so the text always matches).
- Built on DownloadSentinel 3.5.2.

## 4.4.0
- **Download check (protection 12) — built on DownloadSentinel 3.5.1**, so it gets everything new there:
  - **Files that hide what they are are checked:** a download with no extension anywhere that the server only
    calls "binary data" now always opens the warning window (e.g. a malware sample on Discord's file servers
    that slipped through). Protection 18 never *blocks* these — legitimate Linux programs look the same.
  - **Downloads are judged as a whole journey.** Ordinary vendor deliveries (Microsoft, Mozilla, Google,
    CCleaner/Avast, Steam, Discord's app, Brave, …) no longer count against a file for an unrelated referring
    page, a link without extension, a short link or a chat link — they are listed in grey as "normal for …".
    Several small oddities together now add up (two on file-sharing sites). New signal: "link opened from a
    chat or webmail page".
  - **Signal weights reviewed:** fewer false alarms for vendor links and HTTP mirrors; a file whose name and type
    disagree (`invoice.pdf` that is a program) is flagged; nine correctly served file types (`.deb`, `.apk`,
    `.xpi`, `.sh`, …) are no longer a false "type mismatch".
  - The false-positive setting now changes how the check reasons; "High" no longer halves every signal.
  - Warning window: dashes in messages are no longer dropped.
- **Site warning (protection 11): fewer false alarms on developer hosting.** An ordinary site on vercel.app,
  github.io, netlify.app, pages.dev, workers.dev, web.app, … no longer gets "This site needs your attention" just
  for being there (was −52, now −26). A brand name on such a platform (`paypal-login.vercel.app`,
  `microsoft-support.github.io`) is now its own warning signal (−69, phishing). Dynamic-DNS hosts (duckdns.org,
  ddns.net, …) are unchanged. The site check now uses the same, reviewed weights as the download check.
- Tools: a Manifest V3 compliance check (same file as DownloadSentinel's), and list rules that
  declarativeNetRequest cannot express are dropped on purpose and counted — an unknown rule shape stops the build.
- Minor release: the bundled lists were rebuilt — hosting platforms (Public Suffix List of 2026-10-25),
  country codes for domain age (IANA, `.sc` added), top sites (Chrome UX Report 202609, still the newest).
- A page and a download host of the same company are no longer called "unrelated" (discord.com →
  cdn.discordapp.com, github.com → githubusercontent.com, …). New combination "file on a file-sharing platform +
  link opened from a chat or webmail" (a Discord `Nitro_Generator.exe` from a chat: −35, suspicious).
- Warning window: the reputation box always gives the verdict with the count ("2 heuristic risk signals detected —
  probably suspicious").

## 4.3.7
- **Two new DNS checks: DNS4EU Protective and CleanBrowsing Security** (free, malware and phishing only) — choose
  two of five. DNS4EU also blocks sites a court ordered blocked.
- **In France the default DNS checks are now Control D + Cloudflare** (was Quad9 + Cloudflare). A saved choice is
  never changed.
- Options: shorter DNS text.
- Built on DownloadSentinel 3.3.1.

## 4.3.6
- **claude.ai is no longer on the built-in whitelist** — it is a normal site again (its downloads are checked,
  and protections apply as on any site). To skip checks for its downloads, add claude.ai to your trusted
  download domains in Options. The popup line now reads "Trusted: payment, sign-in, streaming, meetings, games".
- Options: "Trust AI downloads" removed again.

## 4.3.5
- **Options is now a button** in the popup, next to Show Matrix and Protections (order: Show Matrix,
  Protections, Options) — users missed the small link at the bottom. The popup is a little wider (440 px).

## 4.3.4
- **Built on DownloadSentinel 3.3.0** (was 3.2.0) — the shared library is now exactly DownloadSentinel's own.
- **Domain age:** a registry that answers without a registration date now counts as a recent domain (−10);
  no domain-age service, or a failed lookup, still counts as nothing. The lookup gives up after 3 s (was 4 s).
- **Options → Trusted downloads:** two choices, "Trust app stores" (always on) and "Trust AI downloads"
  (claude.ai, ChatGPT, Copilot, Gemini — off by default). Your own trusted domains and allow list still count.
- Trusted downloads also work for files without a web address of their own (data: files): the page they came
  from decides.
- **Download warning:** without a VirusTotal key the VirusTotal box says "Reputation lookup at VirusTotal
  skipped" with a link to request a free key. A VirusTotal answer that arrives late updates the open warning
  page; the warning only reopens when that answer makes it worse.
- The download settings in Options can be changed without a VirusTotal key.
- The look-alike check no longer flags government sites (.gov and similar).
- DNS check: an answer with only an alias (CNAME) counts as an answer.
- Removed: the remote list refresh (DownloadSentinel dropped it); the bundled lists are used.

## 4.3.3
- **Trusted download domains now work for files a site makes itself** (claude.ai, web apps: addresses that
  start with "blob:"). Before, such a file was always checked, even with its site on your trusted list.
- Such files no longer get a false "file type was hidden at download start" warning.
- The download check now skips sites on the built-in whitelist, like the site warning does.
- claude.ai is on the built-in whitelist (new group "AI assistants").

## 4.3.2
- **New protection 18, "Block risky downloads (programs, scripts, archives)" — off by default.** When you tick
  it: at level 3 such downloads are blocked from sites outside your safer regions, at levels 4 and 5 from every
  site. At level 3, pages on the built-in whitelist and files from your trusted download domains are not
  blocked; at levels 4 and 5 there is no exception. A small notice says what was blocked; "Download anyway" downloads it once more and then always checks it
  (protection 12). Documents, PDFs and images are never blocked.
- **Protections 10 and 11 swapped:** the abused-TLD block is now 10 and "Warn when opening a site that looks
  suspicious" is 11, so the two warnings sit together (11 and 12). Your ticks carry over.
- Protection 17 now fits on one line: "Block redirects and dialogs from frames".
- Download warning page is more compact (narrower card, tighter spacing, smaller title and buttons).
- Its intro text is shorter, and the two closing lines ("This is what VirusTotal knows …" and
  "This is protection 12 …") are gone. The hints for "no VirusTotal key" and "unknown to VirusTotal" stay.

## 4.3.0
- **New: download protection (protection 12, "Warn when a downloaded file looks risky")** — everything
  DownloadSentinel 3.2.0 does, built in. When a finished download is a program, script or archive, its
  address and host are checked and a warning page shows the results. Options has DownloadSentinel's settings:
  VirusTotal API key, "Silent when probably safe", false-positive reduction, trusted download domains and the
  warning page's colour and title. Without a VirusTotal key you are reminded once per browser start (can be
  switched off). Downloads from a site on your allow list get no warning.
- **Behaviour you will see:** Chrome asks you to approve the new "Manage your downloads" permission and keeps
  3P Matrix switched off until you do (chrome://extensions).
- **Protections renumbered:** the new protection is 12 in the "on every site" group; the level-3 group is now
  13–17 (was 12–16). Your ticked/unticked choices carry over.
- **Look-alike sites are recognised better:** one look-alike check replaces three — "paypa1.com" now says
  "Looks like the brand site paypal.com". Popular sites themselves are never flagged, and a brand name inside
  another word ("ungoogled") no longer counts as impersonation.
- Site warning dialog: the title now reads "This site needs your attention", the button "Go back", and
  "Known suspicious domain" is now "Domain has been misused in the past".
- **Domain age is no longer looked up where it cannot exist:** for sites on hosting platforms (github.io,
  blogspot.com, pages.dev …) and for country codes whose registry publishes no age (.de, .it, .es, .ch, .jp …).
  The warning says "Domain age not applicable / not published" instead of an error, and downloads from such
  sites no longer count it against them.
- Settings backups include the download settings, but never your VirusTotal key; restoring keeps the key you have.

## 4.2.3
- **Show Matrix overrides are always global now, as in uMatrix and 3P-Matrix-lite.** Old site-only
  overrides (saved by 0.2.0–0.2.5) are turned into normal global overrides when you update or restore a
  backup. **Behaviour you will see:** such an override now applies on every site, not only on the site
  where you once set it — and clicking it in Show Matrix undoes it again (before, the click did nothing).
- **Popup counts are always right:** at level 3 the "(N outside safer regions)" count now follows your
  ticked protections (e.g. "4 of 5" when you untick one) instead of always saying 5. Every level and
  protection number shown in the popup, Show Matrix, warning dialog and options page now follows the
  settings automatically.
- Up to 500 sites can be locked or on the allow list (was 400).
- Messages the protections write to the browser console now say "[3PMCF]" (3P Matrix) instead of
  uBlock names, and the ClickFix message points to the 3P Matrix allow list instead of a `$worryfree`
  rule that does nothing here.
- Protection 10 is now called **"Warn when opening a site that looks suspicious"** (was "before"):
  the warning appears as the site starts to open, before you can use it.
- Internal clean-up of the background script — no visible change.
- **When something can't be saved, you now see why** — in a short status line in the popup, the options page,
  the Show Matrix panel and the warning dialog (before, it only went to the browser console). Adding an invalid
  TLD in the safer-regions editor says so instead of silently doing nothing.
- A protection script could run twice on a site that is both in your safer regions and on the built-in
  whitelist while locked at level 5 — now once.
- The extension package now includes its licence (GPLv3) and the licences of the parts it uses.

## 4.2.2
- Show Matrix: larger status squares (✓ = allowed, ✕ = blocked) in every column; a totals line
  under the table; the explanation fits on 2 lines, with "rules apply on every site" in yellow.

## 4.2.1
- **Show Matrix uses the 3P-Matrix-lite layout and model again.** Columns: internal whitelist,
  level mode, image, media, stylesheet, SCRIPT, FRAME, fetch/xhr, other, requests. SCRIPT and FRAME
  show what the rules decide for that domain (green = allowed, red = blocked) — at level 4 every
  non-cdn script domain is red. Click a square to override it, click again to undo.
  "cdn" subdomains of non-cdn domains get their own row (level 4 treats them differently).
  The filter box is gone; Reload page and the "rules apply on every site" line stay.
- **Blocked-request count is more accurate**: requests from sandboxed or data: frames (common for
  ad scripts) are now counted as blocked by 3P Matrix when they are.
- Tools: `package-release-state.mjs` writes `package-release-state.json` (artifact hashes, versions,
  file counts, shipped permissions).

## 4.2.0
- **Abused-TLD block is now protection 11** — a normal checkbox, on by default (nothing changes unless
  you untick it). Its separate popup line is gone; it is counted in "N protections".
- **Protections renumbered** so each group is consecutive: 1–11 on every site, 12–16 outside safer
  regions (were 11–15). Your ticked/unticked choices carry over unchanged.
- **Levels 4 and 5 only block third-party scripts and frames** — never images, video, fonts or CSS.
  Level 4 still allows the built-in whitelist and "cdn" hosts; level 5 allows nothing.
- **Show Matrix: Script and Frame columns** replace 3P-code / 3P-all; each is set on its own. Buttons
  are larger (84×40). Older rules convert automatically: a 3P-code (or else 3P-all) rule sets both.
- **Trusted payment sites** (Stripe, PayPal, …) may register a real payment handler on their own site,
  at levels 3–4 only; protection 1 still blocks every other site.
- **Safer regions panel opens expanded**, so the TLD list is visible the moment the popup opens.
- **Level 5 name** now reads "Strict — no 3P scripts or frames".
- `fullvideosporn.com` added to protection 9's high-risk list (beyond the ported list).

## 4.1.1
- Dead-code cleanup: removed four unused pieces of data that nothing in the extension ever read
  (two unused identity strings, an unused page-path constant, an unused list-version string kept
  only as a duplicate of an existing comment). No behaviour change — nothing you can see is different.
- Show Matrix: the "Rules apply on every site…" help line is now bold and upper case, so it's hard
  to miss. The "Req." column header now reads "REQUESTS".

## 4.1.0
- **Renumbered from 0.2.5 to 4.1.0**, aligning this extension's version line with 3P-Matrix-lite's.
- **Show Matrix overrides (3P-code / 3P-all) are now global by default.** Setting one on a domain
  blocks/allows it on every site, not just the one you were looking at when you set it — matching how
  3P-Matrix-lite's equivalent feature always behaved. **Behaviour you will see:** an override you set
  while observing one site now also applies everywhere else; reload a page to see the effect, as before.
  A rule saved by an older version of this extension (site-specific) still works and still only applies
  to that one site — and always wins over a global rule for the same third party if both exist.

## 0.2.5
- Version bump only, packaging the 0.2.4 working-copy changes below that had not yet been zipped
  (safer-regions default fix, built-in whitelist, protection labels) as their own release.

## 0.2.4
- **Protection descriptions are clearer.** Each one now reads as a plain sentence ("Block sites from
  registering a fake payment handler") instead of a cryptic abbreviation ("Block payment-handler
  install"); a few now wrap to two lines instead of being cut off with "...".
- **The built-in-whitelist summary line is up to date** — it now mentions streaming, meetings and games,
  not just payment/sign-in/CAPTCHA, and still fits on one line.

- **Built-in whitelist: streaming, meeting and gaming apps with a real embeddable widget** are now
  trusted, same as payment and sign-in services already were: Spotify, SoundCloud, Deezer, Apple Music,
  Mixcloud; Zoom, Webex, Whereby, Microsoft Teams, Discord; Steam, itch.io. Services with no embeddable
  widget (Netflix, Disney+, Xbox, PlayStation, WhatsApp, Slack, Google Meet, …) are left out on purpose —
  they're never loaded as third-party content, so adding them would do nothing.
- **These trusted services are now also exempt from protections 9 and 11–15** (camera/mic, Bluetooth,
  obfuscated eval, frame redirects, …) when you visit them directly, not only as a third-party embed —
  at levels 3 and 4, same as the rest of the built-in whitelist. **Behaviour you will see:** if you were
  on, say, zoom.us or discord.com at level 4, camera/mic may have been blocked before; it no longer is,
  unless you've locked that site at level 5 yourself.

- **The suspicious-site warning is now protection 10** in the popup's Protections list ("Warn before opening
  suspicious sites"), so it can be switched off like any other protection. It stays on by default — nothing
  changes unless you untick it. Unticked, sites are no longer checked and no warning dialog appears.
  "On every site" now has 10 protections again; the level-3 protections are renumbered 11–15.
- **No more "Auto-add country codes" slider** in the level-3 safer-regions panel. The list is always built the
  same way as in uBlock Stripped Dynamic: common TLDs plus the country codes of your continent that speak your
  browser's languages. You can still add and remove TLDs, and Default undoes your edits. **Behaviour you will
  see:** if you had moved the slider away from Continent, your list switches to the Continent default after
  updating (your own added and removed TLDs are kept).
- With plain English in your Chrome languages, New Zealand (.nz) is now added too, so all Five Eyes
  countries (us, uk, ca, au, nz) are in your safer regions.
- Safer-regions panel: the explanation text now sits below the TLD list instead of above it, and the list no
  longer scrolls inside its own small box — every TLD is visible at once.
- Country codes on the HaGeZi abused-TLD list (today cf, cm, ga, gq, ml, ng, pw) are never added to the
  safer regions automatically — the same rule as for .biz, .shop, .store, .site and .online. You can still add
  one by hand.
- **No more redundant "Warnings for suspicious sites" bullet** in the popup summary — it was protection 10's
  own name shown twice (once as a bullet, once in the Protections list). The summary count ("N of 15
  protections active") already covers it, same as every other single protection.
- **Unticked protections stay readable:** no more strike-through or grey text, only the empty checkbox.

## 0.2.3
- **Two protections removed:** "Clear history at browser start" and "Block tracking pings" — keep using
  uBlock Stripped Dynamic for those. The remaining protections are renumbered 1–14, and the extension no
  longer asks for permission to clear your browsing history.

## 0.2.2
- **Safer regions now only matter at level 3.** Levels 4 and 5 apply all 16 protections on every site; the
  safer-regions TLD list is ignored there. **Behaviour you will see:** at level 4–5, sites on your own
  country's TLD (for example .nl) no longer get access to camera, microphone, Bluetooth/USB, motion
  sensors or NFC, and obfuscated scripts and frame redirects are blocked there too.
- The popup shows the safer-regions editor and the "in / outside safer regions" label at level 3 only. In
  the Protections list the second group is called "Extra — on every site" at level 4–5.
- Show Matrix closes itself when its 5 minutes are over (it used to stay open saying "stopped").
- Show Matrix help text: "Rules apply to this site only…" always starts on its own line.
- The old level 2 TLD blocklist (with its modes) is gone for good; the HaGeZi abused-TLD list is the only
  one. Nothing changes in what you see — the old list was already no longer used.

## 0.2.1
- **Save / restore settings** now includes your safer-regions settings and your Show Matrix rules. The
  backup file is readable, and the status line summarises what was saved or restored. Backups made with
  0.2.0 still restore.
- **Show Matrix layout:** the 3P-code and 3P-all buttons come right after the domain; seven fixed columns
  show which content types were seen — a mint square with a check when allowed, a red square with a cross
  when blocked by 3P Matrix.

## 0.2.0
- **Show Matrix** is available: see which third parties a page contacts, and block or allow their code
  (3P-code) or everything (3P-all) per site.
- The badge counts only requests blocked by 3P Matrix (not those blocked by other extensions).
- The Protections list opens only from its button; the Show Matrix button works.
- "Safe zone" is now called "safer regions" everywhere.
- Unpacked folders no longer carry the version number ("3P-Matrix", "3P-Matrix-tools").

## 0.1.1
- First prototype for testing: five levels with lock level and startup level (default 2), 16 selectable
  protections, the HaGeZi abused-TLD list from level 2, domain heuristics with online checks (domain age
  and two DNS threat-intelligence resolvers of your choice), warning dialog, allow list, settings backup.
