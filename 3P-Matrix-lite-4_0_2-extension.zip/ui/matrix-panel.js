// ── ui/matrix-panel.js ──────────────────────────────────────────────────────────
// Show Matrix panel UI.
// Renders the live table of third-party connections for one tab, plus:
//   - an informational Mode legend (explains the level's own default colors)
//   - the "Domain" column — plain text, not clickable (see below)
//   - the interactive Script/Frame cells — two INDEPENDENT allow/block
//     controls per domain (core/matrix-rules.js's setMatrixRule(), one call
//     per type), each toggled by clicking its own half
// plus a countdown clock (same MATRIX_DURATION as the SW side — see
// core/connection-matrix.js). No pause/resume, unlike monitor-panel.js.
//
// The tabId/host/level being observed are passed in the panel URL's query
// string (set by ui/popup.js when it opens this window).
//
// Communicates with the SW via chrome.runtime.sendMessage using MSG_* constants.
// ─────────────────────────────────────────────────────────────────────────────

import { MSG_GET_MATRIX_DATA, MSG_STOP_MATRIX, MSG_MATRIX_CLOSED, MSG_SET_MATRIX_RULE } from "../data/message-types.js";

const POLL_MS = 800;    // how often to fetch new entries from SW
const WARN_MS = 60000;  // turn timer yellow at 1 minute remaining

// Level-dependent text for the visible #filterNote line — ONE mechanism,
// same element/layout at every level (L1 through L5); only the text
// differs. Declared once here as the single source of truth.
const FILTER_NOTE_L1     = "Showing domains allowed by 3P-Matrix-lite";
const FILTER_NOTE_L2     = "Filtering domains, whitelists are automatically applied to lower website breakage.";
const FILTER_NOTE_L3_L5  = 'Showing domains allowed by 3P-Matrix-lite, (sub)domains needed for "login with" (e.g. Google) are shown in yellow (and allowed), block them manually.';

// ── Guarded module state — initialised empty, cleared/released explicitly ────
let _pollInterval  = null; // setInterval handle for live data polling
let _clockInterval = null; // setInterval handle for the countdown display
let _clockStarted  = false; // guard: only start the clock once, from the first poll response
let _isStopped     = false;
const _tabId  = _readIntParam("tabId");
const _host   = _readStringParam("host", "—");
const _level  = _readIntParam("level") || 1;

// ── Panel branding color — reflects the ACTUAL protection level now, ────────
// instead of a fixed cyan. Same hex values as popup.js's LEVELS array /
// matrix-panel.html's --lvl1-green.. --lvl5-red tokens. Applied once at init
// via a CSS custom property (--level-color) rather than hardcoded per
// element, so every branding element (title, timer, Close button, filter
// focus ring) stays in sync from one place.
const LEVEL_BRAND_COLOR = {
  1: "var(--lvl1-green)",
  2: "var(--lvl2-blue)",
  3: "var(--lvl3-yellow)",
  4: "var(--lvl4-orange)",
  5: "var(--lvl5-red)"
};

// ── URL param helpers ─────────────────────────────────────────────────────────

function _readIntParam(name) {
  const params = new URLSearchParams(window.location.search);
  const raw = params.get(name);
  const n = raw ? parseInt(raw, 10) : NaN;
  return isNaN(n) ? null : n;
}

function _readStringParam(name, fallback) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name) || fallback;
}

// ── Messaging helper ──────────────────────────────────────────────────────────

function send(msg, cb) {
  try {
    chrome.runtime.sendMessage(msg, function(resp) {
      if (chrome.runtime.lastError) { if (cb) cb(null); return; }
      if (cb) cb(resp);
    });
  } catch(e) {
    if (cb) cb(null);
  }
}

// ── DOM refs ──────────────────────────────────────────────────────────────────

const elHost       = document.getElementById("panelHost");
const elBtnClose    = document.getElementById("btnClose");
const elThead       = document.getElementById("matrixThead");
const elEntryBody   = document.getElementById("entryBody");
const elEmptyState  = document.getElementById("emptyState");
const elTimer       = document.getElementById("timerDisplay");
const elTimerIcon   = document.getElementById("timerIcon");
const elStats       = document.getElementById("panelStats");
const elFilterNote  = document.getElementById("filterNote");

// ── Rendering state ────────────────────────────────────────────────────────────
let _lastEntries = [];

// ── Column model ──────────────────────────────────────────────────────────────
// Groups, not a flat list — each group has 1 sub-column (rendered as a single
// rowspan=2 header cell) or 2 sub-columns (rendered as a colspan=2 group
// header + two Allow/Block sub-headers below it). flattenGroups() derives the
// flat per-cell list every row uses, so header and body are still generated
// from one single source of truth — just a two-level one now, to support
// real grouped headers (MODE / DOMAIN / SCRIPT / FRAME) instead of
// abbreviated flat labels.
//
// Sub-column kinds:
//   "domain"       — the domain name itself
//   "single"       — plain checkmark/dash, non-interactive (image/media/
//                    stylesheet/fetch-xhr/other)
//   "internal-whitelist" — single informational column, LEFT of Mode. Green
//                    if this domain is in the extension's built-in trusted
//                    list; grey if built-in-listed but a per-type override
//                    exists for it (the built-in status is no longer the
//                    sole/deciding factor for at least one type); blank if
//                    not built-in-listed at all. Never clickable.
//   "mode"         — Mode legend, ONE column at every level, fixed green
//                    (allow) / red (block) / grey (overridden — a script or
//                    frame per-type override exists, or the domain is on
//                    the built-in whitelist; either way something other
//                    than the level's own mechanism is deciding this
//                    domain's fate). Per-level coloring (blue at L2, yellow
//                    at L3, etc.) was tried and reverted per explicit
//                    feedback — back to universal colors, same language as
//                    SCRIPT/FRAME. See core/rule-classifier.js's getModeState().
//   "type-status"  — the interactive script/frame status box — one per
//                    type, per-domain, clickable per isStatusClickable()
//                    below. Always colored to the real effective
//                    disposition (green=allow, red=block), whether that's
//                    the level/built-in-whitelist default or an explicit
//                    override — no separate "no color = default" state
//                    (tried, reverted per explicit feedback: users wanted
//                    to see actual status at a glance). Sets/clears an
//                    override via core/matrix-rules.js's
//                    setMatrixRule(domain, type, action).
// `level` is currently unused inside this function — both informational
// columns (INTERNAL WHITELIST, LEVEL MODE) are now shown unconditionally at
// every level. Kept in the signature since column composition is
// inherently level-driven and a future column may need it again.
function buildColumnGroups(level) {
  const groups = [];

  groups.push({ label: "Domains connected", subs: [
    { key: "domain", kind: "domain", label: "Domains connected" }
  ]});

  // ── Internal whitelist (informational, single column, left of Mode) ──────
  // Shown at every level, including L1 — same layout at every level, no
  // exceptions. The underlying green/grey/yellow data is computed
  // level-independently in background.js (a domain's built-in-trusted
  // status doesn't depend on protection level), so there was never a data
  // reason to hide this column at L1 — only a display gate, now removed.
  groups.push({ label: ["INTERNAL", "WHITELIST"], subs: [
    { key: "internal-whitelist", kind: "internal-whitelist", label: ["INTERNAL", "WHITELIST"],
      title: "Internal whitelist — informational: green if this domain is in the extension's built-in trusted list, grey if that status is currently overridden for a type, blank otherwise" }
  ]});

  // ── Mode legend (informational) — always ONE column, every level ─────────
  // Display label is "LEVEL MODE" now (renamed per explicit feedback) — internal
  // kind/key stay "mode" throughout the codebase, only the user-facing text changed.
  // Two-line stacked label, same array-of-lines mechanism the
  // INTERNAL WHITELIST column already uses (_setLabel() in buildHeader()
  // renders an array as stacked, centered <span class="th-line"> lines) —
  // reused as-is, no new rendering logic added for this.
  groups.push({ label: ["LEVEL", "MODE"], subs: [
    { key: "mode", kind: "mode", label: ["LEVEL", "MODE"],
      title: "Level mode — informational: green/red shows what this level's own mechanism would do, grey if a script or frame override exists for this domain, blank at level 1 (no rules exist there at all)" }
  ]});

  // ── Plain observation columns (before script/frame) ───────────────────────
  ["image", "media", "stylesheet"].forEach(function(t) {
    groups.push({ label: t, subs: [{ key: t, kind: "single", type: t, label: t }] });
  });

  // ── script / frame — one interactive status box per type, independent ────
  // for script vs frame (each keeps its own default and its own override —
  // see core/matrix-rules.js). Always shows the real effective disposition —
  // green = allow, red = block — whether that's the default (level mode or
  // a built-in-whitelist allow) or an explicit override; there is no
  // separate "no color" neutral state. Click cycles: current state -> the
  // opposite, as an explicit override -> click again -> back to whatever
  // the default actually is (which may render the SAME color it already
  // showed, if the default itself happens to match — the override is still
  // genuinely cleared underneath; see isStatusClickable()/the click handler
  // below, both still driven by disposition.overridden, unchanged by this).
  // A built-in-whitelisted type is never clickable — see renderEntry()'s
  // isStatusClickable().
  ["script", "frame"].forEach(function(t) {
    groups.push({ label: t.toUpperCase(), subs: [
      { key: t + "-status", kind: "type-status", type: t, label: t.toUpperCase(),
        title: "Click to override this domain's " + t + " — click again to revert to default" }
    ]});
  });

  // ── Remaining plain observation columns ──────────────────────────────────
  ["fetch/xhr", "other"].forEach(function(t) {
    groups.push({ label: t, subs: [{ key: t, kind: "single", type: t, label: t }] });
  });

  return groups;
}

// Derives the flat per-cell list from the grouped model — used by
// renderEntry() to build each row's cells in the same order the header uses.
// Marks the first sub of every group except the very first with groupStart,
// for the vertical divider border between groups.
function flattenColumns(groups) {
  const flat = [];
  groups.forEach(function(g, gi) {
    g.subs.forEach(function(sub, si) {
      flat.push(Object.assign({}, sub, { groupStart: (gi > 0 && si === 0) }));
    });
  });
  return flat;
}

const _groups  = buildColumnGroups(_level);
const _columns = flattenColumns(_groups);

// ── Header ────────────────────────────────────────────────────────────────────
// Two real rows: row 1 holds either a rowspan=2 single header (1-sub groups)
// or a colspan=2 group super-header (2-sub groups: MODE/DOMAIN/SCRIPT/FRAME);
// row 2 holds only the Allow/Block sub-headers for the 2-sub groups. See
// matrix-panel.html's sticky-positioning comment for why both rows have a
// fixed height.
function buildHeader() {
  const row1 = document.createElement("tr");
  const row2 = document.createElement("tr");

  // Renders a th's label — either plain text, or (for a 2-line label like
  // ["INTERNAL", "WHITELIST"]) two stacked block-level spans.
  function _setLabel(th, label) {
    if (Array.isArray(label)) {
      th.innerHTML = "";
      label.forEach(function(line) {
        const span = document.createElement("span");
        span.className = "th-line";
        span.textContent = line;
        th.appendChild(span);
      });
    } else {
      th.textContent = label;
    }
  }

  _groups.forEach(function(g, gi) {
    const isGroupStart = gi > 0;
    if (g.subs.length === 1) {
      const th = document.createElement("th");
      _setLabel(th, g.subs[0].label);
      th.rowSpan = 2;
      if (g.subs[0].title) th.title = g.subs[0].title;
      if (g.subs[0].kind === "domain") th.classList.add("th-domain");
      if (isGroupStart) th.classList.add("group-start");
      row1.appendChild(th);
    } else {
      const th = document.createElement("th");
      _setLabel(th, g.label);
      th.colSpan = g.subs.length;
      if (isGroupStart) th.classList.add("group-start");
      row1.appendChild(th);

      g.subs.forEach(function(sub, si) {
        const subTh = document.createElement("th");
        _setLabel(subTh, sub.label);
        if (sub.title) subTh.title = sub.title;
        if (si === 0) subTh.classList.add("group-start");
        row2.appendChild(subTh);
      });
    }
  });

  elThead.innerHTML = "";
  elThead.appendChild(row1);
  elThead.appendChild(row2);
}

// ── Clock — ported from monitor-panel.js's identical startClock/formatClock ──

function formatClock(ms) {
  const total = Math.floor(Math.max(0, ms) / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return m + ":" + (s < 10 ? "0" : "") + s;
}

function startClock(remainingMs) {
  if (_clockInterval) clearInterval(_clockInterval);
  const deadline = Date.now() + remainingMs;

  _clockInterval = setInterval(function() {
    if (_isStopped) return;
    const left = deadline - Date.now();
    elTimer.textContent = formatClock(left);

    if (left <= 0) {
      elTimer.classList.add("expired");
      elTimerIcon.textContent = "■";
      clearInterval(_clockInterval);
    } else if (left <= WARN_MS) {
      elTimer.classList.add("warning");
    }
  }, 500);
}

// ── Interactivity rules — the per-type status box ────────────────────────────
// L1: nothing is clickable (no rules exist there at all).
// Built-in-protected (disposition.builtinProtected): never clickable — an
//     allow that can't be overruled to block (see core/rule-classifier.js's
//     wouldBlock() step 2 and core/matrix-rules.js's matching guard).
// Already overridden: always clickable — reverting to default is never
//     restricted at any level.
// Not yet overridden, L2 only: clickable UNLESS the default is already
//     "allow" (clicking it would try to create a BLOCK override, and L2
//     has always been allow-only — matches the pre-redesign two-button
//     layout's "only the allow half is clickable" rule for this level).
// Not yet overridden, L3-5: always clickable either direction.
function isStatusClickable(level, disposition) {
  if (level === 1) return false;
  if (disposition.builtinProtected) return false;
  if (disposition.overridden) return true;
  if (level === 2 && disposition.effective === "allow") return false;
  return true;
}

// ── Entry rendering ───────────────────────────────────────────────────────────

function renderEntry(entry) {
  const tr = document.createElement("tr");
  const cells = [];

  _columns.forEach(function(col) {
    if (col.kind === "domain") {
      // Plain text, intentionally not clickable. The panel's actual controls
      // are the independent per-type Script/Frame cells below. A combined
      // frame+script "Domain" control was superseded by those (see
      // CHANGELOG) and has since been removed entirely, including its
      // core/matrix-rules.js primitive — see CHANGELOG for the removal.
      const td = document.createElement("td");
      td.className = "td-domain";
      td.textContent = entry.domain; // textContent, not innerHTML — domain is safe (URL hostname charset) but no reason to risk it
      cells.push(td);
      return;
    }

    if (col.kind === "mode") {
      // One column, fixed green/red (universal, not level-specific — an
      // earlier attempt at per-level coloring was reverted per explicit
      // feedback), universal grey for overridden — see
      // core/rule-classifier.js's getModeState() and background.js's
      // enrichment step. entry.mode is a single string:
      // "allow" | "block" | "grey" (or "empty" as a defensive fallback,
      // though that shouldn't occur in practice — see getModeState()).
      const td = document.createElement("td");
      if (col.groupStart) td.className = "group-start";
      const state = entry.mode || "empty";

      const swatch = document.createElement("span");
      swatch.className = "mini-square";
      if (state === "allow") {
        swatch.classList.add("filled", "fill-green");
      } else if (state === "block") {
        swatch.classList.add("filled", "fill-red");
      } else if (state === "grey") {
        swatch.classList.add("filled", "fill-grey");
      }
      // "empty" — bare outline square, no fill.
      td.appendChild(swatch);
      cells.push(td);
      return;
    }

    if (col.kind === "internal-whitelist") {
      // Informational, never clickable. "green" (built-in trusted, no
      // override), "grey" (built-in trusted but a per-type override exists
      // for it), "yellow" (on the signal list — commonly needed for
      // "Login with X", never auto-allowed), or "empty" (neither) —
      // computed in background.js's enrichment step.
      const td = document.createElement("td");
      if (col.groupStart) td.className = "group-start";
      const state = entry.internalWhitelist || "empty";

      const swatch = document.createElement("span");
      swatch.className = "mini-square";
      if (state === "green") {
        swatch.classList.add("filled", "fill-green");
      } else if (state === "grey") {
        swatch.classList.add("filled", "fill-grey");
      } else if (state === "yellow") {
        swatch.classList.add("filled", "fill-yellow");
      }
      // Domain-specific tooltip explaining WHY this domain is trusted or
      // flagged — e.g. "Built-in whitelist: Payment — core / international"
      // or "Signal: commonly needed for Login with GitHub" — rather than
      // the generic column-header tooltip, per explicit request to always
      // be able to see the reason at a glance.
      if (entry.internalWhitelistCategory) {
        const prefix = state === "yellow" ? "Signal (not auto-allowed): " : "Built-in whitelist: ";
        td.title = prefix + entry.internalWhitelistCategory;
      }
      td.appendChild(swatch);
      cells.push(td);
      return;
    }

    if (col.kind === "single") {
      const td = document.createElement("td");
      if (col.groupStart) td.className = "group-start";
      const has = entry.types.indexOf(col.type) !== -1;
      const span = document.createElement("span");
      span.className = "td-check" + (has ? "" : " empty");
      span.textContent = has ? "✓" : "—";
      td.appendChild(span);
      cells.push(td);
      return;
    }

    if (col.kind === "type-status") {
      // Interactive — per-domain, per-type, ONE box (see buildColumnGroups()
      // above for the no-color/green/red contract and isStatusClickable()
      // for exactly when this is clickable).
      const td = document.createElement("td");
      const disposition = col.type === "frame" ? entry.frameDisposition : entry.scriptDisposition;

      if (!disposition) {
        // Type never observed for this domain — truly blank (not even a
        // dash): the box itself IS the "this type exists" signal now (see
        // the checkmark below), so there is nothing to show at all here.
        td.className = col.groupStart ? "group-start" : "";
        cells.push(td);
        return;
      }

      const clickable = isStatusClickable(_level, disposition);

      td.className = "td-status" +
        (col.groupStart ? " group-start" : "") +
        (clickable ? " clickable" : "");
      td.dataset.domain = entry.domain;
      td.dataset.type   = col.type;
      // The click handler needs both: whether an override is currently
      // active (to decide clear-vs-set) and, when not, which action
      // "opposite of default" actually means for THIS entry right now.
      td.dataset.overridden = disposition.overridden ? "1" : "0";
      td.dataset.effective  = disposition.effective;

      const square = document.createElement("span");
      square.className = "mini-square";
      // Always colored to the real effective disposition — green=allow,
      // red=block — regardless of whether that's an explicit override or
      // just the default (level mode / built-in whitelist) applying. There
      // is deliberately no longer a separate "no color = default" state;
      // per explicit feedback, users wanted to see actual status at a
      // glance rather than infer it. The click cycle itself is unchanged —
      // still driven by disposition.overridden/effective below, not by
      // this fill.
      square.classList.add("filled", disposition.effective === "allow" ? "fill-green" : "fill-red");
      // Checkmark — disposition only ever exists when this type was
      // actually observed (see background.js's enrichment: entry.types),
      // so reaching this point already means "3P frames/scripts of this
      // type exist for this domain". One glyph, always shown here.
      square.textContent = "\u2713";
      if (disposition.builtinProtected) {
        td.title = "Built-in whitelisted — cannot be blocked";
      }
      td.appendChild(square);
      cells.push(td);
      return;
    }
  });

  cells.forEach(function(td) { tr.appendChild(td); });
  return tr;
}

function refreshTable(entries) {
  _lastEntries = entries;
  _renderTable();
}

function _renderTable() {
  elEntryBody.innerHTML = "";
  for (let i = 0; i < _lastEntries.length; i++) {
    elEntryBody.appendChild(renderEntry(_lastEntries[i]));
  }

  if (_lastEntries.length) {
    elEmptyState.style.display = "none";
  } else {
    elEmptyState.style.display = "block";
    elEmptyState.querySelector(".empty-sub").textContent = "Third-party connections appear here as the page loads.";
  }
}

function renderStats(domainCount, requestCount) {
  const d = domainCount || 0;
  const r = requestCount || 0;
  elStats.textContent = d + " domain" + (d === 1 ? "" : "s") + " · " + r + " request" + (r === 1 ? "" : "s");
}

// ── Click-to-override — event delegation on the tbody, so re-rendering the ──
// table on every poll never requires re-attaching per-cell listeners.
// Script/Frame cells carry the .clickable class — each type independent.
elEntryBody.addEventListener("click", function(e) {
  const cell = e.target.closest(".td-status.clickable");
  if (!cell) return;

  const domain     = cell.dataset.domain;
  const type       = cell.dataset.type;
  const overridden = cell.dataset.overridden === "1";
  const effective  = cell.dataset.effective; // "allow" | "block" — current effective disposition

  // Already overridden (colored) -> clicking clears it, reverting to
  // default. Not overridden (no color) -> clicking sets an override to the
  // OPPOSITE of whatever's currently in effect — core/matrix-rules.js's own
  // redundant-override guard is what actually computes "opposite of
  // default" server-side; this is just the UI's one-click toggle intent.
  const newAction = overridden ? null : (effective === "allow" ? "block" : "allow");

  send({ type: MSG_SET_MATRIX_RULE, tabId: _tabId, domain: domain, resourceType: type, action: newAction }, function(resp) {
    if (!resp || !resp.ok) return;
    poll(); // immediate refresh — don't wait for the next 800ms tick
  });
});

// ── Poll ──────────────────────────────────────────────────────────────────────

function startPolling() {
  if (_pollInterval) clearInterval(_pollInterval);
  _pollInterval = setInterval(poll, POLL_MS);
  poll(); // immediate first fetch
}

function stopPolling() {
  if (_pollInterval) { clearInterval(_pollInterval); _pollInterval = null; }
}

function poll() {
  if (_tabId === null || _isStopped) return;
  send({ type: MSG_GET_MATRIX_DATA, tabId: _tabId }, function(resp) {
    if (!resp || !resp.ok || !resp.data) return;
    refreshTable(resp.data.entries || []);
    renderStats(resp.data.domainCount, resp.data.requestCount);
    if (!_clockStarted && typeof resp.data.remaining === "number") {
      _clockStarted = true;
      startClock(resp.data.remaining);
    }
  });
}

// ── Close ─────────────────────────────────────────────────────────────────────

function releaseAndClose() {
  if (_isStopped) { window.close(); return; }
  _isStopped = true;
  stopPolling();
  if (_clockInterval) { clearInterval(_clockInterval); _clockInterval = null; }
  if (_tabId !== null) {
    send({ type: MSG_STOP_MATRIX, tabId: _tabId }, function() { window.close(); });
  } else {
    window.close();
  }
}

elBtnClose.addEventListener("click", releaseAndClose);

// ── SW-initiated close (tab closed, or countdown expired, while panel open) ──

function handleForceClosed(reason) {
  if (_isStopped) return;
  _isStopped = true;
  stopPolling();
  if (_clockInterval) { clearInterval(_clockInterval); _clockInterval = null; }
  elTimer.classList.add("expired");
  elTimerIcon.textContent = "■";
  elEmptyState.style.display = "block";
  const reasonText = {
    tab_closed: "The observed tab was closed.",
    timeout:    "Time limit reached — session closed."
  };
  elEmptyState.querySelector(".empty-sub").textContent = reasonText[reason] || "Show Matrix session ended.";
  setTimeout(function() { window.close(); }, 1200);
}

chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === MSG_MATRIX_CLOSED && msg.tabId === _tabId) {
    handleForceClosed(msg.reason);
  }
});

// ── Filter note — level-dependent text, ONE mechanism for every level ────────
// Same visible #filterNote element/layout (reuses .panel-intro CSS) at every
// level, L1 through L5 — only FILTER_NOTE_L1/L2/L3_L5 text differs.
// Guard: always resets the note element to empty/hidden first, so nothing
// stale can persist if this is ever called more than once.
function setFilterNote() {
  if (!elFilterNote) return;

  // Guard — clear before applying, single source of truth per level below
  elFilterNote.textContent = "";
  elFilterNote.hidden = true;

  const noteText = _level === 1 ? FILTER_NOTE_L1
                  : _level === 2 ? FILTER_NOTE_L2
                  : _level >= 3  ? FILTER_NOTE_L3_L5
                  : "";
  if (noteText) {
    elFilterNote.textContent = noteText;
    elFilterNote.hidden = false;
  }
}

// ── Init ──────────────────────────────────────────────────────────────────────

(function init() {
  elHost.textContent = _host;
  document.body.style.setProperty('--level-color', LEVEL_BRAND_COLOR[_level] || LEVEL_BRAND_COLOR[1]);
  buildHeader();
  setFilterNote();
  if (_tabId === null) {
    elEmptyState.querySelector(".empty-sub").textContent = "No tab to observe — please reopen from the popup.";
    return;
  }
  startPolling();
})();

// ── Release on window close ───────────────────────────────────────────────────
window.addEventListener('beforeunload', function() {
  if (_isStopped) return;
  if (_tabId === null) return;
  try {
    chrome.runtime.sendMessage({ type: MSG_STOP_MATRIX, tabId: _tabId });
  } catch(e) {
    // Intentional: beforeunload gives very little time; SW cleanup is best-effort.
  }
});
