// ── util/tld-utils.js ─────────────────────────────────────────────────────────
// Pure utility functions for the browser's time zone, version string parsing
// and apex-domain reduction. No side effects, no state, no Chrome API calls.
//
// Public interface:
//   getBrowserTimeZone()    — the browser's IANA time zone, or "" when unavailable
//   majorMinor(version)     — extracts "major.minor" from a version string
//   getApexDomain(hostname) — reduces a hostname to its registrable (apex) domain
//
// (Country-TLD detection from browser languages lives ONLY in core/tld-engine.js —
// an older second copy here treated bare language codes as country codes, e.g.
// Swedish "sv" → El Salvador's .sv, and could disagree with the slider's BROWSER
// mode. It was removed so the fresh-install seed and the slider cannot drift apart.)
// ─────────────────────────────────────────────────────────────────────────────

import { MULTI_PART_SUFFIXES } from "../data/constants.js";

// The browser's IANA time zone ("Europe/Amsterdam"), or "" when it can't be read.
// core/tld-engine.js is pure and never reads the environment itself, so callers
// (ui/popup.js, background.js) read it here and hand it in — it is CONTINENT
// mode's fallback for working out which continent the user is on when no
// language tag names a region. "" means "no guess": the engine then adds nothing
// extra rather than failing.
export function getBrowserTimeZone() {
  try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ""; }
  catch (e) { return ""; } // guard: Intl unavailable or throwing — no guess
}

// Extracts "major.minor" from a semver-style version string.
// e.g. "1.6.8" -> "1.6",  "2.0" -> "2.0",  "" -> "0.0"
export function majorMinor(version) {
  const parts = (version || "").split(".");
  return (parts[0] || "0") + "." + (parts[1] || "0");
}

// Reduces a hostname to its registrable (apex) domain, e.g.
// "portal.www.tio.nl" -> "tio.nl", "www.example.co.uk" -> "example.co.uk"
// Single source of truth — used by ui/popup.js (site locking).
export function getApexDomain(hostname) {
  if (!hostname) return hostname;
  const labels = hostname.split(".");
  if (labels.length <= 2) return hostname;

  const lastTwo   = labels.slice(-2).join(".");
  const lastThree = labels.length >= 3 ? labels.slice(-3).join(".") : null;

  if (lastThree && MULTI_PART_SUFFIXES.indexOf(labels.slice(-2).join(".")) !== -1) {
    return lastThree;
  }
  return lastTwo;
}
