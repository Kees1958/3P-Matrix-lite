// ── background.js — 3P Matrix service worker (lifecycle + thin router) ───────
// No business logic here: every branch validates its input and delegates to a core/ or data/
// module (4.2.3, audit finding 6: lock/allow-list → core/site-locks.js, safer-regions edit →
// core/safer-regions.js, Show Matrix overrides → core/matrix-overrides.js, panel windows →
// core/matrix-windows.js, page models → core/view-models.js).
//
// Lifecycle
//   install          → default state, compute safer regions, apply
//   update / reload  → load state, level = startupLevel, recompute safer regions, apply
//   browser startup  → level = startupLevel, apply
//
// Events
//   webNavigation.onBeforeNavigate (top frame) → stage 1 site check → warning dialog (protection 10)
//   webNavigation.onCommitted (top frame)      → reset badge count, per-tab icon
//   webRequest.onErrorOccurred                 → count OUR blocks per tab (rule-matcher attribution)
//   tabs.onRemoved / windows.onRemoved         → release per-tab state and matrix panels (guards)
//
// All state mutations go through mutate(): load → change → save → apply, run
// under withStateLock() so two messages can never interleave.
// ─────────────────────────────────────────────────────────────────────────────

import { LEVEL, LEVEL_INFO, LOG_PREFIX, SEVERITY, MATRIX_SCOPE, MATRIX_ACTION, WARNING_PAGE, WARNING_TARGET_PARAM,
         CHROME_BLOCKED_BY_CLIENT_ERROR, CHROME_NEW_TAB_URL } from "./data/constants.js";
import * as M from "./data/message-types.js";
import { defaultState, loadState, saveState, normalizeState, withStateLock, isValidHost, parseLevel } from "./data/state-storage.js";
import { PROTECTION_BY_KEY } from "./data/protections.js";
import { effectiveLevel } from "./core/policy.js";
import { applyState, getCompiledRules } from "./core/apply-manager.js";
import { matchOutcome } from "./core/rule-matcher.js";
import { computeSaferRegions, editSaferRegions } from "./core/safer-regions.js";
import { scoreLocal } from "./core/site-scorer.js";
import { evaluateSite, clearScoreCache } from "./core/online-checks.js";
import { popupModel, matrixModel, optionsModel } from "./core/view-models.js";
import { lockSite, toggleLock, parseAllowListText, replaceAllowList } from "./core/site-locks.js";
import { setMatrixOverride } from "./core/matrix-overrides.js";
import { openMatrixPanel, closeMatrixPanel, onWindowRemoved } from "./core/matrix-windows.js";
import * as Badge from "./core/badge.js";
import * as Guard from "./core/navigation-guard.js";
import * as Matrix from "./core/connection-matrix.js";
import * as TabSites from "./core/tab-sites.js";
import { toSettingsFile, fromSettingsFile, summarize } from "./data/settings-io.js";
import { parseHttpUrl, registeredDomain } from "./util/domain.js";

// ── Core helpers ─────────────────────────────────────────────────────────────
async function commit(state) {
  const saved = await saveState(state);
  await applyState(saved);
  Badge.setLevelIcon(saved.level);
  await refreshActiveTabIcon(saved);
  return saved;
}

function mutate(change) {
  return withStateLock(async () => {
    const state = await loadState();
    const result = await change(state);
    const saved = await commit(state);
    return { state: saved, result };
  });
}

async function refreshActiveTabIcon(state) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const p = tab && parseHttpUrl(tab.url || "");
    if (tab && p) Badge.setLevelIcon(effectiveLevel(state, p.host), tab.id);
  } catch { /* no window yet at browser start — global icon is enough */ }
}

// ── Lifecycle ────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener((details) => {
  withStateLock(async () => {
    const state = details.reason === "install" ? defaultState() : await loadState();
    state.level = state.startupLevel;
    state.prevLevel = state.startupLevel;
    // Every reason (install, update, reload): the list depends on code (base TLDs, auto-add
    // scope, country data) — 0.2.4 moves users of the removed slider to the fixed Continent scope.
    state.safeZone.tlds = await computeSaferRegions(state.safeZone);
    await commit(state);
  }).catch((e) => console.error(LOG_PREFIX, "onInstalled:", e));
});

chrome.runtime.onStartup.addListener(() => {
  withStateLock(async () => {
    const state = await loadState();
    state.level = state.startupLevel;
    state.prevLevel = state.startupLevel;
    await commit(state);
  }).catch((e) => console.error(LOG_PREFIX, "onStartup:", e));
});

// ── Navigation / request events (registered synchronously at top level) ─────
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  loadState().then((state) => Guard.checkNavigation(details, state))
    .catch((e) => console.error(LOG_PREFIX, "navigation check:", e));
});

chrome.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId !== 0) return;
  Badge.resetCount(details.tabId);
  const p = parseHttpUrl(details.url);
  TabSites.setTopHost(details.tabId, p ? p.host : "");
  Matrix.clearOnNavigation(details.tabId, p ? p.host : "");
  if (!p) return;
  Badge.clearRiskIfOtherSite(details.tabId, registeredDomain(p.host));
  loadState().then((state) => Badge.setLevelIcon(effectiveLevel(state, p.host), details.tabId))
    .catch((e) => console.error(LOG_PREFIX, "tab icon:", e));
});

chrome.webRequest.onErrorOccurred.addListener((details) => {
  if (details.error !== CHROME_BLOCKED_BY_CLIENT_ERROR || details.type === "main_frame" || details.tabId < 0) return;
  // Chrome reports ERR_BLOCKED_BY_CLIENT for blocks by ANY extension — the badge counts only
  // the requests our own rules block (core/rule-matcher.js replays DNR matching; an opaque
  // "null" initiator is matched as the tab's own site, as Chrome does).
  Promise.all([getCompiledRules(), TabSites.topHostOf(details.tabId)]).then(([compiled, topHost]) => {
    if (matchOutcome(compiled, details, topHost).action === "block") Badge.noteBlocked(details.tabId);
  }).catch((e) => console.warn(LOG_PREFIX, "block attribution failed:", e));
}, { urls: ["<all_urls>"] });

chrome.tabs.onRemoved.addListener((tabId) => {
  Badge.releaseTab(tabId);
  Guard.releaseTab(tabId);
  TabSites.releaseTab(tabId);
  closeMatrixPanel(tabId);
});

chrome.windows.onRemoved.addListener(onWindowRemoved);

// ── Input guards (audit finding 11 — C6 / C28) ───────────────────────────────
function requireTabId(msg) {
  if (!Number.isInteger(msg.tabId) || msg.tabId < 0) throw new Error("bad tab");
  return msg.tabId;
}

// The site a warning-page message is about: taken from the sender's own URL (?u=) when the
// message comes from our warning page (C28 — never trust a message field when the sender says
// it), else from msg.url (pages that act on another tab's URL, e.g. tests and the popup).
function warningTarget(msg, sender) {
  const warningPage = chrome.runtime.getURL(WARNING_PAGE);
  if (sender.url && sender.url.startsWith(warningPage)) {
    const u = new URL(sender.url).searchParams.get(WARNING_TARGET_PARAM);
    if (u) return u;
  }
  return msg.url || "";
}

// ── Message router ───────────────────────────────────────────────────────────
const HANDLERS = {
  [M.MSG_GET_POPUP_STATE]: async (msg) => popupModel(await loadState(), msg.tabId, msg.url),

  [M.MSG_SET_LEVEL]: async (msg) => {
    const level = parseLevel(msg.level);
    if (level === null) throw new Error("bad level");
    const { state } = await mutate((s) => { if (s.level !== level) { s.prevLevel = s.level; s.level = level; } });
    return popupModel(state, msg.tabId, msg.url);
  },

  [M.MSG_SET_STARTUP_LEVEL]: async (msg) => {
    const level = parseLevel(msg.level);
    if (level === null) throw new Error("bad level");
    const { state } = await mutate((s) => { s.startupLevel = level; });
    return popupModel(state, msg.tabId, msg.url);
  },

  // Lock: pin the CURRENT session level to the site, then restore the session
  // level the user had before moving the slider (3P-Matrix-lite behaviour).
  [M.MSG_TOGGLE_LOCK]: async (msg) => {
    const p = parseHttpUrl(msg.url || "");
    if (!p) throw new Error("not a lockable page");
    const site = registeredDomain(p.host);
    const { state } = await mutate((s) => toggleLock(s, site));
    return popupModel(state, msg.tabId, msg.url);
  },

  [M.MSG_SET_PROTECTION]: async (msg) => {
    if (!PROTECTION_BY_KEY[msg.key]) throw new Error("unknown protection");
    const { state } = await mutate((s) => {
      if (msg.enabled) delete s.disabledProtections[msg.key]; else s.disabledProtections[msg.key] = true;
    });
    return popupModel(state, msg.tabId, msg.url);
  },

  [M.MSG_SET_SAFE_ZONE]: async (msg) => {
    const { state } = await mutate((s) => editSaferRegions(s.safeZone, msg));
    return popupModel(state, msg.tabId, msg.url);
  },

  // ── Show Matrix ──
  [M.MSG_OPEN_MATRIX]: async (msg) => {
    const p = parseHttpUrl(msg.url || "");
    if (!p || !Number.isInteger(msg.tabId)) throw new Error("Show Matrix works on web pages only");
    await openMatrixPanel(msg.tabId, p.host);
    return true;
  },

  [M.MSG_STOP_MATRIX]: async (msg) => { Matrix.stopMatrix(requireTabId(msg)); return true; },

  [M.MSG_GET_MATRIX_DATA]: async (msg) => matrixModel(await loadState(), msg.tabId),

  [M.MSG_SET_MATRIX_RULE]: async (msg) => {
    const activeSite = Matrix.getMatrixData(msg.tabId).site;    // guard: Show Matrix must be tracking this tab
    const domain = String(msg.domain || "").toLowerCase();
    if (!activeSite || !isValidHost(domain) || !Object.values(MATRIX_SCOPE).includes(msg.scope)) throw new Error("bad matrix rule");
    const action = Object.values(MATRIX_ACTION).includes(msg.action) ? msg.action : null;
    const { state } = await mutate((s) => setMatrixOverride(s, domain, msg.scope, action));
    return matrixModel(state, msg.tabId);
  },

  [M.MSG_RELOAD_TAB]: async (msg) => { await chrome.tabs.reload(requireTabId(msg)); return true; },

  [M.MSG_EVALUATE_SITE]: async (msg, sender) => {
    const state = await loadState();
    const local = scoreLocal(warningTarget(msg, sender));
    if (!local) return null;
    const full = await evaluateSite(local, state.dns);
    if (sender.tab) Badge.setRisk(sender.tab.id, full.site, full.severity);
    return { ...full, levelInfo: LEVEL_INFO };
  },

  [M.MSG_WARNING_ACTION]: async (msg, sender) => {
    const tabId = sender.tab ? sender.tab.id : msg.tabId;
    const p = parseHttpUrl(warningTarget(msg, sender));
    if (!p || tabId === undefined) throw new Error("bad warning action");
    const site = registeredDomain(p.host);
    if (msg.action === M.WARNING_ACTION.GO_BACK) {
      try { await chrome.tabs.goBack(tabId); }
      catch { await chrome.tabs.update(tabId, { url: CHROME_NEW_TAB_URL }); }   // no history: open a new-tab page
      return true;
    }
    if (msg.action === M.WARNING_ACTION.TRUST) {
      await mutate((s) => lockSite(s, site, LEVEL.ALLOW_ALL));
      Badge.setRisk(tabId, site, SEVERITY.NONE);
    } else if (msg.action === M.WARNING_ACTION.CONTINUE_ONCE) {
      Guard.allowOnce(tabId, site);
    } else {
      throw new Error("unknown warning action");
    }
    await chrome.tabs.update(tabId, { url: p.url });
    return true;
  },

  [M.MSG_GET_OPTIONS]: async () => optionsModel(await loadState()),

  [M.MSG_SET_DNS]: async (msg) => {
    const { state } = await mutate((s) => { s.dns = { first: msg.first, second: msg.second }; });
    clearScoreCache();                                      // results depend on the chosen resolvers
    return optionsModel(state);
  },

  // The allow-list text is the authoritative list of LEVEL-1 locks only;
  // sites locked at other levels are never shown or touched here.
  [M.MSG_SET_ALLOW_LIST]: async (msg) => {
    const wanted = parseAllowListText(msg.text);
    const { state } = await mutate((s) => replaceAllowList(s, wanted));
    return optionsModel(state);
  },

  [M.MSG_EXPORT_SETTINGS]: async () => {
    const state = await loadState();
    return { file: toSettingsFile(state, chrome.runtime.getManifest().version), summary: summarize(state) };
  },

  [M.MSG_IMPORT_SETTINGS]: async (msg) => {
    const incoming = fromSettingsFile(msg.settings);                 // throws on a foreign file
    const { state } = await mutate(async (s) => {
      Object.assign(s, normalizeState(incoming));
      s.safeZone.tlds = await computeSaferRegions(s.safeZone);       // recomputed for this browser's languages
    });
    clearScoreCache();
    return { ...optionsModel(state), summary: summarize(state) };
  },

  [M.MSG_RESET_SETTINGS]: async () => {
    const { state } = await mutate(async (s) => {
      Object.assign(s, defaultState());
      s.safeZone.tlds = await computeSaferRegions(s.safeZone);
    });
    clearScoreCache();
    return optionsModel(state);
  }
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Guard: only this extension's own pages may talk to the router (no externally_connectable,
  // but checked anyway — C28).
  if (!sender || sender.id !== chrome.runtime.id) { sendResponse({ ok: false, error: "foreign sender" }); return false; }
  const handler = msg && HANDLERS[msg.type];
  if (!handler) { sendResponse({ ok: false, error: "unknown message" }); return false; }
  handler(msg, sender)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((e) => { console.warn(LOG_PREFIX, msg.type, e); sendResponse({ ok: false, error: String(e && e.message || e) }); });
  return true;                                              // async response
});
