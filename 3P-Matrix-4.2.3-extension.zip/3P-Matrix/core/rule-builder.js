// ── core/rule-builder.js ──────────────────────────────────────────────────────
// Pure DNR rule construction: state in, rule array out. No Chrome API calls.
//
// Public interface:
//   buildDynamicRules(state, opts) — Rule[] for chrome.declarativeNetRequest.updateDynamicRules
//     opts.cdnRegexSupported  boolean — use CDN_HOST_REGEX, else the looser "*cdn*" urlFilter
//   collectRegexes(rules)          — distinct regexFilter strings (for isRegexSupported checks)
//   isLevelMechanismRule(rule)     — true for every rule EXCEPT the built-in whitelist allows and
//                                    Show Matrix overrides: what the level's own mechanism decides
//                                    (Show Matrix "Level mode" column, core/matrix-disposition.js)
//
// Rules are built per rule GROUP (core/policy.js ruleGroups): the global group
// excludes every locked site; each locked group covers only its own sites.
// Rule id = GROUP_ID_STRIDE * group.index + RULE_LOCAL_ID.*
//
// Priority model (data/constants.js PRIORITY, higher wins):
//   L5 code block  >  Show Matrix  >  security blocks (2,4,6,7)  >  L3 safer-regions allow
//   >  abused-TLD block (11)  >  built-in / CDN allow  >  L3/L4 level block
// 4.2: every level (3, 4, 5) targets third-party scripts + frames only (RT.CODE) — never
// images, video, fonts or stylesheets.
// ─────────────────────────────────────────────────────────────────────────────

import {
  LEVEL, GROUP_ID_STRIDE, RULE_LOCAL_ID as ID, PRIORITY, RT, PP_VALUE, SANDBOX_CSP_VALUE,
  CDN_HOST_REGEX, CDN_URL_FILTER_FALLBACK, HTTP_URL_FILTER, IP_LITERAL_REGEX, NON_STANDARD_PORT_REGEX, BYETHOST_REGEX, BUILTIN_EXEMPT_LEVELS,
  MATRIX_RULE_ID_BASE, MATRIX_RULES_MAX, MATRIX_SCOPE, MATRIX_SCOPE_RESOURCE_TYPE, MATRIX_ACTION, MATRIX_SITE_ALL
} from "../data/constants.js";
import { ruleGroups, isProtectionActive, saferRegionsApply, GROUP_KIND } from "./policy.js";
import { PROTECTION_KEY } from "../data/protections.js";
import { SPAM_TLDS, SPAM_TLD_EXCEPTIONS } from "../data/spam-tlds.js";
import { SUSPICIOUS_HOSTING_DOMAINS } from "../data/suspicious-hosting.js";
import { BUILTIN_BOTH, BUILTIN_SCRIPT_ONLY, BUILTIN_FRAME_ONLY, BUILTIN_ALL } from "../data/builtin-domains.js";
import {
  HIGH_RISK_HOSTNAMES, LOCAL_NETWORK_NAME_DOMAINS, LOCAL_NETWORK_INITIATOR_EXEMPT,
  buildLocalNetworkIpv4Regex, buildLocalNetworkIpv6Regex
} from "../data/network-data.js";

const ARRAY_KEYS = new Set(["initiatorDomains", "excludedInitiatorDomains", "requestDomains", "excludedRequestDomains"]);

// ── Scope helpers ────────────────────────────────────────────────────────────
// Sub-resource rules are scoped by the PAGE that makes the request (initiator).
function subScope(group) {
  if (group.kind === GROUP_KIND.LOCKED) return { initiatorDomains: group.sites };
  return group.sites.length ? { excludedInitiatorDomains: group.sites } : {};
}
// Top-level header rules are scoped by the page's OWN domain (request).
function mainScope(group) {
  if (group.kind === GROUP_KIND.LOCKED) return { requestDomains: group.sites };
  return group.sites.length ? { excludedRequestDomains: group.sites } : {};
}
// Merges condition parts; domain arrays are concatenated and de-duplicated.
function cond(...parts) {
  const out = {};
  for (const part of parts) {
    for (const [k, v] of Object.entries(part || {})) {
      if (ARRAY_KEYS.has(k)) out[k] = [...new Set([...(out[k] || []), ...v])];
      else out[k] = v;
    }
  }
  return out;
}
function rule(group, localId, priority, action, condition) {
  return { id: GROUP_ID_STRIDE * group.index + localId, priority, action, condition };
}
const BLOCK = Object.freeze({ type: "block" });
const ALLOW = Object.freeze({ type: "allow" });
function appendHeader(header, value) {
  return { type: "modifyHeaders", responseHeaders: [{ header, operation: "append", value }] };
}

// ── Protection rules (DNR / header mechanisms) ───────────────────────────────
function protectionRules(state, group) {
  const L = group.level;
  function on(key) { return isProtectionActive(state, key, L); }
  const sub = subScope(group);
  const rules = [];

  if (on(PROTECTION_KEY.BLOCK_WEB_BUNDLES)) {                                           // 2
    rules.push(rule(group, ID.WEBBUNDLE, PRIORITY.SECURITY_BLOCK, BLOCK, cond(sub, { resourceTypes: ["webbundle"] })));
  }
  if (on(PROTECTION_KEY.BLOCK_LOCAL_NETWORK)) {                                         // 4
    const base = cond(sub, { domainType: "thirdParty", resourceTypes: [...RT.ALL_SUB], excludedInitiatorDomains: [...LOCAL_NETWORK_INITIATOR_EXEMPT] });
    rules.push(rule(group, ID.LOCALNET_NAMES, PRIORITY.LOCALNET_BLOCK, BLOCK, cond(base, { requestDomains: [...LOCAL_NETWORK_NAME_DOMAINS] })));
    rules.push(rule(group, ID.LOCALNET_IPV4,  PRIORITY.LOCALNET_BLOCK, BLOCK, cond(base, { regexFilter: buildLocalNetworkIpv4Regex(), isUrlFilterCaseSensitive: false })));
    rules.push(rule(group, ID.LOCALNET_IPV6,  PRIORITY.LOCALNET_BLOCK, BLOCK, cond(base, { regexFilter: buildLocalNetworkIpv6Regex(), isUrlFilterCaseSensitive: false })));
  }
  if (on(PROTECTION_KEY.BLOCK_SUSPICIOUS_3P)) {                                         // 6
    const tp = cond(sub, { domainType: "thirdParty" });
    rules.push(rule(group, ID.SUSP_IP,         PRIORITY.SECURITY_BLOCK, BLOCK, cond(tp, { regexFilter: IP_LITERAL_REGEX, isUrlFilterCaseSensitive: false })));
    rules.push(rule(group, ID.SUSP_PORT_BLOCK, PRIORITY.SECURITY_BLOCK, BLOCK, cond(tp, { regexFilter: NON_STANDARD_PORT_REGEX, isUrlFilterCaseSensitive: false })));
    rules.push(rule(group, ID.SUSP_HOSTING,    PRIORITY.SECURITY_BLOCK, BLOCK, cond(tp, { requestDomains: [...SUSPICIOUS_HOSTING_DOMAINS], resourceTypes: [...RT.SUSP_HOSTING] })));
    rules.push(rule(group, ID.SUSP_HOSTING_REGEX, PRIORITY.SECURITY_BLOCK, BLOCK, cond(tp, { regexFilter: BYETHOST_REGEX, isUrlFilterCaseSensitive: false, resourceTypes: [...RT.SUSP_HOSTING] })));
  }
  if (on(PROTECTION_KEY.BLOCK_3P_HTTP)) {                                               // 7
    rules.push(rule(group, ID.HTTP_3P, PRIORITY.SECURITY_BLOCK, BLOCK, cond(sub, { urlFilter: HTTP_URL_FILTER, domainType: "thirdParty", resourceTypes: [...RT.ALL_SUB] })));
  }
  // 11: 3P scripts and frames from abused TLDs, every level ≥ 2. Level 5 skips it — its own
  // code block (higher priority, no exceptions) already covers every such request.
  if (on(PROTECTION_KEY.BLOCK_ABUSED_TLDS) && L !== LEVEL.STRICT) {
    rules.push(rule(group, ID.SPAM_TLD_BLOCK, PRIORITY.SPAM_TLD_BLOCK, BLOCK,
      cond(sub, { domainType: "thirdParty", requestDomains: [...SPAM_TLDS], excludedRequestDomains: [...SPAM_TLD_EXCEPTIONS], resourceTypes: [...RT.CODE] })));
  }
  return rules;
}

// ── Header rules (protections 9, 12–14, 16) ─────────────────────────────────
function headerRules(state, group, safeTlds) {
  const L = group.level;
  function on(key) { return isProtectionActive(state, key, L); }
  const rules = [];
  // Two independent exemptions from protections 12–14/16, merged (cond() unions the domain
  // arrays): safer regions (TLD list, level 3 only — levels 4–5 deliberately ignore it) and the
  // built-in whitelist (0.2.4: same levels as its 3P content allow, 3 and 4, never 5 — user
  // request: a built-in host is trusted on a FIRST-PARTY visit too, not just as a 3P embed).
  const outsideSafe = cond(
    saferRegionsApply(L) && safeTlds.length ? { excludedRequestDomains: safeTlds } : {},
    BUILTIN_EXEMPT_LEVELS.includes(L) && BUILTIN_ALL.length ? { excludedRequestDomains: BUILTIN_ALL } : {}
  );

  // 12–14: one combined Permissions-Policy value (outside safer regions at level 3).
  const pp = [];
  if (on(PROTECTION_KEY.BLOCK_SCP_PRIVACY))  pp.push(PP_VALUE.PRIVACY);
  if (on(PROTECTION_KEY.BLOCK_SCP_SECURITY)) pp.push(PP_VALUE.SECURITY);
  if (on(PROTECTION_KEY.BLOCK_SENSORS_NFC))  pp.push(PP_VALUE.SENSORS);
  if (pp.length) {
    const action = appendHeader("Permissions-Policy", pp.join(", "));
    rules.push(rule(group, ID.HDR_PP_MAIN, PRIORITY.HEADERS, action, cond(mainScope(group), outsideSafe, { resourceTypes: ["main_frame"] })));
    rules.push(rule(group, ID.HDR_PP_SUB,  PRIORITY.HEADERS, action, cond(subScope(group),  outsideSafe, { resourceTypes: ["sub_frame"] })));
  }
  // 16: sandbox CSP (outside safer regions at level 3).
  if (on(PROTECTION_KEY.BLOCK_REDIRECTS_DIALOGS)) {
    const action = appendHeader("Content-Security-Policy", SANDBOX_CSP_VALUE);
    rules.push(rule(group, ID.HDR_CSP_MAIN, PRIORITY.HEADERS, action, cond(mainScope(group), outsideSafe, { resourceTypes: ["main_frame"] })));
    rules.push(rule(group, ID.HDR_CSP_SUB,  PRIORITY.HEADERS, action, cond(subScope(group),  outsideSafe, { resourceTypes: ["sub_frame"] })));
  }
  // 9: high-risk sites get the privacy + security Permissions-Policy on page and frames.
  if (on(PROTECTION_KEY.BLOCK_HIGH_RISK_EVAL)) {
    const hosts = group.kind === GROUP_KIND.LOCKED
      ? HIGH_RISK_HOSTNAMES.filter((h) => group.sites.includes(h))
      : HIGH_RISK_HOSTNAMES.filter((h) => !group.sites.includes(h));
    if (hosts.length) {
      rules.push(rule(group, ID.HDR_HIGH_RISK, PRIORITY.HEADERS,
        appendHeader("Permissions-Policy", `${PP_VALUE.PRIVACY}, ${PP_VALUE.SECURITY}`),
        { requestDomains: hosts, resourceTypes: ["main_frame", "sub_frame"] }));
    }
  }
  return rules;
}

// ── Level (third-party) rules ────────────────────────────────────────────────
function builtinAllowRules(group) {
  const sub = subScope(group);
  const tp = { domainType: "thirdParty" };
  const out = [];
  if (BUILTIN_BOTH.length)        out.push(rule(group, ID.BUILTIN_ALLOW_BOTH,   PRIORITY.BUILTIN_ALLOW, ALLOW, cond(sub, tp, { requestDomains: [...BUILTIN_BOTH],        resourceTypes: [...RT.CODE] })));
  if (BUILTIN_SCRIPT_ONLY.length) out.push(rule(group, ID.BUILTIN_ALLOW_SCRIPT, PRIORITY.BUILTIN_ALLOW, ALLOW, cond(sub, tp, { requestDomains: [...BUILTIN_SCRIPT_ONLY], resourceTypes: ["script"] })));
  if (BUILTIN_FRAME_ONLY.length)  out.push(rule(group, ID.BUILTIN_ALLOW_FRAME,  PRIORITY.BUILTIN_ALLOW, ALLOW, cond(sub, tp, { requestDomains: [...BUILTIN_FRAME_ONLY],  resourceTypes: ["sub_frame"] })));
  return out;
}

function levelRules(group, safeTlds, opts) {
  const L = group.level;
  const sub = subScope(group);
  const tp = { domainType: "thirdParty" };
  const rules = [];
  if (L < LEVEL.MILD) return rules;

  if (L === LEVEL.STRICT) {                                              // L5: scripts + frames, no exceptions
    rules.push(rule(group, ID.L5_BLOCK_CODE, PRIORITY.STRICT_BLOCK, BLOCK, cond(sub, tp, { resourceTypes: [...RT.CODE] })));
    return rules;
  }
  // (L2+ abused-TLD block = protection 11, built in protectionRules.)

  if (L === LEVEL.MEDIUM) {
    rules.push(rule(group, ID.L3_BLOCK_CODE, PRIORITY.LEVEL_BLOCK, BLOCK, cond(sub, tp, { resourceTypes: [...RT.CODE] })));
    if (saferRegionsApply(L) && safeTlds.length) {
      rules.push(rule(group, ID.SAFEZONE_ALLOW, PRIORITY.SAFEZONE_ALLOW, ALLOW, cond(sub, tp, { requestDomains: safeTlds, resourceTypes: [...RT.CODE] })));
    }
    rules.push(...builtinAllowRules(group));
  }

  if (L === LEVEL.HIGH) {
    rules.push(rule(group, ID.L4_BLOCK_CODE, PRIORITY.LEVEL_BLOCK, BLOCK, cond(sub, tp, { resourceTypes: [...RT.CODE] })));
    const cdnMatch = opts.cdnRegexSupported
      ? { regexFilter: CDN_HOST_REGEX, isUrlFilterCaseSensitive: false }
      : { urlFilter: CDN_URL_FILTER_FALLBACK };
    rules.push(rule(group, ID.CDN_ALLOW, PRIORITY.CDN_ALLOW, ALLOW, cond(sub, tp, cdnMatch, { resourceTypes: [...RT.CODE] })));
    rules.push(...builtinAllowRules(group));
  }
  return rules;
}

// ── Show Matrix overrides (always global — every site) ───────────────────────
// Script → resource type "script" from `domain`; Frame → "sub_frame" (4.2: two independent
// columns; disjoint types, so they never compete and share one priority). No initiatorDomains
// filter: an override applies on every first-party site (uMatrix / 3P-Matrix-lite model).
// PRIORITY.MATRIX outranks every level/security rule; only the L5 code block (higher) beats
// it, which is how "no matrix allows at level 5" is enforced.
export function buildMatrixRules(state) {
  const rules = [];
  const overrides = state.matrixRules[MATRIX_SITE_ALL] || {};
  let n = 0;
  for (const [domain, entry] of Object.entries(overrides)) {
    for (const scope of Object.values(MATRIX_SCOPE)) {
      const action = entry[scope];
      if (action !== MATRIX_ACTION.BLOCK && action !== MATRIX_ACTION.ALLOW) continue;
      if (n >= MATRIX_RULES_MAX) return rules;                      // guard: never overflow the band
      const condition = { requestDomains: [domain], domainType: "thirdParty", resourceTypes: [MATRIX_SCOPE_RESOURCE_TYPE[scope]] };
      rules.push({ id: MATRIX_RULE_ID_BASE + n, priority: PRIORITY.MATRIX, action: { type: action }, condition });
      n++;
    }
  }
  return rules;
}

// ── Public ───────────────────────────────────────────────────────────────────
export function buildDynamicRules(state, opts = {}) {
  const safeTlds = state.safeZone.tlds.slice();
  const rules = [];
  for (const group of ruleGroups(state)) {
    if (group.level < LEVEL.MILD) continue;              // L1 = no rules at all
    rules.push(...protectionRules(state, group));
    rules.push(...headerRules(state, group, safeTlds));
    rules.push(...levelRules(group, safeTlds, opts));
  }
  rules.push(...buildMatrixRules(state));
  return rules;
}

const BUILTIN_ALLOW_LOCAL_IDS = new Set([ID.BUILTIN_ALLOW_SCRIPT, ID.BUILTIN_ALLOW_FRAME, ID.BUILTIN_ALLOW_BOTH]);
export function isLevelMechanismRule(r) {
  return r.id < MATRIX_RULE_ID_BASE && !BUILTIN_ALLOW_LOCAL_IDS.has(r.id % GROUP_ID_STRIDE);
}

export function collectRegexes(rules) {
  return [...new Set(rules.map((r) => r.condition.regexFilter).filter(Boolean))];
}
