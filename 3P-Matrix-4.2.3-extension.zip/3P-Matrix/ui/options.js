// ── ui/options.js — options page controller ───────────────────────────────────
// DNS check choice, allow list (= sites locked at level 1), settings backup.
// Every change round-trips through the service worker; every outcome — success or failure — is
// shown in that section's status line (ui/status-line.js), never left in the console only.
// ─────────────────────────────────────────────────────────────────────────────

import * as M from "../data/message-types.js";
import { DNS_NONE } from "../data/constants.js";
import { fillDerivedText } from "./derived-text.js";
import { showStatus, showError, releaseStatus } from "./status-line.js";

// ── Settings (one place) ─────────────────────────────────────────────────────
const EXPORT_FILE_NAME = "3p-matrix-settings.json";
const EXPORT_MIME = "application/json";
const EXPORT_JSON_INDENT = 2;
const RESET_CONFIRM_TEXT = "Reset every 3P Matrix setting to its default?";

// ── Page state (guarded: null until the first model arrives) ─────────────────
let model = null;                      // last options model

function $(id) { return document.getElementById(id); }

function send(type, extra = {}) {
  return chrome.runtime.sendMessage({ type, ...extra })
    .then((res) => { if (!res || !res.ok) throw new Error(res && res.error || "no response"); return res.data; });
}

function fillSelect(sel, value) {
  sel.replaceChildren(...model.providers.map((p) => {
    const o = document.createElement("option");
    o.value = p.id;
    o.textContent = p.host ? `${p.label} — ${p.host}` : p.label;
    o.selected = p.id === value;
    return o;
  }));
}

function render() {
  if (!model) return;
  fillSelect($("dnsFirst"), model.dns.first);
  fillSelect($("dnsSecond"), model.dns.second);
  $("allowList").value = model.allowList;
}

async function saveDns() {
  const wantedSecond = $("dnsSecond").value;
  try {
    model = await send(M.MSG_SET_DNS, { first: $("dnsFirst").value, second: wantedSecond });
    render();
    const cleared = model.dns.second === DNS_NONE && wantedSecond !== DNS_NONE;
    showStatus($("dnsStatus"), cleared ? "Second check cleared — it was the same as the first." : "Saved.");
  } catch (e) { showError($("dnsStatus"), e); }
}

async function saveAllowList() {
  try {
    model = await send(M.MSG_SET_ALLOW_LIST, { text: $("allowList").value });
    render();
    showStatus($("allowStatus"), "Allow list saved.");
  } catch (e) { showError($("allowStatus"), e); }
}

async function exportSettings() {
  let url = null;
  try {
    const data = await send(M.MSG_EXPORT_SETTINGS);
    url = URL.createObjectURL(new Blob([JSON.stringify(data.file, null, EXPORT_JSON_INDENT)], { type: EXPORT_MIME }));
    const a = document.createElement("a");
    a.href = url; a.download = EXPORT_FILE_NAME; a.click();
    showStatus($("ioStatus"), `Saved: ${data.summary}`);
  } catch (e) {
    showError($("ioStatus"), e, "Not saved");
  } finally {
    if (url) setTimeout(() => URL.revokeObjectURL(url), 0);    // release the blob on every path
  }
}

async function importSettings(e) {
  const file = e.target.files && e.target.files[0];
  e.target.value = "";                                      // allow choosing the same file again
  if (!file) return;
  try {
    model = await send(M.MSG_IMPORT_SETTINGS, { settings: JSON.parse(await file.text()) });
    render();
    showStatus($("ioStatus"), `Restored: ${model.summary}`);
  } catch (err) { showError($("ioStatus"), err, "Not restored"); }
}

async function resetSettings() {
  if (!confirm(RESET_CONFIRM_TEXT)) return;
  try {
    model = await send(M.MSG_RESET_SETTINGS);
    render();
    showStatus($("ioStatus"), "All settings reset.");
  } catch (e) { showError($("ioStatus"), e, "Not reset"); }
}

document.addEventListener("DOMContentLoaded", async () => {
  fillDerivedText(document);
  $("dnsFirst").addEventListener("change", saveDns);
  $("dnsSecond").addEventListener("change", saveDns);
  $("allowSave").addEventListener("click", saveAllowList);
  $("allowRevert").addEventListener("click", () => { if (model) $("allowList").value = model.allowList; });
  $("exportAll").addEventListener("click", exportSettings);
  $("importAll").addEventListener("click", () => $("importFile").click());
  $("importFile").addEventListener("change", importSettings);
  $("resetAll").addEventListener("click", resetSettings);
  try {
    model = await send(M.MSG_GET_OPTIONS);
    render();
  } catch (e) { showError($("dnsStatus"), e, "Could not load the settings"); }
});

window.addEventListener("pagehide", releaseStatus);          // release status timers with the page
