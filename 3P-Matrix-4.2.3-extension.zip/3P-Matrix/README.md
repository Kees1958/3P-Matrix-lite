# 3P Matrix — content firewall (4.2.3)

Chrome MV3 extension combining 3P-Matrix-lite (UI, levels, lock level, startup level),
uBlock Stripped Dynamic (privacy & security protections, allow list) and DownloadSentinel
(domain heuristics). Spec: project doc `claude/SPEC_levels_and_protections.md`.

Load unpacked: `chrome://extensions` → Developer mode → Load unpacked → this folder.

## Levels (cumulative)
| L | Third-party content | Protections |
|---|---|---|
| 1 | everything allowed | none |
| 2 | 3P scripts + frames from 445 abused TLDs blocked (protection 11) | 1–11 (every site; 10 = suspicious-site warnings, 11 = abused TLDs) |
| 3 | 3P scripts + frames blocked except safer regions + built-in whitelist | + 12–16 (outside safer regions) |
| 4 | 3P scripts + frames blocked; built-in whitelist + "cdn" hosts allowed | 1–16 on every site |
| 5 | 3P scripts + frames blocked, no exceptions (no whitelist, cdn or Show Matrix allows) | 1–16 on every site |
Since 4.2.0 no level ever blocks third-party images, video, fonts or stylesheets.
Default startup level: 2. The safer-regions TLD list only has an effect at level 3
(data/constants.js `SAFER_REGIONS_LEVELS`); the popup shows its editor only there. Its country codes are
added with the fixed Continent scope, as in uBlock Stripped Dynamic (`SAFER_REGIONS_AUTO_MODE`; no slider).

## Layout
```
manifest.json
background.js            lifecycle, event listeners, thin message router (input checks + delegation only)
data/
  constants.js           EVERY switch, ID, priority, score, threshold, colour, timeout, storage key
  protections.js         registry of the 16 selectable protections (single source of truth)
  state-storage.js       state schema, normalizeState() validation, storage, withStateLock() guard
  message-types.js       runtime message names
  builtin-domains.js     built-in whitelist (script / frame / both) — payment/SSO/CAPTCHA/video/JS libs
                         + streaming/meeting/gaming embeds; also exempts protections 9/12–16
                         on a first-party visit, at levels 3–4 only; its payment hosts
                         (BUILTIN_PAYMENT) are also exempt from protection 1 there
  spam-tlds.js           GENERATED — HaGeZi abused TLDs (tools/build-spam-tlds.mjs)
  suspicious-hosting.js  DDNS / free-hosting domains (protection 6)
  network-data.js        high-risk sites, local-network patterns
  tld-constants.js, country-data.js   safer-regions (TLD whitelist) tables from 3P-Matrix-lite
core/
  policy.js              pure: effective level, active protections, rule groups
  rule-builder.js        pure: state → dynamic DNR rules
  script-builder.js      pure: state → content-script registrations
  apply-manager.js       the only module that writes rules/scripts to Chrome (serialized, regex-validated)
  site-scorer.js         stage 1: local heuristics (DownloadSentinel modules)
  online-checks.js       stage 2: RDAP domain age + two DoH threat-intel resolvers (timeouts, cache)
  site-locks.js          lock / unlock / allow list (pure; allow list = sites locked at level 1)
  matrix-overrides.js    Show Matrix overrides — set / clear, always global (pure)
  matrix-windows.js      Show Matrix panel windows — open, focus, close with tab/timeout
  view-models.js         the data each page receives (popup, Show Matrix, options)
  navigation-guard.js    protection 10: top-level navigation check → warning dialog; "continue once"
  badge.js               per-tab blocked count + risk colour + level icon
  rule-matcher.js        replays DNR matching on our own rules → badge counts only 3P Matrix's blocks
  connection-matrix.js   Show Matrix: per-tab observation of third-party connections
  matrix-disposition.js  Show Matrix: per-row policy decision (script/frame, level mode, whitelist)
  tab-sites.js           per-tab top-level host — stand-in for opaque ("null") initiators
  safer-regions.js, tld-engine.js   safer-regions computation (3P-Matrix-lite engine)
security/                content scripts (MAIN world) — uBlock Stripped Dynamic 10.2.1 + sec-nfc.js
lib/downloadsentinel/    DownloadSentinel 3.0.4 heuristics (2 marked patches: subdomain count, port family)
ui/                      popup, warning dialog, options page
  derived-text.js        every level / protection number / count / threshold a page shows, derived from
                         constants + registry (C39a; HTML uses data-derived placeholders)
util/domain.js           hostname helpers (one registered-domain function, PSL-based)
ui/status-line.js        the one way pages show an action's outcome ("Saved." / "Not saved: …")
LICENSE.txt, THIRD_PARTY_LICENSES.md   GPLv3 + third-party notices (4.2.3)

Tools (separate 3P-Matrix-tools folder, next to this one; npm install there first):
  npm run check            the full check suite (complete-check.mjs) — run before every release
  build-spam-tlds.mjs      regenerates data/spam-tlds.js from spam-tlds-ublock.txt (--check: verify only)
  update-top-sites.mjs     rebuilds the CrUX top-sites filter — once per minor release (4.2 → 4.3);
                           npm run check fails on a minor bump until it has run (data-sources.json)
  package-release-state.mjs  writes package-release-state.json when packaging
```

## Rule groups
Rules are built per *group*, not per site: group 0 = global level (excludes every locked
site), groups 1–5 = all sites locked at that level. Rule id = 10000 × group + local id
(`RULE_LOCAL_ID` in constants). The rule count stays the same however many sites are locked.

## Show Matrix (0.2.0; global overrides since 4.1.0; 3P-Matrix-lite layout and model since 4.2.1)
Popup → Show Matrix opens a panel window for the current tab, reloads the tab and lists every
third-party domain it contacts (a "cdn" subdomain of a non-cdn domain, or a host that is itself a
built-in entry, gets its own row). Columns, as in 3P-Matrix-lite 4.0.2: Internal whitelist ·
Level mode · image · media · stylesheet · SCRIPT · FRAME · fetch/xhr · other · requests.
SCRIPT / FRAME show the policy's real decision (green allow, red block), replayed through the
rules Chrome has (core/matrix-disposition.js + core/rule-matcher.js) — not what was observed.
Level mode = the level's own rules without built-in allows or overrides (grey when something
else decides). Click a SCRIPT/FRAME square: set the opposite as an override; click again: clear.
An override always applies on every site, as in uMatrix / 3P-Matrix-lite (matrixRules key
`MATRIX_SITE_ALL = "*"`). Per-site keys from 0.2.x are merged into the global list on load (4.2.3).
Overrides outrank every level/security rule; only the L5 code block beats them. Stored in
state.matrixRules, DNR ids 900000+ (core/connection-matrix.js, core/matrix-disposition.js,
core/rule-builder.js buildMatrixRules, ui/matrix.*, priority data/constants.js PRIORITY.MATRIX).

## Not in this prototype
- Remote list updates (HaGeZi, hosting list) — the generator script exists; no auto-update.

## Sources & licences
Licence: GPLv3 (`LICENSE.txt`); every bundled component and its licence: `THIRD_PARTY_LICENSES.md`.
- 3P-Matrix-lite 4.0.2, uBlock Stripped Dynamic 10.2.1 (GPLv3, based on uBlock Origin Lite),
  DownloadSentinel 3.0.4 — Kees1958 and co-authors.
- HaGeZi DNS blocklists (abused TLDs, DynDNS) — see github.com/hagezi/dns-blocklists for licence.
