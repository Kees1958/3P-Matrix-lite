// ── core/download-guard.js ────────────────────────────────────────────────────
// Protection 12 "Warn when a downloaded file looks risky" (4.3.0) — DownloadSentinel's (3.3.1 since 4.3.7; 3.3.0 in 4.3.4–4.3.6) download
// protection, ported from its background.js (C21: same two-listener model, same time budget, same
// re-check rules; only settings, logging and the "is it active here" gate are 3P Matrix's).
//
// Model (DownloadSentinel V2.0+): an information/warning tool, never a blocker — the download always
// completes; nothing is paused, resumed or cancelled.
//   onCreated  → monitored file type? start host reputation (DNS threat-intel + RDAP + lists + URL /
//                filename heuristics) and, with a key, the VirusTotal URL check; record startedAt
//   onChanged  → download complete: wait what is left of DS_APP.VT_WAIT_BUDGET_MS, re-check with the
//                confirmed filename/size, combine the scores, then stay silent ("Silent when probably
//                safe") or open the warning window (ui/download-warning.html)
//
// Public interface (called by background.js only):
//   init()                          — idempotent: sweep alarm (4.3.4: no remote list refresh — DS item 18)
//   onCreated(item, state)          — chrome.downloads.onCreated body
//   onChanged(delta, state)         — chrome.downloads.onChanged body
//   onErased(downloadId)            — chrome.downloads.onErased body (release)
//   onAlarm(alarm)                  — chrome.alarms.onAlarm body (stale-entry sweep)
//   onWindowRemoved(windowId)       — a warning window was closed without a button (release)
//   pageModel(downloadId, state)    — what the warning page renders: { record, look } or null
//   dismiss(downloadId)             — the user is done with the warning (release)
//   offerVtKey(state)               — browser start: open the VirusTotal-key nudge when DS would
//   blockedModel(downloadId)        — what the "download blocked" notice renders, or null (protection 18)
//   blockedAction(downloadId, act)  — notice button: OK (release) or DOWNLOAD_ANYWAY (start once more;
//                                     protection 12 then always checks that download)
//
// Protection 18 "Block risky downloads" (4.3.2, off by default): a monitored file type (the same
// classifyDownload() gate as protection 12) from a page outside safer regions (level 3) or from any page
// (levels 4–5) is cancelled at once — before protection 12's check, which is then not needed — and a
// small notice window explains it. "Download anyway" puts the URL on a one-time pass (_bypass, short-
// lived) and downloads it again; that new download skips protection 18 and is ALWAYS checked by
// protection 12 (even when 12 is unticked or its level is lower), as the user asked for the check.
//
// State owned (in memory only — lost on a service-worker restart, as in DownloadSentinel: a lost
// record means the late-entry path re-checks at completion, never a silent pass):
//   _pending  Map<downloadId, record>  — bounded: swept every DS_APP.SWEEP_ALARM_PERIOD_MINUTES,
//                                        max age DS_APP.ENTRY_MAX_AGE_MS; released on dismiss/erase
//   _checked  Set<downloadId>          — onChanged fires several times per download: dedup guard
//   _windows  Map<windowId, downloadId> — open warning / blocked-notice windows; released when closed
//   _blocked  Map<downloadId, notice>  — blocked downloads awaiting the user's choice (released with the
//                                        notice window, its buttons, erase or the sweep)
//   _bypass   Map<url, expiresAt>      — "Download anyway" one-time passes; capped DOWNLOAD_BYPASS_CAP,
//                                        expire after DOWNLOAD_BYPASS_TTL_MS, consumed on first use
//   _forced   Set<downloadId>          — downloads started by "Download anyway": protection 12 always runs
// Every release path goes through release(): record, dedup entry, window link and in-flight VirusTotal
// request (BrowserProtection.abandonPendingRequests) together — no partial cleanup.
// ─────────────────────────────────────────────────────────────────────────────

import { LOG_PREFIX, DOWNLOAD_WARNING_PAGE, DOWNLOAD_ID_PARAM, DOWNLOAD_WARNING_TITLE_DEFAULT,
         DOWNLOAD_BLOCKED_PAGE, DOWNLOAD_BLOCKED_WINDOW, DOWNLOAD_BYPASS_TTL_MS, DOWNLOAD_BYPASS_CAP,
         VT_KEY_PROMPT_PAGE, VT_KEY_PROMPT_WINDOW, CHROME_DOWNLOAD_COMPLETE } from "../data/constants.js";
import { APP as DS_APP } from "../lib/downloadsentinel/util/AppConstants.js";
import { ScoringEngineV2 } from "../lib/downloadsentinel/protection/ScoringEngineV2.js";
import { BrowserProtection } from "../lib/downloadsentinel/protection/BrowserProtection.js";
import { FilenameAnalysis } from "../lib/downloadsentinel/util/FilenameAnalysis.js";
import { DownloadShape } from "../lib/downloadsentinel/util/DownloadShape.js";   // 4.4.0: DS 3.5.0 R1/R4 + delivery context
import { dsSettingsView, vtKeyIsSet, isDownloadCheckActive, isTrustedDownload, shouldOfferVtKey,
         downloadBlockReason, downloadSiteHost, isPageMadeDownload } from "./download-settings.js";
import { BLOCKED_DOWNLOAD_ACTION, MSG_DOWNLOAD_VT_UPDATE } from "../data/message-types.js";

// ── Settings (one place) ─────────────────────────────────────────────────────
const COMBINED_MIN = -100, COMBINED_MAX = 100;   // DownloadSentinel's combined (VT + host) score range
const WINDOW_TYPE_POPUP = "popup";
const WINDOW_STATE_MAXIMIZED = "maximized";      // DownloadSentinel opens its warning maximized
const DOWNLOAD_CONFLICT_ACTION = "uniquify";      // "Download anyway": never overwrite a file with the same name
const DOWNLOAD_EXT_DESKTOP = "desktop";          // DS-H001 Linux launcher (FilenameAnalysis.classifyDownload)

// ── State (see header) ───────────────────────────────────────────────────────
const _pending = new Map();
const _checked = new Set();
const _windows = new Map();
const _blocked = new Map();
const _bypass = new Map();
const _forced = new Set();
let _initialized = false;

// DownloadSentinel 3.3.0 releaseDownload() (item 16): a silent VirusTotal retry still in flight is never
// aborted because the window closed — the record stays (flagged windowClosed) until handleLateVtResult()
// settles it or the retry gives up (it releases its own request); the sweep is the last-resort release.
function release(downloadId, reason) {
  if (BrowserProtection.isVtPending(downloadId) && _pending.has(downloadId)) {
    _pending.get(downloadId).windowClosed = true;
  } else {
    _pending.delete(downloadId);
    BrowserProtection.abandonPendingRequests(downloadId, reason);
  }
  _checked.delete(downloadId);
  _blocked.delete(downloadId);
  _forced.delete(downloadId);
  for (const [windowId, id] of _windows) if (id === downloadId) _windows.delete(windowId);
}

// 4.4.0 (DS 3.5.0 R1): a download that turned out NOT to need a warning after all (an extensionless binary
// that got an ordinary file name at completion). _checked is kept so onChanged keeps ignoring the id; the
// sweep / onErased clean it as before. Any VirusTotal request in flight is aborted.
function releaseWithoutWarning(downloadId, reason) {
  _pending.delete(downloadId);
  BrowserProtection.abandonPendingRequests(downloadId, reason);
}

// Force-release (sweep, erase): the record goes even with a retry in flight, and the request is aborted.
function releaseAll(downloadId, reason) {
  _pending.delete(downloadId);
  BrowserProtection.abandonPendingRequests(downloadId, reason);
  release(downloadId, reason);
}

// ── Lifecycle ────────────────────────────────────────────────────────────────
export function init() {
  if (_initialized) return;
  _initialized = true;
  // Idempotent alarm: get before create, so a service-worker restart never makes a second one.
  chrome.alarms.get(DS_APP.SWEEP_ALARM_NAME)
    .then((a) => { if (!a) return chrome.alarms.create(DS_APP.SWEEP_ALARM_NAME, { periodInMinutes: DS_APP.SWEEP_ALARM_PERIOD_MINUTES }); return undefined; })
    .catch((e) => console.error(LOG_PREFIX, "download sweep alarm:", e));
  // 4.3.4: DownloadSentinel 3.3.0 removed its remote list refresh (FilterDataLoader, item 18) — the bundled
  // lists are the only source; nothing polls a URL any more.
}

export function onAlarm(alarm) {
  if (!alarm || alarm.name !== DS_APP.SWEEP_ALARM_NAME) return;
  const cutoff = Date.now() - DS_APP.ENTRY_MAX_AGE_MS;
  for (const [id, r] of _pending) if ((r.startedAt || 0) < cutoff) releaseAll(id, "stale entry swept");
  for (const id of _checked) if (!_pending.has(id)) _checked.delete(id);   // orphaned by a SW restart
  for (const [id, b] of _blocked) if (b.blockedAt < cutoff) release(id, "stale notice swept");
  pruneBypass();
}

export function onErased(downloadId) { releaseAll(downloadId, "download erased"); }

export function onWindowRemoved(windowId) {
  const id = _windows.get(windowId);
  if (id !== undefined) release(id, "warning window closed");
}

export function dismiss(downloadId) { release(downloadId, "user dismissed"); }

// ── Record helpers (DownloadSentinel background.js, unchanged logic) ─────────
// The settings a record freezes at download start (DS buildSettingsSnapshot): later setting changes do
// not alter a check already running.
function settingsSnapshot(state) {
  const s = dsSettingsView(state);
  return {
    fpLevel:            s.fpReductionLevel,
    autoAllow:          s.autoAllow,
    autoAllowThreshold: s.autoAllowThreshold,
    vtApiKeySet:        vtKeyIsSet(state),
    dnsFirst:           s.dnsFirst,
    dnsSecond:          s.dnsSecond
  };
}

function emptyVt() {
  return { vtDone: false, vtScore: null, vtConfidence: null, vtBreakdown: null, vtHardRule: null,
           vtRawStats: null, vtFilteredStats: null, vtFpLevel: null };
}

// 4.4.0: last argument = DS 3.5.0 downloadContext { visibleExt, isUnknownBinary, fpLevel } from the record.
function hostReputation(r, ext, totalBytes, obfuscation, filename, sizeKnown, isLinuxLauncher) {
  return BrowserProtection.checkHostReputation(
    r.url, r.fileType, ext, r.mime, totalBytes, r.originalUrl, r.isScript, obfuscation,
    FilenameAnalysis.getDoubleExtension(filename), isLinuxLauncher, filename, sizeKnown, r.referrer,
    { first: r.dnsFirst, second: r.dnsSecond }, DownloadShape.contextOf(r));
}

function applyVtResult(r, result) {
  r.vtDone          = true;
  r.vtScore         = result?.score           ?? null;
  r.vtConfidence    = result?.confidence      ?? null;
  r.vtBreakdown     = result?.breakdown       ?? null;
  r.vtHardRule      = result?.hardRuleApplied ?? null;
  r.vtRawStats      = result?.rawStats        ?? null;
  r.vtFilteredStats = result?.filteredStats   ?? null;
  r.vtFpLevel       = result?.fpLevel         ?? null;
}

function originalUrlOf(item, url) { return (item.url && item.url !== url) ? item.url : url; }

async function searchItem(downloadId) {
  try { return (await chrome.downloads.search({ id: downloadId }))[0] || null; }
  catch (e) { console.warn(LOG_PREFIX, "downloads.search:", e); return null; }
}

// ── onCreated — start the checks, record the start time ──────────────────────
export function onCreated(item, state) {
  if (!item) return;
  // Guard: a tiny download can complete before this handler's state load resolved — onChanged then
  // already built a late-entry record (or blocked it); a second pass would double checks and windows.
  if (_checked.has(item.id) || _pending.has(item.id) || _blocked.has(item.id)) return;
  if (consumeBypass(item.url)) _forced.add(item.id);               // "Download anyway": skip 18, always check
  else if (blockIfNeeded(item, state)) return;                     // protection 18
  if (!_forced.has(item.id) && !isDownloadCheckActive(state, item)) return;
  const url = item.finalUrl || item.url || "";
  if (!url || isTrustedDownload(state, item)) return;
  const c = FilenameAnalysis.classifyDownload(url, item.url || "", item.filename || "", item.mime);
  if (!c) return;                                                   // not a monitored file type

  const record = {
    id: item.id, startedAt: Date.now(),                            // before the calls: budget covers setup
    url, originalUrl: originalUrlOf(item, url),
    ext: c.ext, fileType: c.fileType, isScript: c.isScript,
    visibleExt: c.visibleExt, isUnknownBinary: c.isUnknownBinary,   // 4.4.0: R4 input / R1 (re-checked in onChanged)
    filename: item.filename || "", mime: item.mime || "", totalBytes: item.totalBytes || 0,
    referrer: item.referrer || null,
    sizeKnown: (item.totalBytes || 0) > 0,                          // Chrome often reports 0 at creation
    ...emptyVt(),
    hostDone: false, hostResult: null,
    ...settingsSnapshot(state)
  };
  _pending.set(item.id, record);

  hostReputation(record, c.ext, record.totalBytes, null, record.filename, record.sizeKnown, c.isLinuxLauncher)
    .then((hostResult) => { const r = _pending.get(item.id); if (r) { r.hostDone = true; r.hostResult = hostResult; } })
    .catch((e) => console.warn(LOG_PREFIX, "download host reputation:", e));

  const s = dsSettingsView(state);
  if (!record.vtApiKeySet || !s.virusTotalEnabled) { record.vtDone = true; return; }   // no key / VT off: done
  // DS 3.3.0: settings passed in (item 12); a first-attempt timeout gets one silent retry (item 16).
  BrowserProtection.checkIfUrlIsMalicious(item.id, url, (result) => {
    const r = _pending.get(item.id);
    if (r) applyVtResult(r, result);
  }, record.originalUrl, s, (result) => handleLateVtResult(item.id, result));
}

// ── DS 3.3.0 item 16: a VirusTotal verdict that arrives after the first timeout already said "unknown" ──
// Window still open → push it live into the page (MSG_DOWNLOAD_VT_UPDATE). Window already closed → reopen
// only when the verdict is WORSE than what the user saw; otherwise release silently.
function handleLateVtResult(downloadId, result) {
  const record = _pending.get(downloadId);
  if (!record) return;                                             // released for good (sweep / erase)
  applyVtResult(record, result);
  const previous = record.combinedScore;                          // undefined while the page has not opened yet
  const { combined, scaledHostScore, fpMultiplier, vtUnknown } = computeCombinedScore(record);
  if (previous === undefined) return;                              // onChanged has not decided yet: it will use this
  Object.assign(record, { combinedScore: combined, scaledHostScore, fpMultiplier, vtUnknown });
  if (!record.windowClosed) {
    chrome.runtime.sendMessage({ type: MSG_DOWNLOAD_VT_UPDATE, downloadId, record: JSON.parse(JSON.stringify(record)) })
      .catch(() => { /* the page closed in between — its window-close release handles the record */ });
    return;
  }
  if (combined < previous) { record.windowClosed = false; openWarningWindow(downloadId); }   // escalation only
  else releaseAll(downloadId, "late VirusTotal result — no escalation");
}

// DownloadSentinel computeCombinedScore(): VirusTotal unknown → negative heuristic signals scaled by the FP
// level; combined = VT + (scaled) host, clamped to the score range. 4.4.0: the scaling itself is DS 3.5.0's
// shared ScoringEngineV2.scaleHostScoreForUnknownVt() (same function DS and its fp-sweep use).
function computeCombinedScore(record) {
  const vtUnknown = record.vtDone && record.vtScore === null;
  const hostScore = record.hostResult?.score ?? 0;
  const { scaled: scaledHostScore, multiplier: fpMultiplier } =
    ScoringEngineV2.scaleHostScoreForUnknownVt(hostScore, record.fpLevel, vtUnknown);
  const combined = Math.max(COMBINED_MIN, Math.min(COMBINED_MAX, (record.vtScore ?? 0) + scaledHostScore));
  return { combined, scaledHostScore, fpMultiplier, vtUnknown };
}

// ── Late entry: the filename was unknown at onCreated (redirect chains, e.g. Google Drive) ──────────
async function lateEntryRecord(item, state) {
  if (!item || (!_forced.has(item.id) && !isDownloadCheckActive(state, item))) return null;
  const downloadId = item.id;
  const url = item.finalUrl || item.url || "";
  if (!url || isTrustedDownload(state, item)) return null;
  const filename = item.filename || "";
  const c = FilenameAnalysis.classifyDownload(url, item.url || "", filename, item.mime);
  if (!c) return null;
  // What did the ORIGINAL url suggest? (unfiltered extension — DS-H007 category change)
  const suggestedExt = FilenameAnalysis.getRawExt(FilenameAnalysis.extractFilenameFromUrl(item.url || ""));
  const obfuscation = isPageMadeDownload(item.url) ? null : FilenameAnalysis.getObfuscationSignal(suggestedExt, c.ext);
  const record = {
    id: downloadId, startedAt: Date.now(), url, originalUrl: originalUrlOf(item, url),
    ext: c.ext, confirmedExt: c.ext, confirmedFilename: filename, fileType: c.fileType, isScript: c.isScript,
    visibleExt: c.visibleExt, isUnknownBinary: c.isUnknownBinary,   // 4.4.0: filename already confirmed here
    filename, mime: item.mime || "", totalBytes: item.fileSize || 0, referrer: item.referrer || null,
    sizeKnown: true,                                               // complete: fileSize is final
    ...emptyVt(), vtDone: true, vtUnknown: true,                   // no budget left for VirusTotal
    hostDone: false, hostResult: null,
    ...settingsSnapshot(state),
    state: CHROME_DOWNLOAD_COMPLETE, lateEntry: true, obfuscation
  };
  record.hostResult = await hostReputation(record, c.ext, record.totalBytes, obfuscation, filename, true, c.isLinuxLauncher);
  record.hostDone = true;
  _pending.set(downloadId, record);
  return record;
}

// ── onChanged — download complete: wait the rest of the budget, then act ─────
export async function onChanged(delta, state) {
  if (!delta.state || delta.state.current !== CHROME_DOWNLOAD_COMPLETE) return;
  if (_checked.has(delta.id)) return;                             // dedup guard
  _checked.add(delta.id);

  if (_blocked.has(delta.id)) return;                              // protection 18 already handled it
  let record = _pending.get(delta.id);
  if (!record) {
    const item = await searchItem(delta.id);
    if (item && !_forced.has(item.id) && consumeBypass(item.url)) _forced.add(item.id);
    if (item && !_forced.has(item.id) && blockIfNeeded(item, state)) return;   // completed before onCreated ran
    record = await lateEntryRecord(item, state);
  }
  if (!record) { _checked.delete(delta.id); return; }             // not ours: release the guard entry

  const waitLeft = Math.max(0, DS_APP.VT_WAIT_BUDGET_MS - (Date.now() - record.startedAt));
  if (waitLeft > 0) await new Promise((r) => setTimeout(r, waitLeft));
  if (!_pending.has(delta.id)) return;                            // erased/swept while waiting

  // Confirmed filename + size, now that the download is complete.
  const item = await searchItem(delta.id);
  const confirmedFilename   = (item && item.filename) || record.filename;
  const confirmedTotalBytes = (item && item.fileSize) ?? record.totalBytes;

  // 4.4.0 (DS 3.5.0 R1): an extensionless generic binary may have got a real name now — DS's shared
  // decision: ordinary file → no warning; a monitored type → R1 no longer applies, re-score below.
  const shape = DownloadShape.reevaluate(record, confirmedFilename);
  if (shape.outcome === DownloadShape.OUTCOME.RELEASE) {
    releaseWithoutWarning(delta.id, "extensionless binary got an ordinary file name");
    return;
  }
  const shapeChanged = shape.outcome === DownloadShape.OUTCOME.BECAME_KNOWN;
  if (shapeChanged) {
    Object.assign(record, { fileType: shape.classified.fileType, isScript: shape.classified.isScript,
                            visibleExt: shape.classified.visibleExt, isUnknownBinary: false });
  }

  const confirmedExt = FilenameAnalysis.getBlockedExtension(record.url, confirmedFilename) || record.ext;

  // Obfuscation (extension hidden or changed category) and size-newly-known (DS v2.8.0) re-check.
  const obfuscation = record.lateEntry || isPageMadeDownload(record.originalUrl) ? null
    : FilenameAnalysis.getObfuscationSignal(record.ext, confirmedExt);
  const sizeNewlyKnown = !record.lateEntry && !record.sizeKnown && confirmedTotalBytes > 0;
  if ((obfuscation || sizeNewlyKnown || shapeChanged) && record.hostDone) {
    record.hostResult = await hostReputation(record, confirmedExt, confirmedTotalBytes, obfuscation,
                                             confirmedFilename, true, confirmedExt === DOWNLOAD_EXT_DESKTOP);
    record.totalBytes = confirmedTotalBytes;
    record.sizeKnown = true;
  }

  const { combined, scaledHostScore, fpMultiplier, vtUnknown } = computeCombinedScore(record);

  // Stored before the auto-allow decision too: a late VirusTotal verdict (item 16) compares against it, so
  // a silently allowed file still gets a window when VirusTotal later says it is worse.
  Object.assign(record, { confirmedExt, confirmedFilename, scaledHostScore, combinedScore: combined,
                          fpMultiplier, vtUnknown, state: CHROME_DOWNLOAD_COMPLETE });
  // 4.4.0: an extensionless generic binary (R1) always gets the window (DS APP.EXTENSIONLESS_BINARY_ALWAYS_WARN).
  const mustWarn = DownloadShape.mustAlwaysWarn(record);
  if (!mustWarn && record.autoAllow && combined >= record.autoAllowThreshold) { release(delta.id, "auto-allowed"); return; }

  await openWarningWindow(delta.id);
}

function openWarningWindow(downloadId) { return openWindow(DOWNLOAD_WARNING_PAGE, downloadId, null); }

// size null = maximized (DownloadSentinel's warning page); else { width, height }.
async function openWindow(page, downloadId, size) {
  const url = `${chrome.runtime.getURL(page)}?${DOWNLOAD_ID_PARAM}=${encodeURIComponent(downloadId)}`;
  const shape = size ? { width: size.width, height: size.height } : { state: WINDOW_STATE_MAXIMIZED };
  try {
    const win = await chrome.windows.create({ url, type: WINDOW_TYPE_POPUP, ...shape });
    if (win && win.id !== undefined) _windows.set(win.id, downloadId);
  } catch (e) {
    // The user cannot act on a window that did not open: say so and release everything.
    console.error(LOG_PREFIX, "download warning window failed:", e);
    release(downloadId, "warning page open failed");
  }
}

// ── Warning page model ───────────────────────────────────────────────────────
// The record (plain data, C31) plus the page look the user chose in Options. Never the API key.
export function pageModel(downloadId, state) {
  const record = _pending.get(downloadId);
  if (!record) return null;
  const d = state.downloads;
  return {
    record: JSON.parse(JSON.stringify(record)),
    look: { color: { ...d.warningColor }, title: d.warningTitle || DOWNLOAD_WARNING_TITLE_DEFAULT }
  };
}

// ── VirusTotal key nudge (browser start) ─────────────────────────────────────
export async function offerVtKey(state) {
  if (!shouldOfferVtKey(state)) return;
  try {
    await chrome.windows.create({ url: chrome.runtime.getURL(VT_KEY_PROMPT_PAGE), type: WINDOW_TYPE_POPUP,
                                  width: VT_KEY_PROMPT_WINDOW.width, height: VT_KEY_PROMPT_WINDOW.height });
  } catch (e) { console.error(LOG_PREFIX, "VirusTotal key prompt failed:", e); }
}

// ── Protection 18 — block risky downloads (4.3.2) ─────────────────────────────
function pruneBypass() {
  const now = Date.now();
  for (const [url, until] of _bypass) if (until < now) _bypass.delete(url);
}

function consumeBypass(url) {
  pruneBypass();
  if (!url || !_bypass.has(url)) return false;
  _bypass.delete(url);                                              // one time only
  return true;
}

function addBypass(url) {
  pruneBypass();
  _bypass.set(url, Date.now() + DOWNLOAD_BYPASS_TTL_MS);
  while (_bypass.size > DOWNLOAD_BYPASS_CAP) _bypass.delete(_bypass.keys().next().value);   // oldest first
}

// Cancels a monitored download when protection 18 applies; true = blocked (the caller stops there).
function blockIfNeeded(item, state) {
  const reason = downloadBlockReason(state, item);
  if (!reason) return false;
  const url = item.finalUrl || item.url || "";
  const c = url && FilenameAnalysis.classifyDownload(url, item.url || "", item.filename || "", item.mime);
  if (!c) return false;                                             // not a risky file type: never blocked
  // 4.4.0: an extensionless generic binary (DS 3.5.0 R1) is warn-only by decision — legit Linux release
  // binaries look exactly like this — so protection 18 never blocks it; the warning window still opens.
  if (c.isUnknownBinary) return false;
  _blocked.set(item.id, {
    downloadId: item.id, url: item.url || url, filename: item.filename || "", ext: c.ext,
    site: downloadSiteHost(item), reason, blockedAt: Date.now()
  });
  stopDownload(item.id).catch((e) => console.error(LOG_PREFIX, "blocked download could not be stopped:", e));
  openWindow(DOWNLOAD_BLOCKED_PAGE, item.id, DOWNLOAD_BLOCKED_WINDOW);
  return true;
}

// Cancel removes the partial file; a download that already finished (tiny file) is deleted from disk.
async function stopDownload(downloadId) {
  await chrome.downloads.cancel(downloadId);
  const item = await searchItem(downloadId);
  if (item && item.state === CHROME_DOWNLOAD_COMPLETE && item.exists !== false) await chrome.downloads.removeFile(downloadId);
}

export function blockedModel(downloadId) {
  const b = _blocked.get(downloadId);
  return b ? JSON.parse(JSON.stringify(b)) : null;
}

export async function blockedAction(downloadId, action) {
  const b = _blocked.get(downloadId);
  if (!b) throw new Error("this blocked download is no longer active");
  if (action === BLOCKED_DOWNLOAD_ACTION.OK) { release(downloadId, "blocked — OK"); return; }
  if (action !== BLOCKED_DOWNLOAD_ACTION.DOWNLOAD_ANYWAY) throw new Error("unknown action");
  addBypass(b.url);
  release(downloadId, "blocked — download anyway");
  await chrome.downloads.download({ url: b.url, conflictAction: DOWNLOAD_CONFLICT_ACTION });
}
