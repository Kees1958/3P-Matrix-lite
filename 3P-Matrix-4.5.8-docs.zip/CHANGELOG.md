# 3P Matrix — content firewall — changelog

(Started with 4.5.4: earlier docs packages carried no CHANGELOG.md. Technical detail for 4.5.4 is in
PERF_4.5.3_chrome_engine_and_proposals.md section 6 and the principles doc, v13.)

## 4.5.8
- The two DNS checks now default to Control D (first) and DNS4EU Protective (second): together they block more malware than Quad9 + Cloudflare. The same pair applies in every region, France included.
- If you never changed your DNS checks, the update moves you to the new pair once. A pair you picked yourself is kept. (Someone who deliberately picked exactly the old default looks the same as someone who never changed it, and is moved too — pick it again in Options to keep it.)
- A file without an extension from a file-sharing site is now rated "Probably Suspicious" from 32 MB (was 50 MB).
- From 650 MB, such a file gets a stronger warning: "large downloads are often used by malware to evade AV detection". It replaces the separate "exceeds VirusTotal maximum" line for that file, so the same fact is not counted twice. Other large downloads keep the VirusTotal line as before.
- A file from a GitHub/GitLab host that is "currently used to deliver malware" no longer also shows the file-sharing platform line (both said the same thing about the host), and the verdict at the top now matches the score instead of sometimes saying "probably safe".
- That warning now weighs −30 instead of −40: on its own it is "Probably Inconclusive" for a download (the warning still opens); it is a minimum, so the verdict only gets worse when other signals already score lower on their own. For sites: orange badge; the dialog opens from level 2 (Medium) up.

## 4.5.7
- Built-in whitelist: 35 entries added from uBlock Stripped Dynamic's list — meeting apps (Zoom, Google Meet, Jitsi, GoTo …), sign-in (Google, DigiD, eHerkenning, BankID, MitID, itsme, Duo, PingOne) and payment (iDEAL, Mercado Pago, Brazilian banks and acquirers).
- 46 suggested entries rejected, each with its reason (chat and file-upload platforms, closed services, whole game-publisher sites, government portals, messaging apps).

## 4.5.6
- Built-in whitelist reviewed entry by entry: Discord (a chat platform whose file hosts deliver malware), itch.io, Steam Community, OpenAI, FingerprintJS, an insurer and an analytics service removed; several entries moved to the right category.
- Downloads from Discord are checked again.
- Visiting a site that is merely misused for malware delivery (Discord, Telegram, bit.ly, Google Drive …) no longer shows the suspicious-site warning; sites someone created on such platforms still do, and downloads from them stay checked.
- A large file (50 MB or more) without an extension from a file-sharing site is now rated "Probably Suspicious": such files are often padded or packed malware.
- The popup's "Trusted:" line now follows the whitelist's own categories.
- The whitelist is available as JSON (docs: builtin-whitelist.json) for DownloadSentinel and uBlock Stripped Dynamic.

## 4.5.5
- Blocked downloads are now paused instead of deleted: "Download anyway" continues the same download (this also works for SharePoint/OneDrive folder downloads), "OK, cancel" or closing the notice deletes it.
- The blocked-download notice keeps working however long it stays open.
- At levels 1–3 a trusted download domain now also covers files the trusted site serves from another server (for example SharePoint zips); at levels 4–5 only the file's own server counts.
- Options explains at which levels the trusted domains lift the download block.

## 4.5.4
- Faster and lighter: the extension wakes up less often, starts faster, and no longer rewrites its rules when a setting that does not affect them is saved.
- Pages are checked against fewer content-script patterns; the suspicious-site warning appears sooner.
- The badge count, risk colour and "Continue once" are kept while the browser stays open.
- Public Suffix List refreshed; every bundled list can now be rebuilt with this project's own tools.
- Backup files from 0.1.x/0.2.0 and Show Matrix overrides saved by 4.2.2 or older are no longer converted.
