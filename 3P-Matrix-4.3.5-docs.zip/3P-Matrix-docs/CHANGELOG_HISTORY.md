# Changelog History — 3P Matrix — content firewall

Full technical record of releases: what changed, why, how, known limitations and the source worked from.
Policy as in uBlock Stripped Dynamic (Xplainer_Programming_principles_audit_v5.md, B4): written for big
changes only, before the zip. The brief user-facing summary is CHANGELOG.md.

Release packages: `3P-Matrix-<ver>-extension.zip` (folder `3P-Matrix`), `3P-Matrix-<ver>-tools.zip`
(folder `3P-Matrix-tools`), `3P-Matrix-<ver>-docs.zip` (folder `3P-Matrix-docs`, first released with 0.2.2).

Source extensions (all uploaded 2026-10-16): 3P-Matrix-lite 4.0.2, uBlock Stripped Dynamic 10.2.1
(+ tools 2.0.18, docs), DownloadSentinel 3.0.4 (extension + tools). Their change histories are in `sources/`.

---

## 4.3.5 — Options as a popup button

Source worked from: 4.3.4 (same session). User report: complaints that Options does not stand out.
- ui/popup.html: footer link #optionsLink → button #optionsBtn (class action-btn) in .policy-actions; order
  Show Matrix, Protections, Options (user). ui/popup.js opens chrome.runtime.openOptionsPage() on click.
- ui/popup.css: --popup-w 400 → 440 px so the three buttons fit next to "Active policy" (checked in Chromium:
  last button ends at 424 px, no horizontal scroll). The warning dialog's "Options" link is unchanged.

## 4.3.4 — DownloadSentinel 3.3.0 (lib byte-identical) + Corrections-for-3PM.md

Source worked from: 4.3.3 (same session) + DownloadSentinel 3.3.0 zip and Corrections-for-3PM.md (user,
2026-10-21: the DS_ADVICE items implemented one by one in DS, with what 3P Matrix should take over).
- lib/downloadsentinel: replaced by DS 3.3.0 protection/* + util/*, BYTE-IDENTICAL (no 3P Matrix patch).
  Settings.js / Storage.js / MessageTypes.js not vendored: DS 3.3.0 BrowserProtection takes the settings as a
  parameter, 3P Matrix passes dsSettingsView(state). FilterDataLoader is gone in DS 3.3.0 (item 18) — and with it
  the remote list refresh in core/download-guard.js init.
- Domain age (items 1, 2, 21): util/domain-age.js, data/platform-suffixes.js, data/rdap-cctlds.js deleted; the
  site check uses DS util/DomainAge.js domainAgeNotApplicable (same lists as downloads). RDAP rule = DS's (user:
  "use DS implementation"): no RDAP / platform → skipped, failed / timeout → 0, answered without date → −10
  (SCORE.RDAP_NO_DATE, CHECK_STATUS.NO_DATE), < 30 d −30, 30–90 d −10. RDAP_TIMEOUT_MS 4000 → 3000 (as DS).
  tools/update-domain-age-lists.mjs now writes DS's PlatformSuffixes.default.js / RdapCctlds.default.js in lib.
  Two DNS/RDAP implementations kept (item 21, user); core/online-checks.js DNS counts CNAME (type 5) answers.
- Trust (items 25, 27): DS DownloadTrust.isTrustedDomain(fileUrl, domains, referrer) — file host, else the
  referrer (data:, blob:null). trustedDownloadDomains(state) = built-in app stores + APP.AI_DOWNLOAD_DOMAINS when
  state.downloads.trustAiDownloads (new, default false) + the user's domains. The allow list and the built-in
  whitelist stay as before (user: "also use the whitelist you already have"). Options: "Trusted downloads (not
  checked)" with "Trust app stores" (fixed) and "Trust AI downloads" (checkbox). The DS options lock (until a VT
  key is set) is removed, as in DS 3.3.0.
- VirusTotal (items 3, 16): the VT box always shows; without a key it says "Reputation lookup at VirusTotal
  skipped" + link "Request a free (no cost) key at VirusTotal" (VT_JOIN_URL); the separate no-key disclaimer is
  gone. DS one-shot silent retry (3 s + 7 s) via checkIfUrlIsMalicious(…, onLateResult): handleLateVtResult
  pushes MSG_DOWNLOAD_VT_UPDATE to an open warning page (which accepts only its own download id, from its own
  extension) or, when the window is closed, reopens it only if the combined score got worse. release() keeps the
  record (windowClosed) while BrowserProtection.isVtPending; releaseAll() for sweep / erase / no escalation.
- Look-alike (item 17): DS 3.3.0 exempts GovSuffixes at runtime — comes with the lib.
- Items 20, 24: by design, no change.
- e2e: Trust AI downloads persists; the no-key VT box text; a data: download from a trusted page is not checked.

## 4.3.3 — blob: downloads: trusted domains + no false "hidden extension"; 12 respects the built-in whitelist

Source worked from: 4.3.2 (same session). User report: a .zip from claude.ai was checked although claude.ai is in
the trusted download domains, with "Dangerous file type (.zip) was hidden …" (−40).
- Bug (port regression, 4.3.0–4.3.2): core/download-settings.js isTrustedDownloadUrl() used parseHttpUrl(), which
  rejects "blob:https://claude.ai/…" — DownloadSentinel's own isTrustedDomain (UrlUtils.getHostname) accepted it.
  Fix: unwrapBlob() before parsing; downloadSiteHost() also falls back through referrer → finalUrl → url, each
  unwrapped.
- Bug (DownloadSentinel, also in DS 3.2.0): a page-made file (blob:/data:) has no extension in its URL, so the
  obfuscation signal ("hidden at download start", −40) fired for every such file. isPageMadeDownload() skips it
  in both places (late entry + onChanged). Added to DS_ADVICE as item 22.
- User decision: protection 12 skips pages on the built-in whitelist (BUILTIN_ALL), like protection 11.
  data/builtin-domains.js: new category AI_BOTH ["claude.ai"] ("AI assistant"); popup "Trusted: …, AI".
  Side effect (as for every built-in entry): claude.ai exempt from 9/13–17 at levels 3–4, its 3P embeds allowed.
- e2e: a blob: executable opens the warning window without the "hidden" signal; a blob: file from a trusted
  download domain is not checked. Playwright saves downloads under a random name without extension, so the test
  file is recognised by its executable MIME type (application/x-msdownload).

## 4.3.2 — protection 18 (block risky downloads); 10 ⇄ 11; compact download warning page

Source worked from: 4.3.0 (same session). 4.3.1 was never packaged — its changes are part of 4.3.2.
**WARNING FOR IMPLEMENTATION IMPACT:** display numbers 10 and 11 swap (abused-TLD block = 10, suspicious-site
warning = 11); keys unchanged, ticks carry over. Protection count goes to 18 (6 in the level-3 group).

Protection 18 (user decisions 2026-10-20: risky types only · level 3 by the page the download came from ·
notice with "Download anyway" · "Download anyway should trigger the download check")
- data/protections.js: BLOCK_RISKY_DOWNLOADS (blockRiskyDownloads), num 18, from L3, OUTSIDE_SAFER_REGIONS,
  MECH.DOWNLOAD, new registry field `defaultOff` (+ DEFAULT_OFF_KEYS).
- Default off end to end: defaultState() unticks DEFAULT_OFF_KEYS; STATE_SCHEMA_VERSION 2 → 3 with migration
  untickNewDefaultOffV3 (a state or backup from before would otherwise read the missing key as "ticked");
  backups now carry `stateSchema` so a 4.3.2 backup is not migrated again. **Bug found by the new e2e test and
  fixed before release:** normalizeState started from defaultState(), so ticking 18 was undone on every save —
  disabledProtections is now built from the data only.
- core/download-settings.js downloadBlockReason(): level gate via isProtectionActive + saferRegionsApply (L3:
  page TLD outside state.safeZone.tlds; L4–5: always). Reason enum DOWNLOAD_BLOCK_REASON in constants.
  Exemptions (user, 2026-10-20) only at DOWNLOAD_BLOCK_EXEMPT_LEVELS = [level 3]: page on BUILTIN_ALL, or file
  host on the trusted download domains (isTrustedDownloadUrl). Levels 4–5: none. e2e: L3 + trusted host → not
  blocked; same at L4 → blocked.
- core/download-guard.js: blockIfNeeded() before protection 12 in onCreated AND in onChanged (a tiny file can
  finish first): classifyDownload gate, cancel (finished file: removeFile), notice window
  (DOWNLOAD_BLOCKED_WINDOW). "Download anyway": one-time pass per URL (_bypass, TTL 60 s, cap 20) +
  chrome.downloads.download(uniquify); the new download is _forced: skips 18 and always gets protection 12's
  check. _blocked/_forced released with release() (window close, OK, erase, sweep).
- ui/download-blocked.{html,js,css}: site-warning dialog look (reuses warning.css, C21); texts derived.
- Router: MSG_GET_BLOCKED_DOWNLOAD / MSG_BLOCKED_DOWNLOAD_ACTION (BLOCKED_DOWNLOAD_ACTION), id from sender URL.
- e2e: off by default · 4.3.1 state (schema 2) gets it unticked · level 4 blocks with a notice and no check ·
  notice names the file · "Download anyway" opens the download check.

Other
- 10 ⇄ 11 swapped (registry order + num); comments and docs follow. Protection 17 label "Block redirects and
  dialogs from frames" (one popup line).

Download warning page (was 4.3.1; UI only — ui/download-warning.{html,js,css}).
- Card max-width 760 → 600 px, padding 32 → 20/22 px, gaps 16 → 10 px, boxes 14/16 → 8/12 px, title 26 → 20 px,
  buttons 44 → 36 px high, score bar 20 → 14 px. The window still opens maximized (DownloadSentinel behaviour).
- Intro: "…an executable or an archive … Review the results." (was "compressed archive … below before opening the file").
- Removed: the VT-known disclaimer (DISCLAIMER.VT_KNOWN — the line is hidden when VirusTotal answered) and the
  closing "This is protection 12 … Options" note (with its Options link and derived-text fill on this page).
  The no-key and VT-unknown hints stay (they explain the VT button / missing VT data).

## 4.3.0 — download protection (DownloadSentinel 3.2.0) as protection 12; vendored DS library 3.0.4 → 3.2.0

Source worked from: 3P Matrix 4.2.3 extension/tools/docs zips + DownloadSentinel 3.2.0 extension zip
(uploaded 2026-10-20). Decisions (user, 2026-10-20): full DS parity · DS's own warning page, restyled ·
"downloads" required in the manifest (C36 accepted) · shared library upgraded to 3.2.0.

**WARNING FOR IMPLEMENTATION IMPACT:** "downloads" is a new permission with an install warning ("Manage your
downloads"): Chrome disables 3P Matrix for every existing user until they re-approve it. "alarms" (no warning)
is added too. Protection numbers 12–16 become 13–17 (display only, keys unchanged).

What / how
- Vendored library: `lib/downloadsentinel/` = DS 3.2.0 `protection/*` (11 modules) + the `util/*` modules they
  import (+ FilterDataLoader, VtKeyPromptPolicy), byte-identical. The two former 3P Matrix patches are upstream in
  3.2.0. `util/BrandDomains*` removed (replaced by `Brands*`, 534 keywords). Not vendored: DS `Storage.js`,
  `MessageTypes.js` (3P Matrix has its own), `GovSuffixes.default.js` (unused at runtime; build input →
  tools/gov-suffixes.json). `util/Settings.js` is a 3P Matrix adapter: read-only view of state.downloads in DS's
  settings shape (core/download-settings.js dsSettingsView) — the only file that differs from DS.
- Site checks (protection 10): core/site-scorer.js uses LookalikeDomainCheck (brand −65 / site −45,
  SCORE.LOOKALIKE_BRAND / LOOKALIKE_SITE) instead of checkBrandHomoglyph (−65) + checkLookalikeTopSite (−25);
  SketchyUrlCheck brand matching is word-based. Spot check: paypa1.com −25 none → −65 phishing;
  micr0soft-login.com −10 → −65; ungoogled-software.github.io loses "Brand impersonation google".
- Top-sites filter: update-top-sites.mjs now uses the DS 3.2.0 method (CrUX rank ≤ 100,000 ∪ brand websites
  ∪ gov suffixes); rebuilt for 4.3 from CrUX 202609: 80,140 entries, bits identical to DS 3.2.0's shipped file
  (was 759,891 / 1.2 MB). data-sources.json updated.
- One DNS provider table: data/constants.js DNS_PROVIDER/DNS_NONE now come from DS APP.DNS_PROVIDERS (was a
  second identical copy). One DNS choice (state.dns) for sites and downloads.
- Protection 12 (data/protections.js WARN_RISKY_DOWNLOADS, MECH.DOWNLOAD, from L2, every site).
  core/download-guard.js = DS background.js download logic (onCreated/onChanged two-listener model, VT wait
  budget, late entry, obfuscation + size-newly-known re-check, FP multiplier, auto-allow, sweep alarm,
  maximized warning window). Added guards: onCreated skips a download onChanged already handles (tiny-download
  race → double record); a record erased while waiting is not shown; warning windows are tracked and released on
  close (DS kept them until the 30-min sweep); one release() frees record, dedup entry, window link and the
  in-flight VirusTotal request together.
- Gate (core/download-settings.js): effective level of the download's site (referrer, else download host);
  DS trusted download domains (built-in app stores + user list) on the file host, via util/domain isInDomainList.
- State: `state.downloads` (new key, defaults DOWNLOAD_DEFAULTS; no migration, schema stays 2) validated field by
  field in normalizeState. Backup format v2 gains `downloads` without `vtApiKey`; MSG_IMPORT_SETTINGS keeps the
  existing key; Reset clears it.
- Router: MSG_GET_DOWNLOAD_CHECK / MSG_DISMISS_DOWNLOAD (download id read only from the sender's URL — C28),
  MSG_SET_DOWNLOAD_SETTINGS (whitelisted fields; vtApiKey not editable there), MSG_SET_VT_KEY,
  MSG_VT_KEY_PROMPT_DONE. The options model reports only `vtKeySet`, never the key.
- UI: ui/download-warning.* (DS WarningPage port: same sections and texts; textContent only; CSS risk classes;
  status line), ui/vt-key-prompt.* (DS VtKeyPrompt port), Options card "Download protection" (DS options; the
  key-dependent part is a disabled fieldset until a key is saved, as DS locks it). derived-text keys added.
- Warning dialog text (user request): title "This site needs your attention" (suspect severity), button "Go back",
  signal "Domain has been misused in the past (…)". Phishing severity title unchanged.

- Domain age not applicable (user request, 2026-10-20): both RDAP checks already used the registered domain
  (sub.domain.org → domain.org, PSL-based). Gap: on a PSL PRIVATE suffix the registered domain is the user's own
  subdomain (ungoogled-software.github.io) → RDAP 404; ccTLDs without RDAP (de, it, es, ch, jp, ru, co …) → no
  age either. DS 3.2.0 scored both as "recent" (−10). New util/domain-age.js (pure, one rule): skip the lookup —
  no network call, no score — for a platform subdomain (data/platform-suffixes.js = PSL private section, 3,447
  rules) or a two-letter ccTLD not in IANA's RDAP bootstrap (data/rdap-cctlds.js, 72 ccTLDs, publication
  2026-09-30). gTLDs (ICANN-mandated RDAP) and IDN ccTLDs are always asked. Used by core/online-checks.js
  (CHECK_STATUS.NOT_APPLICABLE, signal "Domain age not applicable — site on github.io …") and by a marked
  3P MATRIX PATCH in lib RdapProtection.check (status NOT_APPLICABLE, score 0) — to upstream into DS.
  New tool tools/update-domain-age-lists.mjs (register entries, updateOn minor). This build: the PSL came from
  the GitHub mirror (publicsuffix.org blocked in the build environment); data.iana.org was not reachable from
  the shell either; the user supplied IANA's dns.json (publication 2026-09-30) and the tool was rerun with it
  (--rdap): 72 ccTLDs, identical to the earlier web-fetch read.

Deliberately not ported / differences
- DS popup (master switch = protection 12's tick; VT switch = Options checkbox).
- DS SUBMIT_URL_TO_VT / VT_RESULT_UPDATE flow: unwired in DS 3.2.0 itself (no sender) — porting it would be dead code (C39).
- Without a VT key the warning page hides the VirusTotal box (DS showed "Unknown to VirusTotal" though VT was never asked).
- DS showed a genuine VT score of 0 as "unknown" (`!data.vtScore`); the port tests `=== null`.

Tools
- complete-check.mjs: ESLint's vendored-code ignore was "lib/**", resolved against the tools folder, so it never
  matched ../3P-Matrix/lib (passed only because the old subset had no hits) → "**/lib/downloadsentinel/**".
- e2e-flows.mjs: +15 assertions — VT key (invalid refused, model never contains it, cleared), settings validation,
  backup without key / restore keeps key, C28 refusal, a real .exe download opens the warning window with the
  right record and "Proceed anyway" closes it, no window for an allow-list page or with protection 12 unticked.

Known limitations
- Two DoH/RDAP implementations remain (core/online-checks.js for sites, DS modules for downloads), with different
  timeouts (3/4 s vs 8 s) and DS's "age not published = recent" rule only on downloads.
- FilterDataLoader fetches from raw.githubusercontent.com/Kees1958/uBol-stripped twice a day; until data files are
  published there it keeps the bundled lists. Its results bypass the list-freshness register.
- The Brands list (lib) is not in data-sources.json yet (DS_ALIGNMENT §5).

## 4.2.3 — Show Matrix overrides global only; per-site tier removed (bug-class fix)

Source worked from: 4.2.2 (extension / tools / docs hashes verified against package-release-state.json).

**What.** Show Matrix overrides exist only in the global scope (`matrixRules["*"]`). Per-site keys are
migrated into it on load; the per-site DNR priority tier and its display merge are removed.

**Why.** uMatrix and 3P-Matrix-lite always applied rules globally. When the uBlock Stripped Dynamic
protections were combined with 3P Matrix (0.2.0), uBD's per-site matrix model was taken over by mistake.
4.1.0 made NEW overrides global but kept old per-site entries as a separate, higher tier, and 4.2 converted
their `{code, all}` shape without moving them. Result (audit 2026-10-19, finding 1 / C41 "Delete" missing):
a per-site entry still won in the panel's merge while `MSG_SET_MATRIX_RULE` only ever writes to `"*"`, so
clicking "undo" removed nothing — the override could only be cleared with Reset or by editing a backup.
Confirmed on a real user backup (one rule: `nu.nl → qmusic.be` script+frame block).

**How.**
- `data/state-storage.js`: matrix normalization extracted into `normalizeMatrixRules()` /
  `normalizeMatrixEntry()`. Reads `"*"` first, then each per-site key in stored order; per scope a later
  value replaces an earlier one, so a per-site value wins (as its higher priority did). Valid hosts,
  known scopes/actions, `{code, all}` conversion and the 1000 cap kept (cap now counts domains). Output is
  always `{ "*": {...} }` or `{}`. Idempotent; runs on every load, so update and backup restore both migrate.
- `core/rule-builder.js` `buildMatrixRules`: reads only `"*"`; no `initiatorDomains`; one priority.
- `data/constants.js`: `PRIORITY.MATRIX_GLOBAL` / `MATRIX_SITE` → `PRIORITY.MATRIX` (400000); comments
  rewritten (also removes the stale `{ code, all }` shape description).
- `background.js`: `mergedMatrixOverrides` and `countMatrixPairs` replaced by `globalMatrixOverrides()`.
- Storage key, `"*"` key and backup format v2 unchanged (contracts) — older and newer backups both restore.

**Behaviour visible to the user.** A former site-only override now applies on every site, and can be
undone from the panel.

**Tests.** Node test against the real backup and synthetic cases — user file → global; 2 DNR rules
without initiator at 400000; per-site vs global conflict; `{code}` per-site legacy shape; invalid keys,
hosts and actions dropped; empty → `{}`; idempotent; cap 1000. `node --check` on all JS.

**Limitations.** If the same domain had different per-site rules on two sites, the last stored site wins.

**Removal schedule (user decision 2026-10-19).** All code that only reads data written by older versions
is tagged `COMPAT-REMOVE ≥4.5` and listed in the `data/state-storage.js` header: (1) this per-site merge,
(2) the 4.2 `{code, all}` → `{script, frame}` conversion with `MATRIX_LEGACY_SCOPES`, (3) backup format v1
(0.1.x / 0.2.0) in `settings-io.js`. To be deleted from 4.5.0 on. The code was checked for other old
conversions: none left besides these three. Earlier changes (removed protection keys 0.2.3, `autoTldMode`
≤ 0.2.3, `autoAddCountryCodes` 0.2.4) need no code; the generic validation in `normalizeState()` drops them.

### 4.2.3 (same release) — transcribed UI values replaced by derived values (audit finding 2, C39a)

**What / why.** The popup bullet "(5 outside safer regions)" was a typed literal: wrong as soon as a level-3
protection is unticked, and a leftover of the 4.2 renumbering (protection 11 added, 11–15 → 12–16) — a partial
fix (user decision: this is a BUG, and the class must be fixed end-to-end). A sweep found nine sites of the same
class (18 hits): that bullet; Show Matrix note "(protection 11)" and its "Level N —" prefixes; options.html
"score −30", "protection 10", "level 1"; warning.html "level 1"; popup.html "at level 3"; the startup
`<option>1…5</option>` list; the `for (let n = 1; n <= 5 …)` tick loop and its `/ 4` fill fraction.

**How.**
- New `ui/derived-text.js`: `fillDerivedText(root)` fills `data-derived="KEY"` placeholders from one frozen table
  (level-allow-all, safer-regions-levels, score-suspect-at, protection-num-warn); unknown key → console error +
  `data-derived-missing`. Helpers `protectionNum(key)`, `formatScore(n)`, `levelRange()`.
- `background.js` popupModel: each protection group carries `active` / `total`; popup shows
  `countText(active, total)` for the level-3 ("outside safer regions") group.
- popup: startup options and ticks from `levelRange()`; fill fraction from `LEVEL_MIN/LEVEL_MAX`;
  `TRACK_INSET_PX` (= popup.css `.track` 22 + 22 px) declared once. Placeholder "2 / Mild protection" removed.
- matrix.js: level prefix and protection number derived at render.
- Principle **C39a** added to the Xplainer document (v10) + Part D step 50.
- Tools: `check-derived-literals.mjs` (static check; exit 0 pass / 1 hits / 2 did not run) and
  `test-matrix-migration.mjs` (all expected values imported from the extension's constants).

**Tests.** check-derived-literals: PASS on 4.2.3, 18 hits on 4.2.2 (fault-verified), exit 2 on a bad path.
Chromium: L3 bullet "16 protections (5 outside safer regions)" → after unticking blockScpPrivacy
"15 of 16 protections (4 of 5 outside safer regions)"; startup options and ticks 1–5; options.html shows
−30 / 10 / 1; no `data-derived-missing`, no console errors.

**Not changed (judgment):** the popup line "Trusted: payment, sign-in, streaming, meetings, games" is a wording
summary of the built-in whitelist categories, not a value; left as text.

### 4.2.3 (same release) — lock cap 400 → 500 (audit finding 3, user decision)

`SITE_LOCKS_CAP` 500. Only consumer: the FIFO eviction in `background.js lockSite` and `normalizeState`. DNR
impact: the global rule group carries up to 500 `excludedInitiatorDomains` and scripts up to 500
`excludeMatches` — well within Chrome limits. Eviction stays silent by design at a cap judged "more than enough".

### 4.2.3 (same release) — uBD-only exemptions and identity removed from shipped code (audit findings 4, 25)

**Why.** `$worryfree` and `$saferregions` are uBlock Stripped Dynamic exemption syntaxes; 3P Matrix has neither
(user decision: remove from code and UI). Inventory: `$saferregions` nowhere; `$worryfree` only in
`sec-clickfix-clipboard.js` (header + the console message shown when a ClickFix write is blocked). Same class,
same pass (C39a): log prefixes `[uBol]` (7×, 6 scripts) and `[uBlock-Dynamic]` (1×); "per-toggle allowlist"
(sec-noeval.js), "dashboard checkbox" history (sec-alertbuster.js, sec-dialogbuster.js), "STYLE_GUIDE" reference.

**How.** Each MAIN-world script that logs declares `const LOG_PREFIX = '[3PMCF]'` once in a settings block
(MAIN-world scripts cannot import data/constants.js; a page-visible shared global was rejected per C35). The
ClickFix message and the noeval note now point to the 3P Matrix allow list. Kept on purpose:
`window.eval.__uBolNoEvalInstalled` — internal install guard shared with uBD (eval wrapped once when both run),
never shown to the user. New `tools/check-shipped-terms.mjs`: imports `LOG_PREFIX` from constants.js and fails when
a logging security script lacks the copy or differs; fails on any uBD-only term in the shipped extension
(provenance comments allowed). Exit 0 / 1 / 2 (did not run).

**Tests.** check-shipped-terms: 21 problems on 4.2.2, PASS on 4.2.3, drift injected into one script → caught
(and it caught one header the manual pass had missed). Chromium on a local page: payment-handler,
protocol-handler and alert protections log "[3PMCF] …".

### 4.2.3 (same release) — protection 10 renamed "Warn when opening…" (audit finding 5, user decision)

`onBeforeNavigate` cannot hold a navigation, so the first request to a suspicious site may already be sent when
the tab is redirected to the warning page; the spec's "never loads before the user chooses" overstated it. User
decision: being warned is what counts — no mechanism change; label "Warn before opening…" → "Warn when opening…"
(registry), spec Warning section and navigation-guard header corrected. The options page quoted the name as a typed
copy (C39a) — it now renders the registry label (`data-derived="protection-label-warn"`).

### 4.2.3 (same release) — background.js reduced to lifecycle + thin router (audit findings 6, 17, 20, 26)

**What / why.** background.js claimed "no business logic" but held lock/unlock, allow-list parsing, safer-regions
editing, Show Matrix override and panel-window handling and three view models (C1, C11). Refactor only — no
behaviour change (Ground Rule), message types, storage keys and public names unchanged.
**How.** New pure modules `core/site-locks.js` (isLocked, lockSite, unlockSite, toggleLock, allowListSites,
parseAllowListText, replaceAllowList) and `core/matrix-overrides.js` (globalMatrixOverrides, setMatrixOverride);
`core/matrix-windows.js` owns the tab → panel-window map and its whole lifecycle (open/focus, close on tab close,
window close, timeout); `core/view-models.js` (popupModel, matrixModel, optionsModel); `editSaferRegions()` added to
`core/safer-regions.js`. background.js: 420 → 270 lines, each handler validates input and delegates.
`clampLevel` (which validated, not clamped — finding 17) → exported `parseLevel()` in state-storage.js. Stray blank
line in the header removed (part of finding 20). Show Matrix ▶ timer icon was typed in matrix.html while its
constant `TIMER_RUNNING` was unused (found by lint, finding 26, C39a class) → set from the constant.
**Tests.** ESLint no-undef / no-unused-vars over the extension: clean (it caught one dropped import during the
refactor). New `tools/e2e-flows.mjs` (Playwright + Chromium, values imported from the extension): 15 flows pass —
level, lock pins current level and restores session level, unlock, safer-regions add/remove/default, allow list
parse/replace with a level-5 lock untouched, Trust this site, Show Matrix panel open, override set + undo (DNR rule
added and removed), panel closes with its tab, export. Other tools pass.

### 4.2.3 (same release) — audit findings 7–24 (structure, guards, schema, values, docs, tooling, licence)

Source worked from: the 4.2.3 working tree above. Every step verified by the new suite (below) plus a rule/script
equivalence run against 4.2.2 (identical output for 10 states × 2 CDN modes) where behaviour must not change.
- **7 Layering.** `AUTO_TLD_MODE` and `BASE_TLDS` moved to `data/tld-constants.js` (data never imports core);
  `SAFER_REGIONS_AUTO_MODE = AUTO_TLD_MODE.CONTINENT` (no duplicated number, runtime guard removed). The popup gets
  `saferRegionsRelevant` from the view model instead of importing `core/policy.js`.
- **8 Protection keys.** `PROTECTION_KEY` lists all 16; registry and rule builder use only the enum;
  `isProtectionActive` logs an unknown key instead of silently returning false. `check-protection-keys.mjs`.
- **10 Guards.** `.catch` on both navigation listeners; new `ui/status-line.js` (one timer per element, released on
  pagehide) — popup, options, Show Matrix and warning show failures to the user; options init/export/import/reset
  all guarded; blob URL released in `finally`.
- **11 Input.** Router rejects any sender that is not this extension; `requireTabId()` for reload/stop; the warning
  page's target URL is read from the sender's own `?u=` (C28; `WARNING_TARGET_PARAM`); `isValidTld()` — an invalid
  TLD is refused with a message.
- **12 Rescue registrations.** A site gets at most one (`rescuedSites` set) — 4.2.2 registered a script twice for
  e.g. zoom.us locked at 5 with "us" in safer regions (proven before/after).
- **9 Schema.** `STATE_SCHEMA_VERSION` 2; `STATE_MIGRATIONS` ordered list run from `migrateRaw()` inside
  `normalizeState()` (no `schema` = 1); the matrix conversions moved into the 1→2 step (COMPAT-REMOVE ≥4.5); the
  validator now only knows the current shape.
- **13 Values.** No typed number outside a named constant: DNS wire-format layout (`DNS.*`), `PRIVATE_IPV4_BLOCKS`
  (network-data), `RISK_SCALE_MAX`, `LANG_TAG_MIN_PARTS`, `DECIMAL_RADIX`, `MATRIX_TAB_PARAM`, `ICON_UI_SIZE`,
  `DNS_BLOCK_STYLE` enum, `CHROME_BLOCKED_BY_CLIENT_ERROR`, `CHROME_NEW_TAB_URL`, `HTTP_URL_FILTER`,
  `CDN_URL_FILTER_FALLBACK`, `SCRIPT_ID_SUFFIX`, `STATUS_CLEAR_MS`. `check-magic-numbers.mjs` (acorn).
- **14** UI colours are the common.css tokens; the warning look comes from `LEVEL_INFO`; `LOG_PREFIX` everywhere.
- **15** C9a: every named function is a declaration (ESLint `func-style`). **16** every empty catch states why, or
  reports (a failed warning redirect is now logged — it means the user was not warned). **18/20** comments fixed.
- **21** spec brought in line with the code; **22** 4.2.0 / 4.2.1 entries reconstructed (marked as such).
- **23 Suite.** `complete-check.mjs` (npm run check): suite-wiring, syntax, ESLint, spam-tlds source, protection
  keys, magic numbers, derived literals, shipped terms, state migration, e2e flows — PASS / FAIL / DID NOT RUN, a
  skipped step ends INCOMPLETE (exit 3). Fault-verified: 6 failures on 4.2.2; injected syntax error caught.
  `tools/package.json` (acorn, acorn-walk, eslint 8.57.0, playwright 1.47.2) + `eslint.config.json`.
  `build-spam-tlds.mjs` wrote to `../data/` — outside the extension in the sibling-folder layout; now
  `--extension` (default `../3P-Matrix`) and `--check` (suite step: shipped list matches its source — it does).
- **Upgrade path** proven in real Chromium: state stored by 4.2.2 (schema 1, per-site `{ code }` rule) → global
  Script + Frame, two global DNR rules (e2e-flows now 17 flows; a first test version seeded schema-2 state and
  would have missed a broken migration — caught and fixed in the test).
- **Data-list freshness (user request).** The CrUX top-sites filter had no tool in 3P Matrix (it came pre-built from
  DownloadSentinel). New `update-top-sites.mjs` rebuilds it with the extension's own UrlUtils + BloomFilter —
  verified bit-identical to the shipped filter from the CrUX 202609 list (759,891 registered domains, 7,283,600
  bits, 7 hashes, 1 % FP). New register `data-sources.json` (source, licence, tool, release, entry count, version
  rebuilt for) and suite step `list-freshness` (`check-list-freshness.mjs`): a list marked `updateOn: "minor"`
  must be rebuilt for the manifest's major.minor — 4.2 → 4.3 fails until the tool ran, 4.3.1 → 4.3.2 never does
  (tested: 4.2.4 pass, 4.3.0 fail, pass after the update).
- **24 Licence.** `LICENSE.txt` (GPLv3 — required by the uBlock Origin Lite derivation) and
  `THIRD_PARTY_LICENSES.md` ship in the extension. Top-sites source = Google Chrome UX Report (user, 2026-10-19),
  CC BY 4.0 per developer.chrome.com/docs/crux/methodology.

---

## 4.2.1 — Show Matrix back to the 3P-Matrix-lite layout and model; opaque-initiator attribution

*Reconstructed 2026-10-19 (audit finding 22) from CHANGELOG.md and the 4.2.1 source comments — no technical
write-up was made at release time. Source worked from: 4.2.0.*

**What.** Show Matrix columns become 3P-Matrix-lite 4.0.2's: Internal whitelist · Level mode · image · media ·
stylesheet · SCRIPT · FRAME · fetch/xhr · other · requests; the filter box is removed. Blocked-request counting
attributes requests from sandboxed / data: / srcdoc frames correctly. Tools: `package-release-state.mjs`.
**Why.** The 4.2.0 columns showed what was *observed*, not what the policy *decides*; at level 4 a script domain
could look allowed only because no request had been blocked yet. And webRequest reports an opaque initiator as
"null", which the matcher treated as first-party — so 3P Matrix's own blocks of ad frames looked like another
extension's and were neither counted nor shown as blocked.
**How.**
- `core/connection-matrix.js` records only what was seen (types, count, one sample URL per type); a "cdn" subdomain
  of a non-cdn domain and a host that is itself a built-in entry get their own row (lite's `_groupingKeyFor`, minus
  the cdn-in-both split that only added identical rows).
- New `core/matrix-disposition.js`: per row and scope, the decision is replayed through the rules Chrome has
  (`core/rule-matcher.js`); "Level mode" replays a second compiled set without built-in allows and overrides
  (`apply-manager.getCompiledModeRules`, derived from the same rule array via `isLevelMechanismRule`).
- New `core/tab-sites.js`: each tab's top-level host, used by the matcher as the stand-in for an opaque initiator
  (Chrome matches such requests against the opaque origin's precursor — the tab's own site for these frames).
- `tools/package-release-state.mjs`: SHA-256 per artifact over sorted paths + lengths + bytes, versions, file
  counts, shipped permissions → `package-release-state.json` (multi-artifact integrity rule).
**Limitations.** Only the first sample URL per type is replayed, so a domain whose script URLs are decided
differently by path-specific rules shows the decision for that sample.

## 4.2.0 — abused-TLD block becomes protection 11; levels target scripts and frames only; Script/Frame overrides

*Reconstructed 2026-10-19 (audit finding 22) from CHANGELOG.md and the 4.2 source comments. Source worked from: 4.1.1.*

**What.** (1) The HaGeZi abused-TLD block, an unconditional part of level 2+, becomes selectable protection 11
(`blockAbusedTlds`, on by default); protections renumbered so each group is consecutive: 1–11 every site, 12–16
outside safer regions (keys unchanged, so saved ticks carry over). (2) Levels 3–5 block only third-party scripts and
frames (RT.CODE), never images/video/fonts/CSS. (3) Show Matrix's combined 3P-code / 3P-all overrides become two
independent columns, Script and Frame. (4) Built-in payment hosts (BUILTIN_PAYMENT) may register a real payment
handler on their own site at levels 3–4 (protection 1 `trustedExempt`). (5) `BUILTIN_EXEMPT_LEVELS` declared once in
constants (was two private copies). (6) Safer-regions panel opens expanded; level 5 renamed.
**Why.** Blocking passive content at levels 4–5 broke pages without a security gain the script/frame block did not
already give; the abused-TLD block needed an off switch like every other protection; Script and Frame are disjoint
resource types the user wants to set separately.
**How.**
- `data/protections.js`: new row 11, `PROTECTION_KEY.BLOCK_ABUSED_TLDS`; `core/rule-builder.js` builds the abused-TLD
  rule only when active and skips it at L5 (the L5 block, higher priority, already covers it).
- `RT.CODE` for every level rule; `RT.PASSIVE` documented as never targeted.
- `MATRIX_SCOPE` { SCRIPT, FRAME }, one resource type each (`MATRIX_SCOPE_RESOURCE_TYPE`), one priority per tier;
  saved `{ code, all }` entries converted on load by `normalizeState()` (code, else all → both scopes) — this
  conversion is now the schema-2 migration, COMPAT-REMOVE ≥4.5.
- `trustedExempt` field: `core/script-builder.js` excludes those hosts at BUILTIN_EXEMPT_LEVELS, with a rescue
  registration for such a site locked at level 5.
**Known gap found later.** The renumbering left typed copies of protection numbers and counts in the UI (popup
"(5 outside safer regions)" and others) — fixed class-wide in 4.2.3 (C39a).

## 4.1.1 — dead-code cleanup; Show Matrix help text made bold+caps; "Req." renamed "REQUESTS"

Working from: 4.1.0. Zips changed: extension, tools (build-spam-tlds.mjs only), docs.

**What / why**: user asked to remove all dead/unused code from the extension.

**How (method)**: ESLint (`no-unused-vars`/`no-undef`, flat config, not part of the shipped tools —
ad hoc for this pass) over every `.js` file found zero unused locals or imports anywhere in the
codebase. A second pass cross-referenced every `export`ed symbol against the whole tree (including
`.html` files) for a second occurrence; combined with a per-file reachability check (every `security/`
content script is referenced by path string from `data/protections.js`; every `lib/downloadsentinel/`
module and its `*.default.js` counterpart is imported at least once), this found exactly 4 orphaned
exports in ~35 files — the codebase was already very clean.

**Removed**:
- `data/constants.js`: `EXT_SHORT_NAME`, `EXT_TAGLINE` (never imported; manifest.json's own `name`/
  `short_name`/`description` are separate literal strings and were never meant to read these back),
  `OPTIONS_PAGE` (never imported; the options page is opened by Chrome itself via manifest.json's
  `options_ui.page`, never from our own code).
- `data/spam-tlds.js` + `tools/build-spam-tlds.mjs`: `SPAM_TLDS_VERSION` — the HaGeZi list version,
  exported but never read anywhere; the same version string is already in the generated file's own
  header comment (line 2), so the export was pure duplication. Removed from the generator too, so it
  doesn't reappear on the next `node tools/build-spam-tlds.mjs` run. Verified: regenerating from the
  same input (`tools/spam-tlds-ublock.txt`) with the edited generator produces a byte-identical
  `data/spam-tlds.js` to the hand-edited version (diff clean).

**Also in this release**: user asked for the Show Matrix "Rules apply on every site…" help line to
stand out (bold, upper case) and for the "Req." column header to read "REQUESTS" in full.
`ui/matrix.css` `.mx-help-line` gets `font-weight: bold; text-transform: uppercase` (sentence stays
normal-case in the HTML source; CSS renders it upper case). `ui/matrix.html`'s `Req.` header text
changed to `REQUESTS`; `.col-num` width increased from 52px to 76px so the longer label doesn't wrap —
checked with a headless-browser screenshot of the empty panel, header sits on one line, Seen/Override
columns unaffected.

**Verified**: `node --check` over every `.js` file; the 4.1.0 Show Matrix verification script re-run
clean; ESLint re-run against the edited files, zero warnings; visual check via Playwright screenshot
(not part of the shipped tools — ad hoc for this pass).

**Not removed (flagged, not a clear case)**: nothing else qualified. If something later turns out
unused (a future refactor, a removed protection), re-run the same ESLint pass first.

**Verified**: full `node --check` over every `.js` file; the 4.1.0 Show Matrix verification script
re-run clean against the final tree; ESLint re-run against the two edited files, zero warnings.

## 4.1.0 — version renumbered to match 3P-Matrix-lite; Show Matrix overrides become global

Working from: 0.2.5. Zips changed: extension, docs. Tools repackaged unchanged (spam-tlds builder only).

**What / why**: the user asked to bring this extension's versioning in line with 3P-Matrix-lite (currently
4.0.2) and, separately, to review how Show Matrix overrides should carry across from lite — lite's
equivalent override is global (blocks/allows a third party on every site), while this extension's was
always scoped to the one site you set it on. Decided: make global the default behaviour here too, so a
converted lite rule needs no lossy translation and the two extensions' "block this third party" means
the same thing. A literal per-site rule (pre-4.1 saved data, or a future manual override) is still
supported and always outranks a global rule for the same third party — see `data/constants.js`.

**How**
- `data/constants.js`: new sentinel `MATRIX_SITE_ALL = "*"`, the single declared meaning of "every site"
  as a `matrixRules` key. `PRIORITY.MATRIX_ALL`/`MATRIX_CODE` split into four: `MATRIX_ALL_GLOBAL`,
  `MATRIX_CODE_GLOBAL`, `MATRIX_ALL_SITE`, `MATRIX_CODE_SITE` — site tier strictly above global tier,
  CODE still above ALL within each tier, so a legacy per-site rule always wins a conflict.
- `core/rule-builder.js` `buildMatrixRules()`: a `matrixRules` entry keyed `MATRIX_SITE_ALL` builds a DNR
  condition with no `initiatorDomains` at all (applies everywhere); any other key still sets
  `initiatorDomains: [siteKey]` as before, just on the SITE priority tier instead of the old flat one.
- `background.js` `MSG_SET_MATRIX_RULE`: now always writes to the `MATRIX_SITE_ALL` key instead of the
  tab's current host; the tab's host is still read as a guard (Show Matrix must be actively tracking that
  tab) but no longer used as the storage key. `matrixModel()` merges `matrixRules["*"]` with any legacy
  per-site entry for the currently observed site (new `mergedMatrixOverrides()`, site wins per scope) so
  the panel shows the correct effective state either way.
- `data/state-storage.js` `normalizeState()`: the matrixRules host-validity guard now accepts the literal
  `MATRIX_SITE_ALL` key in addition to a real hostname (everything else is still rejected and dropped,
  same as before).
- `ui/matrix.html` / `ui/matrix.js`: help text and header comment updated ("Rules apply on every site,
  not just this one") — no behavioural change in the UI itself, the 3P-code/3P-all buttons work exactly
  as before, only what they write changed.
- `data/settings-io.js`: comment only — `showMatrixRules`' shape in the settings-backup format is
  unchanged; `"*"` is just a valid siteKey now, so existing backups still round-trip.

**Verified**: a one-off Node script (not shipped) exercised `buildMatrixRules()` and `normalizeState()`
directly — global rule has no `initiatorDomains` and the GLOBAL priority; a legacy site rule keeps
`initiatorDomains` and the SITE priority; a global BLOCK and a conflicting legacy site ALLOW for the same
domain both produce a rule, with the site one's priority strictly higher; `normalizeState()` keeps a `"*"`
key and still drops an invalid one. A mutation check confirmed the test would have failed against the old
(always-per-site) `buildMatrixRules()`, so it genuinely exercises the new behaviour, not a tautology.

**Not done / deliberately out of scope**: no settings-file importer from 3P-Matrix-lite was built — lite
has no settings-export feature of its own to import from, and the user confirmed this release is scope
("feature/defaults parity", not a file converter). No further lite-vs-firewall defaults audit was done
beyond the Show Matrix question — raise anything else you want checked for parity as its own request.

## 0.2.5 — version bump: packages the full 0.2.4 working-copy session as its own release

Working from: 0.2.4 zips (packaged after only the protection-10/safer-regions-slider/Five-Eyes work).
Everything below happened in the same working session but after those zips went out, so it ships here
instead, to keep a clean record of what each zip actually contains.

## 0.2.4 — suspicious-site warning becomes protection 10; safer-regions slider removed; built-in
   whitelist gains streaming/meeting/gaming + a first-party exemption from protections 9/11–15

Working from: 0.2.3. Zips changed: extension, docs. Tools repackaged unchanged.

**What / why**: the user wants the warning for suspicious websites as one of the protections, selectable in
the popup, so "On every site" has 10 protections again (it had 9 after 0.2.3 removed two).

**How**
- `data/protections.js`: new entry `warnSuspiciousSites` (num 10, from L2, every site, new mechanism
  `MECH.NAVIGATION` — no DNR rules, no content script). New `PROTECTION_KEY` enum holds the key for modules
  that test it directly. Level-3 protections renumbered 10–14 → 11–15 (keys, rule ids, priorities unchanged).
- `core/navigation-guard.js`: the old gate `effectiveLevel < LEVEL.MILD` is replaced by
  `isProtectionActive(state, PROTECTION_KEY.WARN_SUSPICIOUS_SITES, effectiveLevel)` — same result while
  ticked; unticked = no stage 1 scoring, no warning dialog (so no stage 2 online checks), badge risk neutral.
  Honours locks: a site locked at L2+ is warned even at global L1, if the protection is ticked.
- `background.js` popupModel: `warningsOn` flag. `ui/popup.js`: bullet "Warnings for suspicious sites" (level
  colour) or "Warnings for suspicious sites off" (neutral) at every level ≥ 2; L4/L5 "N + domain warnings"
  became "N active" + that bullet (the warning is now inside N, so "+" would double count).
- `ui/options.html`: online-checks text says they belong to protection 10.
- Popup bullets (user: redundant once the warning became protection 10): `ui/popup.js` bulletsFor() drops the
  per-bullet `warn`/`warningBullet()` added earlier this release; L4/L5's "N + domain warnings" stays "N
  active" (already fixed in the first 0.2.4 pass). `background.js` popupModel: `warningsOn` removed (nothing
  read it any more) along with its now-unused `isProtectionActive`/`PROTECTION_KEY` imports.
- `ui/popup.css`: `.prot-item.off` no longer dims or strikes through the label (user: unreadable); the
  checkbox alone shows the state. The class is kept as a styling hook.
- Builders untouched: rule-builder and script-builder only act on DNR/HEADER/SCRIPT mechanisms.
- Old saved states have no `warnSuspiciousSites` entry in disabledProtections → ticked (previous behaviour).
  Settings files: no format change (protections.disabled is a key list).
- Stale numbers in comments fixed with the renumber (constants, rule-builder, suspicious-hosting.js said 8
  instead of 6, sec-nfc.js said 14 instead of 13). SPEC brought to the 15-protection list (was still 16).
- `manifest.json` 0.2.3 → 0.2.4. No permission change.

**Safer-regions slider removed** (user: "remove the slider from level 3 for the TLD whitelist and set it
standard the same way as uBlock Dynamic does"). uBlock Stripped Dynamic since 0.0.3 hardcodes 3P-Matrix-lite's
mode 2 "Continent" with no slider (its CHANGELOG_HISTORY 0.0.3: "Explicitly NOT ported: … 4-position slider").
- `data/constants.js`: `DEFAULT_AUTO_TLD_MODE` + `AUTO_TLD_LABELS` replaced by one fixed switch
  `SAFER_REGIONS_AUTO_MODE = 2` (= AUTO_TLD_MODE.CONTINENT). `core/safer-regions.js` guards it (invalid value →
  logged, CONTINENT used) and passes it to the unchanged pure engine `core/tld-engine.js` (comments only).
- State: `safeZone.autoTldMode` removed from the schema; normalizeState() drops a stored value (≤ 0.2.3).
- `background.js` onInstalled recomputes the list for EVERY reason (was install only), so updating users who
  had chosen None/Browser/Worldwide move to Continent at once; their added/removed TLDs are kept.
  MSG_SET_SAFE_ZONE: `autoTldMode` input gone; restoreDefault clears added/removed TLDs. popupModel no longer
  sends the mode or labels.
- Popup: slider, its label row and CSS removed; one intro line explains the default.
- Settings file: `saferRegions.autoAddCountryCodes` no longer written, ignored on restore (format stays v2 —
  missing/extra field is compatible). Summary line no longer shows the mode.
- HaGeZi guard (user: "keep them out when they are on HaGeZi"): `SAFER_REGIONS_SKIP_ABUSED_TLDS = true`;
  core/safer-regions.js drops merged TLDs that are in SPAM_TLDS unless hand-added (manualTlds). Of the 215
  possible auto-added ccTLDs, 7 are on the list today: cf cm ga gq ml ng pw. Test: fr-CM → none of them;
  hand-added cm kept; nl+en list unchanged (3/3).
**Built-in whitelist: streaming, meeting, gaming** (user: "the built-in whitelist should also contain
video and streaming"; follow-up: all three categories, since meeting/gaming weren't removed, just never
ported). `data/builtin-domains.js` restructured into CORE_* (payment/SSO/CAPTCHA/video/JS, unchanged) plus
new STREAMING_*/MEETING_*/GAMING_BOTH sub-arrays, composed into the existing BUILTIN_BOTH/SCRIPT_ONLY/
FRAME_ONLY exports via a dedupe-and-sort merge (`mergedSorted()`) — same exported shape, so every existing
consumer (rule-builder, script-builder, navigation-guard) needed no change for this part. Hand-curated,
not from a live source; limited to services with a genuine embeddable iframe/script (the point of THIS
list is third-party embeds) — Netflix/Disney+/Hulu/Max/Prime Video/Paramount+/Peacock/Crunchyroll (video),
Xbox/PlayStation/Nintendo/Epic/Riot (gaming) and WhatsApp/Telegram/Signal/Slack/Google Meet (meeting) have
no such embed and are deliberately left out — confirmed with the user this asymmetry was intentional
(uBD's own 99-domain list, not in the uploaded files, was not used verbatim).

**Built-in whitelist also exempts protections 9/11–15 on a first-party visit** (user correction: "it
should also apply on the protections" — an initial assumption that this list affects only third-party
embeds was wrong). Two call sites changed, both gated to levels 3–4 only (never 5, matching the existing
3P-content exemption's own level range — `BUILTIN_EXEMPT_LEVELS`/`BUILTIN_ALL` imported where needed):
- `core/rule-builder.js` headerRules(): `outsideSafe` (feeds the Permissions-Policy/CSP header rules for
  9, 11–13, 15) now merges the existing safer-regions-TLD exclusion with a new built-in-whitelist
  exclusion via `cond()`, independently of `saferRegionsApply` (which is level-3-only) — so built-in
  hosts are exempt at level 4 too, where the TLD exemption never applies.
- `core/script-builder.js` registrationsFor(): the SCOPE.OUTSIDE_SAFER_REGIONS content scripts
  (blockSensorsNfc's NFC half, blockObfuscatedEval) get a parallel `inBuiltin()`/`globalBuiltinExclude`
  alongside the existing `inSafer()`/`globalSaferExclude`, at both the per-lock (`runsOnLock`) and global
  (blanket `excludeMatches`) levels. A site locked at level 5 overrides the built-in exemption, same as it
  already overrode the safer-regions one — new rescue registration (id suffix `-builtin-locked`,
  mirroring the existing `-locked` safer-regions rescue) re-includes such a site, since the blanket
  level-3/4 built-in exclude would otherwise hide it.
- Most of the new streaming/meeting/gaming domains are `.com`/`.io`/`.net`, already in BASE_TLDS (the
  safer-regions default), so at level 3 they were already incidentally exempt; the real effect of this
  fix is at level 4 (where the TLD exemption never applies at all) and for `zoom.us` (`.us`, not a default
  TLD) at any level. Confirmed by testing with an empty safer-region TLD list to isolate the mechanism.
- `background.js`/`ui/popup.js`'s earlier 0.2.4 pass added a per-bullet line for protection 10 that
  duplicated its own name in the Protections list; removed (user: "it is part of the 15 protections so
  the text is redundant") — the aggregate "N of 15 protections active" count already covers it, same as
  every other single protection. `warningsOn` dropped from the popup view model; its now-unused
  `isProtectionActive`/`PROTECTION_KEY` imports removed from `background.js`.

**Tests (built-in whitelist)**: Node 21/21 — no duplicate or unsorted entries across the merged
categories, every new domain present, Netflix/Xbox absent. Header-rule test (5/5): zoom.us/discord.com
excluded from the Permissions-Policy main_frame condition at L3 and L4. Script-builder test (12/12, safer-
region list emptied to isolate the mechanism): zoom.us/discord.com excluded from blockObfuscatedEval's
content script at L2–4, not excluded at L5; the realistic-defaults case at L4 (where .com/.io overlap
doesn't apply) confirms zoom.us is excluded only because of the builtin fix; a site locked at L5 gets the
rescue registration and runs the protection; a site locked at L3 under global L1 is correctly held back
by its own builtin-exempt level, while a genuinely non-builtin site in the same scenario still runs.
Chromium (unpacked, dynamic rules + registered content scripts read back live): confirmed at L3 and L4.
Earlier 0.2.4 suites still pass (23 + 8 + 3).

- Clearer protection text (user: "the protections are very short... make them a little more clear"):
  `data/protections.js` PROTECTIONS[].label rewritten as plain sentences for all 15 (e.g. "No camera, mic,
  screen, clipboard-read" → "Block camera, mic, screen-share and clipboard reads"). `ui/popup.css`
  `.prot-item`/`.p-label` drop the single-line `white-space: nowrap; overflow: hidden; text-overflow:
  ellipsis` truncation (`align-items: flex-start`, line-height, small top margins on the checkbox/number
  so they sit level with the first line) — a label now wraps to two lines instead of being cut off with
  an ellipsis; only #15 needs it at 400px width. Purely a label/CSS change — `key`/`num`/`fromLevel`/
  mechanism untouched, so no test depends on label text; full 72-check suite re-run unaffected.
- Built-in-whitelist summary line (same request, "the description of the whitelist should be changed"):
  `ui/popup.js` bulletsFor() builtin bullet — was "Built-in whitelist: payment, login, CAPTCHA" (stale
  since the streaming/meeting/gaming addition above), now "Trusted: payment, sign-in, streaming,
  meetings, games". Checked by measuring scrollWidth vs clientWidth in Chromium (no ellipsis cutoff) —
  a longer draft that also named CAPTCHA was clipped and was shortened to fit.
- Popup layout (user request): `ui/popup.html` moves the two `.safe-intro` paragraphs to after `#tldTags`
  (was before the Add row). `ui/popup.css` `.tags` drops `max-height: 110px; overflow-y: auto` — the tag list
  grows to fit its content instead of scrolling inside a fixed box.
- `core/tld-engine.js` LANG_WORLD_DEFAULTS.en: `nz` added (user decision) — completes the Five Eyes for a bare
  "en" tag; the one deliberate difference from uBD's country-code default. Not on HaGeZi.
- Base TLDs unchanged: 3P Matrix keeps its 13 (uBD's 18 generic TLDs minus biz/shop/store/site/online, which
  are HaGeZi-abused — spec decision). Only the country-code part follows uBD.

**Tests (slider)**: Node 8/8 — default state has no mode; a 0.2.3 state with autoTldMode 0 normalises without it
and keeps its edits; nl-NL+en-US+en → base + nl, us, uk, ie, au, ca, eu, be, mt, im; added/removed honoured;
settings round trip; a 0.2.3 file with "WORLDWIDE" restores. Chromium at L3: no slider, 29 TLDs, Add/× /Default
work, stored safeZone = {manualTlds, excludedTlds, tlds}, no console errors. Earlier suite still 23/23.

**Tests**: unit (Node, chrome mocked) 23/23 — registry 15 entries, nums 1–15, group "On every site" = 10;
counts 10/10 at L2 and 15 at L3; old 0.2.3 state normalises with the warning ticked; DNR rules and script
registrations byte-identical with the warning on/off; guard: dialog at L2/L5 when ticked, none when unticked,
none at L1 or for allow-listed sites, dialog for a site locked at L4 under global L1. Chromium (unpacked
extension): suspicious URL → warning page; untick 10 in the popup → page opens without dialog, popup shows
"9 of 10 protections active · Warnings for suspicious sites off"; re-tick → dialog again; 5 scripts at L2.

WARNING FOR IMPLEMENTATION IMPACT: protection numbers 10–14 shown in the popup become 11–15.

**Known limitations**: the 0.2.3 upgrade-test limitation (content scripts not re-registered after swapping
unpacked files) is not addressed here; this release changes no content-script registrations.

## 0.2.3 — protections 1 and 2 removed
Working from: 0.2.2. Zips changed: extension, docs. Tools repackaged unchanged.

**What / why**: the user keeps "Clear history at browser start" (deleteHistoryOnStart) and "Block tracking
pings" (blockPings) in uBlock Stripped Dynamic and does not want them duplicated here.

**How**
- `data/protections.js`: both entries dropped, remaining 14 renumbered (num 1–14), `MECH.STARTUP` removed
  (no startup-mechanism protection is left). A comment records what was removed and when.
- `background.js`: `clearHistoryOncePerLaunch()` and its SESSION_KEY_BOOTED guard removed; onStartup now only
  restores the startup level and applies. `data/constants.js`: SESSION_KEY_BOOTED removed.
- `manifest.json`: `browsingData` permission dropped — an update that only REMOVES a permission does not
  disable the extension for existing users (the reverse would; see the principles doc, C36).
- Old saved state is cleaned automatically: `normalizeState()` keeps only keys in PROTECTION_KEYS, so
  `deleteHistoryOnStart` / `blockPings` entries in disabledProtections disappear on first load.
- Protection numbers in comments across constants, rule-builder, network-data and README renumbered with the
  registry (ids, priorities and keys unchanged — only display numbers shifted).
- `core/apply-manager.js` guard added (see limitations): our script ids are unregistered one at a time so a
  stale id from a previous version cannot abort the batch; after registering, the set is read back and, on a
  mismatch, re-registered one by one with per-id errors logged.

**Tests**: builders 9/9 protections at L2 and 14 at L3+; safer-levels 14/14; matcher 19/19; settings save +
restore round trip ("14 of 14 protections on"); Chromium fresh install registers the expected 5 scripts at L2
and 7 at L3.

WARNING FOR IMPLEMENTATION IMPACT: history is no longer cleared at browser start and tracking pings are no
longer blocked by 3P Matrix — uBlock Stripped Dynamic must cover both. The protection numbers users see in
the popup shift by two (old 3 = new 1).

**Known limitations**: in a test that upgrades an existing 0.2.2 profile to 0.2.3 by swapping the unpacked
files, no content scripts were registered afterwards (a fresh install is correct, and dynamic DNR rules were
applied). The apply-manager guard above did not change that result and the cause is not yet identified — it
may be an artifact of how the test fakes an update. Workaround: reload the extension in chrome://extensions
after updating. To investigate next: whether Chrome keeps the previous version's persisted registrations
(including `tldm-blockPings`, whose file no longer exists) in a state where getRegisteredContentScripts()
reports nothing while registerContentScripts() silently does not take effect.

---

## 0.2.2 — safer regions at level 3 only; Show Matrix auto-close; dead code removed
Working from: 0.2.1 working tree. Zips changed: extension, docs (new). Tools zip repackaged with unchanged content.

**What / why**
- Safer regions now have an effect at level 3 only (user decision 2026-10-16: "always apply the protections
  at level 4 and 5 and remove the TLD whitelist"). Before, protections 12–16 skipped safer-region sites at
  levels 3–5 because levels are cumulative; at 4–5 that was an unwanted exception.
- Popup: safer-regions panel + IN/OUTSIDE label hidden below level 3 (first step, user screenshot "irrelevant
  for level 2"), then also at 4–5.
- Show Matrix window now closes after the 5-minute observation (user asked whether that guard existed — it
  did not: observation stopped and memory was released, but the window stayed open and overrides in it failed
  with "bad matrix rule" because the observed site was gone).
- Old 3P-Matrix-lite level 2 TLD blocklist code removed (`rebuildBlockedTldList`, `ownCountryTlds`,
  `GENERIC_BLOCKED_TLDS`, `WORLD_BLOCKED_TLDS`) — unreferenced since the HaGeZi list replaced it.

**How**
- `data/constants.js` `SAFER_REGIONS_LEVELS = [LEVEL.MEDIUM]` (single switch); `core/policy.js`
  `saferRegionsApply(level)`. Used by:
  - `core/rule-builder.js` headerRules: `excludedRequestDomains: safeTlds` only when saferRegionsApply(group
    level); levelRules: safer-regions allow rule only then.
  - `core/script-builder.js` (rewritten): per protection, the global registration excludes the safer TLD
    patterns only when the GLOBAL level is 3; locked sites follow their locked level — locked-3 sites in safer
    regions are excluded/omitted, and sites in safer regions locked at 4–5 under a global level 3 get a second
    registration (id `tldm-<key>-locked`) because an excludeMatches TLD pattern cannot be re-included.
  - `ui/popup.js` panel/label visibility; `background.js` popupModel picks the group title
    (`PROTECTION_GROUPS[].titleNoSaferRegions` = "Extra — on every site").
- `SCOPE.OUTSIDE_SAFE_ZONE` renamed `SCOPE.OUTSIDE_SAFER_REGIONS` (internal enum; state key `safeZone` kept —
  storage contract).
- Show Matrix guards: `startMatrix(tabId, host, onExpire)` — the timeout releases data + listener, then
  `background.js closeMatrixPanel()` closes the window (shared with tabs.onRemoved). Panel side
  (`ui/matrix.js`): closes itself when the model reports `observing:false` (covers a service-worker restart,
  which loses the in-memory observation and `_matrixWindows`); last-resort timer re-armed every poll from the
  SW's `remaining` + `MATRIX_CLOSE_GRACE_MS` (5 s); both timers released on `pagehide`.
- Matrix help text: second sentence in `<span class="mx-help-line">` (display:block).

**Tests**: new `safer-levels-test` 14/14 (levels 3/4/5 global, mixed global/locked levels, rescue registration);
builders + matcher tests unchanged and passing; Chromium: all five levels apply without errors, panel only at
L3, L5 eval registration has no TLD excludes; matrix auto-close verified with an 8-second test build (timeout
path and silent-stop path).

WARNING FOR IMPLEMENTATION IMPACT: at levels 4–5, sites on safer-region TLDs (e.g. your own country) lose
camera/mic/Bluetooth/USB/sensors/NFC access and get the eval and frame-redirect protections — sites that need
those must be locked at level 3 or lower, or put on the allow list.

**Known limitations**: a 4–5-locked site in safer regions under a global level 3 gets the scripts in its own
frames only; third-party frames inside it that are themselves on safer TLDs stay excluded by the global TLD
pattern (the DNR header rules do cover them).

**tools 0.2.2:** no content change since 0.1.1 (build-spam-tlds.mjs + HaGeZi source list); repackaged under
the release version.

---

## 0.2.1 — settings backup format v2; Show Matrix column layout
Working from: 0.2.0. Zips changed: extension (tools repackaged unchanged).

**What / why**: the user reported that the safer-regions (TLD whitelist) settings and the Show Matrix changes
were lost in save/restore. Functionally the v1 backup (raw state) did round-trip, but it was unreadable and gave
no feedback, so it could not be checked. Show Matrix layout aligned with uBlock Stripped Dynamic's panel.

**How**
- New `data/settings-io.js` (pure): `toSettingsFile` / `fromSettingsFile` / `summarize`. Format
  `3p-matrix-settings` v2 with plain sections: startupLevel, protections.disabled, saferRegions
  {autoAddCountryCodes, addedTlds, removedTlds, activeTlds (informational, recomputed on restore)}, allowList,
  lockedSites, showMatrixRules, onlineChecks. v1 files (`{format, state}`) still accepted. Restore always runs
  `normalizeState()` and recomputes safer regions for this browser's languages.
- `normalizeState` validates `matrixRules` (valid hosts, known scopes/actions, capped at MATRIX_OVERRIDES_CAP).
- Matrix panel: Third-party domain | Override (3P-code, 3P-all) | Seen: 7 fixed columns (MATRIX_TYPE_ORDER:
  image, media, css, script, frame, xhr, other) | Req. Seen marks: mint #6EE7B7 square + dark ✓ (allowed),
  #EF4444 square + white ✕ (blocked by 3P Matrix). `webtransport` removed from MATRIX_TYPE_LABEL — not a valid
  webRequest filter type (listener registration failed).

**Tests**: io-test / io-ui-test (round trip, v1 import), matrix-test with css/xhr/image requests.

---

## 0.2.0 — Show Matrix; badge counts our blocks only; UI fixes
Working from: 0.1.1. Zips changed: extension (tools repackaged unchanged).

**What / why**
- Show Matrix built (was a disabled button in 0.1.1).
- Badge count equalled uBlock Dynamic's: `webRequest.onErrorOccurred` reports `net::ERR_BLOCKED_BY_CLIENT` for
  every extension's blocks. User chose option 1: count only 3P Matrix's blocks.
- Protections list was always visible; Show Matrix button not clickable; "safe zone" → "safer regions".

**How**
- `core/connection-matrix.js` (ported from 3P-Matrix-lite 4.0.2): per-tab buckets by registered domain, types
  seen + types blocked; capped 150 domains/tab; 5-minute observation; the webRequest.onBeforeRequest listener
  exists only while a tab is observed. `buildMatrixRules`: 3P-code (script+sub_frame) priority 400001, 3P-all
  400000, ids 900000+, only the L5 block-all (500000) outranks them.
- `core/rule-matcher.js`: replays DNR matching on OUR applied rules (resourceTypes, domainType,
  initiator/request domains incl. parents, regexFilter, urlFilter anchors/wildcards; highest priority wins,
  allow beats block at equal priority; ~9 µs/check). `apply-manager.js` keeps the compiled copy of exactly what
  Chrome has. Only outcome "block" is counted (badge and matrix red marks).
- `ui/common.css`: global `[hidden] { display:none !important }` guard (`.prot-panel {display:flex}` overrode
  the attribute).
- `core/safe-zone.js` → `core/safer-regions.js`; all UI/comments renamed (state key `safeZone` kept).
- Zips unpack to version-less folders `3P-Matrix` / `3P-Matrix-tools`.

---

## 0.1.1 — first prototype
Working from: the three source extensions above; spec `SPEC_levels_and_protections.md`.

Architecture: `data/constants.js` holds every switch/ID/priority/score; `data/protections.js` is the registry
of the 16 protections; pure builders (`core/policy.js`, `rule-builder.js`, `script-builder.js`); only
`core/apply-manager.js` writes to Chrome (serialized, coalesced, regexes validated with isRegexSupported).
Rules per GROUP (group 0 global excluding locked sites, groups 1–5 per locked level; id = 10000 × group +
local id). Non-standard-port block as one regex (an allow-twin rule would have overridden TLD/level blocks).
Detection: DownloadSentinel 3.0.4 heuristics (two marked patches: subdomain count beyond the public suffix,
NonStandardPort family) + CombinationScoring; stage 2 (RDAP + two DoH resolvers, RFC 8484 wire format) only
at score ≤ −30. Warning: `webNavigation.onBeforeNavigate` holds the tab on `ui/warning.html`. State: single
key `tldm_state`, `normalizeState`, `withStateLock`. Show Matrix reserved (button disabled).

Known gap: "paypa1" is not seen as a "paypal" typo (DownloadSentinel maps 1→i only).
