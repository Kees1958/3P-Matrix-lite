// ── Constants ─────────────────────────────────────────────────────────────────
var LOG_DURATION_MS = 5 * 60 * 1000;   // 5 minutes
var POLL_INTERVAL   = 2000;             // poll every 2 seconds
var MAX_LOGS        = 500;              // must match background.js MAX_LOGS — used only
                                         // to detect/announce the cap, the actual eviction
                                         // happens in background.js

// ── DOM refs ──────────────────────────────────────────────────────────────────
var timerBadge   = document.getElementById('timerBadge');
var stopBtn      = document.getElementById('stopBtn');
var logBody      = document.getElementById('logBody');
var sessionEnded = document.getElementById('sessionEnded');
var tableWrap    = document.getElementById('tableWrap');
var footerBar    = document.getElementById('footerBar');

var statTotal      = document.getElementById('statTotal');
var statScripts    = document.getElementById('statScripts');
var statFrames     = document.getElementById('statFrames');
var statIp         = document.getElementById('statIp');
var statHttp       = document.getElementById('statHttp');
var statPort       = document.getElementById('statPort');
var statStylesheet = document.getElementById('statStylesheet');
var statAllowed    = document.getElementById('statAllowed');
var statBlocked    = document.getElementById('statBlocked');

// ── State ─────────────────────────────────────────────────────────────────────
var pollTimer    = null;
var countdownInt = null;
var ended        = false;
var lastLogCount = -1;

// ── Helpers ───────────────────────────────────────────────────────────────────
function pad(n) { return n < 10 ? '0' + n : String(n); }

function formatTime(ms) {
  var s = Math.max(0, Math.ceil(ms / 1000));
  return Math.floor(s / 60) + ':' + pad(s % 60);
}

function formatTimestamp(ts) {
  var d = new Date(ts);
  return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function reasonClass(reason) {
  if (reason.indexOf('3P-script') === 0)     return 'script';
  if (reason.indexOf('3P-frame') === 0)      return 'frame';
  if (reason.indexOf('3P-XHR') === 0)        return 'xhr';
  if (reason.indexOf('3P-media') === 0)      return 'media';
  if (reason.indexOf('3P-image') === 0)      return 'image';
  if (reason.indexOf('3P-stylesheet') === 0) return 'stylesheet';
  if (reason.indexOf('3P-font') === 0)       return 'other';
  if (reason.indexOf('3P-ping') === 0)       return 'other';
  if (reason.indexOf('3P-ws') === 0)         return 'xhr';
  if (reason.indexOf('3P-object') === 0)     return 'other';
  if (reason.indexOf('3P-other') === 0)      return 'other';
  if (reason.indexOf('IP block') === 0)      return 'ip';
  if (reason.indexOf('HTTP block') === 0)    return 'http';
  if (reason.indexOf('port:') === 0)         return 'port';
  return 'other';
}

// ── Table rendering ───────────────────────────────────────────────────────────
function renderLogs(logs) {
  if (!logs || logs.length === 0) {
    logBody.innerHTML = '<tr class="empty-row"><td colspan="5">Waiting for third-party traffic\u2026</td></tr>';
    statTotal.textContent      = '0';
    statScripts.textContent    = '0';
    statFrames.textContent     = '0';
    statIp.textContent         = '0';
    statHttp.textContent       = '0';
    statPort.textContent       = '0';
    statStylesheet.textContent = '0';
    statAllowed.textContent    = '0';
    statBlocked.textContent    = '0';
    return;
  }

  // Stats
  var counts = { script: 0, frame: 0, xhr: 0, media: 0, image: 0, stylesheet: 0,
    ip: 0, http: 0, port: 0, other: 0, allowed: 0, blocked: 0 };
  logs.forEach(function(e) {
    var rc = reasonClass(e.reason);
    if (counts[rc] !== undefined) counts[rc]++;
    else counts.other++;
    if (e.action === 'allowed') counts.allowed++;
    else counts.blocked++; // older log entries without an action field default to blocked
  });
  statTotal.textContent      = logs.length;
  statScripts.textContent    = counts.script;
  statFrames.textContent     = counts.frame;
  document.getElementById('statXhr').textContent   = counts.xhr;
  document.getElementById('statMedia').textContent = counts.media;
  statStylesheet.textContent = counts.stylesheet;
  statIp.textContent         = counts.ip;
  statHttp.textContent       = counts.http;
  statPort.textContent       = counts.port;
  statAllowed.textContent    = counts.allowed;
  statBlocked.textContent    = counts.blocked;

  // Only re-render if count changed (avoids scroll reset on every poll)
  if (logs.length === lastLogCount) return;
  lastLogCount = logs.length;

  // Render newest first — use DOM API to avoid XSS via storage-derived values
  var frag = document.createDocumentFragment();
  for (var i = logs.length - 1; i >= 0; i--) {
    var e  = logs[i];
    var rc = reasonClass(e.reason); // returns only hardcoded class strings — safe as className
    var actionType = e.action === 'allowed' ? 'allowed' : 'blocked'; // default for older entries

    var tr = document.createElement('tr');

    var tdDomain = document.createElement('td');
    tdDomain.className = 'domain';
    tdDomain.textContent = e.domain || '\u2014';
    tr.appendChild(tdDomain);

    var tdAction = document.createElement('td');
    tdAction.className = 'action';
    var actionBadge = document.createElement('span');
    actionBadge.className = 'action-badge ' + actionType;
    actionBadge.textContent = actionType;
    tdAction.appendChild(actionBadge);
    tr.appendChild(tdAction);

    var tdReason = document.createElement('td');
    tdReason.className = 'reason';
    var badge = document.createElement('span');
    badge.className = 'reason-badge ' + rc;
    badge.textContent = e.reason;
    tdReason.appendChild(badge);
    tr.appendChild(tdReason);

    var tdUrl = document.createElement('td');
    tdUrl.className = 'url';
    tdUrl.textContent = e.url;
    tr.appendChild(tdUrl);

    var tdTime = document.createElement('td');
    tdTime.className = 'time';
    tdTime.textContent = formatTimestamp(e.time);
    tr.appendChild(tdTime);

    frag.appendChild(tr);
  }
  logBody.innerHTML = ''; // clear previous rows
  logBody.appendChild(frag);
}

// ── Countdown ─────────────────────────────────────────────────────────────────
function startCountdown(startTime) {
  if (countdownInt) clearInterval(countdownInt);

  countdownInt = setInterval(function() {
    var elapsed    = Date.now() - startTime;
    var remaining  = LOG_DURATION_MS - elapsed;

    if (remaining <= 0) {
      clearInterval(countdownInt);
      countdownInt = null;
      timerBadge.textContent = '0:00';
      timerBadge.className   = 'timer-badge done';
      endSession();
      return;
    }

    timerBadge.textContent = formatTime(remaining);
    timerBadge.className   = remaining < 60000 ? 'timer-badge ending' : 'timer-badge';
  }, 500);
}

// ── Poll for new logs ─────────────────────────────────────────────────────────
function startPolling() {
  if (pollTimer) clearInterval(pollTimer);

  pollTimer = setInterval(function() {
    chrome.storage.local.get({ logging: false, logs: [], logStartTime: null, logsCapHit: false }, function(s) {
      // If background stopped logging (timer fired), end here too
      if (!s.logging && !ended) { endSession(); return; }
      renderLogs(s.logs);
      // Once the MAX_LOGS cap has been hit, the oldest entries are being silently
      // overwritten (FIFO eviction in background.js) — let the user know via the
      // footer, since otherwise they'd have no way to tell older data was dropped.
      if (s.logsCapHit && !ended) {
        footerBar.textContent = 'Logging active \u2014 ' + MAX_LOGS + ' entries reached, oldest log lines are now being overwritten';
        footerBar.classList.add('warning');
      }
    });
  }, POLL_INTERVAL);
}

// ── End session ───────────────────────────────────────────────────────────────
function endSession() {
  if (ended) return;
  ended = true;

  if (pollTimer)    { clearInterval(pollTimer);    pollTimer    = null; }
  if (countdownInt) { clearInterval(countdownInt); countdownInt = null; }

  // Tell background to stop (in case timer in background hasn't fired yet)
  try { chrome.runtime.sendMessage({ type: "STOP_LOGGING" }); } catch(e) {}

  // Show session ended UI
  tableWrap.style.display    = 'none';
  sessionEnded.classList.add('visible');
  footerBar.textContent      = 'Session ended — window closing in 3 seconds';
  footerBar.classList.remove('warning');
  timerBadge.className       = 'timer-badge done';

  // Close this tab after 3 seconds
  setTimeout(function() { window.close(); }, 3000);
}

// ── Stop button ───────────────────────────────────────────────────────────────
stopBtn.addEventListener('click', function() { endSession(); });

// ── Boot ──────────────────────────────────────────────────────────────────────
chrome.storage.local.get({ logging: false, logs: [], logStartTime: null, logsCapHit: false }, function(s) {
  if (!s.logging) {
    // Logging already stopped before we opened — just close
    endSession();
    return;
  }

  // Start countdown from the stored start time
  var startTime = s.logStartTime || Date.now();
  startCountdown(startTime);

  // Render existing logs immediately
  renderLogs(s.logs);
  if (s.logsCapHit) {
    footerBar.textContent = 'Logging active \u2014 ' + MAX_LOGS + ' entries reached, oldest log lines are now being overwritten';
    footerBar.classList.add('warning');
  }

  // Start polling
  startPolling();
});

// Also listen for background stopping logging
chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === "LOGGING_STOPPED") endSession();
});
