/**
 * background.js — 3P-Matrix-lite service worker
 *
 * Levels 1–5:
 *   1  Easy mode — allow all
 *   2  Easy mode with enhanced sec.    base safety + domain whitelist + block 3P frames
 *   3  Easy medium mode                base safety + TLD whitelist + block 3P frames+scripts
 *   4  Medium mode — trust CDN's       base safety + domain whitelist + CDN allow + block 3P frames+scripts
 *   5  Medium mode                     base safety + domain whitelist + block 3P frames+scripts + catch-all
 *
 * siteRules: { "hostname": level, ... }  — FIFO cap of 100 entries
 * Site-specific rules use initiatorDomains and get priority 6000+,
 * overriding the global rules which exclude pinned hostnames via excludedInitiatorDomains.
 */

var STORAGE_KEY    = "3pmatrix_state";
var SITE_RULES_CAP = 100;

var DEFAULT_STATE = {
  startupLevel: 1,
  level:        1,
  tlds:         ["com","ai","edu","gov","io","net","org","cloud"],
  domains:      [],
  builtinDomains: null,  // seeded with BUILTIN_DOMAINS on first install, editable/removable by the user
  autoTldMode:  1,
  manualTlds:   [],
  excludedTlds: [],  // TLDs the user explicitly removed — popup.js keeps these out on re-sync
  siteRules:    {},   // { "hostname": level }
  siteRulesOrder: [] // insertion-order array for FIFO eviction
};

// Built-in trusted third-party domains: payment processors, video embeds, CAPTCHA/bot-protection.
// Seeded into state.builtinDomains on install, applied only at level 2 (Easy mode with enhanced
// security). They appear as regular, removable entries in the Domain whitelist tab at L2 —
// no toggle, no special-casing; the user can delete any entry they don't want, just like any
// manually-added domain.
var BUILTIN_DOMAINS = [
  // Payment — core / international
  "js.stripe.com","checkout.stripe.com","stripe.com",
  "paypal.com","paypalobjects.com",
  "js.braintreegateway.com","assets.braintreegateway.com",
  "checkout.com","cdn.checkout.com",
  "adyen.com","checkoutshopper-live.adyen.com",
  "klarna.com","x.klarnacdn.net",
  "squareup.com","js.squareup.com",
  "worldpay.com",
  // Payment — Benelux
  "mollie.com","js.mollie.com","ideal-checkout.nl",
  "wero-wallet.eu","buckaroo.nl","pay.nl","sisow.nl",
  "multi-safepay.com","cm.com","tikkie.nl",
  "onlinepaymentplatform.nl","billink.nl",
  "noda.live","plugandpay.io","pronamicpay.com",
  // Payment — DACH
  "ratepay.com","riverty.com","computop.com","unzer.com","payone.com","twint.ch",
  // Payment — France
  "lyra.com","payplug.com","paybox.com",
  // Payment — Italy
  "nexi.it","satispay.com","postepay.it",
  // Payment — Spain
  "redsys.es","bizum.es",
  // Payment — Nordics
  "vipps.no","mobilepay.dk","vippsmobilepay.com",
  "getswish.se","swish.nu","walleypay.com","siirto.fi","trustly.com",
  // Video embeds
  "youtube.com","youtube-nocookie.com","ytimg.com","googlevideo.com",
  "vimeo.com","player.vimeo.com","vimeocdn.com",
  "wistia.com","fast.wistia.com",
  "dailymotion.com",
  "jwplatform.com","jwpcdn.com",
  "brightcove.com","players.brightcove.net",
  // CAPTCHA / bot protection
  "google.com","recaptcha.net","gstatic.com",
  "hcaptcha.com","js.hcaptcha.com",
  "challenges.cloudflare.com",
  "friendlycaptcha.com"
];

var RP_3P = [
  "sub_frame","stylesheet","script","image",
  "font","object","xmlhttprequest","ping","media","websocket","other"
];
// RP_3P is the full resource-type list, used ONLY for the base safety rules (HTTP/WS/
// port/IP blocks below) and for ALLOW rules (TLD/domain/CDN whitelists, levels 3-5) —
// these are intentionally broad, since an allow rule or a security block (e.g. plain
// HTTP) should apply across every resource type.
//
// IMPORTANT — the extension's actual third-party BLOCKING scope is deliberately
// limited to frames and scripts ONLY (see "Block 3P frames" / "Block 3P scripts"
// below). There must be no catch-all block rule using RP_3P or any other resource-type
// list beyond ["sub_frame"] / ["script","webbundle"] — doing so would also block XHR,
// images, media, fonts, etc., which is explicitly NOT the extension's intended scope.
// A previous version had a level-5 "catch-all" block using RP_3P that silently blocked
// XHR/image/etc. requests; this was a bug, not a feature, and was removed. If a future
// change needs a broader block, scope it explicitly to the intended resource types —
// do not reuse RP_3P for a block rule.

// ── Base safety rules (levels 2–5) ───────────────────────────────────────────
function baseRules(excludedDomains) {
  var cond = excludedDomains && excludedDomains.length
    ? { excludedInitiatorDomains: excludedDomains }
    : {};
  return [
    { id: 1001, priority: 50, action: { type: "block" },
      condition: Object.assign({ regexFilter: "^http://", domainType: "thirdParty",
        isUrlFilterCaseSensitive: false, resourceTypes: RP_3P }, cond) },
    { id: 1002, priority: 50, action: { type: "block" },
      condition: Object.assign({ regexFilter: "^ws://", domainType: "thirdParty",
        isUrlFilterCaseSensitive: false, resourceTypes: ["websocket"] }, cond) },
    { id: 1003, priority: 50, action: { type: "block" },
      condition: Object.assign({ regexFilter: "^https?://[^/?#:]+:([1-9][0-9]?|[1-3][0-9]{2}|4[0-3][0-9]|44[0-2])([/?#]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P }, cond) },
    { id: 1004, priority: 50, action: { type: "block" },
      condition: Object.assign({ regexFilter: "^https?://[^/?#:]+:(44[4-9]|4[5-9][0-9]|[5-9][0-9]{2}|[1-9][0-9]{3,})([/?#]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P }, cond) },
    { id: 1005, priority: 50, action: { type: "block" },
      condition: Object.assign({ regexFilter: "^https?://[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+([/?#:]|$)",
        domainType: "thirdParty", isUrlFilterCaseSensitive: false, resourceTypes: RP_3P }, cond) }
  ];
}

// ── Whitelist allow rule builders ─────────────────────────────────────────────
function tldAllowRules(tlds, excludedDomains) {
  var r = [], cond = excludedDomains && excludedDomains.length
    ? { excludedInitiatorDomains: excludedDomains } : {};
  tlds.slice(0, 100).forEach(function(tld, i) {
    r.push({ id: 2400 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*." + tld + "/*", resourceTypes: RP_3P }, cond) });
    r.push({ id: 2600 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*." + tld + "/",  resourceTypes: RP_3P }, cond) });
  });
  return r;
}

function domainAllowRules(domains, excludedDomains) {
  var r = [], cond = excludedDomains && excludedDomains.length
    ? { excludedInitiatorDomains: excludedDomains } : {};
  domains.slice(0, 100).forEach(function(d, i) {
    r.push({ id: 2000 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*" + d + "/*", resourceTypes: RP_3P }, cond) });
    r.push({ id: 2200 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*" + d + "/",  resourceTypes: RP_3P }, cond) });
  });
  return r;
}

// ── Build rules for a single level (reusable for global + per-site) ───────────
function rulesForLevel(level, tlds, domains, idOffset, initiatorDomains, excludedDomains, builtinDomains) {
  var rules = [];
  if (level === 1) return [];

  var siteScope  = initiatorDomains  && initiatorDomains.length  ? { initiatorDomains: initiatorDomains }   : {};
  var globalExcl = excludedDomains   && excludedDomains.length   ? { excludedInitiatorDomains: excludedDomains } : {};
  var scope      = initiatorDomains  ? siteScope : globalExcl;

  // Base safety
  [
    { id: 1001, regexFilter: "^http://",   resourceTypes: RP_3P },
    { id: 1002, regexFilter: "^ws://",     resourceTypes: ["websocket"] },
    { id: 1003, regexFilter: "^https?://[^/?#:]+:([1-9][0-9]?|[1-3][0-9]{2}|4[0-3][0-9]|44[0-2])([/?#]|$)", resourceTypes: RP_3P },
    { id: 1004, regexFilter: "^https?://[^/?#:]+:(44[4-9]|4[5-9][0-9]|[5-9][0-9]{2}|[1-9][0-9]{3,})([/?#]|$)", resourceTypes: RP_3P },
    { id: 1005, regexFilter: "^https?://[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+([/?#:]|$)", resourceTypes: RP_3P }
  ].forEach(function(r) {
    rules.push({ id: idOffset + r.id, priority: 50, action: { type: "block" },
      condition: Object.assign({ regexFilter: r.regexFilter, domainType: "thirdParty",
        isUrlFilterCaseSensitive: false, resourceTypes: r.resourceTypes }, scope) });
  });

  // Built-in trusted domains (payment/video/captcha) — levels 2, 3 and 4, scoped to
  // sub_frame only since these services load as embedded iframes. This is the one
  // allow-mechanism that's consistent across all "easy"/"medium" levels, so payment
  // checkouts, video embeds and CAPTCHA challenges keep working no matter which of
  // these levels the user is on.
  if ((level === 2 || level === 3 || level === 4) && builtinDomains && builtinDomains.length) {
    builtinDomains.slice(0, 200).forEach(function(d, i) {
      rules.push({ id: idOffset + 2800 + i, priority: 1000, action: { type: "allow" },
        condition: Object.assign({ urlFilter: "*" + d + "/*", resourceTypes: ["sub_frame"] }, scope) });
    });
  }

  // TLD allow (level 3) — scoped to script only. Third-party frames at level 3 are
  // covered exclusively by the built-in whitelist above; the TLD whitelist exists to
  // let trusted scripts load from a user's own trusted TLDs (e.g. their country code).
  if (level === 3) {
    tlds.slice(0, 100).forEach(function(tld, i) {
      rules.push({ id: idOffset + 2400 + i, priority: 1000, action: { type: "allow" },
        condition: Object.assign({ urlFilter: "*." + tld + "/*", resourceTypes: ["script"] }, scope) });
      rules.push({ id: idOffset + 2600 + i, priority: 1000, action: { type: "allow" },
        condition: Object.assign({ urlFilter: "*." + tld + "/",  resourceTypes: ["script"] }, scope) });
    });
  }

  // CDN allow (level 4) — scoped to script only, same reasoning as the TLD whitelist
  // above: frames are already covered by the built-in whitelist at this level.
  if (level === 4) {
    rules.push({ id: idOffset + 3000, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*cdn*", resourceTypes: ["script"] }, scope) });
  }

  // Domain allow (levels 4 and 5) — manual user whitelist, full resource-type scope
  // (covers both frames and scripts). At level 4 this layers on top of the built-in
  // whitelist (sub_frame) and CDN script-only exception, giving the user a way to add
  // their own trusted sources with full coverage, same as level 5.
  if (level === 4 || level === 5) {
    domains.slice(0, 100).forEach(function(d, i) {
      rules.push({ id: idOffset + 2000 + i, priority: 1000, action: { type: "allow" },
        condition: Object.assign({ urlFilter: "*" + d + "/*", resourceTypes: RP_3P }, scope) });
      rules.push({ id: idOffset + 2200 + i, priority: 1000, action: { type: "allow" },
        condition: Object.assign({ urlFilter: "*" + d + "/",  resourceTypes: RP_3P }, scope) });
    });
  }

  // Block 3P frames (levels 2–5) — THIS, plus the script block directly below, is the
  // entire third-party blocking surface of the extension. Resource types other than
  // sub_frame/script/webbundle are never blocked by design (see RP_3P comment above).
  rules.push({ id: idOffset + 3001, priority: 20, action: { type: "block" },
    condition: Object.assign({ domainType: "thirdParty", resourceTypes: ["sub_frame"] }, scope) });

  // Block 3P scripts (levels 3–5)
  if (level >= 3) {
    rules.push({ id: idOffset + 3002, priority: 20, action: { type: "block" },
      condition: Object.assign({ domainType: "thirdParty", resourceTypes: ["script","webbundle"] }, scope) });
  }

  // Visibility-only catch-all (levels 2-5) — an ALLOW rule covering every third-party
  // resource type the extension does NOT block (XHR, image, media, font, stylesheet,
  // ping, websocket, object, other). This has ZERO effect on browsing: these resource
  // types were never blocked to begin with, so "allowing" them changes nothing about
  // what the user can load. It's always present in the ruleset (not conditional on
  // whether logging is currently active) — onRuleMatchedDebug listener itself checks
  // the "logging" flag before writing anything, so this rule existing costs nothing
  // when logging is off. Its only purpose is to make onRuleMatchedDebug fire for this
  // traffic so the request logger can show it when logging IS active — DNR's debug
  // API only fires for requests that match SOME rule, and without this, XHR/image/etc.
  // traffic that hits no whitelist rule would be completely invisible to the logger
  // (see RP_3P comment above for why a BLOCK catch-all must never be used here instead).
  if (level >= 2) {
    rules.push({ id: idOffset + 3500, priority: 5, action: { type: "allow" },
      condition: Object.assign({ domainType: "thirdParty",
        resourceTypes: ["xmlhttprequest","image","media","font","stylesheet","ping","websocket","object","other"] }, scope) });
  }

  return rules;
}

// ── Master rule builder ───────────────────────────────────────────────────────
function buildRules(state) {
  var level      = state.level;
  var tlds       = state.tlds    || [];
  var domains    = state.domains || [];
  var siteRules  = state.siteRules || {};
  var pinnedHosts = Object.keys(siteRules);
  var rules      = [];

  // Global rules — exclude pinned hostnames so site rules win
  rules = rules.concat(rulesForLevel(level, tlds, domains, 0, null, pinnedHosts, state.builtinDomains));

  // Per-site rules — id offset per site slot, widened to 5000 to safely cover the full
  // local ID range used by rulesForLevel (up to 4000) without any risk of collision between
  // adjacent pinned sites' rule sets.
  pinnedHosts.forEach(function(host, i) {
    var siteLevel = siteRules[host];
    var offset    = 100000 + (i * 5000);
    var siteSpecific = rulesForLevel(siteLevel, tlds, domains, offset, [host], null, state.builtinDomains);
    rules = rules.concat(siteSpecific);
  });

  return rules;
}

// ── Icon ──────────────────────────────────────────────────────────────────────
function setIcon(level) {
  var idx = level - 1;
  try {
    chrome.action.setIcon({ path: {
      "16":  "icon_" + idx + "_16.png",
      "32":  "icon_" + idx + "_32.png",
      "48":  "icon_" + idx + "_48.png",
      "128": "icon_" + idx + "_128.png"
    }});
  } catch(e) {}
}

// ── State helpers ─────────────────────────────────────────────────────────────
function loadState(cb) {
  chrome.storage.local.get(STORAGE_KEY, function(stored) {
    var s = Object.assign({}, DEFAULT_STATE, stored[STORAGE_KEY] || {});
    if (s.level === 0) s.level = 1;
    if (s.startupLevel === 0) s.startupLevel = 1;
    if (!s.siteRules) s.siteRules = {};
    if (!s.siteRulesOrder) s.siteRulesOrder = Object.keys(s.siteRules);
    // Seed builtinDomains for upgrades from versions that predate this feature
    if (s.builtinDomains === null || s.builtinDomains === undefined) {
      s.builtinDomains = BUILTIN_DOMAINS.slice();
    }
    cb(s);
  });
}

function saveState(s, cb) {
  var o = {}; o[STORAGE_KEY] = s;
  chrome.storage.local.set(o, cb || function(){});
}

// Maps each currently-active dynamic rule's id -> its action type ('allow'/'block').
// This is necessary because chrome.declarativeNetRequest's MatchedRule type (returned
// in onRuleMatchedDebug's info.rule) only contains { ruleId, rulesetId } — it does NOT
// include the rule's action. There is no way to ask the debug API "was this an allow or
// a block" directly; we have to look it up ourselves from the rules we created.
// Rebuilt every time applyState() successfully updates the ruleset (see call site
// inside applyState below) so it always reflects the currently-active rules.
var RULE_ACTIONS = {};

function rebuildRuleActionIndex() {
  chrome.declarativeNetRequest.getDynamicRules(function(rules) {
    RULE_ACTIONS = {};
    rules.forEach(function(r) {
      if (r.action && r.action.type) RULE_ACTIONS[r.id] = r.action.type;
    });
  });
}

function applyState(s, cb) {
  chrome.declarativeNetRequest.getDynamicRules(function(existing) {
    var removeIds = existing.map(function(r) { return r.id; });
    var addRules  = buildRules(s);
    chrome.declarativeNetRequest.updateDynamicRules(
      { removeRuleIds: removeIds, addRules: addRules },
      function() {
        if (chrome.runtime.lastError) {
          console.warn("[3PM] updateDynamicRules:", chrome.runtime.lastError.message);
          if (cb) cb(0);
          return;
        }
        setIcon(s.level);
        rebuildRuleActionIndex();
        if (cb) cb(addRules.length);
      }
    );
  });
}

// ── FIFO site rules helpers ───────────────────────────────────────────────────
function addSiteRule(s, host, level) {
  if (!s.siteRules) s.siteRules = {};
  if (!s.siteRulesOrder) s.siteRulesOrder = [];

  // Already pinned — just update level, no order change
  if (s.siteRules.hasOwnProperty(host)) {
    s.siteRules[host] = level;
    return s;
  }

  // FIFO eviction if at cap
  if (s.siteRulesOrder.length >= SITE_RULES_CAP) {
    var evicted = s.siteRulesOrder.shift();
    delete s.siteRules[evicted];
  }

  s.siteRules[host] = level;
  s.siteRulesOrder.push(host);
  return s;
}

function removeSiteRule(s, host) {
  if (!s.siteRules) return s;
  delete s.siteRules[host];
  s.siteRulesOrder = (s.siteRulesOrder || []).filter(function(h) { return h !== host; });
  return s;
}

// ── Country TLD detection ─────────────────────────────────────────────────────
var EU_LANGS = {
  "bg":true,"hr":true,"cs":true,"da":true,"nl":true,"et":true,"fi":true,
  "fr":true,"de":true,"el":true,"hu":true,"ga":true,"it":true,"lv":true,
  "lt":true,"mt":true,"pl":true,"pt":true,"ro":true,"sk":true,"sl":true,
  "es":true,"sv":true
};

function browserCountryTlds(cb) {
  chrome.i18n.getAcceptLanguages(function(langs) {
    var seen = {}, tlds = [], hasEuLang = false;
    (langs || []).forEach(function(lang) {
      var parts  = lang.toLowerCase().split('-');
      var region = parts.length > 1 ? parts[parts.length - 1] : parts[0];
      if (EU_LANGS[parts[0]]) hasEuLang = true;
      if (/^[a-z]{2,3}$/.test(region) && !seen[region]) {
        seen[region] = true; tlds.push(region);
      }
    });
    if (hasEuLang && tlds.indexOf('eu') === -1) tlds.push('eu');
    cb(tlds);
  });
}

// ── Lifecycle ─────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === "install") {
    browserCountryTlds(function(countryTlds) {
      var merged = DEFAULT_STATE.tlds.slice();
      countryTlds.forEach(function(tld) {
        if (merged.indexOf(tld) === -1) merged.push(tld);
      });
      var initState = Object.assign({}, DEFAULT_STATE, { tlds: merged, builtinDomains: BUILTIN_DOMAINS.slice() });
      saveState(initState, function() { applyState(initState); });
    });
  } else {
    // Extension reload/update (e.g. reloading from brave://extensions) should reset
    // to startupLevel, same as a real browser restart — otherwise the icon and rules
    // stay stuck at whatever level was last active before the reload. Also clear
    // chrome.storage.session, since it survives extension reloads (it's tied to the
    // browser session, not the extension's lifecycle) and would otherwise make the
    // popup re-apply a stale sessionLevel right back over the freshly-reset state.
    chrome.storage.session.clear(function() {
      loadState(function(s) {
        var boot = Object.assign({}, s, { level: s.startupLevel || 1 });
        saveState(boot, function() { applyState(boot); });
      });
    });
  }
});

chrome.runtime.onStartup.addListener(function() {
  loadState(function(s) {
    var boot = Object.assign({}, s, { level: s.startupLevel || 1 });
    saveState(boot, function() { applyState(boot); });
  });
});

// ── Messages ──────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {
  if (msg.type === "GET_STATE") {
    loadState(function(s) {
      chrome.declarativeNetRequest.getDynamicRules(function(rules) {
        sendResponse({ ok: true, state: s, ruleCount: rules.length });
      });
    });
    return true;
  }
  if (msg.type === "SET_STATE") {
    var ns = Object.assign({}, DEFAULT_STATE, msg.state);
    if (ns.level < 1 || ns.level > 5) ns.level = 1;
    if (ns.startupLevel < 1 || ns.startupLevel > 5) ns.startupLevel = 1;
    if (!ns.siteRules) ns.siteRules = {};
    if (!ns.siteRulesOrder) ns.siteRulesOrder = Object.keys(ns.siteRules);
    saveState(ns, function() {
      applyState(ns, function(count) {
        sendResponse({ ok: true, ruleCount: count });
      });
    });
    return true;
  }
  if (msg.type === "ADD_SITE_RULE") {
    loadState(function(s) {
      addSiteRule(s, msg.host, msg.level);
      saveState(s, function() {
        applyState(s, function(count) {
          sendResponse({ ok: true, ruleCount: count });
        });
      });
    });
    return true;
  }
  if (msg.type === "REMOVE_SITE_RULE") {
    loadState(function(s) {
      removeSiteRule(s, msg.host);
      saveState(s, function() {
        applyState(s, function(count) {
          sendResponse({ ok: true, ruleCount: count });
        });
      });
    });
    return true;
  }
  if (msg.type === "SET_ICON") {
    setIcon(msg.level);
    sendResponse({ ok: true }); return true;
  }
  if (msg.type === "START_LOGGING") {
    startLoggingTimer(); sendResponse({ ok: true }); return true;
  }
  if (msg.type === "STOP_LOGGING") {
    stopLogging(); sendResponse({ ok: true }); return true;
  }
  sendResponse({ ok: false, error: "Unknown: " + msg.type });
});

// ── Logging ───────────────────────────────────────────────────────────────────
// ── Logging boundaries ──────────────────────────────────────────────────────────
// LOG_TIMEOUT_MS — hard ceiling on how long a logging session can run. After this
// many ms, stopLogging() fires automatically regardless of whether the user is still
// looking at the logger tab. This bounds both wall-clock duration AND, indirectly,
// memory use, since logging stops accepting new entries once the timer fires.
//
// MAX_LOGS — hard ceiling on the number of log entries kept in chrome.storage.local
// at any time. Once exceeded, the OLDEST entries are dropped first (FIFO eviction via
// splice(0, ...)), keeping only the most recent MAX_LOGS entries. This bounds storage
// size regardless of how much third-party traffic a page generates.
//
// Set to 500 with the visibility-only catch-all rule in mind (see "Visibility-only
// catch-all" comment further down in rulesForLevel), since that rule causes the
// logger to capture far more traffic than block-only logging did — every XHR, image,
// font, stylesheet, etc. that previously went unobserved is now logged too. A busy
// page can plausibly generate 100-300+ entries within the first few seconds alone, so
// 500 gives meaningful headroom for a typical 5-minute session without growing
// storage usage unreasonably. If a future change increases logged traffic further
// (e.g. logging webRequest-level events too), reconsider this ceiling again.
var LOG_TIMEOUT_MS = 5 * 60 * 1000;
var MAX_LOGS       = 500;
var loggingTimer   = null;

// Stops the active logging session: cancels the timeout, flips the "logging" flag off
// (which makes onRuleMatchedDebug below stop writing on its very next invocation,
// since it re-reads this flag fresh from storage every time rather than caching it),
// and clears the accumulated log array after a short delay so the logger UI has time
// to show the "session ended" state before the data disappears. This is the release
// point for the memory the log array was holding — after this, chrome.storage.local
// for the "logs" key returns to an empty array, freeing whatever was accumulated.
var loggingStopInProgress = false; // guards against stopLogging() being re-entered from
                                    // multiple call sites (message handler, auto-timeout,
                                    // startup recovery) within the same brief window

function stopLogging() {
  if (loggingStopInProgress) return; // already stopping/stopped — avoid duplicate cleanup timer
  loggingStopInProgress = true;
  if (loggingTimer) { clearTimeout(loggingTimer); loggingTimer = null; }
  chrome.storage.local.set({ logging: false, logStartTime: null });
  setTimeout(function() {
    chrome.storage.local.set({ logs: [] });
    loggingStopInProgress = false; // reset so a future START_LOGGING -> STOP_LOGGING cycle works
  }, 3000);
  chrome.runtime.sendMessage({ type: "LOGGING_STOPPED" }, function() {
    if (chrome.runtime.lastError) {}
  });
}

// Starts (or restarts) the LOG_TIMEOUT_MS countdown. Called when a logging session
// begins. The browser's setTimeout itself doesn't survive a service worker restart
// (MV3 service workers are ephemeral), so the recovery handler below reconstructs the
// remaining time from logStartTime whenever the worker wakes back up.
function startLoggingTimer() {
  if (loggingTimer) clearTimeout(loggingTimer);
  loggingTimer = setTimeout(function() {
    loggingTimer = null; stopLogging();
  }, LOG_TIMEOUT_MS);
}

// Recovery path: if the service worker was asleep/restarted while a logging session
// was active (a normal MV3 occurrence — the worker can be evicted from memory between
// events), reconstruct how much of the LOG_TIMEOUT_MS window is left from the stored
// logStartTime and re-arm the timer for exactly that remaining duration. If the full
// 5 minutes has already elapsed while the worker was asleep, stop immediately rather
// than letting a stale session linger indefinitely.
chrome.runtime.onStartup.addListener(function() {
  chrome.storage.local.get({ logging: false, logStartTime: null }, function(s) {
    if (!s.logging) return;
    var elapsed   = s.logStartTime ? (Date.now() - s.logStartTime) : LOG_TIMEOUT_MS;
    var remaining = LOG_TIMEOUT_MS - elapsed;
    if (remaining <= 0) { stopLogging(); return; }
    loggingTimer = setTimeout(function() { loggingTimer = null; stopLogging(); }, remaining);
  });
});

var RULE_NAMES = {
  1001: 'HTTP', 1002: 'WS', 1003: 'port', 1004: 'port',
  1005: 'IP', 3001: 'frame', 3002: 'script', 3500: 'unmatched'
};

function sanitizeUrl(url) { url.search = ''; url.hash = ''; return url.toString(); }

// Builds the human-readable "reason" label shown in the logger table. Works the same
// regardless of whether the matched rule was an allow or a block — the action type
// (allowed/blocked) is tracked separately, see onRuleMatchedDebug below.
function classify(url, type, ruleId) {
  if (ruleId === 1001) return 'HTTP block';
  if (ruleId === 1002) return 'WS block';
  if (ruleId === 1003 || ruleId === 1004) return 'port:' + (url.port || '?');
  if (ruleId === 1005) return 'IP block';
  var typeLabel = {
    'script': '3P-script', 'sub_frame': '3P-frame', 'image': '3P-image',
    'xmlhttprequest': '3P-XHR', 'media': '3P-media', 'websocket': '3P-ws',
    'stylesheet': '3P-stylesheet', 'font': '3P-font', 'ping': '3P-ping',
    'main_frame': 'main-frame', 'object': '3P-object', 'other': '3P-other'
  }[type] || ('3P-' + type);
  var ruleName = RULE_NAMES[ruleId] || 'r' + ruleId;
  return typeLabel + ' [' + ruleName + ']';
}

// Logs every rule match the extension's own DNR ruleset produces — both ALLOW matches
// (e.g. a request hitting the TLD/domain/CDN/built-in whitelist) and BLOCK matches
// (e.g. third-party frame or script blocked). This gives full visibility into what's
// actually happening under the hood for third-party traffic this extension's rules
// touch. Traffic that matches NO rule at all (neither allow nor block) is invisible
// to onRuleMatchedDebug by design — DNR only fires this event for actual rule matches.
chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(function(info) {
  chrome.storage.local.get({ logging: false, logs: [] }, function(s) {
    if (!s.logging) return;
    if (!info.rule || typeof info.rule.ruleId !== 'number') return;
    // MatchedRule (info.rule) only has { ruleId, rulesetId } — look up the actual
    // action type from our own index, built in rebuildRuleActionIndex() above.
    var matchedAction = RULE_ACTIONS[info.rule.ruleId];
    if (!matchedAction) return; // unknown rule id (shouldn't normally happen) — skip rather than mislabel
    var actionType = matchedAction === 'allow' ? 'allowed' : 'blocked';
    var rawUrl = info.request.url;
    if (typeof rawUrl !== 'string' || !rawUrl) return;
    var url;
    try { url = new URL(rawUrl); } catch(e) { return; }
    var reason = classify(url, info.request.type, info.rule.ruleId);
    if (!reason) return;
    var callingDomain = 'unknown';
    try {
      var initiator = info.request.initiator || info.request.documentUrl || '';
      if (initiator) callingDomain = new URL(initiator).hostname || 'unknown';
    } catch(e) {}
    var logs = s.logs || [];
    logs.push({ domain: callingDomain, reason: reason, action: actionType,
      ruleId: info.rule.ruleId, url: sanitizeUrl(url), time: Date.now() });
    // Boundary check: enforce MAX_LOGS on every single write. If exceeded, drop the
    // OLDEST entries first (FIFO) so storage size never grows unbounded even on a
    // page that fires hundreds of third-party requests within the 5-minute window.
    // Note: this means very early page-load traffic can be evicted first if a busy
    // page exceeds MAX_LOGS during a single session — by design, recent activity is
    // prioritized over a complete historical record. We also persist a "logsCapHit"
    // flag the first time this happens, so the logger UI can show a one-time visible
    // warning rather than silently dropping data the user might not notice.
    var capHit = logs.length > MAX_LOGS;
    if (capHit) logs.splice(0, logs.length - MAX_LOGS);
    var toSave = { logs: logs };
    if (capHit) toSave.logsCapHit = true;
    chrome.storage.local.set(toSave);
  });
});
