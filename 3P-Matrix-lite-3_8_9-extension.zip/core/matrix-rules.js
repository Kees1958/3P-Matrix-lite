// ── core/matrix-rules.js ──────────────────────────────────────────────────────
// State mutation for the interactive Matrix's per-domain, per-type overrides.
// Follows the same shape core/block-monitor.js's allowMonitorDomain() used
// to (mutate state, saveState, then applyStateFn to rebuild + push DNR
// rules, then callback) before that module was retired — same pattern,
// applied to a different piece of state.
//
// ── Redundant-override guard (fixes: LEVEL MODE / INTERNAL WHITELIST stuck ──
// grey after "reverting" a script/frame setting) ────────────────────────────
// The Matrix panel's script/frame cells are two independent buttons (Allow /
// Block), not a single toggle. Example bug this guard fixes: LEVEL MODE is
// green (script allowed by the level's own mechanism, no override). User
// clicks Block on script → an explicit override is stored, LEVEL MODE greys
// out (correct — something other than the level's mechanism now decides
// this). User clicks Allow on script again, expecting it to go back to
// "normal" → WITHOUT this guard, that stores a *second* explicit override
// ("allow" this time) rather than clearing the first one, so LEVEL MODE and
// INTERNAL WHITELIST stay grey forever even though script is back to its
// original, non-overridden behavior.
// The fix: before storing an "allow"/"block" action, compare it against
// wouldBlockDefault() — "what the level's own mechanism would do with no
// override at all". If the requested action matches that default, the
// override is redundant, so we clear it instead of storing it. This is the
// only place that decision is made, so every caller gets it automatically.
//
// Public interface:
//   setMatrixRule(domain, type, action, url, activeHost, state, applyStateFn, cb)
//     domain     — third-party eTLD+1 host
//     type       — "frame" | "script" (the only two overridable resource types)
//     action     — "allow" | "block" | null (null = clear/unselect, revert to
//                  the level's default disposition for that domain+type)
//     url        — sample request URL for this domain (needed by
//                  wouldBlockDefault()'s CDN check at level 4 — may be null,
//                  in which case the CDN check simply never matches)
//     activeHost — the 1P hostname the Matrix session is scoped to (for the
//                  per-site level pin lookup)
// ─────────────────────────────────────────────────────────────────────────────

import { saveState } from "../data/state-storage.js";
import { wouldBlockDefault, isBuiltinWhitelistedForType } from "./rule-classifier.js";

// Deletes one type's override for a domain, and drops the domain's entry
// entirely once it holds no overrides at all — shared by every code path
// below that clears an override, so "no empty {} left behind" is guaranteed
// in exactly one place rather than re-implemented per caller.
function _clearOverride(domain, type, state) {
  if (!state.matrixRules || !state.matrixRules[domain]) return;
  delete state.matrixRules[domain][type];
  if (Object.keys(state.matrixRules[domain]).length === 0) {
    delete state.matrixRules[domain];
  }
}

export function setMatrixRule(domain, type, action, url, activeHost, state, applyStateFn, cb) {
  if (!domain || (type !== "frame" && type !== "script")) {
    if (cb) cb({ ok: false, error: "Invalid domain or type" });
    return;
  }
  if (action !== "allow" && action !== "block" && action !== null) {
    if (cb) cb({ ok: false, error: "Invalid action" });
    return;
  }

  // Built-in whitelist can't be overruled — see core/rule-classifier.js's
  // wouldBlock() step 2, which already ignores a "block" override for a
  // built-in-protected type. Refused here too, not just left for the UI to
  // avoid presenting as clickable, so a stale click or any future caller
  // can't silently write a no-op override into storage.
  if (action === "block" && isBuiltinWhitelistedForType(domain, type, state)) {
    if (cb) cb({ ok: false, error: "This type is built-in whitelisted and cannot be blocked" });
    return;
  }

  if (!state.matrixRules) state.matrixRules = {};

  if (action === null) {
    // Clear/unselect — revert to the level's default disposition.
    _clearOverride(domain, type, state);
  } else {
    // Redundant-override guard — see header comment above.
    const wantsBlock     = action === "block";
    const defaultBlocked = wouldBlockDefault(domain, type, url, state, activeHost);
    if (wantsBlock === defaultBlocked) {
      _clearOverride(domain, type, state);
    } else {
      if (!state.matrixRules[domain]) state.matrixRules[domain] = {};
      state.matrixRules[domain][type] = action;
    }
  }

  saveState(state, function() {
    applyStateFn(state, function(count) {
      if (cb) cb({ ok: true, ruleCount: count });
    });
  });
}

