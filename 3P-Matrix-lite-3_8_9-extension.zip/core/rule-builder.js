// ── core/rule-builder.js ──────────────────────────────────────────────────────
// Pure rule construction — builds declarativeNetRequest rule arrays from state.
// No Chrome API calls, no storage access, no side effects.
// All functions take input and return a rules array.
//
// Public interface:
//   buildRules(state, cdnRegexSupported)  — builds the complete rule set from
//     state, returns Rule[]. cdnRegexSupported (boolean, default false) is
//     checked and cached once by background.js's checkCdnRegexSupport() via
//     chrome.declarativeNetRequest.isRegexSupported() — never assumed here,
//     since this module stays free of Chrome API calls by design.
// ─────────────────────────────────────────────────────────────────────────────

import { CDN_HOST_REGEX, SIGNAL_DOMAINS } from "../data/constants.js";

// ── Rule ID map ───────────────────────────────────────────────────────────────
// Global rules use idOffset = 0.
// Per-site rules use idOffset = 100000 + (i * 5000) — the 5000-wide slot safely
// covers the full local ID range used here (highest ID is 3299).
//
//   Range       Purpose                                          Cap
//   ─────────────────────────────────────────────────────────────────
//   (1001–1005 freed — HTTP/WS rules, non-standard-port block, and
//    raw-IP block all removed; see CHANGELOG for the port/IP removal)
//   2000–2199   Free — was User domain whitelist, retired (see CHANGELOG)
//   2200–2399   Free                                               —
//   2400–2499   TLD whitelist          (single *.tld* pattern)   100
//   2500–2599   Free                                               —
//   2600–2999   Built-in domain whitelist (single *d* pattern)   400
//   3000        CDN allow              (level 4 only)              1
//   3001        Block 3P frames        (levels 2–5)               1
//   3002        Block 3P scripts       (levels 3–5)               1
//   3100–3199   Free
//   3200–3299   TLD blacklist          (level 2 only)            100
//   4000–4099   Matrix frame overrides  (per-domain allow/block)  100
//   4100–4199   Matrix script overrides (per-domain allow/block)  100
// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

// Builds signal-list allow rules — LEVEL 2 ONLY (see rulesForLevel below).
// Per explicit design: Level 2 is the light-touch tier meant to minimize
// breakage, so signal-list domains (commonly needed for "Login with X")
// are auto-allowed there, same mechanism as buildBuiltinAllowRules above,
// just a separate ID range and gated to L2 only. At levels 3-5 these
// domains stay purely informational (flagged yellow in Show Matrix,
// enabled by hand) — this function is simply never called there.
function buildSignalAllowRules(idOffset, scope, signalDomains) {
  const rules = [];
  // Range 2200-2399 gives 200 slots — well beyond the current 10 entries.
  const domains = Object.keys(signalDomains || {}).slice(0, 200);
  let i = 0;
  domains.forEach(function(d) {
    const flags = signalDomains[d] || {};
    const resourceTypes = [];
    if (flags.script) resourceTypes.push("script");
    if (flags.frame)  resourceTypes.push("sub_frame");
    if (!resourceTypes.length) return;
    rules.push({ id: idOffset + 2200 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*" + d + "*", resourceTypes: resourceTypes }, scope) });
    i++;
  });
  return rules;
}

// Builds built-in domain allow rules (payment, video, CAPTCHA, JS-libs,
// identity/SSO) for levels 2-5. One rule per domain, but the resourceTypes
// scope is now computed PER DOMAIN from its own script/frame flags (see
// data/constants.js's BUILTIN_DOMAINS) — most domains need both, but some
// are script-only or frame-only, hand-classified rather than assumed, so
// this only ever allows the specific type(s) a domain is actually verified
// to need.
function buildBuiltinAllowRules(idOffset, scope, builtinDomains) {
  const rules = [];
  // Range 2600-2999 gives 400 slots — plenty of headroom.
  const domains = Object.keys(builtinDomains || {}).slice(0, 400);
  let i = 0;
  domains.forEach(function(d) {
    const flags = builtinDomains[d] || {};
    const resourceTypes = [];
    if (flags.script) resourceTypes.push("script");
    if (flags.frame)  resourceTypes.push("sub_frame");
    if (!resourceTypes.length) return; // neither flag set — nothing to allow, skip (shouldn't occur with verified data, but defensive)
    rules.push({ id: idOffset + 2600 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*" + d + "*", resourceTypes: resourceTypes }, scope) });
    i++;
  });
  return rules;
}

// Builds TLD allow rules for level 3 (scripts + frames from whitelisted TLDs).
// Two patterns per TLD. Returns Rule[].
function buildTldAllowRules(idOffset, scope, tlds) {
  const rules = [];
  // Single *.tld* pattern covers bare root and any path — one rule per TLD.
  // Range 2400-2499 gives 100 slots — sufficient for all TLD combinations.
  tlds.slice(0, 100).forEach(function(tld, i) {
    rules.push({ id: idOffset + 2400 + i, priority: 1000, action: { type: "allow" },
      condition: Object.assign({ urlFilter: "*." + tld + "*", resourceTypes: ["script", "sub_frame"] }, scope) });
  });
  return rules;
}

// Builds CDN allow rule for level 4 (scripts only).
// JS-library domains are now covered by buildBuiltinAllowRules at all levels.
// Only the broad *cdn* URL match remains here — level 4 exclusive.
// Builds the level-4 CDN allow rule. Uses a host-scoped regex ("cdn" only
// within the domain, never the path/query) when Chrome's DNR engine supports
// it — checked once and cached by background.js's checkCdnRegexSupport(),
// never assumed. Falls back to the old, looser, always-valid urlFilter
// ("cdn" anywhere in the full URL) if the regex was rejected for any reason —
// degraded precision is fine; a broken ruleset from an invalid regex in an
// atomic updateDynamicRules() batch is not.
function buildCdnAllowRules(idOffset, scope, cdnRegexSupported) {
  const rules = [];
  const condition = cdnRegexSupported
    ? Object.assign({ regexFilter: CDN_HOST_REGEX, isUrlFilterCaseSensitive: false, resourceTypes: ["script"] }, scope)
    : Object.assign({ urlFilter: "*cdn*", resourceTypes: ["script"] }, scope);
  rules.push({ id: idOffset + 3000, priority: 1000, action: { type: "allow" }, condition: condition });
  return rules;
}

// Builds TLD blacklist block rules for level 2 only.
// Blocks 3P scripts from risky/abused TLDs. Priority 15 — lower than the
// main frame/script blocks (20) so general blocks fire first. Returns Rule[].
function buildTldBlacklistRules(idOffset, scope, blockedTlds) {
  const rules = [];
  blockedTlds.slice(0, 100).forEach(function(tld, i) {
    rules.push({ id: idOffset + 3200 + i, priority: 15, action: { type: "block" },
      condition: Object.assign({
        urlFilter: "*." + tld + "/*",
        domainType: "thirdParty",
        resourceTypes: ["script", "webbundle"]
      }, scope) });
  });
  return rules;
}

// Builds the interactive Matrix's per-domain, per-type allow/block overrides.
// This is a genuinely new rule TIER, not a variant of the existing domain
// whitelist: it's the only mechanism in this codebase that can BLOCK a
// domain the built-in/TLD/CDN allowlist would otherwise permit — hence
// priority 2000 for its block half, higher than every existing allow rule
// (1000) so a user block override always wins regardless of what else would
// have allowed it. Its allow half sits at the same 1000 tier as the existing
// allow rules — no need to outrank them, since nothing HIGHER than 1000
// currently exists to conflict with (block-frame/script sit at 20).
//
// Independent per resource type: a domain can have its frame blocked while
// its script is allowed, or vice versa — matrixRules[domain] is
// { frame?: "allow"|"block", script?: "allow"|"block" }, either key
// optional and independent of the other.
//
// Two separate ID ranges (frame vs script) rather than one shared range,
// so a domain needing both overrides doesn't need special-case ID math —
// each type's rules are numbered independently within their own 100-slot band.
function buildMatrixOverrideRules(idOffset, scope, matrixRules) {
  const rules = [];
  const domains = Object.keys(matrixRules || {}).slice(0, 100);

  let frameIdx = 0;
  domains.forEach(function(d) {
    const action = matrixRules[d] && matrixRules[d].frame;
    if (action !== "allow" && action !== "block") return; // no override for this type
    rules.push({
      id: idOffset + 4000 + frameIdx,
      priority: action === "block" ? 2000 : 1000,
      action: { type: action },
      condition: Object.assign({ urlFilter: "*" + d + "*", domainType: "thirdParty", resourceTypes: ["sub_frame"] }, scope)
    });
    frameIdx++;
  });

  let scriptIdx = 0;
  domains.forEach(function(d) {
    const action = matrixRules[d] && matrixRules[d].script;
    if (action !== "allow" && action !== "block") return; // no override for this type
    rules.push({
      id: idOffset + 4100 + scriptIdx,
      priority: action === "block" ? 2000 : 1000,
      action: { type: action },
      condition: Object.assign({ urlFilter: "*" + d + "*", domainType: "thirdParty", resourceTypes: ["script", "webbundle"] }, scope)
    });
    scriptIdx++;
  });

  return rules;
}

// Builds the complete rule array for a single level.
// Used for both global rules (idOffset=0) and per-site rules (idOffset=100000+i*5000).
// Returns Rule[].
function rulesForLevel(level, tlds, domains, idOffset, initiatorDomains, excludedDomains, builtinDomains, blockedTlds, matrixRules, cdnRegexSupported) {
  if (level === 1) return [];   // L1 = allow all, no rules needed

  const siteScope  = initiatorDomains && initiatorDomains.length
    ? { initiatorDomains:         initiatorDomains  } : {};
  const globalExcl = excludedDomains  && excludedDomains.length
    ? { excludedInitiatorDomains: excludedDomains   } : {};
  const scope = initiatorDomains ? siteScope : globalExcl;

  let rules = [];

  if (level >= 2) {
    rules = rules.concat(buildBuiltinAllowRules(idOffset, scope, builtinDomains));
  }
  if (level === 2) {
    // Signal list used AS a whitelist here, and only here — see this
    // module's buildSignalAllowRules() header comment and
    // rule-classifier.js's wouldBlock() decision-order comment (step 3b).
    rules = rules.concat(buildSignalAllowRules(idOffset, scope, SIGNAL_DOMAINS));
  }
  if (level === 3) {
    rules = rules.concat(buildTldAllowRules(idOffset, scope, tlds));
  }
  if (level === 4) {
    rules = rules.concat(buildCdnAllowRules(idOffset, scope, cdnRegexSupported));
  }
  // Domain whitelist (formerly buildDomainAllowRules, using the `domains`
  // param) was retired along with its UI — existing entries were migrated
  // once into state.matrixRules (see background.js's migration on update),
  // which buildMatrixOverrideRules() below now handles instead. `domains`
  // is kept as an unused parameter rather than touching every call site for
  // a parameter that costs nothing to leave unused.

  // Block 3P frames (levels 2-5) — the entire 3P blocking surface of this extension.
  // IMPORTANT: never extend blocking beyond sub_frame + script/webbundle — a
  // broader resourceTypes list here would silently block image/media/xhr/etc
  // traffic this extension has never claimed to touch.
  rules.push({ id: idOffset + 3001, priority: 20, action: { type: "block" },
    condition: Object.assign({ domainType: "thirdParty", resourceTypes: ["sub_frame"] }, scope) });

  // Block 3P scripts (levels 3-5)
  if (level >= 3) {
    rules.push({ id: idOffset + 3002, priority: 20, action: { type: "block" },
      condition: Object.assign({ domainType: "thirdParty", resourceTypes: ["script", "webbundle"] }, scope) });
  }

  if (level === 2 && blockedTlds && blockedTlds.length) {
    rules = rules.concat(buildTldBlacklistRules(idOffset, scope, blockedTlds));
  }

  // Interactive Matrix per-domain overrides — applies at every level reached
  // here (L1 already returned early above, since nothing is blockable there
  // per the feature's own design: no overrides are possible/offered at L1).
  if (matrixRules && Object.keys(matrixRules).length) {
    rules = rules.concat(buildMatrixOverrideRules(idOffset, scope, matrixRules));
  }

  return rules;
}

// Builds the complete declarativeNetRequest rule set from state.
// Global rules exclude pinned hostnames; per-site rules target them specifically.
// Returns Rule[] ready to pass to updateDynamicRules().
export function buildRules(state, cdnRegexSupported) {
  const level       = state.level;
  const tlds        = state.tlds        || [];
  const domains     = state.domains     || [];
  const siteRules   = state.siteRules   || {};
  const matrixRules = state.matrixRules || {};
  const pinnedHosts = Object.keys(siteRules);
  let rules         = [];

  // Global rules — exclude all pinned hosts so their site-specific rules take priority
  rules = rules.concat(
    rulesForLevel(level, tlds, domains, 0, null, pinnedHosts, state.builtinDomains, state.blockedTlds, matrixRules, cdnRegexSupported)
  );

  // Per-site rules — offset 100000 + i*5000 to avoid ID collisions between sites.
  // The 5000-wide slot safely covers the full local ID range used by rulesForLevel (up to 4199).
  pinnedHosts.forEach(function(host, i) {
    const offset = 100000 + (i * 5000);
    rules = rules.concat(
      rulesForLevel(siteRules[host], tlds, domains, offset, [host], null, state.builtinDomains, state.blockedTlds, matrixRules, cdnRegexSupported)
    );
  });

  return rules;
}
