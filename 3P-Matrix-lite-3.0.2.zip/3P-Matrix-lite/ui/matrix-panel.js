// ── ui/matrix-panel.js ──────────────────────────────────────────────────────────
// Show Matrix panel UI.
// Renders the live table of third-party connections for one tab (script,
// frame, image, media, fetch/xhr, websocket, other — not filtered by
// block/allow outcome), plus a countdown clock (same MATRIX_DURATION as the
// SW side — see core/connection-matrix.js). No pause/resume, unlike
// monitor-panel.js.
//
// The tabId being observed is passed in the panel URL's query string (set by
// ui/popup.js when it opens this window) since, unlike block-monitor's single
// global session, connection-matrix.js tracks state per-tab and needs to know
// which tab's bucket to read.
//
// Communicates with the SW via chrome.runtime.sendMessage using MSG_* constants.
// ─────────────────────────────────────────────────────────────────────────────

import { MSG_GET_MATRIX_DATA, MSG_STOP_MATRIX, MSG_MATRIX_CLOSED } from "../data/message-types.js";

const POLL_MS = 800;    // how often to fetch new entries from SW
const WARN_MS = 60000;  // turn timer yellow at 1 minute remaining

// ── Guarded module state — initialised empty, cleared/released explicitly ────
let _pollInterval  = null; // setInterval handle for live data polling
let _clockInterval = null; // setInterval handle for the countdown display
let _clockStarted  = false; // guard: only start the clock once, from the first poll response
let _isStopped     = false;
const _tabId        = _readTabIdFromUrl();
const _host         = _readHostFromUrl();

// Column order must match the <th> order in matrix-panel.html.
const TYPE_COLUMNS = ["cookie", "image", "media", "stylesheet", "script", "frame", "fetch/xhr", "other"];

// ── URL param helpers ─────────────────────────────────────────────────────────

function _readTabIdFromUrl() {
  const params = new URLSearchParams(window.location.search);
  const raw = params.get("tabId");
  const n = raw ? parseInt(raw, 10) : NaN;
  return isNaN(n) ? null : n;
}

function _readHostFromUrl() {
  const params = new URLSearchParams(window.location.search);
  return params.get("host") || "—";
}

// ── Messaging helper ──────────────────────────────────────────────────────────

function send(msg, cb) {
  try {
    chrome.runtime.sendMessage(msg, function(resp) {
      if (chrome.runtime.lastError) { if (cb) cb(null); return; }
      if (cb) cb(resp);
    });
  } catch(e) {
    if (cb) cb(null);
  }
}

// ── DOM refs ──────────────────────────────────────────────────────────────────

const elHost       = document.getElementById("panelHost");
const elBtnClose    = document.getElementById("btnClose");
const elEntryBody   = document.getElementById("entryBody");
const elEmptyState  = document.getElementById("emptyState");
const elTimer       = document.getElementById("timerDisplay");
const elTimerIcon   = document.getElementById("timerIcon");
const elStats       = document.getElementById("panelStats");
const elFilterInput = document.getElementById("filterInput");

// ── Filter state ──────────────────────────────────────────────────────────────
// The full, unfiltered entry list from the last poll — kept so the filter can
// re-render instantly on every keystroke without waiting for the next poll.
let _lastEntries = [];
let _filterText  = "";

// ── Clock — ported from monitor-panel.js's identical startClock/formatClock ──

function formatClock(ms) {
  const total = Math.floor(Math.max(0, ms) / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return m + ":" + (s < 10 ? "0" : "") + s;
}

function startClock(remainingMs) {
  if (_clockInterval) clearInterval(_clockInterval);
  const deadline = Date.now() + remainingMs;

  _clockInterval = setInterval(function() {
    if (_isStopped) return;
    const left = deadline - Date.now();
    elTimer.textContent = formatClock(left);

    if (left <= 0) {
      elTimer.classList.add("expired");
      elTimerIcon.textContent = "■";
      clearInterval(_clockInterval);
    } else if (left <= WARN_MS) {
      elTimer.classList.add("warning");
    }
  }, 500);
}

// ── Entry rendering ───────────────────────────────────────────────────────────

function renderEntry(entry) {
  const tr = document.createElement("tr");

  let cells = '<td class="td-domain">' + entry.domain + '</td>';

  for (let i = 0; i < TYPE_COLUMNS.length; i++) {
    const has = entry.types.indexOf(TYPE_COLUMNS[i]) !== -1;
    cells += '<td class="td-check' + (has ? '' : ' empty') + '">' + (has ? '✓' : '—') + '</td>';
  }

  tr.innerHTML = cells;
  return tr;
}

function refreshTable(entries) {
  _lastEntries = entries;
  _renderFilteredTable();
}

// Applies the current filter text (case-insensitive domain substring match)
// to _lastEntries and re-renders. Called on every poll AND on every filter
// keystroke, so it never waits on a network round-trip to feel responsive.
function _renderFilteredTable() {
  const needle = _filterText.trim().toLowerCase();
  const visible = needle
    ? _lastEntries.filter(function(e) { return e.domain.toLowerCase().indexOf(needle) !== -1; })
    : _lastEntries;

  elEntryBody.innerHTML = "";
  for (let i = 0; i < visible.length; i++) {
    elEntryBody.appendChild(renderEntry(visible[i]));
  }

  if (visible.length) {
    elEmptyState.style.display = "none";
  } else if (needle && _lastEntries.length) {
    // There ARE entries, just none match the filter — distinct message from
    // "nothing observed yet" so it's clear the filter is the reason, not a
    // broken page.
    elEmptyState.style.display = "block";
    elEmptyState.querySelector(".empty-sub").textContent = "No domains match \"" + _filterText.trim() + "\".";
  } else {
    elEmptyState.style.display = "block";
    elEmptyState.querySelector(".empty-sub").textContent = "Third-party connections appear here as the page loads.";
  }
}

// Renders the "N domains · M requests" summary line under the host name.
function renderStats(domainCount, requestCount) {
  const d = domainCount || 0;
  const r = requestCount || 0;
  elStats.textContent = d + " domain" + (d === 1 ? "" : "s") + " · " + r + " request" + (r === 1 ? "" : "s");
}

// ── Poll ──────────────────────────────────────────────────────────────────────

function startPolling() {
  if (_pollInterval) clearInterval(_pollInterval);
  _pollInterval = setInterval(poll, POLL_MS);
  poll(); // immediate first fetch
}

function stopPolling() {
  if (_pollInterval) { clearInterval(_pollInterval); _pollInterval = null; }
}

function poll() {
  if (_tabId === null || _isStopped) return;
  send({ type: MSG_GET_MATRIX_DATA, tabId: _tabId }, function(resp) {
    if (!resp || !resp.ok || !resp.data) return;
    refreshTable(resp.data.entries || []);
    renderStats(resp.data.domainCount, resp.data.requestCount);
    // Start the countdown once, from the first response's remaining time —
    // guarded by _clockStarted so a later poll doesn't reset the deadline.
    if (!_clockStarted && typeof resp.data.remaining === "number") {
      _clockStarted = true;
      startClock(resp.data.remaining);
    }
  });
}

// ── Close ─────────────────────────────────────────────────────────────────────

function releaseAndClose() {
  if (_isStopped) { window.close(); return; }
  _isStopped = true;
  stopPolling();
  if (_clockInterval) { clearInterval(_clockInterval); _clockInterval = null; }
  if (_tabId !== null) {
    send({ type: MSG_STOP_MATRIX, tabId: _tabId }, function() { window.close(); });
  } else {
    window.close();
  }
}

elBtnClose.addEventListener("click", releaseAndClose);

// ── Filter input ──────────────────────────────────────────────────────────────
elFilterInput.addEventListener("input", function() {
  _filterText = elFilterInput.value;
  _renderFilteredTable();
});

// ── SW-initiated close (tab closed, or countdown expired, while panel open) ──

function handleForceClosed(reason) {
  if (_isStopped) return;
  _isStopped = true;
  stopPolling();
  if (_clockInterval) { clearInterval(_clockInterval); _clockInterval = null; }
  elTimer.classList.add("expired");
  elTimerIcon.textContent = "■";
  elEmptyState.style.display = "block";
  const reasonText = {
    tab_closed: "The observed tab was closed.",
    timeout:    "Time limit reached — session closed."
  };
  elEmptyState.querySelector(".empty-sub").textContent = reasonText[reason] || "Show Matrix session ended.";
  setTimeout(function() { window.close(); }, 1200);
}

chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === MSG_MATRIX_CLOSED && msg.tabId === _tabId) {
    handleForceClosed(msg.reason);
  }
});

// ── Init ──────────────────────────────────────────────────────────────────────

(function init() {
  elHost.textContent = _host;
  if (_tabId === null) {
    // Guard: no valid tabId means nothing to observe — show empty state, no polling.
    elEmptyState.querySelector(".empty-sub").textContent = "No tab to observe — please reopen from the popup.";
    return;
  }
  startPolling();
})();

// ── Release on window close ───────────────────────────────────────────────────
// Fires when the user closes the panel via the OS close button rather than
// the in-panel Close button. Best-effort — background.js's tabs.onRemoved /
// onCommitted guards are the safety net if this doesn't fire cleanly.
window.addEventListener('beforeunload', function() {
  if (_isStopped) return; // already cleaned up
  if (_tabId === null) return;
  try {
    chrome.runtime.sendMessage({ type: MSG_STOP_MATRIX, tabId: _tabId });
  } catch(e) {
    // Intentional: beforeunload gives very little time; SW cleanup is best-effort.
  }
});
