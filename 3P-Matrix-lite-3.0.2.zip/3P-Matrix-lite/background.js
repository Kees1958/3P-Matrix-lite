// ── background.js — 3P-Matrix-lite service worker (workflow orchestrator) ─────
//
// This file is a thin router and lifecycle manager only.
// All business logic lives in the modules imported below (each module also
// imports its own transitive dependencies — see the module files themselves).
//
// ── State overview ────────────────────────────────────────────────────────────
//   Persisted (chrome.storage.local, key = STORAGE_KEY):
//     Full state object — see DEFAULT_STATE in data/state-storage.js
//   In-memory only (lost on SW restart, safe to lose):
//     activeSession, monitorEntries — block monitor session (block-monitor.js)
//
// ── Message types handled ─────────────────────────────────────────────────────
//   GET_STATE        — returns current state + rule count
//   SET_STATE        — validates + saves new state, applies rules
//   ADD_SITE_RULE    — pins a per-site level override
//   REMOVE_SITE_RULE — removes a per-site level override
//   SET_ICON         — updates the toolbar icon
//   START_MONITOR    — start block monitor session
//   STOP_MONITOR     — stop block monitor session
//   PAUSE_MONITOR    — pause block monitor listener
//   RESUME_MONITOR   — resume block monitor listener + reload
//   GET_MONITOR_DATA — fetch current FIFO entries + session metadata
//   ALLOW_MONITOR_DOMAIN — add observed domain to whitelist
//   START_MATRIX       — begin Show Matrix observation for a tab
//   STOP_MATRIX        — release Show Matrix state for a tab
//   GET_MATRIX_DATA    — fetch current Show Matrix entries for a tab
// ─────────────────────────────────────────────────────────────────────────────

// ── Load modules ──────────────────────────────────────────────────────────────
// Each imported module pulls in its own transitive dependencies (e.g.
// block-monitor.js imports constants/message-types/state-storage itself) —
// background.js only imports what it references directly.
import { BUILTIN_DOMAINS } from "./data/constants.js";
import {
  MSG_GET_STATE, MSG_SET_STATE, MSG_ADD_SITE_RULE, MSG_REMOVE_SITE_RULE, MSG_SET_ICON,
  MSG_START_MONITOR, MSG_STOP_MONITOR, MSG_PAUSE_MONITOR, MSG_RESUME_MONITOR,
  MSG_GET_MONITOR_DATA, MSG_ALLOW_MONITOR_DOMAIN,
  MSG_START_MATRIX, MSG_STOP_MATRIX, MSG_GET_MATRIX_DATA
} from "./data/message-types.js";
import { DEFAULT_STATE, loadState, saveState } from "./data/state-storage.js";
import { browserCountryTlds, majorMinor } from "./util/tld-utils.js";
import { buildRules } from "./core/rule-builder.js";
import { addSiteRule, removeSiteRule } from "./core/site-rules.js";
import {
  startMonitor, stopMonitor, pauseMonitor, resumeMonitor, getMonitorData,
  allowMonitorDomain, startWatchdog, markMonitorStarted
} from "./core/block-monitor.js";
import {
  startMatrix, stopMatrix, getMatrixData, clearMatrixOnNavigation, clearMatrixOnTabClosed,
  startMatrixWatchdog
} from "./core/connection-matrix.js";

// ── Chrome API wrappers ───────────────────────────────────────────────────────
// These belong conceptually in a data/chrome-services.js but are small enough
// to live here until the extension grows to need that split.

// Updates the toolbar icon to reflect the current level (0-indexed icon filename).
function setIcon(level) {
  const idx = level - 1;
  try {
    chrome.action.setIcon({ path: {
      "16":  "icon_" + idx + "_16.png",
      "32":  "icon_" + idx + "_32.png",
      "48":  "icon_" + idx + "_48.png",
      "128": "icon_" + idx + "_128.png"
    }});
  } catch(e) {
    // Intentional: setIcon may throw if the SW is being torn down or the
    // extension is being reloaded; icon update is best-effort.
  }
}

// Enables Chrome's built-in per-tab blocked request badge count.
// Always enabled — the badge always shows regardless of any toggle.
function enableBadgeCount() {
  if (!chrome.declarativeNetRequest ||
      typeof chrome.declarativeNetRequest.setExtensionActionOptions !== "function") return;
  const result = chrome.declarativeNetRequest.setExtensionActionOptions({
    displayActionCountAsBadgeText: true
  });
  if (result && typeof result.catch === "function") {
    result.catch(function(e) {
      console.warn("[3PM] setExtensionActionOptions:", e && e.message);
    });
  }
}

// ── applyState ────────────────────────────────────────────────────────────────
// Reads existing dynamic rules, replaces them all atomically with the new rule
// set built from state, then updates the icon.
// This is the single point where state changes are applied to Chrome DNR.
function applyState(s, cb) {
  chrome.declarativeNetRequest.getDynamicRules(function(existing) {
    const removeIds = existing.map(function(r) { return r.id; });
    const addRules  = buildRules(s);
    chrome.declarativeNetRequest.updateDynamicRules(
      { removeRuleIds: removeIds, addRules: addRules },
      function() {
        if (chrome.runtime.lastError) {
          console.warn("[3PM] updateDynamicRules:", chrome.runtime.lastError.message);
          if (cb) cb(0);
          return;
        }
        setIcon(s.level);
        if (cb) cb(addRules.length);
      }
    );
  });
}

// ── Boot helper ───────────────────────────────────────────────────────────────
// Shared boot sequence used by both onInstalled (update) and onStartup.
function bootFromStorage() {
  loadState(function(s) {
    const boot = Object.assign({}, s, { level: s.startupLevel || 1 });
    chrome.action.setBadgeBackgroundColor({ color: "#666666" });
    enableBadgeCount();
    saveState(boot, function() { applyState(boot); });
  });
}

// ── Block monitor — navigation hook ──────────────────────────────────────────
// Fires when the monitored tab commits to a new page. Marks the session start
// time so the 5-minute timer begins from actual page load, not from button press.
// Also clears Show Matrix's entries for the tab — a fresh page load means a
// fresh connection list, not accumulation across navigations.
if (chrome.webNavigation && chrome.webNavigation.onCommitted) {
  chrome.webNavigation.onCommitted.addListener(function(details) {
    if (details.frameId !== 0) return; // top-level frame only
    markMonitorStarted(details.tabId);
    clearMatrixOnNavigation(details.tabId);
  });
}

// ── Show Matrix — tab-closed guard ───────────────────────────────────────────
// Releases a tab's matrix bucket (and the shared listener, if it was the last
// tracked tab) the moment the tab is closed, so nothing lingers in memory.
if (chrome.tabs && chrome.tabs.onRemoved) {
  chrome.tabs.onRemoved.addListener(function(tabId) {
    clearMatrixOnTabClosed(tabId);
  });
}

// ── Lifecycle ─────────────────────────────────────────────────────────────────
// ── Boot watchdog ─────────────────────────────────────────────────────────────
startWatchdog();
startMatrixWatchdog();

chrome.runtime.onInstalled.addListener(function(details) {
  const currentVersion    = chrome.runtime.getManifest().version;
  const currentMajorMinor = majorMinor(currentVersion);

  if (details.reason === "install") {
    // Fresh install — detect browser country TLDs and seed built-in domains
    browserCountryTlds(function(countryTlds) {
      const merged = DEFAULT_STATE.tlds.slice();
      countryTlds.forEach(function(tld) {
        if (merged.indexOf(tld) === -1) merged.push(tld);
      });
      const initState = Object.assign({}, DEFAULT_STATE, {
        tlds:              merged,
        builtinDomains:    BUILTIN_DOMAINS.slice(),
        whitelistDropdown: { tld: true, domain: true },
        lastShownVersion:  currentMajorMinor
      });
      chrome.action.setBadgeBackgroundColor({ color: "#666666" });
      enableBadgeCount();
      saveState(initState, function() { applyState(initState); });
    });
  } else {
    // Update / reload — reset to startupLevel, re-expand dropdowns on new major.minor
    chrome.storage.session.clear(function() {
      loadState(function(s) {
        const storedMajorMinor = majorMinor(s.lastShownVersion || "");
        const isNewMajorMinor  = storedMajorMinor !== currentMajorMinor;
        const boot = Object.assign({}, s, { level: s.startupLevel || 1 });
        if (isNewMajorMinor) {
          boot.whitelistDropdown = { tld: true, domain: true };
          boot.lastShownVersion  = currentMajorMinor;
        }
        chrome.action.setBadgeBackgroundColor({ color: "#666666" });
        enableBadgeCount();
        saveState(boot, function() { applyState(boot); });
      });
    });
  }
});

chrome.runtime.onStartup.addListener(bootFromStorage);

// ── Message router ────────────────────────────────────────────────────────────
// Thin router only — no business logic here. Each branch delegates immediately
// to a core or data function.
chrome.runtime.onMessage.addListener(function(msg, _sender, sendResponse) {

  if (msg.type === MSG_GET_STATE) {
    loadState(function(s) {
      chrome.declarativeNetRequest.getDynamicRules(function(rules) {
        sendResponse({ ok: true, state: s, ruleCount: rules.length });
      });
    });
    return true;
  }

  if (msg.type === MSG_SET_STATE) {
    const ns = Object.assign({}, DEFAULT_STATE, msg.state);
    if (ns.level < 1 || ns.level > 5)               ns.level        = 1;
    if (ns.startupLevel < 1 || ns.startupLevel > 5) ns.startupLevel = 1;
    if (!ns.siteRules)    ns.siteRules    = {};
    if (!ns.siteRulesOrder) ns.siteRulesOrder = Object.keys(ns.siteRules);
    saveState(ns, function() {
      applyState(ns, function(count) {
        sendResponse({ ok: true, ruleCount: count });
      });
    });
    return true;
  }

  if (msg.type === MSG_ADD_SITE_RULE) {
    loadState(function(s) {
      addSiteRule(s, msg.host, msg.level);
      saveState(s, function() {
        applyState(s, function(count) {
          sendResponse({ ok: true, ruleCount: count });
        });
      });
    });
    return true;
  }

  if (msg.type === MSG_REMOVE_SITE_RULE) {
    loadState(function(s) {
      removeSiteRule(s, msg.host);
      saveState(s, function() {
        applyState(s, function(count) {
          sendResponse({ ok: true, ruleCount: count });
        });
      });
    });
    return true;
  }

  if (msg.type === MSG_SET_ICON) {
    setIcon(msg.level);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === MSG_START_MONITOR) {
    // Check effective level: siteRules[host] if pinned, else state.level
    loadState(function(s) {
      const effectiveLevel = (msg.host && s.siteRules && s.siteRules[msg.host])
        ? s.siteRules[msg.host]
        : s.level;
      if (effectiveLevel < 2) {
        sendResponse({ ok: false, error: "Monitor only available at level 2 or higher" });
        return;
      }
      startMonitor(msg.tabId, msg.host, s, function(result) {
        sendResponse(result);
      });
    });
    return true;
  }

  if (msg.type === MSG_STOP_MONITOR) {
    stopMonitor(msg.reason || "stopped");
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === MSG_PAUSE_MONITOR) {
    pauseMonitor();
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === MSG_RESUME_MONITOR) {
    // Apply allowed domains first, then resume
    if (msg.state) {
      const ns = Object.assign({}, DEFAULT_STATE, msg.state);
      saveState(ns, function() {
        applyState(ns, function() {
          resumeMonitor(msg.tabId, ns, function(result) {
            sendResponse(result);
          });
        });
      });
    } else {
      loadState(function(s) {
        resumeMonitor(msg.tabId, s, function(result) {
          sendResponse(result);
        });
      });
    }
    return true;
  }

  if (msg.type === MSG_GET_MONITOR_DATA) {
    sendResponse({ ok: true, data: getMonitorData() });
    return true;
  }

  if (msg.type === MSG_ALLOW_MONITOR_DOMAIN) {
    loadState(function(s) {
      allowMonitorDomain(msg.domain, s, applyState, function(result) {
        sendResponse(result);
      });
    });
    return true;
  }

  if (msg.type === MSG_START_MATRIX) {
    startMatrix(msg.tabId, msg.host, function(result) {
      if (result && result.ok) {
        // Always reloads — matches Show blocks' behavior. The listener is
        // already registered (startMatrix ran above), so it survives this
        // reload and sees requests from the very start of the fresh page load.
        // lastError is checked explicitly rather than ignored — reload can
        // silently fail on restricted pages (chrome://, the Web Store, etc.)
        // or an already-closed tab, and that failure would otherwise be invisible.
        chrome.tabs.reload(msg.tabId, {}, function() {
          if (chrome.runtime.lastError) {
            console.warn("[3PM] Show Matrix reload failed:", chrome.runtime.lastError.message);
          }
        });
      }
      sendResponse(result);
    });
    return true;
  }

  if (msg.type === MSG_STOP_MATRIX) {
    stopMatrix(msg.tabId);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === MSG_GET_MATRIX_DATA) {
    sendResponse({ ok: true, data: getMatrixData(msg.tabId) });
    return true;
  }

  sendResponse({ ok: false, error: "Unknown message type: " + msg.type });
});
