// ── core/rule-classifier.js ───────────────────────────────────────────────────
// Shared request classifier — the single source of truth for "would our own
// DNR ruleset block this request, given the current state?"
//
// Extracted from core/block-monitor.js (v2.4.0) originally to be shared with
// core/connection-matrix.js (Show Matrix) as well — that sharing was reverted
// in v2.7.0 once Show Matrix's purpose was clarified as full-visibility
// traffic observation (blocked or not), not an allowed-only view filtered by
// this classifier. Show Matrix now only imports etldPlusOne() from this file,
// not wouldBlock() — block-monitor.js (Show blocks) remains this module's
// only consumer of the actual block/allow decision logic.
// See CHANGELOG.md and the audit notes (C21) for the fuller history.
//
// Public interface:
//   etldPlusOne(url)                                    — eTLD+1 host extraction
//   wouldBlock(thirdPartyHost, resourceType, url, state, activeHost) — boolean
//
// Dependencies: data/constants.js (MULTI_PART_SUFFIXES, BUILTIN_DOMAINS)
// ─────────────────────────────────────────────────────────────────────────────

import { MULTI_PART_SUFFIXES, BUILTIN_DOMAINS } from "../data/constants.js";

// Extracts eTLD+1 from a full URL. Returns empty string on failure.
export function etldPlusOne(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    const labels   = hostname.split(".");
    if (labels.length <= 2) return hostname;
    // Handle common multi-part suffixes (co.uk, com.au, etc.)
    const last2 = labels.slice(-2).join(".");
    // MULTI_PART_SUFFIXES loaded from data/constants.js — single source of truth.
    if (MULTI_PART_SUFFIXES.indexOf(last2) !== -1 && labels.length >= 3) {
      return labels.slice(-3).join(".");
    }
    return last2;
  } catch(e) {
    return "";
  }
}

// Classifies whether our own DNR ruleset would block this request.
// Mirrors rule-builder.js rulesForLevel() exactly — same allow/block order,
// same conditions, referenced by rule ID where applicable.
// Returns true if we would block, false if we would allow.
//
// thirdPartyHost — eTLD+1 of the request URL (from etldPlusOne())
// resourceType   — "frame" | "script" (normalise sub_frame -> "frame" before calling)
// url            — full request URL (needed for the CDN substring check)
// state          — extension state snapshot (level, siteRules, domains, tlds, builtinDomains)
// activeHost     — the 1P hostname the session/matrix is scoped to (for the site-rules lookup)
//
// Decision order (highest DNR priority wins, mirrored here top-to-bottom):
//   1. Level 1            → allow all                          (no rules at L1)
//   2. Builtin whitelist  → allow  (rules 2600–2999, prio 1000, L2–5)
//   3. User whitelist     → allow  (rules 2000–2199, prio 1000, L2–5)
//   4. TLD whitelist      → allow  (rules 2400–2499, prio 1000, L3 only)
//   5. CDN allow          → allow  (rule  3000,      prio 1000, L4 scripts only)
//   6. Block 3P frames    → block  (rule  3001,      prio 20,   L2–5 sub_frame)
//   7. Block 3P scripts   → block  (rule  3002,      prio 20,   L3–5 script)
//   8. Implicit allow     → allow  (nothing matched — not our block)
export function wouldBlock(thirdPartyHost, resourceType, url, state, activeHost) {
  if (!state) return true; // no state — assume block

  // Use effective level — respects per-site pin stored in siteRules
  const level = (activeHost && state.siteRules && state.siteRules[activeHost])
    ? state.siteRules[activeHost]
    : (state.level || 1);

  // ── 1. Level 1 — no rules, allow everything ───────────────────────────────
  if (level === 1) return false;

  // ── 2. Builtin domain whitelist (rules 2600–2999, levels 2–5) ────────────
  // Fall back to BUILTIN_DOMAINS constant if state copy is null (pre-seed)
  const builtins = (state.builtinDomains && state.builtinDomains.length)
    ? state.builtinDomains
    : (typeof BUILTIN_DOMAINS !== "undefined" ? BUILTIN_DOMAINS : []);
  for (let i = 0; i < builtins.length; i++) {
    if (thirdPartyHost === builtins[i] || thirdPartyHost.endsWith("."+builtins[i])) return false;
  }

  // ── 3. User domain whitelist (rules 2000–2199, levels 2–5) ───────────────
  const domains = state.domains || [];
  for (let j = 0; j < domains.length; j++) {
    if (thirdPartyHost === domains[j] || thirdPartyHost.endsWith("."+domains[j])) return false;
  }

  // ── 4. TLD whitelist (rules 2400–2499, level 3 only) ─────────────────────
  if (level === 3) {
    const labels = thirdPartyHost.split(".");
    const tld    = labels[labels.length - 1];
    const tld2   = labels.length >= 2 ? labels.slice(-2).join(".") : tld;
    const tlds   = state.tlds || [];
    if (tlds.indexOf(tld) !== -1 || tlds.indexOf(tld2) !== -1) return false;
  }

  // ── 5. CDN allow (rule 3000, level 4 only, scripts only) ─────────────────
  if (level === 4 && resourceType === "script" && url.toLowerCase().indexOf("cdn") !== -1) return false;

  // ── 6. Block 3P frames (rule 3001, levels 2–5) ───────────────────────────
  if (resourceType === "frame") return true;

  // ── 7. Block 3P scripts (rule 3002, levels 3–5) ──────────────────────────
  if (resourceType === "script" && level >= 3) return true;

  // ── 8. Implicit allow — not blocked by our ruleset ───────────────────────
  return false;
}
