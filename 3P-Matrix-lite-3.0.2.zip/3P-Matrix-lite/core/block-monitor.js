// ── core/block-monitor.js ─────────────────────────────────────────────────────
// Live third-party block monitor.
// Owns the webRequest listener, FIFO entry array, session object,
// timers, all stop conditions, and the watchdog.
//
// Public interface (unchanged — see connection-matrix.js and background.js for
// callers; these names/signatures are a contract, not renamed by this pass):
//   startMonitor(tabId, host, cb)     — start a new session (kills any existing one first)
//   stopMonitor(reason)               — full cleanup, notifies panel
//   pauseMonitor()                    — removeListener, freeze array, accumulate elapsed
//   resumeMonitor(tabId, cb)          — re-register listener, reload tab
//   getMonitorData()                  — returns { session, entries } snapshot
//   allowMonitorDomain(domain, state, cb) — add domain to state whitelist, save + apply
//   startWatchdog()                   — call once on SW boot; kills orphan sessions
//   markMonitorStarted()              — set externally by background.js when the session's
//                                        tab finishes its onCommitted navigation
//
// ── Session state vector (hardening pass) ────────────────────────────────────
// All session fields now live in a single `session` object gated by an
// explicit `phase` enum, instead of a null-or-object `activeSession` plus a
// separate `.paused` boolean. `assertPhase()` is a guard checked at the top
// of every transition function: an unexpected-phase call now logs a warning
// and safely no-ops instead of silently acting on stale/wrong state.
//
// Ported from a sibling extension's more hardened block-monitor.js, which
// itself is a descendant of this same module (see that file's own header —
// it explicitly documents mirroring THIS module's sessionTimeoutHandle/
// watchdogHandle design). This pass only adopts its phase-enum + assertPhase
// structural hardening; it intentionally does NOT adopt that codebase's
// separate Privacy Inspector feature's chrome.storage.session persistence —
// that guard exists there because its capture mechanism is a persistent
// content-script probe that keeps firing across a SW restart, whereas this
// module's webRequest listener does not survive a restart at all, so the
// listener and the session die together (see "State owned" below) and there
// is nothing left to persist metadata for.
//
// State owned by this module (all in-memory, lost on SW restart — intentional:
// the webRequest listener is also lost on SW restart, so no orphan is possible):
//   session        {object}  — single state vector, see SESSION_PHASES below
//   monitorEntries {Array}   — FIFO array, max MONITOR_CAP entries
//   _watchdogTimer {IntervalID} — orphan-session watchdog, SW lifetime
//
// SESSION shape:
//   { phase, tabId, host, startTime, timeElapsed, state, timeoutHandle }
//   phase         — one of SESSION_PHASES (authoritative gate for all transitions)
//   tabId         — tab that owns the session
//   host          — 1P hostname (fixed for the life of the session)
//   startTime     — Date.now() when onCommitted fired (set externally via markMonitorStarted);
//                   null while phase is STARTING or PAUSED
//   timeElapsed   — ms of active listening accumulated before pauses
//   state         — snapshot of extension state at session start (for classification)
//   timeoutHandle — primary 5-minute setTimeout handle
// ─────────────────────────────────────────────────────────────────────────────

import { MSG_MONITOR_CLOSED } from "../data/message-types.js";
import { saveState } from "../data/state-storage.js";
import { etldPlusOne, wouldBlock } from "./rule-classifier.js";

const MONITOR_CAP      = 100;          // max FIFO entries
const MONITOR_DURATION = 5 * 60 * 1000; // 5 minutes in ms
const WATCHDOG_INTERVAL = 5 * 60 * 1000; // watchdog checks every 5 minutes

// Valid phases for the monitor session swimming lane.
const SESSION_PHASES = Object.freeze({
  IDLE:     "idle",      // no session; waiting for startMonitor()
  STARTING: "starting",  // tab reload fired; waiting for onCommitted (markMonitorStarted)
  RUNNING:  "running",   // listener active, capturing requests
  PAUSED:   "paused",    // listener removed; session data preserved
});

// The single session state vector owned by this module.
// All session fields live here — nothing scattered at module scope.
// `phase` is the authoritative gate for all transitions.
let session = {
  phase:         SESSION_PHASES.IDLE,
  tabId:         null,
  host:          null,
  startTime:     null,
  timeElapsed:   0,
  state:         null,
  timeoutHandle: null,
};

let monitorEntries = [];
const _seenDomains  = new Set(); // tracks domains already recorded this session.
                                 // No explicit cap: implicitly bounded by MONITOR_CAP (only
                                 // domains that pass _wouldWeBlock() are added, and entries
                                 // are capped at MONITOR_CAP). Cleared on start/resume.
let _watchdogTimer = null;

// Guard: log a warning when a transition is attempted from an unexpected phase.
// Returns true if the phase matches, false otherwise (caller must then no-op).
function _assertPhase(expected, caller) {
  const ok = Array.isArray(expected)
    ? expected.indexOf(session.phase) !== -1
    : session.phase === expected;
  if (ok) return true;
  console.warn(
    "[block-monitor] " + caller + ": expected phase '" +
    (Array.isArray(expected) ? expected.join("|") : expected) +
    "', got '" + session.phase + "' — ignoring"
  );
  return false;
}

// ── Internal helpers ──────────────────────────────────────────────────────────

// Formats elapsed ms as "+m:ss.hh" (minutes:seconds.hundredths)
function _formatElapsed(ms) {
  const total = Math.floor(ms / 10);   // 10ms units
  const hh    = total % 100;
  const s     = Math.floor(total / 100) % 60;
  const m     = Math.floor(total / 6000);
  return "+" + m + ":" + (s < 10 ? "0" : "") + s + "." + (hh < 10 ? "0" : "") + hh;
}

// Extracts eTLD+1 from a full URL — delegates to core/rule-classifier.js
// (single source of truth, shared with connection-matrix.js).
function _etldPlusOne(url) {
  return etldPlusOne(url);
}

// Sends MSG_MONITOR_CLOSED to the monitor panel (fire-and-forget).
function _notifyPanel(reason) {
  try {
    chrome.runtime.sendMessage({ type: MSG_MONITOR_CLOSED, reason: reason }, function() {
      // Suppress lastError — panel may already be closed; no action needed.
      if (chrome.runtime.lastError) { /* intentional no-op — see comment above */ }
    });
  } catch(e) {
    // Intentional: SW context may be terminating; panel closure is best-effort.
  }
}

// Core cleanup — called by every stop path. Valid from any phase; a no-op
// (still resets defensively) when already IDLE, matching the reference
// endSession()'s early style but preserving this module's existing behavior
// of always clearing timers/listener defensively rather than early-returning.
function _cleanup(reason) {
  // Remove webRequest listener if registered
  try {
    chrome.webRequest.onBeforeRequest.removeListener(_monitorListener);
  } catch(e) {
    // Intentional: listener may already have been removed (e.g. on SW restart).
  }
  // Cancel timer
  if (session.timeoutHandle) { clearTimeout(session.timeoutHandle); }
  // Reset state
  session = {
    phase:         SESSION_PHASES.IDLE,
    tabId:         null,
    host:          null,
    startTime:     null,
    timeElapsed:   0,
    state:         null,
    timeoutHandle: null,
  };
  monitorEntries = [];
  // Notify panel — but NOT when the panel itself triggered the close.
  // Sending MSG_MONITOR_CLOSED back to a closing window causes Chromium to
  // open a new (empty) receiver context, producing the ghost panel users see.
  if (reason && reason !== "panel_closed") _notifyPanel(reason);
}

// Classifies whether our own DNR ruleset would block this request — delegates
// to core/rule-classifier.js (single source of truth, shared with
// connection-matrix.js). Same signature shape as before, adapted to the
// shared function's explicit (state, activeHost) parameters instead of
// closing over module-level `activeSession`.
function _wouldWeBlock(thirdPartyHost, resourceType, url) {
  if (session.phase === SESSION_PHASES.IDLE || !session.state) return true; // no state — assume block
  return wouldBlock(thirdPartyHost, resourceType, url, session.state, session.host);
}

// The webRequest listener function — kept as a named reference so removeListener works.
function _monitorListener(details) {
  // Only capture while actively running — a listener call arriving after
  // pause/stop (a brief in-flight race, not a normal case) is simply ignored
  // here rather than warned about via _assertPhase, since webRequest events
  // are not user-initiated transitions.
  if (session.phase !== SESSION_PHASES.RUNNING) return;
  if (details.tabId !== session.tabId)          return;

  const thirdPartyHost = _etldPlusOne(details.url);
  if (!thirdPartyHost)                          return;

  // Skip if same site as the 1P host
  const firstPartyApex = _etldPlusOne("https://" + session.host);
  if (thirdPartyHost === firstPartyApex)        return;

  const elapsed = _formatElapsed(
    session.timeElapsed + (Date.now() - session.startTime)
  );

  // Skip if our own ruleset would NOT block this — it was blocked by another extension
  if (!_wouldWeBlock(thirdPartyHost, details.type === "sub_frame" ? "frame" : "script", details.url)) return;

  // Skip if this domain has already been recorded this session
  if (_seenDomains.has(thirdPartyHost)) return;
  _seenDomains.add(thirdPartyHost);

  const entry = {
    host:    thirdPartyHost,
    type:    details.type === "sub_frame" ? "frame" : "script",
    elapsed: elapsed
  };

  // FIFO: drop oldest if at cap
  if (monitorEntries.length >= MONITOR_CAP) monitorEntries.shift();
  monitorEntries.push(entry);
}

// ── Public interface ──────────────────────────────────────────────────────────

// Starts a new monitor session. Kills any existing session first (clash —
// valid from any phase, mirrors the reference implementation).
// tabId: the tab to monitor. host: the 1P hostname.
// state: current extension state snapshot for request classification.
// cb: called when ready.
export function startMonitor(tabId, host, state, cb) {
  if (session.phase !== SESSION_PHASES.IDLE) _cleanup("new_session");

  session = {
    phase:         SESSION_PHASES.STARTING,
    tabId:         tabId,
    host:          host,
    startTime:     null, // set by markMonitorStarted() after page reload
    timeElapsed:   0,
    state:         state, // snapshot for _wouldWeBlock() classification
    timeoutHandle: null,
  };
  monitorEntries = [];
  _seenDomains.clear();

  // Register webRequest listener scoped to scripts and frames only
  chrome.webRequest.onBeforeRequest.addListener(
    _monitorListener,
    { urls: ["<all_urls>"], types: ["script", "sub_frame"] }
  );

  // Reload the tab — onCommitted will call markMonitorStarted()
  chrome.tabs.reload(tabId, {}, function() {
    if (cb) cb({ ok: true });
  });
}

// Called by background.js onCommitted handler when the monitored tab finishes
// navigating. This is the true start of the 5-minute session clock.
// Accepts STARTING (normal case) or RUNNING (defensive — a duplicate
// onCommitted firing twice for the same navigation should re-arm the timer,
// not warn-and-ignore, since that's a harmless idempotent retrigger).
export function markMonitorStarted(tabId) {
  if (session.tabId !== tabId) return;
  if (!_assertPhase([SESSION_PHASES.STARTING, SESSION_PHASES.RUNNING], "markMonitorStarted")) return;

  session.phase       = SESSION_PHASES.RUNNING;
  session.startTime   = Date.now();
  session.timeElapsed = 0;

  // Start 5-minute force-close timer
  if (session.timeoutHandle) clearTimeout(session.timeoutHandle);
  session.timeoutHandle = setTimeout(function() {
    _cleanup("timeout");
  }, MONITOR_DURATION);
}

// Full cleanup — called on EXIT button, popup close, or level drop below 4.
// Valid from any phase (mirrors the reference endSession()'s "always safe to
// call" contract) — stopMonitor on an already-IDLE session is a harmless no-op.
export function stopMonitor(reason) {
  if (session.phase === SESSION_PHASES.IDLE) return;
  _cleanup(reason || "stopped");
}

// Pauses the listener. Accumulates elapsed time. Timer stops (resumeMonitor
// re-schedules it for the remaining duration).
export function pauseMonitor() {
  if (!_assertPhase(SESSION_PHASES.RUNNING, "pauseMonitor")) return;
  try {
    chrome.webRequest.onBeforeRequest.removeListener(_monitorListener);
  } catch(e) {
    // Intentional: listener may not be registered if session was already paused.
  }
  // Accumulate elapsed active time before pausing
  session.timeElapsed += Date.now() - session.startTime;
  session.startTime = null;
  if (session.timeoutHandle) { clearTimeout(session.timeoutHandle); session.timeoutHandle = null; }
  session.phase = SESSION_PHASES.PAUSED;
}

// Resumes: applies whitelist changes (caller must do that), clears array,
// re-registers listener, reloads tab. Timer is re-armed for the remaining
// duration (was previously left un-reset across resume — see MONITOR_DURATION
// note below).
// state: updated state snapshot (user may have allowed domains while paused)
export function resumeMonitor(tabId, state, cb) {
  if (!_assertPhase(SESSION_PHASES.PAUSED, "resumeMonitor")) {
    if (cb) cb({ ok: false, error: "No paused session" });
    return;
  }
  // Update state snapshot so classifier reflects any newly allowed domains
  if (state) session.state = state;

  // Clear the entry array and seen-domains set for a fresh start
  monitorEntries = [];
  _seenDomains.clear();

  // Re-register the listener
  try {
    chrome.webRequest.onBeforeRequest.addListener(
      _monitorListener,
      { urls: ["<all_urls>"], types: ["script", "sub_frame"] }
    );
  } catch(e) {
    // Intentional: addListener may throw if the SW is being torn down.
  }

  session.phase     = SESSION_PHASES.RUNNING;
  session.startTime = Date.now();
  if (session.timeoutHandle) clearTimeout(session.timeoutHandle);
  session.timeoutHandle = setTimeout(function() {
    _cleanup("timeout");
  }, Math.max(0, MONITOR_DURATION - session.timeElapsed));

  // Reload the tab
  chrome.tabs.reload(tabId, {}, function() {
    if (cb) cb({ ok: true });
  });
}

// Returns a snapshot of the current session metadata and entry array.
// Output shape is unchanged (monitor-panel.js is a consumer/contract) even
// though the internal representation is now phase-based rather than a
// paused boolean.
export function getMonitorData() {
  if (session.phase === SESSION_PHASES.IDLE) return { session: null, entries: [] };
  const isPaused = session.phase === SESSION_PHASES.PAUSED;
  const elapsed = isPaused
    ? session.timeElapsed
    : session.timeElapsed + (Date.now() - session.startTime);
  return {
    session: {
      tabId:       session.tabId,
      host:        session.host,
      paused:      isPaused,
      elapsed:     elapsed,
      remaining:   Math.max(0, MONITOR_DURATION - elapsed)
    },
    entries: monitorEntries.slice() // defensive copy
  };
}

// Adds a domain to the state domain whitelist, saves and applies rules.
// Called when the user presses Allow in the paused panel.
export function allowMonitorDomain(domain, state, applyStateFn, cb) {
  if (!domain) { if (cb) cb({ ok: false, error: "No domain" }); return; }
  if (!state.domains) state.domains = [];
  if (state.domains.indexOf(domain) === -1) {
    state.domains.push(domain);
  }
  saveState(state, function() {
    applyStateFn(state, function(count) {
      if (cb) cb({ ok: true, ruleCount: count });
    });
  });
}

// Watchdog: call once on SW boot. Kills any orphan RUNNING session older than
// 5 minutes. In practice the primary timeoutHandle handles cleanup; this is
// the fallback for the case where a SW restart lost that handle but somehow
// left `session` still logically RUNNING (defensive — in this module's
// current in-memory-only design that combination shouldn't actually arise,
// since a restart wipes `session` too, but the watchdog costs nothing to keep
// as a second line of defense against a future change to that assumption).
export function startWatchdog() {
  if (_watchdogTimer) clearInterval(_watchdogTimer);
  _watchdogTimer = setInterval(function() {
    if (session.phase !== SESSION_PHASES.RUNNING) return; // PAUSED/STARTING have no live startTime to measure
    const elapsed = session.timeElapsed + (Date.now() - session.startTime);
    if (elapsed > MONITOR_DURATION) {
      _cleanup("timeout");
    }
  }, WATCHDOG_INTERVAL);
}
