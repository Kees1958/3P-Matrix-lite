// ── core/connection-matrix.js ──────────────────────────────────────────────────
// Show Matrix — passive, always-on per-tab observer of ALL third-party
// connections (script/frame/image/media/stylesheet/font/object/fetch-xhr/
// websocket/ping/other), regardless of whether our own ruleset would block
// them.
//
// Sibling to core/block-monitor.js, not a variant of it — and NOT filtered by
// the same classifier: block-monitor.js is a bounded, reload-triggered
// session specifically for reviewing/allowlisting requests our ruleset WOULD
// BLOCK. This module serves a different purpose entirely — full-visibility
// traffic observation, blocked or not — so it does NOT call
// core/rule-classifier.js at all.
//
// Public interface:
//   startMatrix(tabId, host, cb)        — begin observing a tab (idempotent — calling
//                                         again for the same tab just resets its entries/timer)
//   stopMatrix(tabId)                   — release a single tab's tracked state
//   getMatrixData(tabId)                — returns current entries + remaining time for a tab
//   clearMatrixOnNavigation(tabId)      — call from webNavigation.onCommitted (main frame)
//   clearMatrixOnTabClosed(tabId)       — call from tabs.onRemoved
//   startMatrixWatchdog()               — call once on SW boot; kills orphan buckets
//                                         (belt-and-suspenders fallback, mirrors
//                                         block-monitor.js's startWatchdog())
//
// State owned by this module (all in-memory, lost on SW restart — safe,
// because the webRequest listener is also lost on SW restart, so there is no
// orphaned-listener case to guard against beyond the ones handled below):
//   _tabs           {Map<tabId, TabBucket>} — one bucket per actively-tracked tab
//   _listenerActive {boolean}               — whether the shared webRequest
//                                              listener is currently registered
//   _watchdogTimer  {IntervalID}             — orphan-bucket watchdog, SW lifetime
//
// TabBucket shape:
//   { host, entries: Map<domain, EntryRecord>, startTime, timeoutHandle, requestCount }
//   host          — 1P hostname the tab was on when tracking started (for same-site skip)
//   entries       — Map keyed by third-party domain; see ENTRY shape below
//   startTime     — Date.now() when startMatrix() was called; MATRIX_DURATION counts down from here
//   timeoutHandle — primary auto-close setTimeout handle for this tab
//   requestCount  — running count of resource requests observed via
//                   _matrixListener (onBeforeRequest) — NOT incremented by the
//                   cookie listeners below, since those fire on separate
//                   stages (onBeforeSendHeaders/onHeadersReceived) of a
//                   request _matrixListener may have already counted; counting
//                   in all three would double- or triple-count the same
//                   underlying request.
//
// ENTRY shape:
//   { domain, types: Set<string> }
//   types — labels derived from MATRIX_RESOURCE_TYPES, plus "cookie": "image" |
//           "media" | "stylesheet" | "script" | "frame" | "fetch/xhr" | "other"
//           ("other" also covers font/object/ping/csp_report/webbundle/
//           websocket — see _typeLabel). "cookie" is added by a separate
//           header-inspection mechanism, not _typeLabel — see the Cookie
//           detection section below; it isn't a webRequest.ResourceType at
//           all, so it doesn't fit the same dispatch path as the others.
// ─────────────────────────────────────────────────────────────────────────────

import { MATRIX_RESOURCE_TYPES, MATRIX_CAP, MATRIX_DURATION } from "../data/constants.js";
import { MSG_MATRIX_CLOSED } from "../data/message-types.js";
import { etldPlusOne } from "./rule-classifier.js";

// ── Guarded module state — initialised empty, cleared/released explicitly ────
const _tabs = new Map();     // tabId -> TabBucket
let _listenerActive = false; // guards against double-registering the listener
let _watchdogTimer   = null; // orphan-bucket watchdog interval handle

// Maps a raw webRequest resourceType to the label shown in the Show Matrix
// table. Returns null for anything totally unrecognized (shouldn't happen
// given the listener's own types filter, but the fallback here is
// defense-in-depth rather than an assumption that the filter alone is
// sufficient). font/object/ping/csp_report/webbundle/websocket all collapse
// into "other" — stylesheet gets its own column (re-added after observing
// elevated third-party stylesheet traffic tends to correlate with heavier
// embedded ad-tech/widget infrastructure — a real, visible signal even
// though webRequest can't see stylesheet *content*, only that a request
// happened).
function _typeLabel(resourceType) {
  if (resourceType === "sub_frame")      return "frame";
  if (resourceType === "script")         return "script";
  if (resourceType === "image")          return "image";
  if (resourceType === "media")          return "media";
  if (resourceType === "stylesheet")     return "stylesheet";
  if (resourceType === "xmlhttprequest") return "fetch/xhr";
  if (resourceType === "font" || resourceType === "object" ||
      resourceType === "ping" || resourceType === "csp_report" ||
      resourceType === "webbundle" || resourceType === "websocket" ||
      resourceType === "other") return "other";
  return null;
}

// Resolves the third-party host for a request, or null if the bucket is
// unknown, the URL doesn't parse, or it's actually same-site (not third-party
// at all). Shared by _matrixListener and the cookie listeners below, since all
// three need the exact same resolution/skip logic.
function _thirdPartyHostFor(bucket, url) {
  const thirdPartyHost = etldPlusOne(url);
  if (!thirdPartyHost) return null;
  const firstPartyApex = etldPlusOne("https://" + bucket.host);
  if (thirdPartyHost === firstPartyApex) return null;
  return thirdPartyHost;
}

// Finds (or creates, respecting the FIFO cap) a domain's entry in a bucket.
// Shared by _matrixListener and the cookie listeners below.
function _getOrCreateEntry(bucket, thirdPartyHost) {
  let entry = bucket.entries.get(thirdPartyHost);
  if (!entry) {
    // Enforce the FIFO cap by domain count, not raw event count — dropping the
    // oldest-seen domain keeps the table showing the most recently-active set.
    if (bucket.entries.size >= MATRIX_CAP) {
      const oldestKey = bucket.entries.keys().next().value;
      bucket.entries.delete(oldestKey);
    }
    entry = { domain: thirdPartyHost, types: new Set() };
    bucket.entries.set(thirdPartyHost, entry);
  }
  return entry;
}

// Checks a headers array (as provided by onBeforeSendHeaders/onHeadersReceived)
// for a header matching the given name, case-insensitively (HTTP header names
// are case-insensitive per spec, and Chrome doesn't normalize casing for us).
function _hasHeader(headers, name) {
  if (!headers) return false;
  for (let i = 0; i < headers.length; i++) {
    if (headers[i].name && headers[i].name.toLowerCase() === name) return true;
  }
  return false;
}

// The shared webRequest listener. Fires for every tracked tab at once —
// dispatches into whichever tab bucket (if any) matches details.tabId.
function _matrixListener(details) {
  const bucket = _tabs.get(details.tabId);
  if (!bucket) return;

  const thirdPartyHost = _thirdPartyHostFor(bucket, details.url);
  if (!thirdPartyHost) return;

  const typeLabel = _typeLabel(details.type);
  if (!typeLabel) return; // unrecognized type — shouldn't reach here given the listener's own types filter, but drop it defensively rather than pollute an entry's types Set

  _getOrCreateEntry(bucket, thirdPartyHost).types.add(typeLabel);
  bucket.requestCount++;
}

// ── Cookie detection ──────────────────────────────────────────────────────────
// "cookie" isn't a webRequest.ResourceType at all — unlike every other column,
// it's not about what KIND of resource was requested, it's about whether a
// Cookie (outgoing) or Set-Cookie (incoming) header was present on ANY
// request to that third party, regardless of its resource type. This needs
// two separate listener stages, since onBeforeRequest (used above) fires
// before headers exist at all:
//   onBeforeSendHeaders — outgoing Cookie header (browser is sending a
//                         previously-stored cookie back to that domain)
//   onHeadersReceived   — incoming Set-Cookie header (that domain is asking
//                         the browser to store a new cookie)
// Both require the 'extraHeaders' extraInfoSpec — Chrome hides Cookie/
// Set-Cookie from webRequest listeners by default (since Chrome 72) unless
// explicitly requested. Not filtered by `types` — a cookie can travel on any
// request type, not just the ones MATRIX_RESOURCE_TYPES enumerates.
function _cookieSendListener(details) {
  const bucket = _tabs.get(details.tabId);
  if (!bucket) return;
  if (!_hasHeader(details.requestHeaders, "cookie")) return;
  const thirdPartyHost = _thirdPartyHostFor(bucket, details.url);
  if (!thirdPartyHost) return;
  _getOrCreateEntry(bucket, thirdPartyHost).types.add("cookie");
}

function _cookieReceiveListener(details) {
  const bucket = _tabs.get(details.tabId);
  if (!bucket) return;
  if (!_hasHeader(details.responseHeaders, "set-cookie")) return;
  const thirdPartyHost = _thirdPartyHostFor(bucket, details.url);
  if (!thirdPartyHost) return;
  _getOrCreateEntry(bucket, thirdPartyHost).types.add("cookie");
}

// Registers the shared listeners if not already active. Safe to call repeatedly.
function _ensureListener() {
  if (_listenerActive) return;
  chrome.webRequest.onBeforeRequest.addListener(
    _matrixListener,
    { urls: ["<all_urls>"], types: MATRIX_RESOURCE_TYPES }
  );
  // Cookie detection — separate stages, not filtered by `types` (a cookie can
  // travel on any request type). 'extraHeaders' is required for Chrome to
  // actually include Cookie/Set-Cookie in these events at all (hidden by
  // default since Chrome 72) — this does carry a real, documented Chrome
  // performance cost, which is the tradeoff for getting this signal at all.
  chrome.webRequest.onBeforeSendHeaders.addListener(
    _cookieSendListener,
    { urls: ["<all_urls>"] },
    ["requestHeaders", "extraHeaders"]
  );
  chrome.webRequest.onHeadersReceived.addListener(
    _cookieReceiveListener,
    { urls: ["<all_urls>"] },
    ["responseHeaders", "extraHeaders"]
  );
  _listenerActive = true;
}

// Releases the shared listeners once no tabs remain tracked. Safe to call repeatedly.
function _releaseListenerIfIdle() {
  if (!_listenerActive || _tabs.size > 0) return;
  try {
    chrome.webRequest.onBeforeRequest.removeListener(_matrixListener);
  } catch(e) {
    // Intentional: listener may already be gone (e.g. SW restart mid-teardown).
  }
  try {
    chrome.webRequest.onBeforeSendHeaders.removeListener(_cookieSendListener);
  } catch(e) {
    // Intentional: see above.
  }
  try {
    chrome.webRequest.onHeadersReceived.removeListener(_cookieReceiveListener);
  } catch(e) {
    // Intentional: see above.
  }
  _listenerActive = false;
}

// Sends MSG_MATRIX_CLOSED to the Show Matrix panel (fire-and-forget). Ported
// from core/block-monitor.js's _notifyPanel — same shape, same suppression
// of chrome.runtime.lastError when the panel is already closed (C21: reuse a
// proven sibling pattern rather than inventing a new one).
function _notifyPanel(tabId, reason) {
  try {
    chrome.runtime.sendMessage({ type: MSG_MATRIX_CLOSED, tabId: tabId, reason: reason }, function() {
      if (chrome.runtime.lastError) { /* intentional no-op — panel may already be closed */ }
    });
  } catch(e) {
    // Intentional: SW context may be terminating; panel closure is best-effort.
  }
}

// ── Public interface ──────────────────────────────────────────────────────────

// Starts (or restarts) tracking for a single tab. Idempotent: calling again
// for a tab already being tracked simply clears its entries and re-arms the
// timer from a fresh MATRIX_DURATION window, rather than erroring or creating
// a duplicate bucket.
export function startMatrix(tabId, host, cb) {
  _clearTimeoutHandle(tabId); // guard: release any stale handle before replacing the bucket
  const bucket = {
    host: host, entries: new Map(),
    startTime: Date.now(), timeoutHandle: null,
    requestCount: 0
  };
  _tabs.set(tabId, bucket);
  bucket.timeoutHandle = setTimeout(function() {
    _timeoutMatrix(tabId);
  }, MATRIX_DURATION);
  _ensureListener();
  if (cb) cb({ ok: true });
}

// Clears a tab's timeout handle without touching anything else — used both
// as a guard before replacing a bucket and as part of full teardown.
function _clearTimeoutHandle(tabId) {
  const bucket = _tabs.get(tabId);
  if (bucket && bucket.timeoutHandle) { clearTimeout(bucket.timeoutHandle); bucket.timeoutHandle = null; }
}

// Auto-close path — the primary timer (or the watchdog fallback) firing.
// Notifies the panel with reason "timeout" before releasing the bucket, same
// shape as clearMatrixOnTabClosed's "tab_closed" notification below.
function _timeoutMatrix(tabId) {
  if (!_tabs.has(tabId)) return;
  stopMatrix(tabId);
  _notifyPanel(tabId, "timeout");
}

// Stops tracking a single tab and releases its memory. Releases the shared
// listener too, if this was the last tracked tab.
export function stopMatrix(tabId) {
  _clearTimeoutHandle(tabId);
  _tabs.delete(tabId);
  _releaseListenerIfIdle();
}

// Returns a defensive-copy snapshot of a tab's current entries plus the
// remaining/elapsed time for the panel's countdown display.
export function getMatrixData(tabId) {
  const bucket = _tabs.get(tabId);
  if (!bucket) return { entries: [], elapsed: 0, remaining: 0, domainCount: 0, requestCount: 0 };
  const entries = [];
  bucket.entries.forEach(function(entry) {
    entries.push({
      domain: entry.domain,
      types:  Array.from(entry.types)
    });
  });
  const elapsed = Date.now() - bucket.startTime;
  return {
    entries:      entries,
    elapsed:      elapsed,
    remaining:    Math.max(0, MATRIX_DURATION - elapsed),
    domainCount:  bucket.entries.size,
    requestCount: bucket.requestCount
  };
}

// Call from webNavigation.onCommitted (main_frame only) — a fresh navigation
// means a fresh page, so the entry list and request count both reset rather
// than carrying over from a page the user has since left.
export function clearMatrixOnNavigation(tabId) {
  const bucket = _tabs.get(tabId);
  if (!bucket) return;
  bucket.entries.clear();
  bucket.requestCount = 0;
}

// Call from tabs.onRemoved — releases the bucket entirely so closed tabs
// never leak memory in _tabs, and notifies any open panel to close itself.
export function clearMatrixOnTabClosed(tabId) {
  const wasTracked = _tabs.has(tabId);
  stopMatrix(tabId);
  if (wasTracked) _notifyPanel(tabId, "tab_closed");
}

// Watchdog: call once on SW boot. Kills any orphan bucket whose timer somehow
// didn't fire (e.g. a SW restart lost the setTimeout handle for an in-memory
// bucket) — belt-and-suspenders fallback, same rationale and shape as
// core/block-monitor.js's startWatchdog(). In this module's current
// in-memory-only design a SW restart also wipes `_tabs` itself, so this
// shouldn't actually be reachable today; kept as a second line of defense
// against a future change to that assumption.
export function startMatrixWatchdog() {
  if (_watchdogTimer) clearInterval(_watchdogTimer);
  _watchdogTimer = setInterval(function() {
    _tabs.forEach(function(bucket, tabId) {
      const elapsed = Date.now() - bucket.startTime;
      if (elapsed > MATRIX_DURATION) _timeoutMatrix(tabId);
    });
  }, MATRIX_DURATION);
}
