#!/usr/bin/env node
// ── tools/complete-check.mjs ────────────────────────────────────────────────
// Automated pre-release check suite (Part D of the programming-principles
// audit standard). Run via `npm run check` before every version bump that
// is about to be zipped — not just before a store submission.
//
// What this suite covers (see README section below for what it does NOT):
//   1. Syntax        — `node --check` on every extension .js file
//   2. ESLint         — the project's own .eslintrc.json rule set
//   3. JSON validity  — manifest.json and package.json parse cleanly
//   4. File cross-reference (C20) — every path declared in manifest.json
//      (background, popup, icons, web_accessible_resources, content_scripts),
//      every `import`/`<script src>` in the extension, resolves to a real
//      file on disk; every .js/.html file on disk is reachable from
//      manifest.json (directly or transitively via imports)
//   5. Message-routing cross-reference (C20a) — every MSG_* constant in
//      data/message-types.js has both a router `case` in background.js AND
//      at least one sender elsewhere (either the imported identifier, or its
//      literal string value — the latter covers a plain, non-ES-module
//      content script that cannot `import` the constant), UNLESS it is in
//      the maintained BROADCAST_ONLY set below (which instead must have an
//      .onmessage reader) — this is the exact check that would have caught
//      MSG_SET_MATRIX_DOMAIN_RULE having no sender (see CHANGELOG).
//   6. Version sync   — manifest.json and package.json report the same
//      version string.
//
// What this suite deliberately does NOT cover, and why:
//   - No JSDOM dry-run / live DOM+JS execution (the full standard's step 5).
//     This is a small, dependency-light script by design; a real DOM
//     harness would need jsdom as a devDependency.
//   - No functional smoke test against mocked chrome.storage (step 6).
//   - No CSS class cross-reference or DNR rule-ID collision check (steps
//     9/11) — this extension has no DNR-rule-generation build step and a
//     single small CSS file per page, both audited manually instead.
// These gaps are intentional simplifications for this extension's size, not
// oversights — flagged explicitly per C13a/C13b (no silent partial coverage).
//
// Exit code is non-zero if any hard check fails. Warnings (e.g. the
// BROADCAST_ONLY set needing a manual update) print but do not fail the run.
// ─────────────────────────────────────────────────────────────────────────────

import { execFileSync } from "node:child_process";
import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// ── Config — single source of truth for this script's own tunables ─────────
// Directories scanned for .js files (relative to ROOT).
const JS_SCAN_DIRS = ["", "core", "data", "ui", "util", "content"];
// Message types sent only via chrome.runtime.sendMessage broadcast / a
// dedicated .onmessage reader, by design — expected to have NO router case
// in background.js. Maintain this by hand whenever a broadcast-only type is
// added (see C20a in the standard).
const BROADCAST_ONLY = new Set(["MSG_MATRIX_CLOSED"]);

let failed = false;
const warn = (msg) => console.warn(`⚠ WARN  ${msg}`);
const fail = (msg) => { failed = true; console.error(`✗ FAIL  ${msg}`); };
const ok   = (msg) => console.log(`✓ OK    ${msg}`);

function listJsFiles() {
  const out = [];
  for (const dir of JS_SCAN_DIRS) {
    const abs = path.join(ROOT, dir);
    if (!existsSync(abs)) continue;
    for (const entry of readdirSync(abs)) {
      const full = path.join(abs, entry);
      if (statSync(full).isFile() && entry.endsWith(".js")) out.push(full);
    }
  }
  return out;
}

// ── 1. Syntax check ─────────────────────────────────────────────────────────
function checkSyntax() {
  console.log("\n── 1. Syntax (node --check) ──");
  for (const file of listJsFiles()) {
    try {
      execFileSync(process.execPath, ["--check", file], { stdio: "pipe" });
    } catch (e) {
      fail(`${path.relative(ROOT, file)}: ${e.stderr?.toString().trim() || e.message}`);
      continue;
    }
  }
  if (!failed) ok(`${listJsFiles().length} files parsed cleanly`);
}

// ── 2. ESLint ────────────────────────────────────────────────────────────────
function checkLint() {
  console.log("\n── 2. ESLint ──");
  if (!existsSync(path.join(ROOT, ".eslintrc.json"))) {
    warn("no .eslintrc.json found — skipping lint step");
    return;
  }
  // Prefer the locally-installed devDependency (matches package.json's
  // pinned version and its legacy .eslintrc.json format) over `npx`, which
  // silently fetches the latest major version and breaks on flat-config-only
  // ESLint releases.
  const localBin = path.join(ROOT, "node_modules", ".bin", process.platform === "win32" ? "eslint.cmd" : "eslint");
  if (!existsSync(localBin)) {
    warn("eslint not installed locally — run `npm install` first; skipping lint step");
    return;
  }
  try {
    execFileSync(localBin, [".", "--ext", ".js"], { cwd: ROOT, stdio: "pipe" });
    ok("eslint clean");
  } catch (e) {
    fail(`eslint reported issues:\n${e.stdout?.toString() || e.message}`);
  }
}

// ── 3. JSON validity ─────────────────────────────────────────────────────────
function loadJson(relPath) {
  const full = path.join(ROOT, relPath);
  if (!existsSync(full)) { fail(`${relPath}: file not found`); return null; }
  try {
    return JSON.parse(readFileSync(full, "utf8"));
  } catch (e) {
    fail(`${relPath}: invalid JSON — ${e.message}`);
    return null;
  }
}

function checkJson() {
  console.log("\n── 3. JSON validity ──");
  const manifest = loadJson("manifest.json");
  const pkg      = loadJson("package.json");
  if (manifest && pkg) ok("manifest.json and package.json parse cleanly");
  return { manifest, pkg };
}

// ── 4. File cross-reference (C20) ───────────────────────────────────────────
// Strips /* block */ and // line comments before static analysis, so
// example code quoted inside a header comment (e.g. "Load via: import ...")
// is never mistaken for a real import statement.
function stripComments(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/(^|[^:])\/\/.*$/gm, "$1");
}

function extractImportPaths(file) {
  const src = stripComments(readFileSync(file, "utf8"));
  const paths = [];
  const importRe = /\bimport\s+(?:[\s\S]*?\bfrom\s+)?["']([^"']+)["']/g;
  let m;
  while ((m = importRe.exec(src)) !== null) {
    if (m[1].startsWith(".") || m[1].startsWith("/")) paths.push(m[1]);
  }
  return paths;
}

function extractHtmlScriptSrcs(file) {
  const src = readFileSync(file, "utf8").replace(/<!--[\s\S]*?-->/g, "");
  const paths = [];
  const re = /<script[^>]+src=["']([^"']+)["']/g;
  let m;
  while ((m = re.exec(src)) !== null) paths.push(m[1]);
  return paths;
}

function checkFileReferences(manifest) {
  console.log("\n── 4. File cross-reference (C20) ──");
  if (!manifest) { warn("skipped — manifest.json failed to parse"); return; }

  const declared = new Set();

  // manifest.json declared paths
  if (manifest.background?.service_worker) declared.add(manifest.background.service_worker);
  if (manifest.action?.default_popup) declared.add(manifest.action.default_popup);
  for (const iconPath of Object.values(manifest.icons || {})) declared.add(iconPath);
  for (const iconPath of Object.values(manifest.action?.default_icon || {})) declared.add(iconPath);
  for (const war of manifest.web_accessible_resources || []) {
    for (const r of war.resources || []) declared.add(r);
  }
  for (const cs of manifest.content_scripts || []) {
    for (const js of cs.js || []) declared.add(js);
    for (const css of cs.css || []) declared.add(css);
  }

  // Every declared path must exist on disk.
  for (const p of declared) {
    if (!existsSync(path.join(ROOT, p))) fail(`manifest.json references missing file: ${p}`);
  }

  // Every HTML file's <script src> and every JS file's static imports must
  // resolve — walked transitively from the manifest's own entry points.
  const visited = new Set();
  const toVisit = [...declared].filter((p) => p.endsWith(".js") || p.endsWith(".html"));

  while (toVisit.length) {
    const rel = toVisit.pop();
    if (visited.has(rel)) continue;
    visited.add(rel);
    const abs = path.join(ROOT, rel);
    if (!existsSync(abs)) continue; // already flagged above if it was manifest-declared

    const dir = path.dirname(rel);
    if (rel.endsWith(".html")) {
      for (const src of extractHtmlScriptSrcs(abs)) {
        const resolved = path.normalize(path.join(dir, src));
        if (!existsSync(path.join(ROOT, resolved))) {
          fail(`${rel}: <script src="${src}"> does not resolve to a file on disk`);
        } else {
          toVisit.push(resolved);
        }
      }
    } else if (rel.endsWith(".js")) {
      for (const imp of extractImportPaths(abs)) {
        const resolved = path.normalize(path.join(dir, imp));
        if (!existsSync(path.join(ROOT, resolved))) {
          fail(`${rel}: import "${imp}" does not resolve to a file on disk`);
        } else {
          toVisit.push(resolved);
        }
      }
    }
  }

  // Every .js file on disk should be reachable from the manifest, or be a
  // build-time-only tool explicitly excluded here.
  const buildOnly = new Set(["tools/complete-check.mjs"]);
  for (const file of listJsFiles()) {
    const rel = path.relative(ROOT, file).split(path.sep).join("/");
    if (buildOnly.has(rel)) continue;
    if (!visited.has(rel)) warn(`${rel} is not reachable from manifest.json — orphaned file, or an untracked entry point`);
  }

  if (!failed) ok("all declared/imported/script-src paths resolve to real files");
}

// ── 5. Message-routing cross-reference (C20a) ───────────────────────────────
function checkMessageRouting() {
  console.log("\n── 5. Message-routing cross-reference (C20a) ──");
  const typesFile = path.join(ROOT, "data/message-types.js");
  if (!existsSync(typesFile)) { warn("data/message-types.js not found — skipped"); return; }

  const typesSrc = readFileSync(typesFile, "utf8");
  const constDecls = [...typesSrc.matchAll(/export const (MSG_\w+)\s*=\s*"([^"]+)"/g)];
  const constNames = constDecls.map((m) => m[1]);
  const valueOf     = Object.fromEntries(constDecls.map((m) => [m[1], m[2]]));

  const bgFile = path.join(ROOT, "background.js");
  const bgSrc  = existsSync(bgFile) ? readFileSync(bgFile, "utf8") : "";

  // Every JS file's sendMessage/send() call sites, to find senders.
  const allSrc = listJsFiles().map((f) => readFileSync(f, "utf8")).join("\n");

  for (const name of constNames) {
    const hasRouterCase = new RegExp(`case\\s+${name}\\s*:`).test(bgSrc);
    // A real sender constructs a message payload with this type — the
    // codebase's own consistent shape is `{ type: MSG_X, ... }`. Matching
    // that specific shape (rather than any occurrence of the name) avoids
    // false negatives from the constant's own declaration, its import list,
    // or its router `case` all counting as "used".
    //
    // A sender is also valid if it uses the constant's raw STRING VALUE
    // directly (`{ type: "THE_VALUE", ... }`) instead of the imported
    // identifier — this is deliberate, not a gap: a plain (non-ES-module)
    // content script (see content/fail-break.js) cannot `import` from
    // data/message-types.js at all, so MSG_FAIL_BREAK's one sender uses its
    // literal string value instead, exactly as that file's own header
    // comment documents. Recognizing this pattern generally (not as a
    // one-off special case) means any FUTURE content script that needs the
    // same workaround is covered automatically, with no changes needed here.
    const hasAnySender = new RegExp(`type:\\s*${name}\\b`).test(allSrc)
      || (valueOf[name] && new RegExp(`type:\\s*["']${valueOf[name]}["']`).test(allSrc));

    if (BROADCAST_ONLY.has(name)) {
      const hasReader = new RegExp(`${name}[\\s\\S]{0,80}onmessage|onmessage[\\s\\S]{0,200}${name}`, "m").test(allSrc)
        || (allSrc.match(new RegExp(`msg\\.type\\s*===\\s*${name}`)) !== null);
      if (!hasReader) fail(`${name} is in BROADCAST_ONLY but no .onmessage reader found for it`);
      if (hasRouterCase) warn(`${name} is in BROADCAST_ONLY but ALSO has a background.js router case — is it still broadcast-only?`);
    } else {
      if (!hasRouterCase) fail(`${name}: no router case in background.js (and not in BROADCAST_ONLY)`);
      if (!hasAnySender) warn(`${name}: has a router case but no sendMessage call site found anywhere — dead message type? (see MSG_SET_MATRIX_DOMAIN_RULE precedent in CHANGELOG)`);
    }
  }
  if (!failed) ok(`${constNames.length} message types checked (${BROADCAST_ONLY.size} broadcast-only)`);
}

// ── 6. Version sync ──────────────────────────────────────────────────────────
function checkVersionSync(manifest, pkg) {
  console.log("\n── 6. Version sync ──");
  if (!manifest || !pkg) { warn("skipped — manifest.json or package.json failed to parse"); return; }
  if (manifest.version !== pkg.version) {
    fail(`version mismatch: manifest.json=${manifest.version} package.json=${pkg.version}`);
  } else {
    ok(`manifest.json and package.json both at ${manifest.version}`);
  }
}

// ── Run ──────────────────────────────────────────────────────────────────────
checkSyntax();
checkLint();
const { manifest, pkg } = checkJson();
checkFileReferences(manifest);
checkMessageRouting();
checkVersionSync(manifest, pkg);

console.log("\n" + (failed ? "✗ complete-check FAILED — see above" : "✓ complete-check passed"));
process.exit(failed ? 1 : 0);
