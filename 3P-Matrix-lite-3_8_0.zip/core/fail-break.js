// ── core/fail-break.js ──────────────────────────────────────────────────────
// Fail-break protection: at levels 2 and 3, relax a specific tab back to
// level 1 the moment the user types into a form field (level 2: any field;
// level 3: a password/payment/address field — see content/fail-break.js).
//
// Implemented as ONE declarativeNetRequest SESSION rule per tab — deliberately
// NOT a dynamic rule, and NOT a change to state.level/state.siteRules:
//   - Session rules live only for the current browser session and are never
//     written to chrome.storage — nothing here is persisted, matching the
//     extension's privacy policy (see privacy.md's "Fail-Break Protection").
//   - DNR's condition.tabIds field — which lets one rule apply to a single
//     tab only — is available exclusively to session rules, not dynamic
//     ones. This is the only mechanism that can express "relax blocking for
//     THIS tab only" without touching the global/dynamic ruleset every other
//     tab also uses, and without rebuilding or even reading buildRules().
//   - A single high-priority "allow" rule, scoped to one tabId, outranks
//     every dynamic block rule for that tab specifically — nothing else in
//     the ruleset needs to know this override exists.
//
// Public interface:
//   applyFailBreakOverride(tabId, cb) — installs the override for one tab
//                                        (idempotent — a second call for an
//                                        already-overridden tab is a no-op)
//   clearFailBreakOverride(tabId, cb) — releases it; call on tab close, the
//                                        user moving the slider, or the user
//                                        locking the site (see background.js's
//                                        MSG_CLEAR_FAIL_BREAK handler and
//                                        chrome.tabs.onRemoved hook)
//   hasFailBreakOverride(tabId)       — true if currently active for tabId
// ───────────────────────────────────────────────────────────────────────────

// ── Named constants — declared once, here, with clear comments ─────────────
// Priority chosen to outrank every other rule this extension's dynamic
// ruleset can ever produce — the matrix override's block half is the
// highest existing priority in the codebase, at 2000 (see core/rule-
// builder.js's buildMatrixOverrideRules() header). A tab-scoped allow above
// that always wins for that tab, regardless of which other rule it's up
// against, without this module needing to know what those rules are.
const FAIL_BREAK_RULE_PRIORITY = 3000;

// The full breadth of third-party resource types this extension's ruleset
// can ever block — sub_frame + script/webbundle, and nothing else (see
// core/rule-builder.js's own "never extend blocking beyond" comment). The
// override only needs to counter exactly what could be blocking the page,
// not a broader set.
const FAIL_BREAK_RESOURCE_TYPES = ["sub_frame", "script", "webbundle"];

// ── Guarded module state — initialised empty, cleared/released explicitly ──
// Tracks which tabIds currently have a session rule installed, so
// applyFailBreakOverride() can be idempotent and clearFailBreakOverride()
// can no-op cleanly for a tab that was never overridden — in-memory only,
// lost (harmlessly — session rules are too) on SW restart.
const _activeTabs = new Set();

// Installs (or refreshes) the fail-break override for one tab. Idempotent:
// calling this again for a tab that already has the override active is a
// cheap no-op, so callers never need to check hasFailBreakOverride() first.
export function applyFailBreakOverride(tabId, cb) {
  if (typeof tabId !== "number") { if (cb) cb(); return; } // guard: no valid tab, nothing to install
  if (_activeTabs.has(tabId)) { if (cb) cb(); return; }

  const rule = {
    id: tabId, // tabId is always a positive integer — safe, collision-free 1:1 rule id within the session-rule namespace
    priority: FAIL_BREAK_RULE_PRIORITY,
    action: { type: "allow" },
    condition: { tabIds: [tabId], domainType: "thirdParty", resourceTypes: FAIL_BREAK_RESOURCE_TYPES }
  };

  chrome.declarativeNetRequest.updateSessionRules(
    { addRules: [rule], removeRuleIds: [tabId] }, // removeRuleIds first, defensively — guards against a stale rule from an evicted/reused tabId
    function() {
      if (chrome.runtime.lastError) { /* intentional no-op — tab may already be gone by the time this resolves */ }
      _activeTabs.add(tabId);
      if (cb) cb();
    }
  );
}

// Releases the fail-break override for one tab. Guard: no-ops cleanly if the
// tab never had one, so every caller (tab close, slider move, site lock) can
// call this unconditionally without checking state first.
export function clearFailBreakOverride(tabId, cb) {
  if (typeof tabId !== "number") { if (cb) cb(); return; }
  if (!_activeTabs.has(tabId)) { if (cb) cb(); return; }

  chrome.declarativeNetRequest.updateSessionRules(
    { removeRuleIds: [tabId] },
    function() {
      if (chrome.runtime.lastError) { /* intentional no-op — tab may already be gone */ }
      _activeTabs.delete(tabId);
      if (cb) cb();
    }
  );
}

// True if tabId currently has an active fail-break override.
export function hasFailBreakOverride(tabId) {
  return _activeTabs.has(tabId);
}
