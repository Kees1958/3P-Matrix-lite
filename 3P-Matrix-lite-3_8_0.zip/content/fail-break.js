// ── content/fail-break.js ───────────────────────────────────────────────────
// Fail-break trigger — runs inside every page (and every frame) this
// extension has host permission for. Watches for the user typing into a
// form field and reports it to the background service worker, which decides
// (based on the current effective level for this site) whether to relax
// blocking for this tab. See core/fail-break.js for that decision and the
// actual override mechanism; this file's only job is detection + reporting.
//
// Deliberately NOT an ES module. Chrome's manifest.json content_scripts
// entries do not support "type": "module" the way background.service_worker
// does, so this file cannot `import` from data/message-types.js or
// data/constants.js — everything it needs is self-contained below, each
// with a comment pointing to its authoritative source. This is the same
// "documented, deliberate, cross-context duplication" precedent already
// used elsewhere in this codebase (e.g. matrix-panel.html's CSS level-color
// variables) — not a new pattern invented for this file.
//
// The message type is sent as the literal string "FAIL_BREAK" (not a
// declared constant) for the same import-limitation reason — it MUST match
// data/message-types.js's exported MSG_FAIL_BREAK value exactly. If that
// value is ever changed, both send call sites below must be updated by
// hand to match — tools/complete-check.mjs's message-routing check
// (C20a) verifies this string is actually present here, so a drift would
// surface as a "dead message type" warning on the next check run.
//
// Privacy note (see privacy.md's "Fail-Break Protection" section): this
// script reads a field's type/autocomplete metadata only — NEVER the value
// typed into it — and sends nothing anywhere except one short message to
// this extension's own background service worker.
(function() {
  "use strict";

  // ── Named constants — declared once, here, with clear comments ───────────
  // Sensitive-field detection tokens — checked against an input element's
  // browser-normalized `autocomplete` IDL value (i.e. the same
  // classification mechanism the browser's own autofill uses, per the
  // WHATWG Autofill spec: https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill).
  // This is the closest an extension can get to "the browser's own sense of
  // which fields are sensitive" without access to Chrome's internal,
  // non-extensible autofill heuristics. type="password" is checked
  // separately below, since password fields don't require an autocomplete
  // attribute to be meaningfully sensitive.
  const SENSITIVE_AUTOCOMPLETE_TOKENS = [
    // Password / auth
    "current-password", "new-password", "one-time-code",
    // Payment
    "cc-name", "cc-number", "cc-exp", "cc-exp-month", "cc-exp-year", "cc-csc", "cc-type",
    // Address
    "street-address", "address-line1", "address-line2", "address-line3",
    "address-level1", "address-level2", "address-level3", "address-level4",
    "country", "country-name", "postal-code",
    // Personal info
    "name", "given-name", "family-name", "additional-name",
    "honorific-prefix", "honorific-suffix", "email", "tel", "tel-national", "bday"
  ];

  // Determines whether an input element counts as "sensitive" for level 3's
  // fail-break trigger. Never inspects the field's VALUE — only its type
  // and its browser-normalized autocomplete token.
  function isSensitiveField(el) {
    if (!el) return false;
    if ((el.type || "").toLowerCase() === "password") return true;
    const token = (el.autocomplete || "").toLowerCase(); // browser-normalized IDL value, not the raw attribute string
    return SENSITIVE_AUTOCOMPLETE_TOKENS.indexOf(token) !== -1;
  }

  // ── One-shot-per-category detection ───────────────────────────────────────
  // "input" events only ever fire on an element the user actually typed
  // into (a real <input>/<textarea>/contenteditable) — never on a click — so
  // no extra element-type filtering is needed to satisfy the "entering
  // values, not clicking something" requirement.
  //
  // Fires at most twice total (once for "any field" — level 2 — and once for
  // "a sensitive field" — level 3), then fully removes its own listener.
  // This keeps the steady-state cost at effectively zero: not a
  // per-keystroke check once both categories have already been reported.
  let firedBasic     = false;
  let firedSensitive = false;

  function handleInput(evt) {
    const el = evt.target;
    if (!el) return;

    if (!firedBasic) {
      firedBasic = true;
      // Value MUST match data/message-types.js's MSG_FAIL_BREAK — see this
      // file's header comment.
      try { chrome.runtime.sendMessage({ type: "FAIL_BREAK", sensitive: false }); } catch (e) { /* extension context may be gone (e.g. reloaded) — nothing to do */ }
    }
    if (!firedSensitive && isSensitiveField(el)) {
      firedSensitive = true;
      // Same value/rationale as the send above.
      try { chrome.runtime.sendMessage({ type: "FAIL_BREAK", sensitive: true }); } catch (e) { /* same as above */ }
    }
    if (firedBasic && firedSensitive) {
      document.removeEventListener("input", handleInput, true); // guard: release once both categories are reported — nothing left for this listener to do
    }
  }

  document.addEventListener("input", handleInput, true);
})();
