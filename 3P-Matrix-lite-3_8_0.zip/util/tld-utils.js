// ── util/tld-utils.js ─────────────────────────────────────────────────────────
// Pure utility functions for TLD detection and version string parsing.
// No side effects, no state, no Chrome API calls (except chrome.i18n which
// is a pure query with no side effects).
//
// Public interface:
//   browserCountryTlds(cb)  — detects country TLDs from browser language settings
//   majorMinor(version)     — extracts "major.minor" from a version string
//   getApexDomain(hostname) — reduces a hostname to its registrable (apex) domain
// ─────────────────────────────────────────────────────────────────────────────

import { EU_LANGS, MULTI_PART_SUFFIXES } from "../data/constants.js";

// Reads the browser's accepted languages and extracts country-code TLDs.
// Also adds "eu" if any EU language is detected.
// Calls cb(tlds) with an array of TLD strings, e.g. ["nl", "be", "eu"].
export function browserCountryTlds(cb) {
  chrome.i18n.getAcceptLanguages(function(langs) {
    const seen = {}, tlds = [];
    let hasEuLang = false;
    (langs || []).forEach(function(lang) {
      const parts  = lang.toLowerCase().split("-");
      const region = parts.length > 1 ? parts[parts.length - 1] : parts[0];
      if (EU_LANGS[parts[0]]) hasEuLang = true;
      if (/^[a-z]{2,3}$/.test(region) && !seen[region]) {
        seen[region] = true;
        tlds.push(region);
      }
    });
    if (hasEuLang && tlds.indexOf("eu") === -1) tlds.push("eu");
    cb(tlds);
  });
}

// Extracts "major.minor" from a semver-style version string.
// e.g. "1.6.8" -> "1.6",  "2.0" -> "2.0",  "" -> "0.0"
export function majorMinor(version) {
  const parts = (version || "").split(".");
  return (parts[0] || "0") + "." + (parts[1] || "0");
}

// Reduces a hostname to its registrable (apex) domain, e.g.
// "portal.www.tio.nl" -> "tio.nl", "www.example.co.uk" -> "example.co.uk"
// Single source of truth — used by ui/popup.js (site locking) and
// background.js (resolving the hostname core/fail-break.js's content script
// reports, via MSG_FAIL_BREAK, into the same apex-domain format state.siteRules
// keys use).
export function getApexDomain(hostname) {
  if (!hostname) return hostname;
  const labels = hostname.split(".");
  if (labels.length <= 2) return hostname;

  const lastTwo   = labels.slice(-2).join(".");
  const lastThree = labels.length >= 3 ? labels.slice(-3).join(".") : null;

  if (lastThree && MULTI_PART_SUFFIXES.indexOf(labels.slice(-2).join(".")) !== -1) {
    return lastThree;
  }
  return lastTwo;
}
