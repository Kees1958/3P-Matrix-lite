// ── data/state-storage.js ─────────────────────────────────────────────────────
// State schema, defaults and chrome.storage.local read/write.
// The only file allowed to call chrome.storage directly.
//
// Public interface:
//   loadState(cb)    — reads state from storage, merges defaults, calls cb(state)
//   saveState(s, cb) — writes state to storage, calls cb() when done
//
// State is persisted under a single storage key (STORAGE_KEY).
// On SW restart, loadState() reconstructs the full state object from storage.
// ─────────────────────────────────────────────────────────────────────────────

import { BUILTIN_DOMAINS } from "./constants.js";

export const STORAGE_KEY    = "3pmatrix_state";   // single chrome.storage.local key for all state
export const SITE_RULES_CAP = 200;                // max number of per-site pinned rules (FIFO eviction)

// ── Named constants for storage keys used outside this module ─────────────────
// These keys are written directly by popup.js and monitor-panel.js (not via
// loadState/saveState) because they are UI-session state, not extension state.
// Declaring them here keeps all storage key names in one place.
export const SESSION_KEY_LEVEL      = "sessionLevel";      // chrome.storage.session — active slider level
export const SESSION_KEY_PREV_LEVEL = "prevSessionLevel";  // chrome.storage.session — pre-lock level

export const DEFAULT_STATE = {
  startupLevel: 1,
  level:        1,
  tlds:         ["com", "ai", "edu", "gov", "io", "net", "org", "cloud", "dev", "app", "page"],
  builtinDomains: null,    // seeded with BUILTIN_DOMAINS on first install, editable by user
  autoTldMode:  1,
  manualTlds:   [],
  excludedTlds: [],        // TLDs the user explicitly removed — kept out on re-sync
  siteRules:    {},        // { "hostname": level }
  siteRulesOrder: [],      // insertion-order array for FIFO eviction
  // Whitelist dropdown state: true = expanded, false = collapsed.
  // Resets to expanded on fresh install or major.minor version update.
  whitelistDropdown: { tld: true, domain: true },
  lastShownVersion: "",    // "major.minor" e.g. "1.3" — used to detect version updates
  showBlockedCount: true,        // toolbar badge showing per-tab blocked request count (reserved for future UI toggle)
  blockedTldDropdownOpen: false, // TLD blacklist dropdown starts collapsed
  // TLD blacklist for level 2 script blocking.
  // blockedTldMode: 0=None, 1=User, 2=Generic, 3=World
  blockedTldMode:    0,
  blockedTlds:       [],   // active computed list (rebuilt from mode + manualBlockedTlds)
  // Interactive Show Matrix per-domain, per-type overrides.
  // { [domain]: { frame?: "allow"|"block", script?: "allow"|"block" } }
  // Independent from `domains` above (which is a domain-wide, type-agnostic
  // whitelist used by the Domain whitelist tab) — matrixRules is scoped to a
  // single resource type per entry, and can express BOTH allow and block
  // (domains has no block concept at all). A key present here always wins
  // over the level's default disposition for that domain+type — see
  // rule-builder.js's buildMatrixOverrideRules() for the priority mechanics.
  // Only "frame" and "script" keys are ever set — those are the only two
  // resource types this extension's DNR rules are built to block at all.
  matrixRules:       {},
  manualBlockedTlds: []    // TLDs the user explicitly added (persisted across mode changes)
};

// Reads state from chrome.storage.local, merges with DEFAULT_STATE to ensure
// all keys are present (handles new keys added in later versions gracefully),
// and normalises any invalid values before calling cb(state).
export function loadState(cb) {
  chrome.storage.local.get(STORAGE_KEY, function(stored) {
    const s = Object.assign({}, DEFAULT_STATE, stored[STORAGE_KEY] || {});
    if (s.level === 0)        s.level        = 1;
    if (s.startupLevel === 0) s.startupLevel = 1;
    if (!s.siteRules)         s.siteRules     = {};
    if (!s.siteRulesOrder)    s.siteRulesOrder = Object.keys(s.siteRules);
    if (s.builtinDomains === null || s.builtinDomains === undefined) {
      s.builtinDomains = Object.assign({}, BUILTIN_DOMAINS);
    }
    if (!s.blockedTlds)        s.blockedTlds        = [];
    if (!s.manualBlockedTlds)  s.manualBlockedTlds  = [];
    if (typeof s.blockedTldMode !== "number") s.blockedTldMode = 0;
    cb(s);
  });
}

// Writes state to chrome.storage.local as a single atomic operation.
// All related state fields are always written together — never update
// individual fields separately to avoid inconsistent intermediate state.
export function saveState(s, cb) {
  const o = {};
  o[STORAGE_KEY] = s;
  chrome.storage.local.set(o, cb || function() {});
}
