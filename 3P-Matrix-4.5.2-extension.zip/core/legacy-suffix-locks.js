// ── core/legacy-suffix-locks.js ───────────────────────────────────────────────
// COMPAT-REMOVE ≥4.6 — one-time conversion for the 4.4.5 upgrade, delete together with its test cases.
//
// Before 4.4.5 a lock on a shared host was stored under the bare suffix ("sharepoint.com") and covered
// every tenant. Since 4.4.5 locks are per tenant ("acme-my.sharepoint.com"), so that key can never match
// again. On update the lock is carried over to the tenant hosts the user has OPEN in tabs right now (same
// level); whatever cannot be converted (no such tab open) is dropped by the schema-4 migration
// (data/state-storage.js) — the user locks that tenant when they next need it.
//
// Public interface:
//   convertSuffixLocks(raw, hosts)  — pure: returns { raw, converted } — a copy of the raw stored state with
//                                     tenant locks added for every host (of `hosts`) under a locked
//                                     shared-hosting suffix; `converted` = the tenant domains added
//   convertStoredSuffixLocks()      — Promise<string[]> — reads storage, converts with the open tabs' hosts,
//                                     writes back only when something changed (never throws)
//
// Guards: runs only from background.js onInstalled (reason "update"), under the state lock; a state at
// schema ≥ 4 is left alone (already migrated); SITE_LOCKS_CAP respected; nothing is held after the call.
// ─────────────────────────────────────────────────────────────────────────────

import { STORAGE_KEY_STATE, SHARED_HOSTING_SUFFIXES, SITE_LOCKS_CAP, LOG_PREFIX } from "../data/constants.js";
import { registeredDomain, parseHttpUrl } from "../util/domain.js";

const FIRST_SCHEMA_WITHOUT_LEGACY_LOCKS = 4;

export function convertSuffixLocks(raw, hosts) {
  const locks = (raw && raw.siteLocks && typeof raw.siteLocks === "object") ? { ...raw.siteLocks } : {};
  const order = Array.isArray(raw && raw.siteLocksOrder) ? raw.siteLocksOrder.slice() : Object.keys(locks);
  const converted = [];
  const schema = Number.isInteger(raw && raw.schema) ? raw.schema : 1;
  if (schema >= FIRST_SCHEMA_WITHOUT_LEGACY_LOCKS) return { raw, converted };
  for (const host of hosts) {
    const suffix = SHARED_HOSTING_SUFFIXES.find((s) => host.endsWith("." + s));
    if (!suffix || !Object.prototype.hasOwnProperty.call(locks, suffix)) continue;
    const tenant = registeredDomain(host);
    if (tenant === suffix || Object.prototype.hasOwnProperty.call(locks, tenant)) continue;   // already locked
    if (order.length >= SITE_LOCKS_CAP) break;                                                 // guard: lock cap
    locks[tenant] = locks[suffix];
    order.push(tenant);
    converted.push(tenant);
  }
  return converted.length ? { raw: { ...raw, siteLocks: locks, siteLocksOrder: order }, converted } : { raw, converted };
}

export async function convertStoredSuffixLocks() {
  try {
    const stored = (await chrome.storage.local.get(STORAGE_KEY_STATE))[STORAGE_KEY_STATE];
    if (!stored) return [];
    const hosts = new Set();
    for (const tab of await chrome.tabs.query({})) {
      const p = parseHttpUrl(tab.url || tab.pendingUrl || "");
      if (p) hosts.add(p.host);
    }
    const { raw, converted } = convertSuffixLocks(stored, hosts);
    if (converted.length) await chrome.storage.local.set({ [STORAGE_KEY_STATE]: raw });
    return converted;
  } catch (e) {
    console.warn(LOG_PREFIX, "legacy suffix lock conversion failed — the schema-4 migration drops them:", e);
    return [];
  }
}
