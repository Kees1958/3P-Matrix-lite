# Notice — 3P Matrix — content firewall (tools)

Copyright (C) 2026 Kees1958 and co-authors. Distributed under the GNU General Public License v3 — the licence
text is `LICENSE.txt` in the extension package (3P-Matrix-<version>-extension.zip); third-party components and their
licences are listed in `THIRD_PARTY_LICENSES.md` there.

This package is never shipped inside the extension. Its scripts need the development dependencies in
`package.json` (acorn, eslint, espree, eslint-scope: MIT; playwright: Apache-2.0), which are installed with
`npm ci` and not included in this package.
