// ── core/matrix-rules.js ──────────────────────────────────────────────────────
// State mutation for the interactive Matrix's per-domain, per-type overrides.
// Mirrors core/block-monitor.js's allowMonitorDomain() exactly in shape
// (mutate state, saveState, then applyStateFn to rebuild + push DNR rules,
// then callback) — same pattern, applied to a different piece of state.
//
// ── Redundant-override guard (fixes: LEVEL MODE / INTERNAL WHITELIST stuck ──
// grey after "reverting" a script/frame setting) ────────────────────────────
// The Matrix panel's script/frame cells are two independent buttons (Allow /
// Block), not a single toggle. Example bug this guard fixes: LEVEL MODE is
// green (script allowed by the level's own mechanism, no override). User
// clicks Block on script → an explicit override is stored, LEVEL MODE greys
// out (correct — something other than the level's mechanism now decides
// this). User clicks Allow on script again, expecting it to go back to
// "normal" → WITHOUT this guard, that stores a *second* explicit override
// ("allow" this time) rather than clearing the first one, so LEVEL MODE and
// INTERNAL WHITELIST stay grey forever even though script is back to its
// original, non-overridden behavior.
// The fix: before storing an "allow"/"block" action, compare it against
// wouldBlockDefault() — "what the level's own mechanism would do with no
// override at all". If the requested action matches that default, the
// override is redundant, so we clear it instead of storing it. This is the
// only place that decision is made, so every caller gets it automatically.
//
// Public interface:
//   setMatrixRule(domain, type, action, url, activeHost, state, applyStateFn, cb)
//     domain     — third-party eTLD+1 host
//     type       — "frame" | "script" (the only two overridable resource types)
//     action     — "allow" | "block" | null (null = clear/unselect, revert to
//                  the level's default disposition for that domain+type)
//     url        — sample request URL for this domain (needed by
//                  wouldBlockDefault()'s CDN check at level 4 — may be null,
//                  in which case the CDN check simply never matches)
//     activeHost — the 1P hostname the Matrix session is scoped to (for the
//                  per-site level pin lookup)
// ─────────────────────────────────────────────────────────────────────────────

import { saveState } from "../data/state-storage.js";
import { wouldBlockDefault } from "./rule-classifier.js";

// Deletes one type's override for a domain, and drops the domain's entry
// entirely once it holds no overrides at all — shared by every code path
// below that clears an override, so "no empty {} left behind" is guaranteed
// in exactly one place rather than re-implemented per caller.
function _clearOverride(domain, type, state) {
  if (!state.matrixRules || !state.matrixRules[domain]) return;
  delete state.matrixRules[domain][type];
  if (Object.keys(state.matrixRules[domain]).length === 0) {
    delete state.matrixRules[domain];
  }
}

export function setMatrixRule(domain, type, action, url, activeHost, state, applyStateFn, cb) {
  if (!domain || (type !== "frame" && type !== "script")) {
    if (cb) cb({ ok: false, error: "Invalid domain or type" });
    return;
  }
  if (action !== "allow" && action !== "block" && action !== null) {
    if (cb) cb({ ok: false, error: "Invalid action" });
    return;
  }

  if (!state.matrixRules) state.matrixRules = {};

  if (action === null) {
    // Clear/unselect — revert to the level's default disposition.
    _clearOverride(domain, type, state);
  } else {
    // Redundant-override guard — see header comment above.
    const wantsBlock     = action === "block";
    const defaultBlocked = wouldBlockDefault(domain, type, url, state, activeHost);
    if (wantsBlock === defaultBlocked) {
      _clearOverride(domain, type, state);
    } else {
      if (!state.matrixRules[domain]) state.matrixRules[domain] = {};
      state.matrixRules[domain][type] = action;
    }
  }

  saveState(state, function() {
    applyStateFn(state, function(count) {
      if (cb) cb({ ok: true, ruleCount: count });
    });
  });
}

// Sets/clears BOTH frame and script together, atomically (one state write,
// one rule rebuild). NOTE: no longer the UI's actual entry point — the panel
// now uses independent per-type setMatrixRule() calls for its split
// script/frame columns (see ui/matrix-panel.js). Kept as a lower-level
// primitive in case a single combined "Domain" control is ever reinstated.
// url/activeHost — same meaning as setMatrixRule()'s, required here too so
// this function gets the same redundant-override guard (see this file's
// header comment) rather than silently regressing if it's ever wired back
// up to the UI.
export function setMatrixDomainRule(domain, action, url, activeHost, state, applyStateFn, cb) {
  if (!domain) { if (cb) cb({ ok: false, error: "No domain" }); return; }
  if (action !== "allow" && action !== "block" && action !== null) {
    if (cb) cb({ ok: false, error: "Invalid action" });
    return;
  }

  if (!state.matrixRules) state.matrixRules = {};

  if (action === null) {
    delete state.matrixRules[domain];
  } else {
    // Redundant-override guard, applied per type — see header comment.
    // Only the type(s) that actually differ from the default get stored;
    // if BOTH types already match the default, no override is needed at
    // all and the domain entry is dropped entirely.
    const wantsBlock = action === "block";
    const next = {};
    ["frame", "script"].forEach(function(type) {
      const defaultBlocked = wouldBlockDefault(domain, type, url, state, activeHost);
      if (wantsBlock !== defaultBlocked) next[type] = action;
    });
    if (Object.keys(next).length === 0) {
      delete state.matrixRules[domain];
    } else {
      state.matrixRules[domain] = next;
    }
  }

  saveState(state, function() {
    applyStateFn(state, function(count) {
      if (cb) cb({ ok: true, ruleCount: count });
    });
  });
}
