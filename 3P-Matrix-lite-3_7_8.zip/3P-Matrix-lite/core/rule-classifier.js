// ── core/rule-classifier.js ───────────────────────────────────────────────────
// Shared request classifier — the single source of truth for "would our own
// DNR ruleset block this request, given the current state?"
//
// Extracted from core/block-monitor.js (v2.4.0) originally to be shared with
// core/connection-matrix.js (Show Matrix) as well — that sharing was reverted
// in v2.7.0 once Show Matrix's purpose was clarified as full-visibility
// traffic observation (blocked or not), not an allowed-only view filtered by
// this classifier. Show Matrix now only imports etldPlusOne() from this file
// for its own traffic-observation entries — but as of the Mode redesign
// (v3.2.0), background.js's MSG_GET_MATRIX_DATA handler also imports the
// individual mechanism-check helpers below directly, to compute WHICH
// specific mechanism governs each domain's Mode coloring. wouldBlock() itself
// is built FROM these same helpers, so both consumers can never drift into
// different opinions about the same domain.
// See CHANGELOG.md and the audit notes (C21) for the fuller history.
//
// Public interface:
//   etldPlusOne(url)                                    — eTLD+1 host extraction
//   getEffectiveLevel(state, activeHost)                — resolves per-site pin if any
//   isBuiltinWhitelisted(thirdPartyHost, state)          — boolean, ANY type (domain-level)
//   isBuiltinWhitelistedForType(thirdPartyHost, resourceType, state) — boolean, type-aware
//   isSignalDomain(thirdPartyHost)                      — boolean (commonly needed for "Login with X",
//                                                          never auto-allowed except at Level 2 — see wouldBlock())
//   isSignalDomainForType(thirdPartyHost, resourceType)  — boolean, type-aware (used by wouldBlock() at L2)
//   getBuiltinCategory(thirdPartyHost, state)            — string | null (tooltip "why" text, builtin OR signal)
//   isTldWhitelisted(thirdPartyHost, state)              — boolean (level-independent check;
//                                                          caller decides whether level 3 applies it)
//   isTldBlacklisted(thirdPartyHost, state)              — boolean (ditto, level 2)
//   isCdnMatch(url)                                      — boolean (ditto, level 4 + script-only)
//   wouldBlock(thirdPartyHost, resourceType, url, state, activeHost) — boolean
//   wouldBlockDefault(thirdPartyHost, resourceType, url, state, activeHost) — boolean
//                                                          (same as wouldBlock(), but deliberately
//                                                          IGNORES any Matrix override — "what would
//                                                          the level's own mechanism decide on its
//                                                          own". Used by core/matrix-rules.js to detect
//                                                          when a requested override has become
//                                                          redundant with the default — see that
//                                                          module's header comment.)
//
// Dependencies: data/constants.js (MULTI_PART_SUFFIXES, BUILTIN_DOMAINS, BUILTIN_DOMAIN_CATEGORY)
// ─────────────────────────────────────────────────────────────────────────────

import { MULTI_PART_SUFFIXES, BUILTIN_DOMAINS, SIGNAL_DOMAINS, BUILTIN_DOMAIN_CATEGORY } from "../data/constants.js";

// Extracts eTLD+1 from a full URL. Returns empty string on failure.
export function etldPlusOne(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    const labels   = hostname.split(".");
    if (labels.length <= 2) return hostname;
    // Handle common multi-part suffixes (co.uk, com.au, etc.)
    const last2 = labels.slice(-2).join(".");
    // MULTI_PART_SUFFIXES loaded from data/constants.js — single source of truth.
    if (MULTI_PART_SUFFIXES.indexOf(last2) !== -1 && labels.length >= 3) {
      return labels.slice(-3).join(".");
    }
    return last2;
  } catch(e) {
    return "";
  }
}

// Resolves the effective protection level — respects a per-site pin stored
// in state.siteRules, falling back to the global state.level.
export function getEffectiveLevel(state, activeHost) {
  if (!state) return 1;
  return (activeHost && state.siteRules && state.siteRules[activeHost])
    ? state.siteRules[activeHost]
    : (state.level || 1);
}

// Generic exact-match-priority lookup against any domain->flags map —
// shared by both BUILTIN_DOMAINS and SIGNAL_DOMAINS lookups below, since
// they need identical semantics: exact match always wins first, regardless
// of object key iteration order (a more specific subdomain's own narrower
// flags must never be silently overridden by a broader parent-domain entry
// that also happens to match via suffix — e.g. "js.hcaptcha.com" is
// script-only, but "hcaptcha.com" is frame-only; without this exact-match
// priority, whichever one iteration happened to reach first would
// arbitrarily win). Among multiple suffix matches, the longest (most
// specific) wins.
function _findEntryInMap(thirdPartyHost, map) {
  if (Object.prototype.hasOwnProperty.call(map, thirdPartyHost)) {
    return Object.assign({ key: thirdPartyHost }, map[thirdPartyHost]);
  }
  let bestKey = null;
  const keys = Object.keys(map);
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (thirdPartyHost.endsWith("." + key)) {
      if (!bestKey || key.length > bestKey.length) bestKey = key;
    }
  }
  return bestKey ? Object.assign({ key: bestKey }, map[bestKey]) : null;
}

// Finds the builtin entry matching this host. Falls back to the
// BUILTIN_DOMAINS constant if state's own copy is empty/missing (pre-seed case).
function _findBuiltinEntry(thirdPartyHost, state) {
  const builtins = (state && state.builtinDomains && Object.keys(state.builtinDomains).length)
    ? state.builtinDomains
    : (typeof BUILTIN_DOMAINS !== "undefined" ? BUILTIN_DOMAINS : {});
  return _findEntryInMap(thirdPartyHost, builtins);
}

// Finds the signal-list entry matching this host. Not user-editable state
// (unlike builtinDomains) — always reads the static SIGNAL_DOMAINS constant.
function _findSignalEntry(thirdPartyHost) {
  return _findEntryInMap(thirdPartyHost, typeof SIGNAL_DOMAINS !== "undefined" ? SIGNAL_DOMAINS : {});
}

// Builtin domain whitelist match (rules 2600–2999, levels 2–5) — domain
// level, ANY type. Used by getModeState() (a domain builtin-whitelisted for
// either type is enough to grey out Mode) and the INTERNAL WHITELIST
// column (which stays a single column, not split by type, per explicit
// decision — "don't split in the panel"). For the actual per-request
// allow/block decision, wouldBlock() uses isBuiltinWhitelistedForType()
// instead, which respects the specific script/frame flags per domain.
export function isBuiltinWhitelisted(thirdPartyHost, state) {
  return !!_findBuiltinEntry(thirdPartyHost, state);
}

// Type-aware builtin whitelist match — true only if this SPECIFIC resource
// type is flagged for this domain (most domains are script+frame both, but
// some are script-only or frame-only — see data/constants.js's
// BUILTIN_DOMAINS, hand-classified rather than assumed, to avoid silently
// allowing a type a domain was never verified to need).
export function isBuiltinWhitelistedForType(thirdPartyHost, resourceType, state) {
  const entry = _findBuiltinEntry(thirdPartyHost, state);
  if (!entry) return false;
  if (resourceType === "frame")  return !!entry.frame;
  if (resourceType === "script") return !!entry.script;
  return false; // no other resource type was ever covered by the builtin whitelist
}

// Signal-list match — domain level, ANY type. NEVER used for the actual
// allow/block decision (wouldBlock() never calls this — signal domains are
// deliberately not auto-allowed). Purely informational: powers the
// INTERNAL WHITELIST column's yellow state in Show Matrix, flagging that
// this domain is commonly needed for a "Login with X" flow, without
// silently whitelisting it. See data/constants.js's SIGNAL_DOMAINS header
// comment for the full rationale.
export function isSignalDomain(thirdPartyHost) {
  return !!_findSignalEntry(thirdPartyHost);
}

// Type-aware signal-list match — used by wouldBlock() at Level 2 only (see
// its decision-order comment). Same shape as isBuiltinWhitelistedForType().
export function isSignalDomainForType(thirdPartyHost, resourceType) {
  const entry = _findSignalEntry(thirdPartyHost);
  if (!entry) return false;
  if (resourceType === "frame")  return !!entry.frame;
  if (resourceType === "script") return !!entry.script;
  return false;
}

// Returns the human-readable category for a builtin-whitelisted OR
// signal-list domain (e.g. "Payment — core / international",
// "Identity / SSO — GitHub"), or null if neither. Purely informational —
// used only for the INTERNAL WHITELIST column's explanatory tooltip in Show
// Matrix ("why was this domain trusted/flagged"), never consulted for the
// actual allow/block decision. Checks builtin first (respects a user
// having removed the domain from their own state.builtinDomains), then
// falls back to the signal list.
export function getBuiltinCategory(thirdPartyHost, state) {
  const categories = typeof BUILTIN_DOMAIN_CATEGORY !== "undefined" ? BUILTIN_DOMAIN_CATEGORY : {};
  const builtinEntry = _findBuiltinEntry(thirdPartyHost, state);
  if (builtinEntry) return categories[builtinEntry.key] || null;
  const signalEntry = _findSignalEntry(thirdPartyHost);
  if (signalEntry) return categories[signalEntry.key] || null;
  return null;
}

// TLD whitelist match (rules 2400–2499) — the mechanism level 3 uses.
// Level-independent check; wouldBlock() only applies it when level===3.
export function isTldWhitelisted(thirdPartyHost, state) {
  const labels = thirdPartyHost.split(".");
  const tld    = labels[labels.length - 1];
  const tld2   = labels.length >= 2 ? labels.slice(-2).join(".") : tld;
  const tlds   = (state && state.tlds) || [];
  return tlds.indexOf(tld) !== -1 || tlds.indexOf(tld2) !== -1;
}

// TLD blacklist match (rules 3200+) — the mechanism level 2 uses to block
// scripts (frames are blocked unconditionally at L2 regardless of this).
// Level-independent check; wouldBlock() only applies it when level===2.
export function isTldBlacklisted(thirdPartyHost, state) {
  const labels = thirdPartyHost.split(".");
  const tld    = labels[labels.length - 1];
  const tld2   = labels.length >= 2 ? labels.slice(-2).join(".") : tld;
  const blocked = (state && state.blockedTlds) || [];
  return blocked.indexOf(tld) !== -1 || blocked.indexOf(tld2) !== -1;
}

// CDN allow match (rule 3000) — the mechanism level 4 uses to allow scripts
// (frames are blocked unconditionally at L4 regardless of this — see
// buildCdnAllowRules() in rule-builder.js, which is script-only).
// Checks the HOSTNAME only, not the full URL — an earlier version checked
// the whole URL, which meant "cdn" appearing anywhere in a request's path
// or query string (nothing to do with the domain itself) produced a false
// match. Plain JS URL parsing has no DNR/regex complexity limits to worry
// about, unlike the DNR-side version of this same check in rule-builder.js.
export function isCdnMatch(url) {
  if (!url) return false;
  try {
    return new URL(url).hostname.toLowerCase().indexOf("cdn") !== -1;
  } catch(e) {
    return false; // malformed URL — treat as no match, not a crash
  }
}

// Computes the interactive Matrix's per-domain Mode disposition — a single
// combined signal per domain now (not split into Allow/Block columns), and
// deliberately dropped the per-level color scheme entirely: Mode just shows
// whether the level's own mechanism would allow or block this domain, full
// stop, using the same fixed green/red/grey language as SCRIPT/FRAME.
//
//   "allow" — the level's own mechanism (TLD blacklist/whitelist, CDN match,
//             block-only at L5, or "always allow" at L1) would allow this domain
//   "block" — same mechanism would block it
//   overridden — true if EITHER a script or frame per-type override exists
//             for this domain, OR the domain is on the built-in whitelist —
//             either way, something other than the level's own TLD/CDN
//             mechanism is what's actually deciding this domain's fate, so
//             Mode greys out rather than showing a mechanism-based color
//             that wouldn't actually explain what's happening. Never true
//             at L1 — nothing is being overruled there, since L1's own
//             mechanism already is "always allow."
//   applicable — false only if `state` itself is missing (defensive
//             fallback); every real level, including L1, has a real answer.
//
// Deliberately does NOT consider built-in whitelist status — that has its
// own dedicated signal (the INTERNAL WHITELIST column).
//
//   L1 — always allow   L2 — TLD blacklist   L3 — TLD whitelist
//   L4 — CDN match       L5 — always block
//
// thirdPartyHost, url, state, activeHost — same meaning as wouldBlock()'s
// parameters; url is only actually used at level 4 (isCdnMatch).
export function getModeState(thirdPartyHost, url, state, activeHost) {
  if (!state) return { applicable: false, winnerSide: "block", overridden: false };
  const level = getEffectiveLevel(state, activeHost);

  // L1 genuinely always allows — that's a real, reportable answer (green),
  // not "nothing to report." Overrides are ignored at L1, matching
  // wouldBlock()'s L1 behavior elsewhere (nothing is blockable there at all).
  if (level === 1) return { applicable: true, winnerSide: "allow", overridden: false };

  let winnerSide;
  if (level === 2)      winnerSide = isTldBlacklisted(thirdPartyHost, state) ? "block" : "allow";
  else if (level === 3) winnerSide = isTldWhitelisted(thirdPartyHost, state) ? "allow" : "block";
  else if (level === 4) winnerSide = isCdnMatch(url) ? "allow" : "block";
  else                   winnerSide = "block"; // level 5

  const rule = state.matrixRules && state.matrixRules[thirdPartyHost];
  const hasTypeOverride = !!(rule && (rule.frame || rule.script));
  const isBuiltin = isBuiltinWhitelisted(thirdPartyHost, state);
  const overridden = hasTypeOverride || isBuiltin;

  return { applicable: true, winnerSide: winnerSide, overridden: overridden };
}
// Mirrors rule-builder.js rulesForLevel() exactly — same allow/block order,
// same conditions, referenced by rule ID where applicable. Built from the
// individually-exported mechanism checks above, so this decision and Mode's
// per-domain coloring (background.js) can never drift into different
// opinions about the same domain.
// Returns true if we would block, false if we would allow.
//
// thirdPartyHost — eTLD+1 of the request URL (from etldPlusOne())
// resourceType   — "frame" | "script" (normalise sub_frame -> "frame" before calling)
// url            — full request URL (needed for the CDN substring check)
// state          — extension state snapshot (level, siteRules, domains, tlds, builtinDomains, matrixRules)
// activeHost     — the 1P hostname the session/matrix is scoped to (for the site-rules lookup)
//
// Decision order (highest DNR priority wins, mirrored here top-to-bottom):
//   1. Level 1            → allow all                          (no rules at L1)
//   2. Matrix override    → allow/block (per state.matrixRules) (prio 1000/2000, L2–5 — see rule-builder.js's buildMatrixOverrideRules)
//   3. Builtin whitelist  → allow  (rules 2600–2999, prio 1000, L2–5)
//   3b. Signal list       → allow  (rules 2200–2399, prio 1000, LEVEL 2 ONLY — per explicit
//                                   design: Level 2 is the light-touch tier meant to minimize
//                                   breakage, so signal-list domains are auto-allowed there,
//                                   same as the builtin whitelist. At levels 3-5 the signal
//                                   list is purely informational — flagged yellow in Show
//                                   Matrix, never auto-allowed; the user enables by hand.)
//   3c. TLD blacklist     → block  (rules 3200–3299, prio 15,   LEVEL 2 ONLY, scripts only —
//                                   previously only reflected in getModeState()'s L2 coloring,
//                                   never actually in this decision cascade; fixed here)
//   4. TLD whitelist      → allow  (rules 2400–2499, prio 1000, L3 only)
//   5. CDN allow          → allow  (rule  3000,      prio 1000, L4 scripts only)
//   6. Block 3P frames    → block  (rule  3001,      prio 20,   L2–5 sub_frame)
//   7. Block 3P scripts   → block  (rule  3002,      prio 20,   L3–5 script)
//   8. Implicit allow     → allow  (nothing matched — not our block)
// Steps 3–8 of the decision cascade documented above — everything AFTER the
// Level-1 short-circuit (step 1) and the Matrix override check (step 2).
// Factored out as the single source of truth for "what would the level's
// own TLD/CDN/whitelist mechanism decide, on its own" — consumed by BOTH
// wouldBlock() (step 2 included below — the real, effective decision) and
// wouldBlockDefault() (step 2 skipped on purpose — the default a Matrix
// override gets compared against). Neither caller duplicates this cascade,
// so they can never drift into different opinions about the same domain.
function _cascadeFromStep3(thirdPartyHost, resourceType, url, state, level) {
  // ── 3. Builtin domain whitelist (rules 2600–2999, levels 2–5) ────────────
  // Type-aware — a domain builtin-whitelisted for script only must still
  // have its frame blocked by the rules below, and vice versa.
  if (isBuiltinWhitelistedForType(thirdPartyHost, resourceType, state)) return false;

  // ── 3b. Signal list, LEVEL 2 ONLY (rules 2200–2399) ───────────────────────
  if (level === 2 && isSignalDomainForType(thirdPartyHost, resourceType)) return false;

  // ── 3c. TLD blacklist, LEVEL 2 ONLY, scripts only (rules 3200–3299) ──────
  if (level === 2 && resourceType === "script" && isTldBlacklisted(thirdPartyHost, state)) return true;

  // ── 4. TLD whitelist (rules 2400–2499, level 3 only) ─────────────────────
  if (level === 3 && isTldWhitelisted(thirdPartyHost, state)) return false;

  // ── 5. CDN allow (rule 3000, level 4 only, scripts only) ─────────────────
  if (level === 4 && resourceType === "script" && isCdnMatch(url)) return false;

  // ── 6. Block 3P frames (rule 3001, levels 2–5) ───────────────────────────
  if (resourceType === "frame") return true;

  // ── 7. Block 3P scripts (rule 3002, levels 3–5) ──────────────────────────
  if (resourceType === "script" && level >= 3) return true;

  // ── 8. Implicit allow — not blocked by our ruleset ───────────────────────
  return false;
}

export function wouldBlock(thirdPartyHost, resourceType, url, state, activeHost) {
  if (!state) return true; // no state — assume block

  const level = getEffectiveLevel(state, activeHost);

  // ── 1. Level 1 — no rules, allow everything ───────────────────────────────
  if (level === 1) return false;

  // ── 2. Matrix override — always wins over everything below, per the ──────
  // interactive Matrix feature's design ("Domain rules always overwrite MODE
  // rules"). Checked here so Show blocks and the Matrix's own cell coloring
  // both reflect the exact same effective disposition — one classifier,
  // never two independently-drifting opinions about the same request.
  if (state.matrixRules && state.matrixRules[thirdPartyHost]) {
    const override = state.matrixRules[thirdPartyHost][resourceType];
    if (override === "block") return true;
    if (override === "allow") return false;
  }

  return _cascadeFromStep3(thirdPartyHost, resourceType, url, state, level);
}

// Same decision as wouldBlock(), but step 2 (the Matrix override) is
// deliberately skipped — "what would this domain's disposition be if no
// override existed at all". NOT used for the real allow/block decision
// (that stays wouldBlock()'s job) — only used by core/matrix-rules.js to
// detect when a user-requested override would just reproduce the default,
// so it can be cleared instead of stored (see that module's header comment
// and the v3.7.5 CHANGELOG entry for the bug this fixes).
export function wouldBlockDefault(thirdPartyHost, resourceType, url, state, activeHost) {
  if (!state) return true; // no state — assume block, matches wouldBlock()
  const level = getEffectiveLevel(state, activeHost);
  if (level === 1) return false;
  return _cascadeFromStep3(thirdPartyHost, resourceType, url, state, level);
}
