// ── data/active-threat-hosts.js ───────────────────────────────────────────────
// Hosts seen RIGHT NOW (live threat-intel, not a generic "open platform" rule)
// serving malware — but ONLY when the URL also looks like the actual delivery
// pattern of that campaign, not for ordinary use of the same host.
//
// 2026-10-28: GitHub's raw-content, release-asset and codeload CDNs are being
// used to distribute SmartLoader payloads inside .zip files hosted in
// throwaway/disposable repos (observed via urlhaus.abuse.ch/browse — repos
// such as Danisxxx/*, atkntmll/*, Chitra0307/*, iLuiz07/*, DuyTran1503/*
// serving a fresh zip every few seconds). These same hosts are also the
// everyday way countless legitimate pages load a raw .js/.css/.json/.md
// file — a host-only match would warn on that ordinary traffic too, so the
// "GitHub raw/release" entry below is only one half of the rule: it fires
// only when the request ALSO ends in an archive/executable extension
// (RISKY_DELIVERY_EXT_RE), i.e. something actually being downloaded and run,
// not a source/content file being read by a page. See core/site-scorer.js
// matchesActiveThreat() for how the two halves combine.
//
// Deliberately kept OUT of the shared lib/downloadsentinel/ library
// (RiskyHostingSites, CombinationScoring's FAMILY_MAP, …): those files are
// reused unchanged from DownloadSentinel (see core/site-scorer.js's header).
// This list is a short-lived, 3P-Matrix-only addition for hosts/patterns
// currently seeing real abuse — review and prune periodically, it is not a
// permanent blocklist. An entry whose campaign has died down should be
// removed, extension requirement and all.
//
// githubassets.com (the GitHub UI's own static-asset CDN) is NOT included —
// unrelated host, already built-in trusted (script only, 4.4.7).
// ─────────────────────────────────────────────────────────────────────────────

// Hosts currently part of an active campaign (exact match, lowercase).
export const ACTIVE_THREAT_HOSTS = Object.freeze([
  "raw.githubusercontent.com",
  "release-assets.githubusercontent.com",
  "codeload.github.com",
  "objects.githubusercontent.com",
  "media.githubusercontent.com"
]);

// Archive/executable extensions — the actual delivery vehicle for a payload,
// as opposed to a source/content file (.js, .css, .json, .md, .png, …) the
// same hosts serve constantly and harmlessly. Case-insensitive, end of path.
export const RISKY_DELIVERY_EXT_RE = /\.(zip|rar|7z|tar|tgz|gz|exe|msi|bat|cmd|scr|jar|apk|dmg|pkg|iso|ps1|vbs)$/i;
