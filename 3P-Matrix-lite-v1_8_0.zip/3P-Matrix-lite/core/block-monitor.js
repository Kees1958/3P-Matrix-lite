// ── core/block-monitor.js ─────────────────────────────────────────────────────
// Live third-party block monitor.
// Owns the webRequest listener, FIFO entry array, session object,
// timers, all stop conditions, and the watchdog.
//
// Public interface:
//   startMonitor(tabId, host, cb)     — start a new session (kills any existing one first)
//   stopMonitor(reason)               — full cleanup, notifies panel
//   pauseMonitor()                    — removeListener, freeze array, accumulate elapsed
//   resumeMonitor(tabId, cb)          — re-register listener, reload tab
//   getMonitorData()                  — returns { session, entries } snapshot
//   allowMonitorDomain(domain, state, cb) — add domain to state whitelist, save + apply
//   startWatchdog()                   — call once on SW boot; kills orphan sessions
//
// Dependencies (must be loaded before this file):
//   data/message-types.js — MSG_MONITOR_CLOSED
//   data/state-storage.js — saveState()
//   core/rule-builder.js  — buildRules() (via applyState in background.js)
//
// State owned by this module (all in-memory, lost on SW restart — safe because
// the webRequest listener is also lost on SW restart, so no orphan is possible):
//   activeSession  {object|null}  — see SESSION shape below
//   monitorEntries {Array}        — FIFO array, max MONITOR_CAP entries
//   _sessionTimer  {TimeoutID}    — 5-minute force-close timer
//   _watchdogTimer {IntervalID}   — orphan-session watchdog
//
// SESSION shape:
//   { tabId, host, startTime, paused, timeElapsed }
//   tabId       — tab that owns the session
//   host        — 1P hostname (fixed for the life of the session)
//   startTime   — Date.now() when onCommitted fired (set externally via markMonitorStarted)
//   paused      — boolean
//   timeElapsed — ms of active listening accumulated before pauses
// ─────────────────────────────────────────────────────────────────────────────

var MONITOR_CAP      = 100;          // max FIFO entries
var MONITOR_DURATION = 5 * 60 * 1000; // 5 minutes in ms
var WATCHDOG_INTERVAL = 5 * 60 * 1000; // watchdog checks every 5 minutes

var activeSession  = null;
var monitorEntries = [];
var _sessionTimer  = null;
var _watchdogTimer = null;

// ── Internal helpers ──────────────────────────────────────────────────────────

// Formats elapsed ms as "+m:ss"
function _formatElapsed(ms) {
  var total = Math.floor(ms / 1000);
  var m = Math.floor(total / 60);
  var s = total % 60;
  return "+" + m + ":" + (s < 10 ? "0" : "") + s;
}

// Extracts eTLD+1 from a full URL. Returns empty string on failure.
function _etldPlusOne(url) {
  try {
    var hostname = new URL(url).hostname.toLowerCase();
    var labels   = hostname.split(".");
    if (labels.length <= 2) return hostname;
    // Handle common multi-part suffixes (co.uk, com.au, etc.)
    var last2 = labels.slice(-2).join(".");
    var MULTI = [
      "co.uk","org.uk","ac.uk","gov.uk","co.jp","co.kr","co.nz","co.za",
      "com.au","net.au","org.au","com.br","com.cn","com.mx","com.tr",
      "co.in","co.id","com.sg"
    ];
    if (MULTI.indexOf(last2) !== -1 && labels.length >= 3) {
      return labels.slice(-3).join(".");
    }
    return last2;
  } catch(e) {
    return "";
  }
}

// Sends MSG_MONITOR_CLOSED to the monitor panel (fire-and-forget).
function _notifyPanel(reason) {
  try {
    chrome.runtime.sendMessage({ type: MSG_MONITOR_CLOSED, reason: reason }, function() {
      // Ignore errors — panel may already be closed
      if (chrome.runtime.lastError) {}
    });
  } catch(e) {}
}

// Core cleanup — called by every stop path.
function _cleanup(reason) {
  // Remove webRequest listener if registered
  if (_monitorListener) {
    try {
      chrome.webRequest.onBeforeRequest.removeListener(_monitorListener);
    } catch(e) {}
  }
  // Cancel timers
  if (_sessionTimer)  { clearTimeout(_sessionTimer);  _sessionTimer  = null; }
  // Reset state
  activeSession  = null;
  monitorEntries = [];
  // Notify panel
  if (reason) _notifyPanel(reason);
}

// The webRequest listener function — kept as a named reference so removeListener works.
function _monitorListener(details) {
  if (!activeSession)                           return;
  if (details.tabId !== activeSession.tabId)    return;
  if (activeSession.paused)                     return;

  var thirdPartyHost = _etldPlusOne(details.url);
  if (!thirdPartyHost)                          return;

  // Skip if same site as the 1P host
  var firstPartyApex = _etldPlusOne("https://" + activeSession.host);
  if (thirdPartyHost === firstPartyApex)        return;

  var elapsed = _formatElapsed(
    activeSession.timeElapsed + (Date.now() - activeSession.startTime)
  );

  var entry = {
    host:    thirdPartyHost,
    type:    details.type === "sub_frame" ? "frame" : "script",
    elapsed: elapsed
  };

  // FIFO: drop oldest if at cap
  if (monitorEntries.length >= MONITOR_CAP) monitorEntries.shift();
  monitorEntries.push(entry);
}

// ── Public interface ──────────────────────────────────────────────────────────

// Starts a new monitor session. Kills any existing session first.
// tabId: the tab to monitor. host: the 1P hostname. cb: called when ready.
function startMonitor(tabId, host, cb) {
  // Kill existing session before starting a new one
  if (activeSession) _cleanup("new_session");

  activeSession = {
    tabId:       tabId,
    host:        host,
    startTime:   Date.now(), // overwritten by markMonitorStarted() after page reload
    paused:      false,
    timeElapsed: 0
  };
  monitorEntries = [];

  // Register webRequest listener scoped to scripts and frames only
  chrome.webRequest.onBeforeRequest.addListener(
    _monitorListener,
    { urls: ["<all_urls>"], types: ["script", "sub_frame"] }
  );

  // Reload the tab — onCommitted will call markMonitorStarted()
  chrome.tabs.reload(tabId, {}, function() {
    if (cb) cb({ ok: true });
  });
}

// Called by background.js onCommitted handler when the monitored tab finishes
// navigating. This is the true start of the 5-minute session clock.
function markMonitorStarted(tabId) {
  if (!activeSession || activeSession.tabId !== tabId) return;
  activeSession.startTime   = Date.now();
  activeSession.timeElapsed = 0;

  // Start 5-minute force-close timer
  if (_sessionTimer) clearTimeout(_sessionTimer);
  _sessionTimer = setTimeout(function() {
    _cleanup("timeout");
  }, MONITOR_DURATION);
}

// Full cleanup — called on EXIT button, popup close, or level drop below 4.
function stopMonitor(reason) {
  _cleanup(reason || "stopped");
}

// Pauses the listener. Accumulates elapsed time. Timer keeps running.
function pauseMonitor() {
  if (!activeSession || activeSession.paused) return;
  try {
    chrome.webRequest.onBeforeRequest.removeListener(_monitorListener);
  } catch(e) {}
  // Accumulate elapsed active time before pausing
  activeSession.timeElapsed += Date.now() - activeSession.startTime;
  activeSession.paused = true;
}

// Resumes: applies whitelist changes (caller must do that), clears array,
// re-registers listener, reloads tab. Timer is NOT reset.
function resumeMonitor(tabId, cb) {
  if (!activeSession) { if (cb) cb({ ok: false, error: "No active session" }); return; }

  // Clear the entry array for a fresh start
  monitorEntries = [];

  // Re-register the listener
  try {
    chrome.webRequest.onBeforeRequest.addListener(
      _monitorListener,
      { urls: ["<all_urls>"], types: ["script", "sub_frame"] }
    );
  } catch(e) {}

  activeSession.paused = false;
  // Reset startTime reference — timeElapsed already accumulated
  activeSession.startTime = Date.now();

  // Reload the tab
  chrome.tabs.reload(tabId, {}, function() {
    if (cb) cb({ ok: true });
  });
}

// Returns a snapshot of the current session metadata and entry array.
function getMonitorData() {
  if (!activeSession) return { session: null, entries: [] };
  var elapsed = activeSession.paused
    ? activeSession.timeElapsed
    : activeSession.timeElapsed + (Date.now() - activeSession.startTime);
  return {
    session: {
      tabId:       activeSession.tabId,
      host:        activeSession.host,
      paused:      activeSession.paused,
      elapsed:     elapsed,
      remaining:   Math.max(0, MONITOR_DURATION - elapsed)
    },
    entries: monitorEntries.slice() // defensive copy
  };
}

// Adds a domain to the state domain whitelist, saves and applies rules.
// Called when the user presses Allow in the paused panel.
function allowMonitorDomain(domain, state, applyStateFn, cb) {
  if (!domain) { if (cb) cb({ ok: false, error: "No domain" }); return; }
  if (!state.domains) state.domains = [];
  if (state.domains.indexOf(domain) === -1) {
    state.domains.push(domain);
  }
  saveState(state, function() {
    applyStateFn(state, function(count) {
      if (cb) cb({ ok: true, ruleCount: count });
    });
  });
}

// Watchdog: call once on SW boot. Kills any orphan session older than 5 minutes.
// In practice the 5-minute session timer handles cleanup; this is the fallback.
function startWatchdog() {
  if (_watchdogTimer) clearInterval(_watchdogTimer);
  _watchdogTimer = setInterval(function() {
    if (!activeSession) return;
    var elapsed = activeSession.timeElapsed + (Date.now() - activeSession.startTime);
    if (elapsed > MONITOR_DURATION) {
      _cleanup("timeout");
    }
  }, WATCHDOG_INTERVAL);
}
