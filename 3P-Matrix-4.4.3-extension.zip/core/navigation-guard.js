// ── core/navigation-guard.js ──────────────────────────────────────────────────
// First-party site check on every top-level navigation — protection 11 (num 10 until 4.3.1)
// "Warn when opening suspicious sites" (PROTECTION_KEY.WARN_SUSPICIOUS_SITES).
// Timing (4.2.3): onBeforeNavigate cannot hold a navigation — the tab is redirected to the warning
// page as fast as possible, but the first request to the site may already have been sent. The user
// is always warned before using the page; "when", not "before", is the honest promise.
// Active when the site's effective level ≥ its fromLevel (2) AND the user has not
// unticked it in the popup. Inactive → nothing is scored, no dialog, neutral badge.
// Stage 1 (local, ~0.4 ms) runs here. 4.4.1: the dialog opens when site-scorer dialogDecision() says so —
// score at or below SITE_DIALOG_FROM[the site's level], or a site exception (known bad, impersonation);
// the dialog page then asks for stage 2. A suspicious score below the line gets the orange badge only.
//
// Public interface:
//   checkNavigation(details, state) — webNavigation.onBeforeNavigate handler body
//   allowOnce(tabId, site)          — "Continue once": skip the check for this tab + site
//   releaseTab(tabId)               — tab closed: drop its one-time allowances
//   warningUrlFor(url)              — extension URL of the warning dialog for `url`
//
// Skipped (never scored): non-http(s), private/local hosts, the built-in
// whitelist, sites where protection 11 is not active (level 1 / allow list,
// or unticked), and sites allowed once in this tab.
// ─────────────────────────────────────────────────────────────────────────────

import { SEVERITY, WARNING_PAGE, WARNING_TARGET_PARAM, LOG_PREFIX } from "../data/constants.js";
import { BUILTIN_ALL } from "../data/builtin-domains.js";
import { PROTECTION_KEY } from "../data/protections.js";
import { effectiveLevel, isProtectionActive } from "./policy.js";
import { scoreLocal, dialogDecision } from "./site-scorer.js";
import { setRisk } from "./badge.js";
import { parseHttpUrl, registeredDomain, isInDomainList } from "../util/domain.js";

// tabId → Set<site> allowed once ("Continue once"). Bounded by open tabs.
const _allowedOnce = new Map();

export function allowOnce(tabId, site) {
  if (!_allowedOnce.has(tabId)) _allowedOnce.set(tabId, new Set());
  _allowedOnce.get(tabId).add(site);
}

export function releaseTab(tabId) { _allowedOnce.delete(tabId); }

export function warningUrlFor(url) {
  return `${chrome.runtime.getURL(WARNING_PAGE)}?${WARNING_TARGET_PARAM}=${encodeURIComponent(url)}`;
}

export function checkNavigation(details, state) {
  if (details.frameId !== 0 || details.tabId < 0) return;
  const p = parseHttpUrl(details.url);
  if (!p) return;
  const site = registeredDomain(p.host);

  const level = effectiveLevel(state, p.host);
  if (!isProtectionActive(state, PROTECTION_KEY.WARN_SUSPICIOUS_SITES, level)) {
    setRisk(details.tabId, site, SEVERITY.NONE);               // level 1 / allow list / unticked
    return;
  }
  if (isInDomainList(p.host, BUILTIN_ALL)) { setRisk(details.tabId, site, SEVERITY.NONE); return; }
  const once = _allowedOnce.get(details.tabId);
  if (once && once.has(site)) return;                          // keep the risk colour, no dialog

  const local = scoreLocal(details.url);
  if (!local) { setRisk(details.tabId, site, SEVERITY.NONE); return; }
  setRisk(details.tabId, site, local.severity);                // badge colour: severity, whatever the dialog decision
  if (!dialogDecision(local, level).warn) return;               // 4.4.1: staged by level, exceptions always open it

  // Not silent: a failed redirect means the user was NOT warned (tab closed meanwhile is the usual cause).
  chrome.tabs.update(details.tabId, { url: warningUrlFor(details.url) }).catch((e) => console.warn(LOG_PREFIX, "warning redirect failed:", e));
}
