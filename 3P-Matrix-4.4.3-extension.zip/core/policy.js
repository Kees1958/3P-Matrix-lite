// ── core/policy.js ────────────────────────────────────────────────────────────
// Pure policy resolution — answers "which level applies where, and which
// protections are active at that level". No Chrome API calls, no side effects.
//
// Public interface:
//   effectiveLevel(state, host)         — lock level of the host's registered domain, else state.level
//   lockedLevelOf(state, host)          — lock level or null
//   isProtectionEnabled(state, key)     — user has not unticked it
//   isProtectionActive(state, key, lvl) — enabled AND lvl >= its fromLevel
//   ruleGroups(state)                   — the rule groups the builders iterate over:
//        [{ index: 0, level: state.level, kind: "global", sites: [all locked sites] },
//         { index: L, level: L,           kind: "locked", sites: [sites locked at L] }, ...]
//     Global rules EXCLUDE every locked site; each locked group INCLUDES only its sites.
//     One group per level (not per site) keeps the rule count independent of the
//     number of locks.
//   protectionCounts(state, level)      — { active, total } for the popup
//   saferRegionsApply(level)            — does the safer-regions list have any effect at this level?
// ─────────────────────────────────────────────────────────────────────────────

import { LEVEL_MIN, LEVEL_MAX, SAFER_REGIONS_LEVELS, LOG_PREFIX } from "../data/constants.js";
import { PROTECTIONS, PROTECTION_BY_KEY } from "../data/protections.js";
import { registeredDomain } from "../util/domain.js";

export const GROUP_KIND = Object.freeze({ GLOBAL: "global", LOCKED: "locked" });

export function lockedLevelOf(state, host) {
  if (!host) return null;
  const site = registeredDomain(host);
  return Object.prototype.hasOwnProperty.call(state.siteLocks, site) ? state.siteLocks[site] : null;
}

export function effectiveLevel(state, host) {
  const locked = lockedLevelOf(state, host);
  return locked === null ? state.level : locked;
}

export function isProtectionEnabled(state, key) {
  return state.disabledProtections[key] !== true;
}

export function saferRegionsApply(level) {
  return SAFER_REGIONS_LEVELS.includes(level);
}

export function isProtectionActive(state, key, level) {
  const p = PROTECTION_BY_KEY[key];
  // Guard (4.2.3, audit finding 8): an unknown key is a coding error — say so loudly instead of
  // silently treating the protection as off. tools/check-protection-keys.mjs catches it statically.
  if (!p) { console.error(LOG_PREFIX, "unknown protection key:", key); return false; }
  return isProtectionEnabled(state, key) && level >= p.fromLevel;
}

export function ruleGroups(state) {
  const allLocked = state.siteLocksOrder.slice();
  const groups = [{ index: 0, level: state.level, kind: GROUP_KIND.GLOBAL, sites: allLocked }];
  for (let lvl = LEVEL_MIN; lvl <= LEVEL_MAX; lvl++) {
    const sites = allLocked.filter((s) => state.siteLocks[s] === lvl);
    if (sites.length) groups.push({ index: lvl, level: lvl, kind: GROUP_KIND.LOCKED, sites });
  }
  return groups;
}

export function protectionCounts(state, level) {
  const applicable = PROTECTIONS.filter((p) => level >= p.fromLevel);
  const active = applicable.filter((p) => isProtectionEnabled(state, p.key)).length;
  return { active, total: applicable.length };
}
