// ── core/script-builder.js ────────────────────────────────────────────────────
// Pure computation of content-script registrations for every SCRIPT protection.
// No Chrome API calls.
//
// Public interface:
//   buildScriptRegistrations(state) — RegisteredContentScript[] for chrome.scripting
//
// For each protection with scripts, where does it run?
//   active globally (state.level >= fromLevel, enabled):
//       matches  = <all_urls>  (or its fixed host list)
//       excludes = sites locked BELOW fromLevel
//                + safer regions, when scoped outside them AND the global level is 3
//                + the built-in whitelist (data/builtin-domains.js), when scoped outside
//                  safer regions AND the global level is 3 or 4 — 0.2.4, matches the built-in
//                  whitelist's own 3P-content exemption (never at level 5); a first-party visit
//                  to a trusted host is exempt here too, not just its third-party embeds
//                + locked sites that sit in safer regions at a locked level 3
//       plus a second registration (id suffix SCRIPT_ID_SUFFIX.SAFER_LOCKED) for sites locked at
//       level 4–5 that the global level-3 safer-regions exclude would otherwise skip
//   not active globally:
//       matches  = sites locked AT/ABOVE fromLevel (intersected with a fixed host list),
//                  minus sites in safer regions locked at level 3, minus built-in-whitelist
//                  sites locked at level 3 or 4
// 4.2: the same built-in exemption also applies to an EVERY_SITE protection that names its own
// trustedExempt host list (protection 1: payment hosts), at the same levels (3–4, never 2 or 5).
// Safer regions only count at SAFER_REGIONS_LEVELS (level 3); levels 4–5 run every
// protection on every site except the built-in whitelist (3, 4 only). Every script: MAIN
// world, all frames, document_start, persisted across sessions.
// ─────────────────────────────────────────────────────────────────────────────

import { SCRIPT_ID_PREFIX, SCRIPT_ID_SUFFIX, BUILTIN_EXEMPT_LEVELS } from "../data/constants.js";
import { PROTECTIONS, SCOPE } from "../data/protections.js";
import { isProtectionEnabled, saferRegionsApply } from "./policy.js";
import { hostMatchPattern, tldMatchPattern, isInDomainList } from "../util/domain.js";
import { BUILTIN_ALL } from "../data/builtin-domains.js";

const ALL_URLS = "<all_urls>";
function builtinExemptAt(level) { return BUILTIN_EXEMPT_LEVELS.includes(level); }

// Host list exempt from protection p on a first-party visit (at BUILTIN_EXEMPT_LEVELS), or null.
//   OUTSIDE_SAFER_REGIONS protections → the whole built-in whitelist (0.2.4)
//   EVERY_SITE protection with trustedExempt → that list (4.2: protection 1 → payment hosts)
function trustedHostsFor(p) {
  if (p.scope === SCOPE.OUTSIDE_SAFER_REGIONS) return BUILTIN_ALL;
  return p.trustedExempt && p.trustedExempt.length ? p.trustedExempt : null;
}

function baseRegistration(id, p, matches, excludeMatches) {
  const reg = {
    id,
    js: [...p.scripts],
    matches,
    allFrames: true,
    runAt: "document_start",
    world: "MAIN",
    persistAcrossSessions: true
  };
  if (excludeMatches.length) reg.excludeMatches = [...new Set(excludeMatches)];
  return reg;
}

function registrationsFor(state, p) {
  if (!p.scripts || !p.scripts.length || !isProtectionEnabled(state, p.key)) return [];

  const scoped = p.scope === SCOPE.OUTSIDE_SAFER_REGIONS;
  const saferTlds = state.safeZone.tlds;
  function inSafer(site) { return scoped && isInDomainList(site, saferTlds); }
  const trustedHosts = trustedHostsFor(p);
  function inBuiltin(site) { return !!trustedHosts && isInDomainList(site, trustedHosts); }
  const locks = state.siteLocksOrder.map((site) => ({ site, level: state.siteLocks[site] }));
  const fixedHosts = p.matchHosts ? [...p.matchHosts] : null;
  function allowedHost(site) { return !fixedHosts || fixedHosts.includes(site); }
  const extraExcludes = p.extraExcludes ? [...p.extraExcludes] : [];
  const id = SCRIPT_ID_PREFIX + p.key;

  // Locked sites where this protection runs: level high enough, not exempt by safer regions
  // or by the built-in whitelist (checked at the SITE'S OWN locked level, same as safer regions).
  function runsOnLock({ site, level }) {
    return level >= p.fromLevel && !(saferRegionsApply(level) && inSafer(site)) && !(builtinExemptAt(level) && inBuiltin(site));
  }

  if (state.level < p.fromLevel) {
    const hosts = locks.filter(runsOnLock).map((l) => l.site).filter(allowedHost);
    return hosts.length ? [baseRegistration(id, p, hosts.map(hostMatchPattern), extraExcludes)] : [];
  }

  const globalSaferExclude = scoped && saferRegionsApply(state.level);
  const globalBuiltinExclude = !!trustedHosts && builtinExemptAt(state.level);
  const excludeSites = locks.filter((l) => !runsOnLock(l)).map((l) => l.site);
  const excludes = [
    ...excludeSites.map(hostMatchPattern),
    ...(globalSaferExclude ? saferTlds.map(tldMatchPattern) : []),
    ...(globalBuiltinExclude ? trustedHosts.map(hostMatchPattern) : []),
    ...extraExcludes
  ];
  const matches = fixedHosts ? fixedHosts.map(hostMatchPattern) : [ALL_URLS];
  const regs = [baseRegistration(id, p, matches, excludes)];

  const rescuedSites = new Set();                 // guard: a site gets at most ONE rescue registration
  if (globalSaferExclude) {
    // Locks at levels without safer regions (4–5) that the TLD exclude above skipped.
    const rescued = locks.filter((l) => runsOnLock(l) && inSafer(l.site)).map((l) => l.site).filter(allowedHost);
    rescued.forEach((s) => rescuedSites.add(s));
    if (rescued.length) regs.push(baseRegistration(id + SCRIPT_ID_SUFFIX.SAFER_LOCKED, p, rescued.map(hostMatchPattern), extraExcludes));
  }
  if (globalBuiltinExclude) {
    // A built-in-whitelist site locked at level 5 (STRICT): the lock is a deliberate choice for
    // maximum protection there, so the built-in exemption does NOT apply (runsOnLock already
    // reflects that) — but the blanket trusted-host exclude above would still hide it, so rescue it.
    // 4.2.3 (audit finding 12): a site already rescued above (in safer regions AND built-in) is
    // skipped here, so its script is never injected twice.
    const builtinRescued = locks.filter((l) => runsOnLock(l) && inBuiltin(l.site) && !rescuedSites.has(l.site))
      .map((l) => l.site).filter(allowedHost);
    if (builtinRescued.length) regs.push(baseRegistration(id + SCRIPT_ID_SUFFIX.BUILTIN_LOCKED, p, builtinRescued.map(hostMatchPattern), extraExcludes));
  }
  return regs;
}

export function buildScriptRegistrations(state) {
  return PROTECTIONS.flatMap((p) => registrationsFor(state, p));
}
