# 3P-Matrix-lite — Changelog

---

## 2.1.2 — 2026-07-15
**Code quality — no behaviour changes**

*Duplicated constants removed*
- `EU_LANGS` was defined in three places (`util/tld-utils.js`, `core/tld-engine.js`, and implicitly via `tld-utils.js`). Moved to `data/constants.js` as the single source of truth. `util/tld-utils.js` and `core/tld-engine.js` now reference it from there.
- `MULTI_PART_SUFFIXES` was defined twice verbatim (in `core/block-monitor.js` as an inline local `MULTI` array, and in `ui/popup.js`). Moved to `data/constants.js`. Both files now reference the shared constant.
- `LEVEL_COLORS` in `ui/popup.js` duplicated the colour values already stored in `LEVELS[].color`. Removed `LEVEL_COLORS`; the one call site now uses `LEVELS[pinnedLevel - 1].color` directly.

*DEFAULT_STATE divergence fixed*
- `ui/popup.js` and `data/state-storage.js` each held a copy of `DEFAULT_STATE` that had diverged: `state-storage.js` had `showBlockedCount` that `popup.js` was missing; `popup.js` had `blockedTldDropdownOpen` that `state-storage.js` was missing. Both copies are now fully in sync. A warning comment has been added to `popup.js` requiring any future key addition to be mirrored in both files.

*Storage key constants*
- The raw string literals `"monitorHideWarning"`, `"sessionLevel"` and `"prevSessionLevel"` were scattered as repeated raw strings across `ui/popup.js` and `ui/monitor-panel.js`. Named constants `LOCAL_KEY_HIDE_WARNING`, `SESSION_KEY_LEVEL` and `SESSION_KEY_PREV_LEVEL` are now declared in `data/state-storage.js` and used everywhere.

*Double message send fixed*
- The Import Allow save handler in `ui/popup.js` was firing `MSG_SET_STATE` twice for the same state object (once with a callback, once fire-and-forget). The redundant second send has been removed.

*Silent catch blocks documented*
- All `catch(e) {}` blocks in `background.js`, `core/block-monitor.js` and `ui/monitor-panel.js` now carry an explanatory comment confirming they are intentional and describing why the error is safely ignored.

*CSS tokens*
- `--radius: 6px` and `--radius-sm: 4px` added to `:root` in `ui/popup.html` to match `ui/monitor-panel.html`. Raw `6px` values in `popup.html` now have a matching variable (consumers will be migrated in a future pass).
- Dead CSS rule `.rule-text.dim` removed from `ui/popup.html` — it was identical to `.rule-text` and had no visual effect.

*Stale files removed*
- `logger.html` and `logger.js` removed from extension root — they were legacy artefacts unreferenced by the manifest or any other file.
- Root-level `popup.html` and `popup.js` removed — superseded by `ui/popup.html` and `ui/popup.js` since v2.0; the manifest correctly points to `ui/`.

*_seenDomains bound documented*
- Added a comment to `_seenDomains` in `core/block-monitor.js` explaining its implicit size bound (capped indirectly by `MONITOR_CAP` and `_wouldWeBlock()` filtering; cleared on start/resume).

---

## 1.6.2 — 2025
**Bug fixes**
- Added `tabs` permission to manifest — without it, `chrome.tabs.query` silently returned nothing in the Chrome Web Store version, breaking popup initialisation entirely (slider, lock button, logger all non-functional). Developer mode was permissive and hid the bug.
- Removed `tabs` permission again in favour of routing all `tab.url` reads through the background service worker, which can read tab URLs via `<all_urls>` host_permissions without needing the explicit `tabs` permission. This avoids a prior store rejection where a reviewer found the `tabs` permission unnecessary.
- Fixed stale logs from a previous session appearing in a new logger session. When a prior session was still marked active in storage, clicking SHOW LOGS re-opened the logger without clearing old entries. Now every click always resets `logs`, `logHost` and `logStartTime` before opening the logger tab.
- Fixed `RULE_NAMES` TLD-block index: previously used `GENERIC_BLOCKED_TLDS.concat(WORLD_BLOCKED_TLDS)` to map rule IDs 3200+, but since WORLD already contains all GENERIC entries the concat double-counted them, misassigning rule names from ID 3236 onward. Now uses `WORLD_BLOCKED_TLDS` only (the superset).
- Fixed potential stale-log persistence across SW restarts: `logging: false` and `logs: []` are now written atomically in a single `chrome.storage.local.set()` call instead of two separate calls with a 3-second delay between them. A SW eviction between the two writes could previously leave stale logs in storage.

**Architecture**
- Added `GET_ACTIVE_TAB_INFO` and `RELOAD_ACTIVE_TAB` message handlers to background.js so popup.js and logger.js never call `chrome.tabs.query` directly.

---

## 1.6.1 — 2025
**Features**
- Logger now filters to only show traffic from the 1P domain that was active when SHOW LOGS was clicked. Previously all tabs' traffic was captured indiscriminately.
- Logger header now shows the logged domain name (passed as a URL parameter from the popup, avoiding storage/timing races).
- Removed the "Show blocked domains panel" checkbox (leftover from v2.0 blocked-panel experiment).

**Known limitation**
- `tabs` permission was missing from manifest, breaking the store version entirely (see 1.6.2).

---

## 1.6.0 — 2025
**Features**
- Level 3 (Easy medium mode) now allows both 3P scripts **and** 3P frames from whitelisted TLDs, not just scripts. Bullet text updated to reflect this.
- Removed the explanatory "(covers 95% of traffic...)" info line from the L3 Active Policy panel.

---

## 1.5.0 — 2025
**Features**
- Logger: added **Allow** column at levels 4 and 5. Blocked 3P-script rows get an Allow button that whitelists the script's own domain (extracted from the request URL, not the 1P calling domain) and immediately reloads the source tab.
- Logger: Allow column appears between the Action and Reason columns.
- Logger: domain header pill shows which 1P domain is being logged.

**Bug fixes**
- Allow button previously added the 1P calling domain instead of the 3P script domain. Fixed by extracting hostname from `e.url` rather than using `e.domain`.

---

## 1.4.0 — 2025
**Features**
- Request logger with 5-minute session countdown.
- Logger captures all allowed and blocked third-party traffic matching the extension's rules via `onRuleMatchedDebug`.
- Visibility-only catch-all allow rule (ID 3500) added so XHR/image/font/etc traffic is visible in the logger even though it is never blocked.
- SHOW LOGS button with active/pulsing state.

**Architecture**
- `declarativeNetRequestFeedback` permission added to support `onRuleMatchedDebug`.
- `LOG_TIMEOUT_MS` = 5 minutes, `MAX_LOGS` = 500 (FIFO eviction).
- SW restart recovery: reconstructs remaining log timeout from stored `logStartTime`.

---

## 1.3.x and earlier
- Core DNR rule engine with 5 levels.
- TLD whitelist (L3), domain whitelist (L4/L5), CDN allow (L4), built-in payment/video/CAPTCHA whitelist (L2–L4).
- Per-site lock rules with FIFO cap of 100 entries.
- Toolbar badge showing per-tab blocked request count via `displayActionCountAsBadgeText`.
- Auto TLD detection from browser language settings (BROWSER / CONTINENT / WORLDWIDE modes).
- TLD blacklist for L2 (NONE / USER / GENERIC / WORLD modes).
