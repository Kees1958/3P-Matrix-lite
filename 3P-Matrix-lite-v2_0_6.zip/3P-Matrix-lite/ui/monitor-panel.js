// ── ui/monitor-panel.js ───────────────────────────────────────────────────────
// Block monitor panel UI.
// Renders the live FIFO entry list, elapsed clock, pause/resume/exit controls,
// and allow buttons (visible only while paused).
//
// Communicates with the SW via chrome.runtime.sendMessage using MSG_* constants
// loaded from data/message-types.js.
//
// Dependencies (loaded before this file via <script src>):
//   data/message-types.js — MSG_* constants
// ─────────────────────────────────────────────────────────────────────────────

var _pollInterval  = null;   // setInterval handle for live data polling
var _clockInterval = null;   // setInterval handle for elapsed clock
var _sessionStart  = null;   // Date when session started (from first data response)
var _isPaused      = false;
var _isStopped     = false;
var _knownEntries  = [];     // local copy — compared against SW data on each poll
var _allowedSet    = {};     // domain -> true, tracks what user allowed this session
var _currentState  = null;   // state snapshot for allow operations

var POLL_MS  = 800;   // how often to fetch new entries from SW while running
var WARN_MS  = 60000; // turn timer orange at 1 minute remaining

// ── Helpers ───────────────────────────────────────────────────────────────────

function send(msg, cb) {
  try {
    chrome.runtime.sendMessage(msg, function(resp) {
      if (chrome.runtime.lastError) { if (cb) cb(null); return; }
      if (cb) cb(resp);
    });
  } catch(e) {
    if (cb) cb(null);
  }
}

function formatClock(ms) {
  var total = Math.floor(Math.max(0, ms) / 1000);
  var m = Math.floor(total / 60);
  var s = total % 60;
  return m + ":" + (s < 10 ? "0" : "") + s;
}

// ── DOM refs ──────────────────────────────────────────────────────────────────

var elHost        = document.getElementById("panelHost");
var elTimer       = document.getElementById("timerDisplay");
var elTimerIcon   = document.getElementById("timerIcon");
var elBtnPause    = document.getElementById("btnPause");
var elBtnExit     = document.getElementById("btnExit");
var elStatusBar   = document.getElementById("statusBar");
var elEntryBody   = document.getElementById("entryBody");
var elEmptyState  = document.getElementById("emptyState");

// ── Entry rendering ───────────────────────────────────────────────────────────

function renderEntry(entry, index) {
  var tr = document.createElement("tr");
  tr.dataset.index = index;
  if (_allowedSet[entry.host]) tr.classList.add("allowed-row");

  var typeIcon  = entry.type === "frame" ? "frame" : "script";
  var typeClass = entry.type === "frame" ? "type-frame" : "type-script";

  var allowedLabel = _allowedSet[entry.host] ? " allowed" : "";

  tr.innerHTML =
    '<td class="td-elapsed">' + entry.elapsed + '</td>' +
    '<td class="td-type"><span class="' + typeClass + '">' + typeIcon + '</span></td>' +
    '<td class="td-host">' + entry.host + '</td>' +
    '<td class="td-allow">' +
      '<button class="allow-btn' + allowedLabel + '" data-domain="' + entry.host + '">' +
        (_allowedSet[entry.host] ? "✓ Allowed" : "Allow") +
      '</button>' +
    '</td>';

  // Allow button click
  var btn = tr.querySelector(".allow-btn");
  if (btn && !_allowedSet[entry.host]) {
    btn.addEventListener("click", function() {
      handleAllow(entry.host, tr, btn);
    });
  }

  return tr;
}

function refreshTable(entries) {
  elEmptyState.style.display = entries.length ? "none" : "block";

  // Full re-render on each poll (entries are bounded to 100, so this is cheap)
  elEntryBody.innerHTML = "";
  for (var i = 0; i < entries.length; i++) {
    elEntryBody.appendChild(renderEntry(entries[i], i));
  }

  // Auto-scroll to bottom if not paused (show newest entries)
  if (!_isPaused) {
    var scroll = document.getElementById("tableScroll");
    if (scroll) scroll.scrollTop = scroll.scrollHeight;
  }
}

// ── Allow handler ─────────────────────────────────────────────────────────────

function handleAllow(domain, tr, btn) {
  if (_allowedSet[domain]) return;
  _allowedSet[domain] = true;

  // Optimistic UI update
  btn.textContent = "✓ Allowed";
  btn.classList.add("allowed");
  tr.classList.add("allowed-row");

  // Tell SW to add to whitelist
  send({ type: MSG_ALLOW_MONITOR_DOMAIN, domain: domain }, function(resp) {
    if (!resp || !resp.ok) {
      // Roll back optimistic update on failure
      delete _allowedSet[domain];
      btn.textContent = "Allow";
      btn.classList.remove("allowed");
      tr.classList.remove("allowed-row");
    }
  });
}

// ── Clock ─────────────────────────────────────────────────────────────────────

function startClock(remainingMs) {
  if (_clockInterval) clearInterval(_clockInterval);
  var deadline = Date.now() + remainingMs;

  _clockInterval = setInterval(function() {
    if (_isPaused || _isStopped) return;
    var left = deadline - Date.now();
    elTimer.textContent = formatClock(left);

    if (left <= 0) {
      elTimer.classList.add("expired");
      elTimerIcon.textContent = "■";
      clearInterval(_clockInterval);
    } else if (left <= WARN_MS) {
      elTimer.classList.add("warning");
    }
  }, 500);
}

// ── Poll ──────────────────────────────────────────────────────────────────────

function startPolling() {
  if (_pollInterval) clearInterval(_pollInterval);
  _pollInterval = setInterval(poll, POLL_MS);
  poll(); // immediate first fetch
}

function stopPolling() {
  if (_pollInterval) { clearInterval(_pollInterval); _pollInterval = null; }
}

function poll() {
  send({ type: MSG_GET_MONITOR_DATA }, function(resp) {
    if (!resp || !resp.ok || !resp.data) return;
    var data = resp.data;

    // Session gone — SW cleaned up (timeout or level change)
    if (!data.session) {
      handleForceClosed("Session ended");
      return;
    }

    // Update host label on first response
    if (elHost.textContent === "—" && data.session.host) {
      elHost.textContent = data.session.host;
    }

    // Start clock on first response
    if (!_sessionStart && data.session.remaining !== undefined) {
      _sessionStart = true;
      startClock(data.session.remaining);
    }

    refreshTable(data.entries);
    _knownEntries = data.entries;
  });
}

// ── Stop reasons from SW ──────────────────────────────────────────────────────

function handleForceClosed(reason) {
  if (_isStopped) return;
  _isStopped = true;
  stopPolling();
  if (_clockInterval) clearInterval(_clockInterval);

  // Auto-close on timeout — give the user 2 seconds to see the reason
  if (reason && reason.indexOf("Time limit") !== -1) {
    elStatusBar.textContent = reason;
    elStatusBar.classList.add("visible");
    setTimeout(function() { window.close(); }, 2000);
    return;
  }

  elTimer.classList.add("expired");
  elTimerIcon.textContent = "■";
  elBtnPause.disabled = true;
  elStatusBar.textContent = reason || "Monitor session ended.";
  elStatusBar.classList.add("visible");
}

// ── Pause / Resume ────────────────────────────────────────────────────────────

function setPaused(val) {
  _isPaused = val;
  document.body.classList.toggle("paused", val);
  elBtnPause.textContent = val ? "Resume" : "Pause";
  elTimerIcon.textContent = val ? "⏸" : "▶";
  var hint = document.getElementById("pauseHint");
  if (hint) hint.textContent = val
    ? "Select domains to allow, then Resume to apply"
    : "Press Pause to allow domains";
}

elBtnPause.addEventListener("click", function() {
  if (_isStopped) return;

  if (!_isPaused) {
    // Pause
    send({ type: MSG_PAUSE_MONITOR }, function() {
      setPaused(true);
      stopPolling();
    });
  } else {
    // Resume — check hide-warning preference first
    chrome.storage.local.get({ monitorHideWarning: false }, function(r) {
      if (r.monitorHideWarning) {
        executeResume(); // skip confirmation
      } else {
        document.getElementById('resumeConfirm').classList.add('visible');
      }
    });
  }
});

// ── Exit ──────────────────────────────────────────────────────────────────────

elBtnExit.addEventListener("click", function() {
  send({ type: MSG_STOP_MONITOR, reason: "exit" }, function() {
    window.close();
  });
});

// ── Resume confirm bar ───────────────────────────────────────────────────────

function executeResume() {
  // Get the tabId from session metadata — do NOT use chrome.tabs.query here
  // because the active window is the monitor panel itself, not the monitored tab.
  send({ type: MSG_GET_MONITOR_DATA }, function(resp) {
    if (!resp || !resp.ok || !resp.data || !resp.data.session) return;
    var tabId = resp.data.session.tabId;
    if (!tabId) return;
    send({ type: MSG_RESUME_MONITOR, tabId: tabId }, function(resp2) {
      if (!resp2 || !resp2.ok) return;
      setPaused(false);
      _knownEntries = [];
      _allowedSet   = {};
      elEntryBody.innerHTML = "";
      elEmptyState.style.display = "block";
      startPolling();
    });
  });
}

function doResume() {
  document.getElementById('resumeConfirm').classList.remove('visible');
  executeResume();
}

document.getElementById('resumeOk').addEventListener('click', doResume);
document.getElementById('resumeCancel').addEventListener('click', function() {
  document.getElementById('resumeConfirm').classList.remove('visible');
});

// ── Listen for SW-initiated close ─────────────────────────────────────────────

chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === MSG_MONITOR_CLOSED) {
    var reasonMap = {
      timeout:     "Time limit reached — session closed.",
      new_session: "Monitor started on another tab — session closed.",
      stopped:     "Monitor session ended."
    };
    handleForceClosed(reasonMap[msg.reason] || "Monitor session ended.");
  }
});

// ── Init ──────────────────────────────────────────────────────────────────────

(function init() {
  // Start polling immediately — session is already running when the panel opens
  startPolling();
})();

// ── Cleanup on window close ───────────────────────────────────────────────────
// Fires when the user closes the popup window via the OS close button.
// Uses sendBeacon-style synchronous send — beforeunload gives very little time
// so we use a synchronous XMLHttpRequest fallback pattern via sendMessage.
// The watchdog in background.js is the safety net if this doesn't fire cleanly.
window.addEventListener('beforeunload', function() {
  if (_isStopped) return; // already cleaned up
  try {
    // sendMessage is async but we fire-and-forget — the watchdog covers any gap
    chrome.runtime.sendMessage({ type: MSG_STOP_MONITOR, reason: 'panel_closed' });
  } catch(e) {}
});
