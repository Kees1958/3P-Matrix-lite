// ── ui/popup.js — popup page controller ────────────────────────────────────────
import {
  MSG_GET_STATE, MSG_SET_STATE, MSG_ADD_SITE_RULE, MSG_REMOVE_SITE_RULE, MSG_SET_ICON,
  MSG_START_MONITOR
} from "../data/message-types.js";
import { MULTI_PART_SUFFIXES } from "../data/constants.js";
import { DEFAULT_STATE, SESSION_KEY_LEVEL, SESSION_KEY_PREV_LEVEL, LOCAL_KEY_HIDE_WARNING } from "../data/state-storage.js";
import { BASE_TLDS, rebuildTldList, rebuildBlockedTldList } from "../core/tld-engine.js";

// ── Level definitions ──────────────────────────────────────────────────────────
const LEVELS = [
  { name: "Easy mode \u2014 allow all", color: "#16A34A", showDomain: true, showTld: false,
    rules: [{ type: "allow", text: "All traffic allowed \u2014 no restrictions active" }] },
  { name: "Easy mode with enhanced security", color: "#93C5FD", showDomain: false, showTld: false,
    rules: [
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Non-standard ports blocked (allowed: 80, 443, 8080, 8443)" },
      { type: "block", text: "Third-party frames are blocked" }
    ]},
  { name: "Easy medium mode", color: "#FACC15", showDomain: false, showTld: true,
    rules: [
      { type: "allow", text: "##TLDWHITELIST##" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Non-standard ports blocked (allowed: 80, 443, 8080, 8443)" },
      { type: "block", text: "Third-party frames not in TLD whitelist are blocked" },
      { type: "block", text: "Third-party scripts not in TLD whitelist are blocked" }
    ]},
  { name: "Medium mode \u2014 trust CDN\u2019s", color: "#FB923C", showDomain: true, showTld: false,
    rules: [
      { type: "allow", text: "3P-scripts for URL\u2019s with CDN in name are allowed" },
      { type: "allow", text: "Whitelisted domains are allowed as 3P" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Non-standard ports blocked (allowed: 80, 443, 8080, 8443)" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]},
  { name: "Medium mode", color: "#C0392B", showDomain: true, showTld: false,
    rules: [
      { type: "allow", text: "Whitelisted domains are allowed as 3P" },
      { type: "allow", text: "Built-in whitelist allows payment services, video embeds, CAPTCHA\u2019s and important JS-libraries" },
      { type: "block", text: "IP address only connections are blocked" },
      { type: "block", text: "Non-standard ports blocked (allowed: 80, 443, 8080, 8443)" },
      { type: "block", text: "Third-party frames are blocked" },
      { type: "block", text: "Third-party scripts are blocked" }
    ]}
];

// LEVEL_COLORS removed — use LEVELS[n - 1].color directly (single source of truth).

// GENERIC_BLOCKED_TLDS and WORLD_BLOCKED_TLDS are used internally by
// core/tld-engine.js's rebuildBlockedTldList() — not needed directly here.
const BLOCKED_TLD_LABELS = ["NONE","USER","GENERIC","WORLD"];
const BLOCKED_TLD_HINTS  = [
  "No TLD script blocking active",
  "Block 3P scripts from your own list of risky TLDs",
  "Block 3P scripts from known low-quality / high-abuse TLDs",
  "Generic list plus high-risk country TLDs"
];

let state       = Object.assign({}, DEFAULT_STATE);
let domainPage  = 0, tldPage = 0;
const DOMAIN_PAGE_SIZE = 500, TLD_PAGE_SIZE = 500;
let currentHost    = "";  // exact hostname of the active tab
let lockDomain     = "";  // registrable (apex) domain used for locking — covers subdomains
let sessionLevel     = 0;  // current global level this session (0 = not yet initialised)
let prevSessionLevel = 0;  // level before last slider move — restored when lock is set

// MULTI_PART_SUFFIXES loaded from data/constants.js (single source of truth).

// Reduce a hostname to its registrable (apex) domain, e.g.
// "portal.www.tio.nl" -> "tio.nl", "www.example.co.uk" -> "example.co.uk"
function getApexDomain(hostname) {
  if (!hostname) return hostname;
  const labels = hostname.split('.');
  if (labels.length <= 2) return hostname;

  const lastTwo   = labels.slice(-2).join('.');
  const lastThree = labels.length >= 3 ? labels.slice(-3).join('.') : null;

  if (lastThree && MULTI_PART_SUFFIXES.indexOf(labels.slice(-2).join('.')) !== -1) {
    return lastThree;
  }
  return lastTwo;
}

// ── SVG icons ─────────────────────────────────────────────────────────────────
const SVG_LOCKED = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
  + '<path fill-rule="evenodd" clip-rule="evenodd" d="M4 6V4C4 1.79086 5.79086 0 8 0C10.2091 0 12 1.79086 12 4V6H14V16H2V6H4ZM6 4C6 2.89543 6.89543 2 8 2C9.10457 2 10 2.89543 10 4V6H6V4ZM7 13V9H9V13H7Z" fill="rgba(0,0,0,0.6)"/>'
  + '</svg>';

const SVG_UNLOCKED = '<svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">'
  + '<path fill-rule="evenodd" clip-rule="evenodd" d="M11.5 2C10.6716 2 10 2.67157 10 3.5V6H13V16H1V6H8V3.5C8 1.567 9.567 0 11.5 0C13.433 0 15 1.567 15 3.5V4H13V3.5C13 2.67157 12.3284 2 11.5 2ZM9 10H5V12H9V10Z" fill="#ffffff"/>'
  + '</svg>';

// ── Auto TLD ──────────────────────────────────────────────────────────────────
const AUTO_TLD_LABELS = ["NONE", "BROWSER", "CONTINENT", "WORLDWIDE"];
const AUTO_TLD_HINTS  = [
  "No country codes added automatically",
  "Add country codes from your browser\u2019s language settings",
  "Same continent: adds countries sharing your browser language",
  "Worldwide: adds all countries sharing your browser language"
];
// LANG_TLD_MAP, BASE_TLDS, computeAutoTlds(), rebuildTldList(), rebuildBlockedTldList()
// are loaded from core/tld-engine.js

function renderBlockedTags() {
  renderPage('blocked-tld-tags', state.blockedTlds, 0);
}

// ── Lock button ───────────────────────────────────────────────────────────────
// ── Whitelist dropdowns ───────────────────────────────────────────────────────
// Applies the current dropdown open/closed state for both TLD (L3) and domain (L4)
// panels. Called on boot and whenever the user toggles a dropdown.
function applyDropdownState() {
  const tldOpen       = state.whitelistDropdown && state.whitelistDropdown.tld    !== false;
  const domainOpen    = state.whitelistDropdown && state.whitelistDropdown.domain !== false;
  const blockedTldOpen = state.blockedTldDropdownOpen === true; // starts collapsed (false)

  const tldBtn     = document.getElementById('tldDropdownBtn');
  const tldContent = document.getElementById('tldDropdownContent');
  const domBtn     = document.getElementById('domainDropdownBtn');
  const domContent = document.getElementById('domainDropdownContent');
  const blkBtn     = document.getElementById('blockedTldDropdownBtn');
  const blkContent = document.getElementById('blockedTldDropdownContent');

  if (tldBtn && tldContent) {
    tldBtn.classList.toggle('open', tldOpen);
    tldContent.classList.toggle('collapsed', !tldOpen);
  }
  if (domBtn && domContent) {
    domBtn.classList.toggle('open', domainOpen);
    domContent.classList.toggle('collapsed', !domainOpen);
  }
  if (blkBtn && blkContent) {
    blkBtn.classList.toggle('open', blockedTldOpen);
    blkContent.classList.toggle('collapsed', !blockedTldOpen);
  }
}

function initDropdownToggle(btnId, contentId, stateKey) {
  const btn     = document.getElementById(btnId);
  const content = document.getElementById(contentId);
  if (!btn || !content) return;
  btn.addEventListener('click', function() {
    const nowOpen = content.classList.contains('collapsed');
    content.classList.toggle('collapsed', !nowOpen);
    btn.classList.toggle('open', nowOpen);
    if (stateKey === 'blockedTld') {
      // blockedTld dropdown state stored separately from whitelistDropdown
      state.blockedTldDropdownOpen = nowOpen;
    } else {
      if (!state.whitelistDropdown) state.whitelistDropdown = { tld: true, domain: true };
      state.whitelistDropdown[stateKey] = nowOpen;
    }
    pushState();
  });
}

function renderLockBtn() {
  const btn     = document.getElementById('lockBtn');
  const tooltip = document.getElementById('lockTooltip');
  if (!btn) return;

  const isPinned = lockDomain && state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain);

  if (isPinned) {
    const pinnedLevel = state.siteRules[lockDomain];
    const color       = LEVELS[pinnedLevel - 1].color;
    btn.innerHTML   = SVG_LOCKED;
    btn.style.background    = color;
    btn.classList.add('is-locked');
    tooltip.textContent = 'Locked to L' + pinnedLevel + ' \u2014 click to unlock';
  } else {
    btn.innerHTML   = SVG_UNLOCKED;
    btn.style.background    = 'var(--surface)';
    btn.classList.remove('is-locked');
    tooltip.textContent = 'Lock L' + sessionLevel + ' for this site';
  }
}

function handleLockClick() {
  if (!lockDomain) return;
  if (state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain)) {
    // Unlock
    chrome.runtime.sendMessage({ type: MSG_REMOVE_SITE_RULE, host: lockDomain }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok) {
        delete state.siteRules[lockDomain];
        state.siteRulesOrder = (state.siteRulesOrder || []).filter(function(h) { return h !== lockDomain; });
        updateRuleCount(resp.ruleCount);
        render();
        renderLockBtn();
        renderPinnedList();
      }
    });
  } else {
    // Lock to current level — capture host, level and restore target before async call
    // so concurrent state changes (e.g. auto-TLD mode) can't corrupt the restore.
    const lockedHost     = lockDomain;
    const lockedLevel    = sessionLevel;
    const restoreToLevel = prevSessionLevel;
    chrome.runtime.sendMessage({ type: MSG_ADD_SITE_RULE, host: lockedHost, level: lockedLevel }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok) {
        if (!state.siteRules) state.siteRules = {};
        if (!state.siteRulesOrder) state.siteRulesOrder = [];
        // FIFO eviction mirror in popup state
        if (!Object.prototype.hasOwnProperty.call(state.siteRules, lockedHost)) {
          if (state.siteRulesOrder.length >= 100) {
            const evicted = state.siteRulesOrder.shift();
            delete state.siteRules[evicted];
          }
          state.siteRulesOrder.push(lockedHost);
        }
        state.siteRules[lockedHost] = lockedLevel;
        // Restore session to the captured pre-lock level
        sessionLevel     = restoreToLevel;
        prevSessionLevel = restoreToLevel;
        state.level      = sessionLevel;
        const _s = {}; _s[SESSION_KEY_LEVEL] = sessionLevel; _s[SESSION_KEY_PREV_LEVEL] = prevSessionLevel;
        chrome.storage.session.set(_s);
        // Update icon to restored session level and sync background global level
        chrome.runtime.sendMessage({ type: MSG_SET_ICON, level: sessionLevel });
        chrome.runtime.sendMessage({ type: MSG_SET_STATE, state: state });
        updateRuleCount(resp.ruleCount);
        render();
        renderLockBtn();
        renderPinnedList();
      }
    });
  }
}

// ── Pinned sites list (no UI — hidden FIFO list) ────────────────────────────
function renderPinnedList() { /* no panel — managed silently in background */ }

// ── Tabs ──────────────────────────────────────────────────────────────────────
function updateTabs(displayLevel) {
  const lvl              = LEVELS[(displayLevel || 1) - 1];
  const tabBar           = document.querySelector('.tab-bar');
  const domainTab        = document.querySelector('[data-tab="domain"]');
  const tldTab           = document.querySelector('[data-tab="tld"]');
  const blockedTldTab    = document.querySelector('[data-tab="blocked-tld"]');
  const domainPanel      = document.getElementById('panel-domain');
  const tldPanel         = document.getElementById('panel-tld');
  const blockedTldPanel  = document.getElementById('panel-blocked-tld');

  // Guard: if DOM elements missing, bail out
  if (!tabBar || !domainTab || !tldTab || !domainPanel || !tldPanel) return;

  // Blocked TLD panel now lives inside the tab system — always hide the standalone version
  if (blockedTldPanel) blockedTldPanel.style.display = 'none';

  // L1: hide tab bar and all panels
  if (displayLevel === 1) {
    tabBar.style.display = 'none';
    domainPanel.classList.remove('active');
    tldPanel.classList.remove('active');
    if (blockedTldPanel) blockedTldPanel.classList.remove('active');
    return;
  }

  tabBar.style.display = '';

  // L2: TLD blacklist tab (left, default) | Domain whitelist tab (right)
  if (displayLevel === 2) {
    tldTab.style.display = 'none';
    domainTab.style.display = '';
    if (blockedTldTab) blockedTldTab.style.display = '';
    // Default to blocked TLD tab
    const activeL2 = state._l2ActiveTab || 'blocked-tld'; // default: TLD blacklist on left
    domainTab.classList.toggle('active', activeL2 === 'domain');
    domainTab.style.borderBottomColor = activeL2 === 'domain' ? lvl.color : '';
    if (blockedTldTab) { blockedTldTab.classList.toggle('active', activeL2 === 'blocked-tld'); blockedTldTab.style.borderBottomColor = activeL2 === 'blocked-tld' ? lvl.color : ''; }
    tldPanel.classList.remove('active');
    domainPanel.classList.toggle('active', activeL2 === 'domain');
    if (blockedTldPanel) blockedTldPanel.classList.toggle('active', activeL2 === 'blocked-tld');
    if (blockedTldPanel) blockedTldPanel.style.display = '';
    return;
  }

  // L3: TLD whitelist tab (left, default) | Domain whitelist tab (right)
  if (displayLevel === 3) {
    if (blockedTldTab) blockedTldTab.style.display = 'none';
    tldTab.style.display = '';
    domainTab.style.display = '';
    const activeL3 = state._l3ActiveTab || 'tld'; // default: TLD whitelist on left
    tldTab.classList.toggle('active', activeL3 === 'tld');
    tldTab.style.borderBottomColor = activeL3 === 'tld' ? lvl.color : '';
    domainTab.classList.toggle('active', activeL3 === 'domain');
    domainTab.style.borderBottomColor = activeL3 === 'domain' ? lvl.color : '';
    tldPanel.classList.toggle('active', activeL3 === 'tld');
    domainPanel.classList.toggle('active', activeL3 === 'domain');
    if (blockedTldPanel) blockedTldPanel.classList.remove('active');
    return;
  }

  // L4, L5: domain only
  if (blockedTldTab) blockedTldTab.style.display = 'none';
  tldTab.style.display = 'none';
  domainTab.style.display = '';
  tldTab.classList.remove('active');
  domainTab.classList.add('active');
  domainTab.style.borderBottomColor = lvl.color;
  tldPanel.classList.remove('active');
  domainPanel.classList.add('active');
  if (blockedTldPanel) blockedTldPanel.classList.remove('active');
}

// ── Render ────────────────────────────────────────────────────────────────────
function render() {
  // Guard: bail out if DOM not ready
  if (!document.getElementById('levelNum')) return;

  // If on a pinned site show its locked level in the slider, else show sessionLevel/state.level
  const isPinned   = lockDomain && state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain);
  const displayVal = isPinned ? state.siteRules[lockDomain] : sessionLevel;
  const val        = displayVal || 1;
  const lvl        = LEVELS[val - 1];

  document.getElementById('levelNum').textContent  = val;
  document.getElementById('levelName').textContent = lvl.name;
  document.documentElement.style.setProperty('--accent', lvl.color);

  // Track fill
  const slider    = document.getElementById('slider');
  const trackFill = document.getElementById('trackFill');
  const fillPx    = 9 + ((slider.offsetWidth - 18) * (val - 1) / 4);
  trackFill.style.width      = fillPx + 'px';
  trackFill.style.background = lvl.color;

  // Disable slider and show hint when on a pinned site
  slider.disabled = isPinned;
  const hint = document.getElementById('siteLockHint');
  if (hint) hint.classList.toggle('visible', isPinned);

  // Ticks
  for (let i = 1; i <= 5; i++) {
    const tick = document.getElementById('tick-' + i);
    if (tick) tick.classList.toggle('active', i === val);
  }

  // Policy rules
  let html = '';
  // At L2: built-in whitelist frames line is first, JS-libraries line is second — inject both before the loop
  if (val === 2) {
    html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot allow"></div></div>'
      + '<div class="rule-text">Whitelisted domains are allowed as 3P</div></div>';
    html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot allow"></div></div>'
      + '<div class="rule-text">Built-in whitelist allows payment services, video embeds, CAPTCHA\u2019s and important JS-libraries</div></div>';
    const blockedCount = (state.blockedTldMode > 0 && state.blockedTlds) ? state.blockedTlds.length : 0;
    html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot block"></div></div>'
      + '<div class="rule-text dim">Blocks 3P-scripts from ' + blockedCount + ' risky TLD\u2019s</div></div>';
  }
  for (let r = 0; r < lvl.rules.length; r++) {
    const rule = lvl.rules[r];
    const ruleText = rule.text;

    // ##TLDWHITELIST## — inject TLD count + info line + built-in lines all at once
    if (ruleText === '##TLDWHITELIST##') {
      html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot allow"></div></div>'
        + '<div class="rule-text">Allows 3P-scripts &amp; frames from ' + (state.tlds ? state.tlds.length : 0) + ' whitelisted TLD\u2019s</div></div>';
      html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot allow"></div></div>'
        + '<div class="rule-text">Whitelisted domains are allowed as 3P</div></div>';
      html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot allow"></div></div>'
        + '<div class="rule-text">Built-in whitelist allows payment services, video embeds, CAPTCHA\u2019s and important JS-libraries</div></div>';
      continue;
    }

    if (rule.type === 'info') {
      html += '<div class="rule-row rule-info"><div class="rule-text rule-text-info">' + ruleText + '</div></div>';
    } else {
      const dot = (val === 1)
        ? '<div class="rule-hyphen">\u2013</div>'
        : '<div class="rule-dot-wrap"><div class="rule-dot ' + rule.type + '"></div></div>';
      const textClass = rule.type === 'block' ? 'rule-text dim' : 'rule-text';
      html += '<div class="rule-row">' + dot + '<div class="' + textClass + '">' + ruleText + '</div></div>';
    }
    // At L4: inject built-in lines after the first rule (CDN line)
    if (r === 0 && val === 4) {
      html += '<div class="rule-row"><div class="rule-dot-wrap"><div class="rule-dot allow"></div></div>'
        + '<div class="rule-text">Built-in whitelist allows payment services, video embeds, CAPTCHA\u2019s and important JS-libraries</div></div>';
    }
  }
  const ruleListEl = document.getElementById('ruleList');
  if (ruleListEl) ruleListEl.innerHTML = html;

  // Startup badge
  const badge = document.getElementById('startupBadge');
  if (badge) badge.style.borderColor = LEVELS[(state.startupLevel || 1) - 1].color;
  const sel = document.getElementById('startupSelect');
  if (sel) sel.value = String(state.startupLevel);

  // Update SHOW BLOCKS button state based on effective level
  if (typeof updateShowBlocksBtn === 'function') updateShowBlocksBtn();

  // Tab active underline color
  document.querySelectorAll('.tab-btn.active').forEach(function(btn) {
    btn.style.borderBottomColor = lvl.color;
  });

  // Add button colors
  const addBtns = document.querySelectorAll('.wl-add-btn');
  for (let b = 0; b < addBtns.length; b++) {
    addBtns[b].style.color      = (val === 5) ? '#FFFFFF' : '#000000';
    addBtns[b].style.background = lvl.color;
  }

  updateTabs(val);
  renderLockBtn();
}

// ── Push state ────────────────────────────────────────────────────────────────
function pushState() {
  if (typeof chrome === 'undefined' || !chrome.runtime) return;
  chrome.runtime.sendMessage({ type: MSG_SET_STATE, state: state }, function(resp) {
    if (chrome.runtime.lastError) return;
    if (resp && resp.ok) updateRuleCount(resp.ruleCount);
  });
}

function updateRuleCount(n) {
  // no dedicated counter element in this version, ignore
}

// ── Paginated whitelist ───────────────────────────────────────────────────────
function renderDomainTags() {
  // Domain whitelist tab is only ever shown at L4/L5 — built-in trusted domains (L2 only)
  // are never mixed into this view since L2 has no whitelist UI at all.
  renderPage('domain-tags', state.domains, domainPage);
}

function renderPage(containerId, items, page) {
  const container    = document.getElementById(containerId);
  const isTld        = containerId === 'tld-tags';
  const isBlockedTld = containerId === 'blocked-tld-tags';
  if (!container) return;
  container.innerHTML = '';
  if (!items || items.length === 0) {
    const e = document.createElement('div'); e.className = 'wl-empty'; e.textContent = 'None added yet';
    container.appendChild(e);
    return;
  }
  const pageSize   = (isTld || isBlockedTld) ? TLD_PAGE_SIZE : DOMAIN_PAGE_SIZE;
  const totalPages = Math.ceil(items.length / pageSize);
  page = Math.max(0, Math.min(page, totalPages - 1));
  if (isTld) tldPage = page; else domainPage = page;
  const start = page * pageSize, end = Math.min(start + pageSize, items.length);
  for (let i = start; i < end; i++) {
    (function(v) {
      const tag = document.createElement('div'); tag.className = 'wl-tag';
      const LOWERCASE = {'ai':true,'io':true};
      const display = (v.length === 2 && !LOWERCASE[v]) ? v.toUpperCase() : v;
      tag.innerHTML = display + '<button class="wl-tag-remove" title="Remove">&times;</button>';
      tag.querySelector('.wl-tag-remove').addEventListener('click', function() {
        if (isTld) {
          // Remove from active list and from the manual list so the boot re-sync
          // (which rebuilds state.tlds from manualTlds + autoTlds) does not restore it.
          state.tlds = state.tlds.filter(function(x) { return x !== v; });
          if (state.manualTlds) {
            state.manualTlds = state.manualTlds.filter(function(x) { return x !== v; });
          }
          // Remember the removal so auto-detection won't silently bring it back.
          // BASE_TLDS are protected and cannot be excluded.
          if (BASE_TLDS.indexOf(v) === -1) {
            if (!state.excludedTlds) state.excludedTlds = [];
            if (state.excludedTlds.indexOf(v) === -1) state.excludedTlds.push(v);
          }
          renderPage(containerId, state.tlds, tldPage);
        } else if (isBlockedTld) {
          // Remove from the manual list first, then rebuild state.blockedTlds from
          // remaining manual entries + the mode's base list.
          // Without this, the next popup open rebuilds state.blockedTlds from
          // state.manualBlockedTlds which still contains the entry, silently restoring it.
          if (state.manualBlockedTlds) {
            state.manualBlockedTlds = state.manualBlockedTlds.filter(function(x) { return x !== v; });
          }
          state.blockedTlds = rebuildBlockedTldList(state.blockedTldMode || 0, state.manualBlockedTlds || []);
          renderBlockedTags();
        } else {
          state.domains = state.domains.filter(function(x) { return x !== v; });
          renderDomainTags();
        }
        pushState();
      });
      container.appendChild(tag);
    })(items[i]);
  }
}

function initWhitelist(inputId, btnId, tagsId, stateKey) {
  const input    = document.getElementById(inputId);
  const btn      = document.getElementById(btnId);
  const isTld    = stateKey === 'tlds';
  const sanitize = isTld
    ? function(v) { return v.replace(/^\.+/, '').toLowerCase(); }
    : function(v) { return v.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').toLowerCase(); };

  function addEntry() {
    const raw = sanitize(input.value.trim());
    if (!raw || state[stateKey].length >= 200 || state[stateKey].indexOf(raw) !== -1) {
      input.value = ''; return;
    }
    state[stateKey].push(raw);
    if (isTld) {
      renderPage(tagsId, state.tlds, Math.floor((state.tlds.length - 1) / TLD_PAGE_SIZE));
    } else {
      renderDomainTags();
    }
    input.value = ''; input.focus();
    pushState();
  }
  btn.addEventListener('click', addEntry);
  input.addEventListener('keydown', function(e) { if (e.key === 'Enter') addEntry(); });
  if (isTld) {
    renderPage(tagsId, state.tlds, 0);
  } else {
    renderDomainTags();
  }
}

// ── Boot ──────────────────────────────────────────────────────────────────────
// ── MonitorController ────────────────────────────────────────────────────────
// Self-contained module owning all Show Blocks / block monitor UI logic.
// Single responsibility: wire the Show Blocks button, confirmation dialog,
// and hide-warning preference. Exposes two methods:
//   MonitorController.init()    — call once from DOMContentLoaded
//   MonitorController.update()  — call from render() to sync button state
//
// Dependencies (module scope):
//   getEffectiveLevel()  — defined below
//   updateShowBlocksBtn() — defined below, calls MonitorController.update()
//   currentHost, state, LEVELS — popup.js globals
//   MSG_START_MONITOR — data/message-types.js
// ─────────────────────────────────────────────────────────────────────────────
const MonitorController = (function() {
  let _winId          = null;   // open monitor window id
  let _hideWarning    = false;  // persisted preference — skip confirmation dialog
  let _pendingTabId   = null;   // tabId waiting for confirm dialog OK

  // Opens the monitor panel as a popup window after SW confirms session started.
  // If a monitor window from this popup session is already open, focus it
  // instead of creating a duplicate (the Show Blocks button has no click-guard,
  // so repeated clicks while the popup stays open previously opened one window
  // per click). Self-healing: if _winId points to a window the user already
  // closed, chrome.runtime.lastError fires and we fall through to create a
  // fresh one.
  function _launch(tabId) {
    if (_winId !== null) {
      chrome.windows.update(_winId, { focused: true }, function() {
        if (chrome.runtime.lastError) {
          // Stale id — that window no longer exists. Clear it and open a new one.
          _winId = null;
          _createMonitorWindow(tabId);
        }
        // else: existing window focused, nothing more to do.
      });
      return;
    }
    _createMonitorWindow(tabId);
  }

  function _createMonitorWindow(tabId) {
    chrome.runtime.sendMessage(
      { type: MSG_START_MONITOR, tabId: tabId, host: currentHost },
      function(result) {
        if (!result || !result.ok) return;
        const panelUrl = chrome.runtime.getURL('ui/monitor-panel.html');
        chrome.windows.create({
          url: panelUrl, type: 'popup', width: 740, height: 520
        }, function(win) { _winId = win ? win.id : null; });
      }
    );
  }

  // Silently switches to Domain whitelist tab at L2/L3 without persisting tab state
  function _switchToDomainTab(eff) {
    document.querySelectorAll('.tab-btn').forEach(function(b) {
      b.classList.remove('active'); b.style.borderBottomColor = '';
    });
    document.querySelectorAll('.tab-panel').forEach(function(p) {
      p.classList.remove('active');
    });
    const btn = document.querySelector('[data-tab="domain"]');
    if (btn) {
      btn.classList.add('active');
      btn.style.borderBottomColor = LEVELS[eff - 1].color;
    }
    const panel = document.getElementById('panel-domain');
    if (panel) panel.classList.add('active');
    // Deliberately NOT saving to state._l2ActiveTab / state._l3ActiveTab
    // so the TLD tab remains default when reopening the popup
  }

  // Public: wire all DOM elements — call once from DOMContentLoaded
  function init() {
    const overlay      = document.getElementById('monitorConfirmOverlay');
    const hideCheckbox = document.getElementById('monitorHideWarning');
    const okBtn        = document.getElementById('monitorConfirmOk');
    const cancelBtn    = document.getElementById('monitorConfirmCancel');
    const showBtn      = document.getElementById('showBlocksBtn');

    if (!overlay || !showBtn) return;

    // Load persisted hide-warning preference
    const _defWarn = {}; _defWarn[LOCAL_KEY_HIDE_WARNING] = false;
    chrome.storage.local.get(_defWarn, function(r) {
      _hideWarning = !!r[LOCAL_KEY_HIDE_WARNING];
      if (hideCheckbox) hideCheckbox.checked = _hideWarning;
    });

    // Confirm dialog — OK
    if (okBtn) okBtn.addEventListener('click', function() {
      if (hideCheckbox && hideCheckbox.checked) {
        _hideWarning = true;
        const _w = {}; _w[LOCAL_KEY_HIDE_WARNING] = true;
        chrome.storage.local.set(_w);
      }
      overlay.classList.remove('visible');
      if (_pendingTabId) _launch(_pendingTabId);
      _pendingTabId = null;
    });

    // Confirm dialog — Cancel
    if (cancelBtn) cancelBtn.addEventListener('click', function() {
      overlay.classList.remove('visible');
      _pendingTabId = null;
    });

    // Hide-warning checkbox — live toggle
    if (hideCheckbox) hideCheckbox.addEventListener('change', function() {
      _hideWarning = hideCheckbox.checked;
      const _w = {}; _w[LOCAL_KEY_HIDE_WARNING] = _hideWarning;
      chrome.storage.local.set(_w);
    });

    // Show Blocks button
    showBtn.addEventListener('click', function() {
      const eff = getEffectiveLevel();
      if (eff < 2 || !currentHost) return;

      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (!tabs || !tabs[0]) return;
        const tabId = tabs[0].id;

        // At L2/L3 silently switch to Domain whitelist tab before launching
        if (eff === 2 || eff === 3) _switchToDomainTab(eff);

        if (_hideWarning) {
          _launch(tabId);
        } else {
          _pendingTabId = tabId;
          overlay.classList.add('visible');
        }
      });
    });
  }

  // Public: sync Show Blocks button enabled/disabled state — call from render()
  function update() {
    const showBtn   = document.getElementById('showBlocksBtn');
    const importBtn = document.getElementById('importAllowBtn');
    if (!showBtn) return;
    const eff = getEffectiveLevel();
    const isL1 = eff < 2;
    // At L1: hide Show blocks, show Import allow
    showBtn.style.display   = isL1 ? 'none' : 'inline-block';
    if (importBtn) importBtn.style.display = isL1 ? 'inline-block' : 'none';
    // At L2+: keep Show blocks enabled
    showBtn.disabled = false;
    showBtn.title = 'Monitor blocked requests on this tab';
  }

  return { init: init, update: update };
})();

// ── Effective level + Show Blocks button state ───────────────────────────────
// Defined at module scope so render() can call updateShowBlocksBtn() at any time,
// including before DOMContentLoaded fires.
function getEffectiveLevel() {
  const isPinned = lockDomain && state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain);
  return isPinned ? state.siteRules[lockDomain] : (sessionLevel || state.level || 1);
}

function updateShowBlocksBtn() {
  // Delegates to MonitorController — single source of truth for button state
  MonitorController.update();
}

document.addEventListener('DOMContentLoaded', function() {

  // Ticks
  const tickRow = document.getElementById('tickRow');
  for (let i = 1; i <= 5; i++) {
    const t = document.createElement('div');
    t.className = 'tick'; t.textContent = i; t.id = 'tick-' + i;
    tickRow.appendChild(t);
  }

  // Slider: pinned sites keep their lock, slider only changes global session level
  document.getElementById('slider').addEventListener('input', function() {
    const newLevel     = parseInt(this.value, 10);
    prevSessionLevel = sessionLevel;
    sessionLevel     = newLevel;
    state.level      = newLevel;
    const _s = {}; _s[SESSION_KEY_LEVEL] = sessionLevel; _s[SESSION_KEY_PREV_LEVEL] = prevSessionLevel;
    chrome.storage.session.set(_s);

    // Auto-collapse both whitelist dropdowns when the user moves the slider —
    // so next time they arrive at L3 or L4 they see the compact version, not
    // the expanded one they may have already read.
    if (!state.whitelistDropdown) state.whitelistDropdown = { tld: true, domain: true };
    state.whitelistDropdown.tld    = false;
    state.whitelistDropdown.domain = false;

    render();
    applyDropdownState();
    chrome.runtime.sendMessage({ type: MSG_SET_STATE, state: state }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.ok) chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs && tabs[0]) chrome.tabs.reload(tabs[0].id);
      });
    });
  });

  // Startup select
  document.getElementById('startupSelect').addEventListener('change', function() {
    state.startupLevel = parseInt(this.value, 10);
    render(); pushState();
  });

  // Tabs — track active tab per level so switching levels restores the right tab
  document.querySelectorAll('.tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      const val = (sessionLevel || state.level || 1);
      document.querySelectorAll('.tab-btn').forEach(function(b) {
        b.classList.remove('active'); b.style.borderBottomColor = '';
      });
      document.querySelectorAll('.tab-panel').forEach(function(p) { p.classList.remove('active'); });
      this.classList.add('active');
      this.style.borderBottomColor = LEVELS[val - 1].color;
      const panelEl = document.getElementById('panel-' + this.dataset.tab);
      if (panelEl) panelEl.classList.add('active');
      // Track active tab per level for restore on level switch
      if (val === 2) state._l2ActiveTab = this.dataset.tab;
      if (val === 3) state._l3ActiveTab = this.dataset.tab;
      // Update Show blocks button since eligibility depends on active tab at L2/L3
      updateShowBlocksBtn();
    }.bind(btn));
  });

  initWhitelist('domain-input', 'domain-add', 'domain-tags', 'domains');
  // NOTE: tld-input/tld-add are wired exclusively by addManualTld() below.
  // initWhitelist() is NOT called for TLDs — it only updates state.tlds and
  // would push state before state.manualTlds is updated, causing the new TLD
  // to be dropped on the next re-sync from manualTlds + autoTldMode.

  // Whitelist dropdown toggles — L3 TLD and L4 Domain panels
  initDropdownToggle('tldDropdownBtn',        'tldDropdownContent',        'tld');
  initDropdownToggle('domainDropdownBtn',     'domainDropdownContent',     'domain');
  initDropdownToggle('blockedTldDropdownBtn', 'blockedTldDropdownContent', 'blockedTld');

  // ── TLD Blacklist slider (Level 2) ──────────────────────────────────────────
  const blockedTldSliderEl = document.getElementById('blockedTldSlider');
  const blockedTldValueEl  = document.getElementById('blockedTldValue');
  const blockedTldHintEl   = document.getElementById('blockedTldHint');

  function updateBlockedTldSliderUI(mode) {
    if (blockedTldValueEl) blockedTldValueEl.textContent = BLOCKED_TLD_LABELS[mode];
    if (blockedTldHintEl)  blockedTldHintEl.textContent  = BLOCKED_TLD_HINTS[mode];
    if (blockedTldSliderEl) blockedTldSliderEl.value = mode;
  }

  function applyBlockedTldMode(mode) {
    state.blockedTldMode = mode;
    state.blockedTlds    = rebuildBlockedTldList(mode, state.manualBlockedTlds || []);
    renderBlockedTags();
    render(); // update Active Policy blocked TLD count
    pushState();
  }

  if (blockedTldSliderEl) {
    blockedTldSliderEl.addEventListener('input', function() {
      const mode = parseInt(this.value, 10);
      updateBlockedTldSliderUI(mode);
      applyBlockedTldMode(mode);
    });
  }

  // Blocked TLD manual add
  const blockedTldInput  = document.getElementById('blocked-tld-input');
  const blockedTldAddBtn = document.getElementById('blocked-tld-add');
  function addBlockedTld() {
    if (!blockedTldInput) return;
    const raw = blockedTldInput.value.trim().replace(/^\.+/, '').toLowerCase();
    if (!raw) return;
    if (!state.manualBlockedTlds) state.manualBlockedTlds = [];
    if (state.manualBlockedTlds.indexOf(raw) === -1) state.manualBlockedTlds.push(raw);
    if (state.blockedTlds.indexOf(raw) === -1) {
      state.blockedTlds.push(raw);
      renderBlockedTags();
      pushState();
    }
    blockedTldInput.value = ''; blockedTldInput.focus();
  }
  if (blockedTldAddBtn) blockedTldAddBtn.addEventListener('click', addBlockedTld);
  if (blockedTldInput)  blockedTldInput.addEventListener('keydown', function(e) { if (e.key === 'Enter') addBlockedTld(); });

  updateBlockedTldSliderUI(state.blockedTldMode || 0);
  renderBlockedTags();


  const domainRowsSelect = document.getElementById('domainRowsSelect');
  const domainTagsBox    = document.getElementById('domain-tags');
  if (domainRowsSelect) {
    domainRowsSelect.addEventListener('change', function() {
      if (domainTagsBox) domainTagsBox.style.height = this.value + 'px';
    });
  }

  // Auto TLD slider
  const autoSlider  = document.getElementById('autoTldSlider');
  const autoValue   = document.getElementById('autoTldValue');
  const autoHint    = document.getElementById('autoTldHint');
  let browserLangs = [];
  if (typeof chrome !== 'undefined' && chrome.i18n) {
    chrome.i18n.getAcceptLanguages(function(langs) { browserLangs = langs || []; });
  }
  function updateAutoSliderUI(mode) {
    autoValue.textContent = AUTO_TLD_LABELS[mode];
    autoHint.textContent  = AUTO_TLD_HINTS[mode];
    autoSlider.value      = mode;
  }
  function applyAutoTlds(mode) {
    chrome.i18n.getAcceptLanguages(function(langs) {
      browserLangs = langs || [];
      rebuildTldList(mode, browserLangs, state.manualTlds || [], state.excludedTlds || [], function(merged) {
        state.tlds = merged; state.autoTldMode = mode;
        renderPage('tld-tags', state.tlds, 0);
        render(); // update Active Policy TLD count
        pushState();
      });
    });
  }
  autoSlider.addEventListener('input', function() {
    const mode = parseInt(this.value, 10);
    updateAutoSliderUI(mode); applyAutoTlds(mode);
  });

  // Manual TLD add
  const tldInput  = document.getElementById('tld-input');
  const tldAddBtn = document.getElementById('tld-add');
  function addManualTld() {
    const raw = tldInput.value.trim().replace(/^\.+/, '').toLowerCase();
    if (!raw) return;
    if (!state.manualTlds) state.manualTlds = [];
    if (state.manualTlds.indexOf(raw) === -1) state.manualTlds.push(raw);
    // Re-adding a previously-excluded TLD clears the exclusion — explicit re-add wins.
    if (state.excludedTlds) {
      state.excludedTlds = state.excludedTlds.filter(function(x) { return x !== raw; });
    }
    if (state.tlds.indexOf(raw) === -1) {
      state.tlds.push(raw);
      renderPage('tld-tags', state.tlds, Math.floor((state.tlds.length - 1) / TLD_PAGE_SIZE));
      pushState();
    }
    tldInput.value = ''; tldInput.focus();
  }
  tldAddBtn.addEventListener('click', addManualTld);
  tldInput.addEventListener('keydown', function(e) { if (e.key === 'Enter') addManualTld(); });

  // Lock button
  document.getElementById('lockBtn').addEventListener('click', handleLockClick);

  // ── SHOW BLOCKS button ───────────────────────────────────────────────────────
  // Opens the block monitor panel in a new tab. Only enabled at effective level 4 or 5.
  MonitorController.init();

  // ── IMPORT ALLOW button & overlay ────────────────────────────────────────────
  // At L1: replaces Show blocks. Opens a textarea where the user pastes domain names
  // (one per line). On Save & Lock, each domain is added to state.siteRules at level 1.
  (function() {
    const overlay   = document.getElementById('importAllowOverlay');
    const textarea  = document.getElementById('importAllowTextarea');
    const saveBtn   = document.getElementById('importAllowSave');
    const cancelBtn = document.getElementById('importAllowCancel');
    const openBtn   = document.getElementById('importAllowBtn');
    if (!overlay || !openBtn) return;

    openBtn.addEventListener('click', function() {
      textarea.value = '';
      overlay.classList.add('visible');
      textarea.focus();
    });

    cancelBtn.addEventListener('click', function() {
      overlay.classList.remove('visible');
    });

    saveBtn.addEventListener('click', function() {
      const lines = textarea.value.split(/\r?\n/);
      let added = 0;
      lines.forEach(function(line) {
        // Strip protocol and path, lowercase
        const domain = line.trim()
          .replace(/^https?:\/\//i, '')
          .replace(/\/.*$/, '')
          .toLowerCase();
        if (!domain) return;
        if (!state.siteRules) state.siteRules = {};
        if (!state.siteRulesOrder) state.siteRulesOrder = [];
        // FIFO eviction — mirror handleLockClick logic
        if (!Object.prototype.hasOwnProperty.call(state.siteRules, domain)) {
          if (state.siteRulesOrder.length >= 100) {
            const evicted = state.siteRulesOrder.shift();
            delete state.siteRules[evicted];
          }
          state.siteRulesOrder.push(domain);
        }
        state.siteRules[domain] = 1;  // lock at level 1
        added++;
      });
      if (added > 0) {
        chrome.runtime.sendMessage({ type: MSG_SET_STATE, state: state }, function(resp) {
          if (chrome.runtime.lastError) return;
          if (resp && resp.ok) updateRuleCount(resp.ruleCount);
        });
        renderPinnedList();
      }
      overlay.classList.remove('visible');
    });
  })();

  // Get current tab hostname directly — tabs permission is now declared
  if (typeof chrome !== 'undefined' && chrome.tabs) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs && tabs[0]) {
        try { currentHost = new URL(tabs[0].url).hostname; } catch(e) { /* unparseable tab URL (e.g. chrome:// pages) — currentHost stays unset */ }
        lockDomain = getApexDomain(currentHost);
      }
      const hostnameEl = document.getElementById('siteHostname');
      if (hostnameEl) hostnameEl.textContent = currentHost || '—';
      renderLockBtn();
    });
  }

  // Sync with background — read session storage first, then persistent state
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    const _sessDefaults = {}; _sessDefaults[SESSION_KEY_LEVEL] = 0; _sessDefaults[SESSION_KEY_PREV_LEVEL] = 0;
    chrome.storage.session.get(_sessDefaults, function(sess) {
      chrome.runtime.sendMessage({ type: MSG_GET_STATE }, function(resp) {
        if (chrome.runtime.lastError) return;
        if (resp && resp.ok && resp.state) {
          state = Object.assign({}, DEFAULT_STATE, resp.state);
          if (!state.startupLevel) state.startupLevel = 1;
          if (!state.autoTldMode && state.autoTldMode !== 0) state.autoTldMode = 1;
          if (!state.manualTlds)    state.manualTlds    = [];
          if (!state.excludedTlds)  state.excludedTlds  = [];
          if (!state.siteRules)     state.siteRules     = {};
          if (!state.siteRulesOrder) state.siteRulesOrder = Object.keys(state.siteRules);
          if (!state.whitelistDropdown) state.whitelistDropdown = { tld: true, domain: true };
          if (!state.blockedTlds)       state.blockedTlds       = [];
          if (!state.manualBlockedTlds) state.manualBlockedTlds = [];
          if (typeof state.blockedTldMode !== 'number') state.blockedTldMode = 0;
          BASE_TLDS.forEach(function(t) { if (state.tlds.indexOf(t) === -1) state.tlds.push(t); });

          // Initialise session levels:
          // - If already set this session, restore them
          // - If first open this session (both 0), initialise from startupLevel
          if (sess[SESSION_KEY_LEVEL]) {
            sessionLevel     = sess[SESSION_KEY_LEVEL];
            prevSessionLevel = sess[SESSION_KEY_PREV_LEVEL] || sess[SESSION_KEY_LEVEL];
          } else {
            sessionLevel     = state.startupLevel;
            prevSessionLevel = state.startupLevel;
            const _si = {}; _si[SESSION_KEY_LEVEL] = sessionLevel; _si[SESSION_KEY_PREV_LEVEL] = prevSessionLevel;
            chrome.storage.session.set(_si);
          }

          // Update icon to reflect actual session level (without changing stored state)
          chrome.runtime.sendMessage({ type: MSG_SET_ICON, level: sessionLevel });

          // Set slider: pinned site shows its locked level, otherwise show sessionLevel
          const _pinned = lockDomain && state.siteRules && Object.prototype.hasOwnProperty.call(state.siteRules, lockDomain);
          document.getElementById('slider').value        = _pinned ? state.siteRules[lockDomain] : sessionLevel;
          document.getElementById('startupSelect').value = String(state.startupLevel);
          updateAutoSliderUI(state.autoTldMode);

          // Re-sync the auto-added TLD list from the browser's CURRENT language settings
          // using the latest mapping logic, rather than trusting whatever was saved to
          // storage by a previous version of this logic. Manual TLD entries are preserved.
          if (state.autoTldMode !== 0 && typeof chrome !== 'undefined' && chrome.i18n) {
            chrome.i18n.getAcceptLanguages(function(currentLangs) {
              rebuildTldList(state.autoTldMode, currentLangs || [], state.manualTlds || [], state.excludedTlds || [], function(merged) {
                state.tlds = merged;
                renderPage('tld-tags', state.tlds, 0);
                pushState();
              });
            });
          }

          render();
          renderDomainTags();
          renderPage('tld-tags',    state.tlds,    0);
          renderLockBtn();
          applyDropdownState();
          updateBlockedTldSliderUI(state.blockedTldMode || 0);
          renderBlockedTags();
        }
      });
    });
  }
});
