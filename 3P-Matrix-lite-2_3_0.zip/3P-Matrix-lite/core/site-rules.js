// ── core/site-rules.js ────────────────────────────────────────────────────────
// Per-site pinned rule management (add, remove, FIFO eviction).
//
// Public interface:
//   addSiteRule(state, host, level)  — adds/updates a per-site rule, returns state
//   removeSiteRule(state, host)      — removes a per-site rule, returns state
// ─────────────────────────────────────────────────────────────────────────────

import { SITE_RULES_CAP } from "../data/state-storage.js";

// Adds or updates a per-site pinned rule in state.
// If the host is already pinned, only the level is updated (no order change).
// If adding a new host would exceed SITE_RULES_CAP, the oldest host is evicted (FIFO).
// Mutates and returns the state object — caller must saveState() afterwards.
export function addSiteRule(state, host, level) {
  if (!state.siteRules)      state.siteRules     = {};
  if (!state.siteRulesOrder) state.siteRulesOrder = [];

  if (Object.prototype.hasOwnProperty.call(state.siteRules, host)) {
    // Already pinned — update level only, preserve insertion order
    state.siteRules[host] = level;
    return state;
  }

  // Evict oldest entry if at cap
  if (state.siteRulesOrder.length >= SITE_RULES_CAP) {
    const evicted = state.siteRulesOrder.shift();
    delete state.siteRules[evicted];
  }

  state.siteRules[host] = level;
  state.siteRulesOrder.push(host);
  return state;
}

// Removes a per-site pinned rule from state.
// Mutates and returns the state object — caller must saveState() afterwards.
export function removeSiteRule(state, host) {
  if (!state.siteRules) return state;
  delete state.siteRules[host];
  state.siteRulesOrder = (state.siteRulesOrder || []).filter(function(h) {
    return h !== host;
  });
  return state;
}
