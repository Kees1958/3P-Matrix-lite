// ── core/tld-engine.js ────────────────────────────────────────────────────────
// Pure TLD computation: derives the active TLD whitelist and blocked-TLD list
// from browser language settings, user preferences and mode flags.
// No Chrome API calls, no DOM access, no side effects.
//
// Public interface:
//   rebuildTldList(mode, browserLangs, manualTlds, excludedTlds, cb) — builds full merged TLD whitelist
//   rebuildBlockedTldList(mode, manualBlockedTlds)       — builds the blocked TLD list for level 2
//   BASE_TLDS — base whitelist, always included regardless of mode/language
//
// computeAutoTlds() is internal-only — called by rebuildTldList(), not used elsewhere.
// ─────────────────────────────────────────────────────────────────────────────

import { EU_LANGS, GENERIC_BLOCKED_TLDS, WORLD_BLOCKED_TLDS } from "../data/constants.js";

// Base TLDs always included in the whitelist regardless of mode or language.
// These cover the most common legitimate third-party origins on the web.
export const BASE_TLDS = ["com","ai","edu","gov","io","net","org","cloud","dev","app","page"];

// Per-language map of additional country TLDs to include at continent and worldwide scope.
// continent = geographically or linguistically close countries beyond the base.
// worldwide  = all countries where this language has significant official/primary use.
// The base country itself is handled by LANG_DEFAULT_COUNTRY / LANG_WORLD_DEFAULTS.
const LANG_TLD_MAP = {
  "nl": { continent: ["be"],                worldwide: ["be","sr","aw","cw","eu"] },
  "fr": { continent: ["be","ch","lu","mc"], worldwide: ["be","ch","lu","mc","ca","sn","ci","cm","mg","cd","tn","ma","dz","eu"] },
  "de": { continent: ["at","ch","li","lu"], worldwide: ["at","ch","li","lu","eu"] },
  // es: continent adds Andorra (Spanish-speaking European microstate); worldwide adds all Latin America
  "es": { continent: ["ad"],                worldwide: ["ad","mx","ar","co","pe","ve","cl","ec","gt","cu","bo","do","hn","py","sv","ni","cr","pa","uy","eu"] },
  "pt": { continent: [],                    worldwide: ["br","ao","mz","cv","gw","st","eu"] },
  "it": { continent: ["ch","sm","va"],      worldwide: ["ch","sm","va","eu"] },
  // en: continent = only European English-speaking countries (UK already base, ie/mt are neighbors)
  //     au/nz/ca are not on the European continent — they move to worldwide
  "en": { continent: ["ie","mt"],           worldwide: ["ie","mt","au","nz","ca","za","ng","gh","ke","ug","tz","sg","in","ph","jm"] },
  // sv: se is already the base country via LANG_DEFAULT_COUNTRY; fi is the only continental addition
  //     (Swedish is a co-official language of Finland)
  "sv": { continent: ["fi"],               worldwide: ["fi","eu"] },
  // da: fo (Faroe Islands) and gl (Greenland) are Danish-speaking territories — correct continent additions
  "da": { continent: ["fo","gl"],          worldwide: ["fo","gl","eu"] },
  "no": { continent: [],                   worldwide: ["eu"] },
  "fi": { continent: [],                   worldwide: ["eu"] },
  "pl": { continent: [],                   worldwide: ["eu"] },
  "ro": { continent: ["md"],               worldwide: ["md","eu"] },
  "el": { continent: ["cy"],               worldwide: ["cy","eu"] },
  "hu": { continent: [],                   worldwide: ["eu"] },
  "cs": { continent: ["sk"],               worldwide: ["sk","eu"] },
  "sk": { continent: ["cz"],               worldwide: ["cz","eu"] },
  "hr": { continent: ["rs","ba","me","si"],worldwide: ["rs","ba","me","si","eu"] },
  "sr": { continent: ["hr","ba","me","si"],worldwide: ["hr","ba","me","si","eu"] },
  "bg": { continent: [],                   worldwide: ["eu"] },
  // "ru" (Russian) excluded for geopolitical reasons — ru/by domains intentionally not added
  "uk": { continent: [],                   worldwide: ["eu"] },  // Ukrainian language (not "United Kingdom"); "by" excluded for geopolitical reasons
  "tr": { continent: [],                   worldwide: ["cy"] },
  "zh": { continent: ["hk","tw","sg"],     worldwide: ["hk","tw","sg","mo"] },
  "ja": { continent: [],                   worldwide: [] },
  "ko": { continent: [],                   worldwide: [] },
  "he": { continent: [],                   worldwide: [] },
  "th": { continent: [],                   worldwide: [] },
  "id": { continent: [],                   worldwide: [] },
  // hi: np (Nepal) is the only contiguous country where Hindi is widely spoken as primary
  //     pk/bd/lk are worldwide at best (Urdu/Bengali/Sinhala are those countries' primary languages)
  "hi": { continent: ["np"],               worldwide: ["np","pk","bd","lk"] },
  "vi": { continent: [],                   worldwide: [] }
};

// Explicit mapping from a bare 2-letter language code to its most likely default country.
// Used ONLY when the browser reports a language with no region subtag (e.g. "nl" not "nl-NL").
// Languages are omitted here when the language code does not reliably imply one specific country.
//
// Why this matters: language code != country code in many cases. For example "sv" is the
// ISO code for Swedish, but "sv" is also the ccTLD for El Salvador — without this map, a
// bare "sv" browser language would silently add El Salvador's TLD.
const LANG_DEFAULT_COUNTRY = {
  "nl": "nl", "de": "de", "it": "it", "pl": "pl",
  "da": "dk", "fi": "fi", "el": "gr", "hu": "hu", "cs": "cz",
  "sk": "sk", "hr": "hr", "bg": "bg", "tr": "tr",
  "th": "th", "vi": "vn", "id": "id", "ja": "jp", "ko": "kr",
  "he": "il", "hi": "in"
  // Omitted (ambiguous without a region subtag):
  //   sv — Swedish ≠ El Salvador's "sv" ccTLD; needs "sv-SE"
  //   no — kept out for consistency
  //   zh — could be CN, TW, HK, SG
  //   uk — Ukrainian language, "uk" ccTLD is United Kingdom — never auto-guess
  //   ar — could be any of 20+ Arabic-speaking countries
};

// World languages spoken across many countries where readers commonly consume sources
// from several countries interchangeably. Bare language tags (no region subtag, e.g. "en"
// instead of "en-US") add this small cluster of most-read source countries.
const LANG_WORLD_DEFAULTS = {
  "en": ["uk", "us", "ie", "au", "ca"],   // BBC/UK, CNN/NYT/US, Ireland, Australia, Canada
  "fr": ["fr", "be", "ca"],               // France, Belgium, Canada (Quebec)
  "es": ["es", "mx", "ar"]                // Spain, Mexico, Argentina — three largest sources
};

// Hand-picked region-pairing table. Used only when the browser supplies a language WITH
// a region subtag (e.g. "en-IE", "en-US", "da-FO"). A pairing is added only when the
// region has its own distinct national identity and users there commonly read both their
// own region's sources and the larger parent country's sources.
// Format: "lang-REGION" -> [extra country code to add alongside the region itself]
const REGION_PAIRINGS = {
  "en-ie": ["uk"],   // Ireland <-> UK
  "en-uk": ["us"],   // UK <-> US
  "en-gb": ["us"],
  "en-us": ["uk"],
  "da-fo": ["dk"],   // Faroe Islands <-> Denmark
  "en-im": ["uk"],   // Isle of Man <-> UK
  "fr-ca": ["fr"],   // Canadian French <-> France
  "es-mx": ["es"],   // Mexican Spanish <-> Spain
  "pt-br": ["pt"]    // Brazilian Portuguese <-> Portugal
};

// EU_LANGS is loaded from data/constants.js (single source of truth).

// Computes auto-detected TLDs from browser language settings and the chosen scope mode.
// mode: 0=None, 1=Browser (country only), 2=Continent, 3=Worldwide.
// Calls cb(tlds) with an array of TLD strings.
function computeAutoTlds(mode, browserLangs, cb) {
  if (mode === 0) { cb([]); return; }
  const browserCountries = [];
  let hasEuLang = false;
  browserLangs.forEach(function(lang) {
    const parts = lang.toLowerCase().split('-');
    const lc = parts[0];
    if (EU_LANGS[lc]) hasEuLang = true;

    if (parts.length > 1) {
      // Explicit region subtag present (e.g. "nl-BE" -> "be") — use it directly.
      const region = parts[parts.length - 1];
      if (/^[a-z]{2,3}$/.test(region) && browserCountries.indexOf(region) === -1)
        browserCountries.push(region);
      // Check the hand-picked region-pairing table for a companion country.
      const pairKey = lc + '-' + region;
      if (REGION_PAIRINGS[pairKey]) {
        REGION_PAIRINGS[pairKey].forEach(function(c) {
          if (browserCountries.indexOf(c) === -1) browserCountries.push(c);
        });
      }
    } else if (LANG_WORLD_DEFAULTS[lc]) {
      // Bare world-language tag — add the cluster of most-read source countries.
      LANG_WORLD_DEFAULTS[lc].forEach(function(c) {
        if (browserCountries.indexOf(c) === -1) browserCountries.push(c);
      });
    } else if (LANG_DEFAULT_COUNTRY[lc]) {
      // Bare tag for a language with one unambiguous default country.
      const dflt = LANG_DEFAULT_COUNTRY[lc];
      if (browserCountries.indexOf(dflt) === -1) browserCountries.push(dflt);
    }
  });
  if (hasEuLang && browserCountries.indexOf('eu') === -1) browserCountries.push('eu');
  if (mode === 1) { cb(browserCountries); return; }
  const extra = browserCountries.slice();
  browserLangs.forEach(function(lang) {
    const lc = lang.toLowerCase().split('-')[0];
    const map = LANG_TLD_MAP[lc];
    if (!map) return;
    (mode === 2 ? map.continent : map.worldwide).forEach(function(tld) {
      if (extra.indexOf(tld) === -1) extra.push(tld);
    });
  });
  cb(extra);
}

// Builds the full merged TLD whitelist from auto-detected, manual, and excluded TLDs.
// BASE_TLDS are always included and cannot be excluded.
// Calls cb(tlds) with the final array.
export function rebuildTldList(mode, browserLangs, manualTlds, excludedTlds, cb) {
  computeAutoTlds(mode, browserLangs, function(autoTlds) {
    let merged = BASE_TLDS.slice();
    autoTlds.forEach(function(t) { if (merged.indexOf(t) === -1) merged.push(t); });
    (manualTlds || []).forEach(function(t) { if (merged.indexOf(t) === -1) merged.push(t); });
    // Drop anything the user explicitly removed, except BASE_TLDS which are always kept.
    if (excludedTlds && excludedTlds.length) {
      merged = merged.filter(function(t) {
        return BASE_TLDS.indexOf(t) !== -1 || excludedTlds.indexOf(t) === -1;
      });
    }
    cb(merged);
  });
}

// Builds the blocked TLD list from the current mode and manual additions.
// mode: 0=None (empty), 1=User (manual only), 2=Generic, 3=World.
// Returns the merged array synchronously.
export function rebuildBlockedTldList(mode, manualBlockedTlds) {
  let base = [];
  if (mode === 2) base = GENERIC_BLOCKED_TLDS.slice();
  else if (mode === 3) base = WORLD_BLOCKED_TLDS.slice();
  const merged = base.slice();
  (manualBlockedTlds || []).forEach(function(t) {
    if (merged.indexOf(t) === -1) merged.push(t);
  });
  return merged;
}
