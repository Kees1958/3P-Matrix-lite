// ── util/tld-utils.js ─────────────────────────────────────────────────────────
// Pure utility functions for TLD detection and version string parsing.
// No side effects, no state, no Chrome API calls (except chrome.i18n which
// is a pure query with no side effects).
//
// Public interface:
//   browserCountryTlds(cb)  — detects country TLDs from browser language settings
//   majorMinor(version)     — extracts "major.minor" from a version string
// ─────────────────────────────────────────────────────────────────────────────

import { EU_LANGS } from "../data/constants.js";

// Reads the browser's accepted languages and extracts country-code TLDs.
// Also adds "eu" if any EU language is detected.
// Calls cb(tlds) with an array of TLD strings, e.g. ["nl", "be", "eu"].
export function browserCountryTlds(cb) {
  chrome.i18n.getAcceptLanguages(function(langs) {
    const seen = {}, tlds = [];
    let hasEuLang = false;
    (langs || []).forEach(function(lang) {
      const parts  = lang.toLowerCase().split("-");
      const region = parts.length > 1 ? parts[parts.length - 1] : parts[0];
      if (EU_LANGS[parts[0]]) hasEuLang = true;
      if (/^[a-z]{2,3}$/.test(region) && !seen[region]) {
        seen[region] = true;
        tlds.push(region);
      }
    });
    if (hasEuLang && tlds.indexOf("eu") === -1) tlds.push("eu");
    cb(tlds);
  });
}

// Extracts "major.minor" from a semver-style version string.
// e.g. "1.6.8" -> "1.6",  "2.0" -> "2.0",  "" -> "0.0"
export function majorMinor(version) {
  const parts = (version || "").split(".");
  return (parts[0] || "0") + "." + (parts[1] || "0");
}
