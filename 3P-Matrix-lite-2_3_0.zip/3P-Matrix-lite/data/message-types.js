// ── data/message-types.js ─────────────────────────────────────────────────────
// Named constants for all chrome.runtime.sendMessage message types.
// Defining them here (rather than as raw strings) means a typo in either
// background.js or popup.js produces a ReferenceError instead of a silent
// no-op where the message is never handled.
//
// Load via: import { MSG_GET_STATE, ... } from "./data/message-types.js"
// (used by background.js, ui/popup.js, ui/monitor-panel.js)
//
// Dependencies: none
// ─────────────────────────────────────────────────────────────────────────────

export const MSG_GET_STATE        = "GET_STATE";         // popup → SW: fetch current state + rule count
export const MSG_SET_STATE        = "SET_STATE";         // popup → SW: save new state and apply rules
export const MSG_ADD_SITE_RULE    = "ADD_SITE_RULE";     // popup → SW: pin a per-site level override
export const MSG_REMOVE_SITE_RULE = "REMOVE_SITE_RULE";  // popup → SW: unpin a per-site level override
export const MSG_SET_ICON         = "SET_ICON";          // popup → SW: update the toolbar icon
// MSG_GET_ACTIVE_TAB_INFO and MSG_RELOAD_ACTIVE_TAB removed in v1.7.3 —
// popup now calls chrome.tabs directly since the tabs permission is declared.

// ── Block monitor messages ────────────────────────────────────────────────────
export const MSG_START_MONITOR        = "START_MONITOR";        // popup → SW: start session, register listener, reload tab
export const MSG_STOP_MONITOR         = "STOP_MONITOR";         // panel → SW: end session, full cleanup
export const MSG_PAUSE_MONITOR        = "PAUSE_MONITOR";        // panel → SW: pause listener, freeze array
export const MSG_RESUME_MONITOR       = "RESUME_MONITOR";       // panel → SW: apply whitelist, clear array, re-register, reload
export const MSG_GET_MONITOR_DATA     = "GET_MONITOR_DATA";     // panel → SW: fetch current FIFO array + session metadata
export const MSG_ALLOW_MONITOR_DOMAIN = "ALLOW_MONITOR_DOMAIN"; // panel → SW: add observed domain to whitelist
export const MSG_MONITOR_CLOSED       = "MONITOR_CLOSED";       // SW → panel: notify panel to close (clash / force close / level change)
