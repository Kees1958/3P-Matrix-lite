# 3P-Matrix-lite — Changelog

---

## 2.3.0 — 2026-07-24
**`var` → `let`/`const` modernization complete (no behavior changes)**

Finished converting the remaining, higher-risk files: `background.js`,
`core/block-monitor.js`, `ui/monitor-panel.js`, and `ui/popup.js` (146 occurrences —
the largest file). The codebase is now 100% `var`-free, and `.eslintrc.json` enables
`no-var` and `prefer-const` permanently (previously excluded while this work was in
progress).

`background.js` and `core/block-monitor.js` were converted manually, checking every
variable individually for real reassignment (module-scope session state like
`activeSession`, `monitorEntries`, `_sessionTimer` — which genuinely get reassigned
through the session lifecycle — correctly became `let`; everything else became
`const`). Both were desk-tested afterward: `background.js` by dispatching all 11
message types through its listener and confirming identical responses;
`core/block-monitor.js` with a dedicated test covering the full session lifecycle
(start → block detection with builtin/user whitelist checks and dedup → pause →
resume → stop), all 15 assertions passing.

`ui/monitor-panel.js` and `ui/popup.js` were converted using ESLint's own scope
analysis (`no-var`/`prefer-const` with `--fix`) rather than manual regex — at this
scale, real JS scope analysis is more reliable than pattern matching. Both were
checked for closures inside `for`-loops before running the fix (none of the 6 raw
loops across these two files capture their loop counter in an async callback, so
`var`→`let` cannot change behavior here) — `ui/popup.js`'s domain/TLD tag list
already used a manual IIFE workaround for the classic loop-closure bug, which is left
in place unchanged. Both files were then desk-tested in a simulated browser
environment (jsdom + a stubbed `chrome` API): `monitor-panel.js` for polling, table
rendering, and pause/resume; `popup.js` for tick rendering, level-based rule-list
rendering at two different levels, and tag removal via the IIFE-wrapped loop — all
assertions passing with zero runtime errors.

---

## 2.2.1 — 2026-07-24
**`var` → `let`/`const` modernization (steps 1–3 of a staged plan; no behavior changes)**

Converted `var` to `let`/`const` in the lower-risk files first — those with no
`for`-loop closures, where `var` vs `let` genuinely cannot change behavior. Every
conversion was checked individually against actual reassignment before choosing
`const` (never reassigned) vs `let` (reassigned) — this was not a blanket
find-and-replace. Two real reassignment patterns were caught and correctly kept as
`let`: `rules` in `core/rule-builder.js` (`rules = rules.concat(...)`, used to build
up a rule array from several sub-builders) and `base`/`merged` in
`core/tld-engine.js`'s TLD-list functions (conditionally reassigned per mode).

Files fully converted: `data/message-types.js`, `data/constants.js`,
`data/state-storage.js`, `util/tld-utils.js`, `core/rule-builder.js`,
`core/tld-engine.js`, `core/site-rules.js`.

`core/site-rules.js` was additionally verified with a dedicated desk test
(add/update/remove/FIFO-eviction-at-cap/empty-state scenarios) — all passed
identically to the pre-conversion behavior.

Remaining `var` usage — `background.js`, `core/block-monitor.js`,
`ui/monitor-panel.js`, `ui/popup.js` — involves real `for`-loops and closures where
`var`→`let` conversion can change behavior (usually by fixing a latent bug) and
needs case-by-case verification; deferred to a later pass. `.eslintrc.json` still
intentionally omits `no-var` until that work is done.

---

## 2.2.0 — 2026-07-24
**ESLint added; ES module migration; real bugs fixed; new feature**

*ES module migration*
- The whole codebase now uses real `import`/`export` instead of `importScripts`/`<script>`
  load order and an implicit shared global scope. The service worker loads with
  `"type": "module"`, and both UI pages load their controller as a single
  `<script type="module">`. Each file now imports exactly what it uses directly.
- Internal `var` usage inside function bodies was deliberately left untouched — this
  codebase uses `var` pervasively (not just at module boundaries, unlike a previous
  ESLint pass on a different extension), so a blanket `var` → `let`/`const` rewrite
  was treated as a separate decision, not bundled into this migration. `.eslintrc.json`
  intentionally omits `no-var` for now.
- `.eslintrc.json` added (`eslint:recommended`, `sourceType: "module"`) — resolves
  cross-file references natively; no manually-maintained globals list needed.

*Fixed: `DEFAULT_STATE` duplication removed for good*
- `ui/popup.js` kept its own literal copy of `DEFAULT_STATE`, separate from
  `data/state-storage.js`'s copy — the exact duplication that caused the divergence
  fixed manually in 2.1.2. Verified before removing it: both copies were currently
  identical, and `state-storage.js`'s copy is only ever read by its own
  `loadState`/`saveState`, which `popup.js` never calls (it talks to the service
  worker via messages instead) — so nothing depended on which copy was in scope.
  `popup.js` now imports `DEFAULT_STATE` from `state-storage.js`; the "must stay in
  sync" comment and the manual-sync risk it warned about are both gone.

*Fixed: `domainTags` undefined-variable bug*
- `ui/popup.js`'s domain-rows-select handler referenced a bare `domainTags`
  identifier that was never declared anywhere — the actual element has
  `id="domain-tags"`. Fixed by caching the real element reference.

*Fixed: domain pagination reset bug*
- `renderDomainTags()` always re-rendered at page 0 after adding/removing a domain
  tag, instead of preserving the current page like the equivalent TLD code does with
  `tldPage`. The `domainPage` variable was being tracked correctly but never actually
  consulted. Now uses `domainPage`, matching the TLD behavior.

*Fixed: `ns` redeclared in background.js*
- Two separate `var ns` declarations in the same function scope (different `if`
  branches for `MSG_SET_STATE` and `MSG_RESUME_MONITOR`). Harmless at runtime — the
  branches are mutually exclusive — but a real `no-redeclare` violation. Both are now
  `const`, scoped to their own block.

*Fixed: `no-prototype-builtins` (8 occurrences)*
- Direct `.hasOwnProperty()` calls in `core/site-rules.js` and `ui/popup.js` replaced
  with `Object.prototype.hasOwnProperty.call(...)`.

*Cleaned up: dead state removed*
- `ui/monitor-panel.js`: `_knownEntries` (written on every poll, never read — the
  actual refresh-comparison logic uses `_lastCount` instead) and `_currentState`
  (declared, never assigned or read) removed.
- Two empty blocks (an intentional `lastError` swallow in `core/block-monitor.js`,
  an intentional URL-parse `catch` in `ui/popup.js`) documented with clarifying
  comments rather than left bare.

*New: duplicate monitor-window prevention*
- The "Show Blocks" button had no click-guard — clicking it more than once while the
  popup stayed open (there was no cooldown or disabled state) opened a new monitor
  window every time. `_winId` was already being tracked for exactly this purpose but
  was never actually checked before creating a new window (a real, unused-variable
  bug caught by ESLint). Fixed: `_launch()` now focuses the existing monitor window
  if one is already open, and only creates a new one if none exists or the tracked
  window was closed independently (detected via `chrome.runtime.lastError`, which
  clears the stale id and creates a fresh window).

---

## 2.1.2 — 2026-07-15
**Code quality — no behaviour changes**

*Duplicated constants removed*
- `EU_LANGS` was defined in three places (`util/tld-utils.js`, `core/tld-engine.js`, and implicitly via `tld-utils.js`). Moved to `data/constants.js` as the single source of truth. `util/tld-utils.js` and `core/tld-engine.js` now reference it from there.
- `MULTI_PART_SUFFIXES` was defined twice verbatim (in `core/block-monitor.js` as an inline local `MULTI` array, and in `ui/popup.js`). Moved to `data/constants.js`. Both files now reference the shared constant.
- `LEVEL_COLORS` in `ui/popup.js` duplicated the colour values already stored in `LEVELS[].color`. Removed `LEVEL_COLORS`; the one call site now uses `LEVELS[pinnedLevel - 1].color` directly.

*DEFAULT_STATE divergence fixed*
- `ui/popup.js` and `data/state-storage.js` each held a copy of `DEFAULT_STATE` that had diverged: `state-storage.js` had `showBlockedCount` that `popup.js` was missing; `popup.js` had `blockedTldDropdownOpen` that `state-storage.js` was missing. Both copies are now fully in sync. A warning comment has been added to `popup.js` requiring any future key addition to be mirrored in both files.

*Storage key constants*
- The raw string literals `"monitorHideWarning"`, `"sessionLevel"` and `"prevSessionLevel"` were scattered as repeated raw strings across `ui/popup.js` and `ui/monitor-panel.js`. Named constants `LOCAL_KEY_HIDE_WARNING`, `SESSION_KEY_LEVEL` and `SESSION_KEY_PREV_LEVEL` are now declared in `data/state-storage.js` and used everywhere.

*Double message send fixed*
- The Import Allow save handler in `ui/popup.js` was firing `MSG_SET_STATE` twice for the same state object (once with a callback, once fire-and-forget). The redundant second send has been removed.

*Silent catch blocks documented*
- All `catch(e) {}` blocks in `background.js`, `core/block-monitor.js` and `ui/monitor-panel.js` now carry an explanatory comment confirming they are intentional and describing why the error is safely ignored.

*CSS tokens*
- `--radius: 6px` and `--radius-sm: 4px` added to `:root` in `ui/popup.html` to match `ui/monitor-panel.html`. Raw `6px` values in `popup.html` now have a matching variable (consumers will be migrated in a future pass).
- Dead CSS rule `.rule-text.dim` removed from `ui/popup.html` — it was identical to `.rule-text` and had no visual effect.

*Stale files removed*
- `logger.html` and `logger.js` removed from extension root — they were legacy artefacts unreferenced by the manifest or any other file.
- Root-level `popup.html` and `popup.js` removed — superseded by `ui/popup.html` and `ui/popup.js` since v2.0; the manifest correctly points to `ui/`.

*_seenDomains bound documented*
- Added a comment to `_seenDomains` in `core/block-monitor.js` explaining its implicit size bound (capped indirectly by `MONITOR_CAP` and `_wouldWeBlock()` filtering; cleared on start/resume).

---

## 1.6.2 — 2025
**Bug fixes**
- Added `tabs` permission to manifest — without it, `chrome.tabs.query` silently returned nothing in the Chrome Web Store version, breaking popup initialisation entirely (slider, lock button, logger all non-functional). Developer mode was permissive and hid the bug.
- Removed `tabs` permission again in favour of routing all `tab.url` reads through the background service worker, which can read tab URLs via `<all_urls>` host_permissions without needing the explicit `tabs` permission. This avoids a prior store rejection where a reviewer found the `tabs` permission unnecessary.
- Fixed stale logs from a previous session appearing in a new logger session. When a prior session was still marked active in storage, clicking SHOW LOGS re-opened the logger without clearing old entries. Now every click always resets `logs`, `logHost` and `logStartTime` before opening the logger tab.
- Fixed `RULE_NAMES` TLD-block index: previously used `GENERIC_BLOCKED_TLDS.concat(WORLD_BLOCKED_TLDS)` to map rule IDs 3200+, but since WORLD already contains all GENERIC entries the concat double-counted them, misassigning rule names from ID 3236 onward. Now uses `WORLD_BLOCKED_TLDS` only (the superset).
- Fixed potential stale-log persistence across SW restarts: `logging: false` and `logs: []` are now written atomically in a single `chrome.storage.local.set()` call instead of two separate calls with a 3-second delay between them. A SW eviction between the two writes could previously leave stale logs in storage.

**Architecture**
- Added `GET_ACTIVE_TAB_INFO` and `RELOAD_ACTIVE_TAB` message handlers to background.js so popup.js and logger.js never call `chrome.tabs.query` directly.

---

## 1.6.1 — 2025
**Features**
- Logger now filters to only show traffic from the 1P domain that was active when SHOW LOGS was clicked. Previously all tabs' traffic was captured indiscriminately.
- Logger header now shows the logged domain name (passed as a URL parameter from the popup, avoiding storage/timing races).
- Removed the "Show blocked domains panel" checkbox (leftover from v2.0 blocked-panel experiment).

**Known limitation**
- `tabs` permission was missing from manifest, breaking the store version entirely (see 1.6.2).

---

## 1.6.0 — 2025
**Features**
- Level 3 (Easy medium mode) now allows both 3P scripts **and** 3P frames from whitelisted TLDs, not just scripts. Bullet text updated to reflect this.
- Removed the explanatory "(covers 95% of traffic...)" info line from the L3 Active Policy panel.

---

## 1.5.0 — 2025
**Features**
- Logger: added **Allow** column at levels 4 and 5. Blocked 3P-script rows get an Allow button that whitelists the script's own domain (extracted from the request URL, not the 1P calling domain) and immediately reloads the source tab.
- Logger: Allow column appears between the Action and Reason columns.
- Logger: domain header pill shows which 1P domain is being logged.

**Bug fixes**
- Allow button previously added the 1P calling domain instead of the 3P script domain. Fixed by extracting hostname from `e.url` rather than using `e.domain`.

---

## 1.4.0 — 2025
**Features**
- Request logger with 5-minute session countdown.
- Logger captures all allowed and blocked third-party traffic matching the extension's rules via `onRuleMatchedDebug`.
- Visibility-only catch-all allow rule (ID 3500) added so XHR/image/font/etc traffic is visible in the logger even though it is never blocked.
- SHOW LOGS button with active/pulsing state.

**Architecture**
- `declarativeNetRequestFeedback` permission added to support `onRuleMatchedDebug`.
- `LOG_TIMEOUT_MS` = 5 minutes, `MAX_LOGS` = 500 (FIFO eviction).
- SW restart recovery: reconstructs remaining log timeout from stored `logStartTime`.

---

## 1.3.x and earlier
- Core DNR rule engine with 5 levels.
- TLD whitelist (L3), domain whitelist (L4/L5), CDN allow (L4), built-in payment/video/CAPTCHA whitelist (L2–L4).
- Per-site lock rules with FIFO cap of 100 entries.
- Toolbar badge showing per-tab blocked request count via `displayActionCountAsBadgeText`.
- Auto TLD detection from browser language settings (BROWSER / CONTINENT / WORLDWIDE modes).
- TLD blacklist for L2 (NONE / USER / GENERIC / WORLD modes).
